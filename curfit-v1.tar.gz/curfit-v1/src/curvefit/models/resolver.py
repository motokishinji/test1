"""3 経路のモデル指定を単一の解決済み表現に一本化する（要件 3.1〜3.5、4.1〜4.6、5.4）。

本モジュールが所有するのは次の 5 点である。

1. **経路の吸収** — 組込モデル名・数式文字列・利用者定義 Python 関数の 3 経路を
   :class:`PreparedModel` に、モデル式を前提としない手法を :class:`PreparedSmoother` に
   収束させる。以降の層はモデル指定の由来を知らずに済む
2. **初期値の優先順位** — **明示指定 > 組込モデルの自動推定** の順序（要件 4.2）は
   ここでのみ実装される。他の層がこの順序を再実装してはならない
3. **束縛の反映** — 上下限（要件 4.4）と固定指定（要件 4.5）を解決済み表現に織り込む
4. **識別子の確定** — 推定対象パラメータの名前を、結果出力の識別子として確定する
   （要件 3.5）
5. **補った既定値の中継** — 組込モデルの選択肢はモデル実体の組み立てに要るため、
   既定値はここで消費される。何を補ったかを :attr:`PreparedModel.applied_defaults` に
   載せて当てはめ層へ渡す（要件 5.4）。値そのものは登録簿が所有し、ここでは決めない

検出した違反は最初の 1 件で打ち切らず、全件を :class:`~curvefit.errors.ConfigViolation`
のタプルとして返す（要件 3.4）。利用者由来の指定に起因する失敗を例外として送出しない
のは、実行前ゲートが違反を一括収集して修正の往復を減らすためである。

``sample`` は組込モデルの初期値自動推定に用いる代表データである。``None`` の場合は
自動推定を行わない。実行前ゲートはこの形で呼び出し、データに依存しない違反だけを
検出する（設計の Implementation Notes）。当てはめ本体はジョブごとに、そのジョブの
入力データを ``sample`` として解決を呼び直す。設定解決時に 1 回だけ推定して使い回すと、
ファイルごとにスケールの異なるデータで収束が悪化する。

lmfit はモデル実体とパラメータ束を組み立てるためだけに使う。公開シグネチャの注釈に
lmfit の型を一切現さない（設計の Allowed Dependencies）。組み立てた実体は
:class:`object` として保持し、実際に読むのは :mod:`curvefit.engines.least_squares` に
限る。
"""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from types import MappingProxyType
from typing import Literal, TypeAlias

from lmfit import Model

from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.expression import INDEPENDENT_VARIABLE, build_expression_model
from curvefit.models.registry import (
    MAX_POLYNOMIAL_DEGREE,
    MIN_POLYNOMIAL_DEGREE,
    POLYNOMIAL_DEGREE_OPTION,
    BuiltinModelSpec,
    resolve_builtin,
)
from curvefit.types import DataSeries, FloatArray

MethodKind: TypeAlias = Literal["builtin", "expression", "callable", "smoother"]
"""モデル指定の経路。要件 3.1〜3.3 の 3 経路と、要件 5.1 の平滑化手法。"""

Bound: TypeAlias = tuple[float | None, float | None]
"""パラメータの下限と上限。``None`` はその側を指定しないことを表す。"""


class SmootherKind(StrEnum):
    """モデル式を前提としない当てはめ手法（要件 5.1）。

    本来この列挙は当てはめ契約とともに語られるものだが、:class:`MethodSpec` が
    参照するため解決層に置く。依存方向は ``models → engines`` ではなく
    ``engines → models`` であり、逆向きの import は設計の依存方向制約に反する。
    """

    LINEAR = "linear"
    POLYNOMIAL = "polynomial"
    SPLINE = "spline"
    MOVING_AVERAGE = "moving_average"


def _frozen(mapping: Mapping[str, object] | None) -> Mapping[str, object]:
    """呼び出し側の辞書から切り離した、書き換え不能な写像を返す。"""
    return MappingProxyType(dict(mapping or {}))


PARAMETER_FIELDS: tuple[str, ...] = ("initial", "bounds", "fixed")
"""パラメータ名で引く :class:`MethodSpec` の場。**この並びが報告の順序でもある**（要件 8.2）。

`options` を含めない。あちらは選択肢名で引くものであり、対象がパラメータではない。

**所有をここ 1 か所に寄せる。** 同じ並びを実行前ゲートと解決層に別々に書くと、場が
増えたときに片方だけが更新されうる。実際にそれは起きた。平滑化手法に対する
`initial` / `bounds` / `fixed` の指定が解決層では未知パラメータとして検査される一方、
実行前ゲートには対応する検査が無く、指定が黙って捨てられていた（タスク 9.1）。
場が増えても取り残されないことは
``tests/unit/test_models_resolver.py`` が `dataclasses.fields` から導いて固定する。
"""


@dataclass(frozen=True)
class MethodSpec:
    """利用者が記述した当てはめ手法 1 件の指定。解決前の表現である。

    生成後に変更されず、渡された写像は複製したうえで凍結する。設定ファイルから
    構築した指定が実行の途中で書き換わると、要件 8 の再現性が成立しない。
    """

    name: str
    """出力に現れる識別名。違反の報告箇所にも用いる。"""

    kind: MethodKind
    builtin: str | None = None
    """組込モデル名（要件 3.1）。``kind`` が ``"builtin"`` のとき必須。"""

    expression: str | None = None
    """数式文字列（要件 3.2）。``kind`` が ``"expression"`` のとき必須。"""

    function: Callable[..., FloatArray] | None = None
    """利用者定義のモデル関数（要件 3.3）。``kind`` が ``"callable"`` のとき必須。"""

    smoother: SmootherKind | None = None
    """平滑化手法（要件 5.1）。``kind`` が ``"smoother"`` のとき必須。"""

    initial: Mapping[str, float] = field(default_factory=dict)
    """明示指定された初期値（要件 4.2）。自動推定に優先する。

    以下の 3 つの場は、いずれもモデル関数フィットの経路（``"builtin"`` /
    ``"expression"`` / ``"callable"``）でのみ意味を持つ。平滑化手法は名前付き
    パラメータを持たないため、``kind`` が ``"smoother"`` のときの指定は解釈できない
    項目として実行前ゲートが報告する（要件 4.4、4.5、8.5）。
    """

    bounds: Mapping[str, Bound] = field(default_factory=dict)
    """パラメータごとの下限と上限（要件 4.4）。"""

    fixed: Mapping[str, float] = field(default_factory=dict)
    """固定するパラメータとその値（要件 4.5）。"""

    options: Mapping[str, float | int] = field(default_factory=dict)
    """手法固有の選択肢。多項式の次数や移動平均の窓長など（要件 5.4）。

    意味を持つのは ``kind`` が ``"builtin"`` または ``"smoother"`` のときに限る。
    数式文字列と利用者定義関数の経路への指定は解釈できない項目として報告する（要件 8.5）。
    """

    def __post_init__(self) -> None:
        for name in (*PARAMETER_FIELDS, "options"):
            object.__setattr__(self, name, _frozen(getattr(self, name)))


@dataclass(frozen=True)
class PreparedModel:
    """解決済みのモデル関数フィット。由来（3 経路のいずれか）は残らない。"""

    display_name: str
    """出力に現れる識別名。"""

    parameter_names: tuple[str, ...]
    """推定対象パラメータの名前。結果出力における識別子となる（要件 3.5）。

    他のパラメータから決まる派生量は含まない。含めると要件 2.4 の
    「点数が推定対象パラメータ数を下回るか」の判定が狂う。
    """

    applied_defaults: Mapping[str, float | int]
    """既定値で補った手法固有の選択肢（要件 5.4）。利用者が明示した値は含まない。

    値を決めるのは登録簿であり（:meth:`~curvefit.models.registry.BuiltinModelSpec.applied_defaults`）、
    本層はそれを当てはめ層へ運ぶだけである。運ぶ必要があるのは、組込モデルの選択肢が
    **モデル実体の組み立てに要る** ためである。次数が決まらなければパラメータ名すら
    定まらず、既定値は解決の時点で消費される。当てはめ層からは補われた事実を観測
    できない。平滑化手法はこれと違い、既定値が当てはめの時点で確定するため、解決済み
    表現は何も持たない（:class:`PreparedSmoother`）。
    """

    _model: object = field(repr=False)
    """モデル実体（lmfit の ``Model``）。当てはめエンジン以外は参照しない。"""

    _parameters: object = field(repr=False)
    """パラメータ束（lmfit の ``Parameters``）。初期値・上下限・変動可否が確定している。"""

    def __post_init__(self) -> None:
        object.__setattr__(self, "applied_defaults", _frozen(self.applied_defaults))


@dataclass(frozen=True)
class PreparedSmoother:
    """解決済みの回帰・スムージング手法（要件 5.1）。"""

    display_name: str
    kind: SmootherKind
    options: Mapping[str, float | int]
    """利用者が指定した選択肢。既定値の補完は行わない。

    既定値は当てはめエンジンが単独で所有し、当てはめの時点で適用して記録する
    （``engines.smoothing`` の ``_int_option``）。既定値の定義が解決層とエンジンの
    2 か所に分かれると、検証を通った設定が実行時に別の値で動く事故が起こるため、
    補われた選択肢を持つ場をここには設けない。
    """

    def __post_init__(self) -> None:
        object.__setattr__(self, "options", _frozen(self.options))


PreparedMethod: TypeAlias = PreparedModel | PreparedSmoother


def _location(spec: MethodSpec, field_name: str) -> str:
    """違反の報告箇所を、手法の識別名から決定的に導出する。"""
    return f"method[{spec.name}].{field_name}"


def _violation(
    kind: ViolationKind, spec: MethodSpec, field_name: str, message: str
) -> ConfigViolation:
    return ConfigViolation(kind=kind, location=_location(spec, field_name), message=message)


def _requires_explicit_initial(kind: MethodKind) -> bool:
    """初期値の明示が必須となる経路か（要件 4.3）。

    組込モデル以外は自動推定の手段を持たないため、初期値なしでは当てはめを
    開始できない。
    """
    return kind in ("expression", "callable")


def _accepts_options(kind: MethodKind) -> bool:
    """手法固有の選択肢に意味がある経路か（要件 5.4）。

    多項式の次数を取る組込モデルと、窓長などを取る平滑化手法に限られる。数式文字列と
    利用者定義関数はモデルの形が指定そのものに現れるため、選択肢の入る余地がない。
    """
    return kind in ("builtin", "smoother")


def _describe(spec: MethodSpec) -> str:
    """違反の報告に載せる、原因となった指定内容（要件 3.4）。"""
    if spec.kind == "builtin":
        return repr(spec.builtin)
    if spec.kind == "expression":
        return repr(spec.expression)
    if spec.kind == "callable":
        return repr(getattr(spec.function, "__name__", spec.function))
    return repr(spec.smoother)


# --- 経路ごとのモデル実体の組み立て ------------------------------------------------


@dataclass(frozen=True)
class _Built:
    """組み立てたモデル実体と、その組み立てで既定値に頼った選択肢。

    2 つを 1 つの値で返すのは、既定値を補ったのが組み立てそのものだからである。
    別々に求めると、実際に組み立てに使った選択肢と記録する選択肢が食い違いうる。
    """

    model: object
    applied_defaults: Mapping[str, float | int] = field(default_factory=dict)


def _validate_builtin_options(
    spec: MethodSpec, builtin: BuiltinModelSpec
) -> tuple[ConfigViolation, ...]:
    """手法固有の選択肢を、モデル実体を作る前に検証する。

    対応表の ``create()`` は未知の選択肢名に :class:`ValueError` を送出する。利用者由来の
    綴り誤りが例外になるとバッチ全体が落ちるため、ここで違反として捕まえる（要件 3.4）。
    値域の検証も同様で、負の次数は退化したモデルを黙って生成し、上限超過は基盤
    ライブラリの例外になる。
    """
    violations: list[ConfigViolation] = []
    for key in sorted(spec.options):
        if key not in builtin.default_options:
            accepted = ", ".join(sorted(builtin.default_options)) or "（なし）"
            violations.append(
                _violation(
                    ViolationKind.CONFIG_INVALID,
                    spec,
                    "options",
                    f"組込モデル {builtin.name!r} は選択肢 {key!r} を持たない。"
                    f"指定できる選択肢: {accepted}",
                )
            )
            continue
        if key == POLYNOMIAL_DEGREE_OPTION:
            violations.extend(_validate_degree(spec, spec.options[key]))
    return tuple(violations)


def _validate_degree(spec: MethodSpec, value: float | int) -> tuple[ConfigViolation, ...]:
    """多項式の次数が整数かつ許容範囲内であることを検証する。"""
    if isinstance(value, bool) or not isinstance(value, int):
        return (
            _violation(
                ViolationKind.CONFIG_INVALID,
                spec,
                "options",
                f"次数 {value!r} は整数でなければならない。",
            ),
        )
    if not MIN_POLYNOMIAL_DEGREE <= value <= MAX_POLYNOMIAL_DEGREE:
        return (
            _violation(
                ViolationKind.CONFIG_INVALID,
                spec,
                "options",
                f"次数 {value} は範囲外である。"
                f"{MIN_POLYNOMIAL_DEGREE} 以上 {MAX_POLYNOMIAL_DEGREE} 以下を指定する。",
            ),
        )
    return ()


def _unaccepted_option_violations(spec: MethodSpec) -> tuple[ConfigViolation, ...]:
    """選択肢を受け付けない経路に書かれた選択肢を違反として集める（要件 8.5）。

    数式文字列と利用者定義関数の経路では ``options`` に意味がない。黙って捨てると、
    設定ファイルの記述と実際の実行条件が食い違ったまま当てはめが成功し、要件 8 の
    再現性が成立しない。組込モデルと平滑化手法が未知の選択肢を拒否しているのと
    同じ方針である。

    選択肢が空であることは既定であり、「何も指定していない」を意味するため違反ではない。
    報告に載せる名前は、写像の走査順に左右されないよう名前順に並べる（要件 8.2）。
    """
    if _accepts_options(spec.kind) or not spec.options:
        return ()
    names = ", ".join(repr(name) for name in sorted(spec.options))
    return (
        _violation(
            ViolationKind.CONFIG_INVALID,
            spec,
            "options",
            f"{_describe(spec)} によるモデルは手法固有の選択肢を持たないため、"
            f"選択肢 {names} を解釈できない。該当の指定を削除する。",
        ),
    )


def _build_builtin(spec: MethodSpec) -> _Built | tuple[ConfigViolation, ...]:
    """組込モデル名からモデル実体を組み立てる（要件 3.1、5.4）。

    指定のない選択肢は登録簿の既定値で補われる。補った選択肢を併せて返すのは、
    それが実行条件として記録すべき「利用者が書いていないのに効いた値」だからである
    （要件 5.4）。値は登録簿から受け取るだけで、ここでは決めない。
    """
    if not spec.builtin:
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "builtin",
                "組込モデル名が指定されていない。",
            ),
        )
    builtin = resolve_builtin(spec.builtin, location=_location(spec, "builtin"))
    if isinstance(builtin, ConfigViolation):
        return (builtin,)

    violations = _validate_builtin_options(spec, builtin)
    if violations:
        return violations

    options = {key: int(value) for key, value in spec.options.items()}
    try:
        return _Built(builtin.create(options), builtin.applied_defaults(options))
    except Exception as error:  # noqa: BLE001 - 基盤ライブラリの例外を外に漏らさない
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "builtin",
                f"組込モデル {spec.builtin!r} の実体を組み立てられない"
                f"（{type(error).__name__}: {error}）。",
            ),
        )


def _build_expression(spec: MethodSpec) -> _Built | tuple[ConfigViolation, ...]:
    """数式文字列からモデル実体を組み立てる（要件 3.2）。"""
    if not spec.expression:
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "expression",
                "数式が指定されていない。",
            ),
        )
    built = build_expression_model(spec.expression, location=_location(spec, "expression"))
    if isinstance(built, ConfigViolation):
        return (built,)
    # 数式の経路は手法固有の選択肢を持たない（:func:`_accepts_options`）ため、補う
    # 既定値も存在しない。
    return _Built(built.create())


def _build_callable(spec: MethodSpec) -> _Built | tuple[ConfigViolation, ...]:
    """利用者定義の Python 関数からモデル実体を組み立てる（要件 3.3）。

    独立変数は数式経路と同じ ``x`` に固定する。経路によって独立変数の名前が変わると、
    以降の層が由来を意識せずに済むという本モジュールの前提が崩れる。
    """
    if spec.function is None:
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "function",
                "モデル関数が指定されていない。",
            ),
        )
    try:
        model = Model(spec.function, independent_vars=[INDEPENDENT_VARIABLE])
    except Exception as error:  # noqa: BLE001 - 基盤ライブラリの例外を外に漏らさない
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "function",
                f"関数 {_describe(spec)} をモデルとして解釈できない"
                f"（{type(error).__name__}: {error}）。"
                f"第 1 引数に独立変数 {INDEPENDENT_VARIABLE!r} を取る関数を指定する。",
            ),
        )
    if not model.param_names:
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "function",
                f"関数 {_describe(spec)} は推定対象のパラメータを 1 つも持たない。"
                f"独立変数 {INDEPENDENT_VARIABLE!r} 以外の引数を少なくとも 1 つ設ける。",
            ),
        )
    # 利用者定義関数の経路も手法固有の選択肢を持たない（:func:`_accepts_options`）。
    return _Built(model)


_BUILDERS: Mapping[str, Callable[[MethodSpec], _Built | tuple[ConfigViolation, ...]]] = (
    MappingProxyType(
        {
            "builtin": _build_builtin,
            "expression": _build_expression,
            "callable": _build_callable,
        }
    )
)


# --- 束縛の検証と反映 --------------------------------------------------------------


def _unknown_parameter_violations(
    spec: MethodSpec, parameter_names: tuple[str, ...]
) -> tuple[ConfigViolation, ...]:
    """モデルが持たないパラメータへの指定を違反として集める。

    黙って捨てると、綴り誤りの上下限や固定指定が効かないまま当てはめが成功し、
    設定ファイルの記述と実際の実行条件が食い違う。要件 8 の再現性の意図に反する。
    """
    violations: list[ConfigViolation] = []
    known = set(parameter_names)
    for field_name in PARAMETER_FIELDS:
        specified: Mapping[str, object] = getattr(spec, field_name)
        for name in sorted(set(specified) - known):
            violations.append(
                _violation(
                    ViolationKind.CONFIG_INVALID,
                    spec,
                    field_name,
                    f"パラメータ {name!r} は解決したモデルに存在しない。"
                    f"指定できる名前: {', '.join(parameter_names)}",
                )
            )
    return tuple(violations)


def _conflict_violations(
    spec: MethodSpec, parameter_names: tuple[str, ...]
) -> tuple[ConfigViolation, ...]:
    """初期値と固定値が同一パラメータに与えられた指定を違反として集める。

    片方を黙って採ると、どちらが効いたのかが実行条件の記録から追えなくなる。
    """
    return tuple(
        _violation(
            ViolationKind.CONFIG_INVALID,
            spec,
            "fixed",
            f"パラメータ {name!r} に初期値と固定値の両方が指定されている。"
            "固定するパラメータには初期値を与えない。",
        )
        for name in parameter_names
        if name in spec.initial and name in spec.fixed
    )


def _effective_bounds(spec: MethodSpec, name: str, intrinsic: Bound) -> tuple[float, float]:
    """指定された上下限と、モデルが元から持つ上下限を合成する。

    指定がない側はモデル固有の値を用いる。モデル固有の制約（正でなければならない幅など）
    を無視すると、範囲外の初期値が基盤ライブラリに黙って丸められ、要件 4.2 が求める
    「指定された初期値を使用する」が成立しなくなる。
    """
    lower, upper = spec.bounds.get(name, (None, None))
    intrinsic_lower, intrinsic_upper = intrinsic
    return (
        intrinsic_lower if lower is None else float(lower),
        intrinsic_upper if upper is None else float(upper),
    )


def _bound_violations(
    spec: MethodSpec, parameter_names: tuple[str, ...], intrinsic: Mapping[str, Bound]
) -> tuple[ConfigViolation, ...]:
    """上下限の整合（要件 4.4）と、初期値との矛盾（要件 4.6）を検証する。"""
    violations: list[ConfigViolation] = []
    for name in parameter_names:
        lower, upper = _effective_bounds(spec, name, intrinsic[name])
        if lower > upper:
            violations.append(
                _violation(
                    ViolationKind.CONFIG_INVALID,
                    spec,
                    "bounds",
                    f"パラメータ {name!r} の下限 {lower} が上限 {upper} を上回っている。",
                )
            )
            continue
        for field_name in ("fixed", "initial"):
            specified: Mapping[str, float] = getattr(spec, field_name)
            if name not in specified:
                continue
            value = float(specified[name])
            if lower <= value <= upper:
                continue
            violations.append(
                _violation(
                    ViolationKind.INITIAL_OUT_OF_BOUNDS,
                    spec,
                    field_name,
                    f"パラメータ {name!r} に指定された値 {value} は"
                    f"許容範囲 [{lower}, {upper}] の外にある。",
                )
            )
    return tuple(violations)


def _initial_required_violation(
    spec: MethodSpec, missing: tuple[str, ...]
) -> ConfigViolation:
    """初期値の指定が必須である旨の違反を組み立てる（要件 4.3）。"""
    detail = (
        f"初期値のないパラメータ: {', '.join(missing)}"
        if missing
        else "全パラメータに初期値を与える"
    )
    return _violation(
        ViolationKind.INITIAL_REQUIRED,
        spec,
        "initial",
        f"{_describe(spec)} によるモデルは初期値の自動推定を行えないため、"
        f"初期値の指定が必須である。{detail}。",
    )


# --- 解決 --------------------------------------------------------------------------


def _resolve_smoother(spec: MethodSpec) -> PreparedSmoother | tuple[ConfigViolation, ...]:
    """モデル式を前提としない手法を解決する（要件 5.1）。

    選択肢の値域検証と既定値の補完はここで行わない。既定値は当てはめエンジンが
    単独で所有し、制約の検証は実行前ゲートがその定数を参照して行う。

    ``initial`` / ``bounds`` / ``fixed`` の拒否（要件 4.4、4.5、8.5）も同じ理由で
    実行前ゲートが担う。平滑化手法についての制約はそこに集めてあり、ここで一部だけを
    返すと同じ手法の他の違反が同時に報告されなくなる
    （:func:`curvefit.preflight._smoother_parameter_violations`）。
    """
    if spec.smoother is None:
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "smoother",
                "平滑化手法が指定されていない。"
                f"選択できる手法: {', '.join(kind.value for kind in SmootherKind)}",
            ),
        )
    try:
        kind = SmootherKind(spec.smoother)
    except ValueError:
        return (
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                "smoother",
                f"平滑化手法 {spec.smoother!r} は存在しない。"
                f"選択できる手法: {', '.join(k.value for k in SmootherKind)}",
            ),
        )
    return PreparedSmoother(display_name=spec.name, kind=kind, options=spec.options)


def _resolve_model(
    spec: MethodSpec, sample: DataSeries | None
) -> PreparedModel | tuple[ConfigViolation, ...]:
    """モデル関数フィットの 3 経路を解決する。"""
    # 選択肢の検査はモデルの組み立てに依存しない。先に集めておくことで、モデルを
    # 解決できなかった場合でも同時に報告でき、修正の往復が減る（要件 3.4）。
    violations: list[ConfigViolation] = list(_unaccepted_option_violations(spec))

    built = _BUILDERS[spec.kind](spec)
    if isinstance(built, tuple):
        violations.extend(built)
        # モデルが組み立てられなければパラメータ名が確定しない。初期値必須の判定は
        # パラメータ名を必要としないため、ここでも報告して修正の往復を減らす。
        if _requires_explicit_initial(spec.kind) and not spec.initial and not spec.fixed:
            violations.append(_initial_required_violation(spec, ()))
        return tuple(violations)

    model = built.model
    # 派生量は make_params() の呼び出しで param_names に追加されるため、推定対象の
    # 確定は必ずその前に行う（要件 3.5）。
    parameter_names = tuple(model.param_names)

    try:
        parameters = model.make_params()
    except Exception as error:  # noqa: BLE001 - 基盤ライブラリの例外を外に漏らさない
        # 数式からは、式としては解釈できてもパラメータとして束縛できない名前
        # （`eval` など）が抽出されうる。素通しすると当てはめ層で未捕捉の例外になり、
        # バッチ全体が落ちる（要件 3.4）。
        violations.append(
            _violation(
                ViolationKind.MODEL_UNRESOLVED,
                spec,
                spec.kind,
                f"{_describe(spec)} から得たパラメータ名を束縛できない"
                f"（{type(error).__name__}: {error}）。パラメータ名を変更する。",
            )
        )
        return tuple(violations)

    if _requires_explicit_initial(spec.kind):
        missing = tuple(
            name
            for name in parameter_names
            if name not in spec.initial and name not in spec.fixed
        )
        if missing:
            violations.append(_initial_required_violation(spec, missing))

    violations.extend(_unknown_parameter_violations(spec, parameter_names))
    violations.extend(_conflict_violations(spec, parameter_names))

    intrinsic: Mapping[str, Bound] = {
        name: (parameters[name].min, parameters[name].max) for name in parameter_names
    }
    violations.extend(_bound_violations(spec, parameter_names, intrinsic))

    if violations:
        return tuple(violations)

    return _apply_bindings(
        spec, sample, model, parameters, parameter_names, built.applied_defaults
    )


def _apply_bindings(
    spec: MethodSpec,
    sample: DataSeries | None,
    model: object,
    parameters: object,
    parameter_names: tuple[str, ...],
    applied_defaults: Mapping[str, float | int],
) -> PreparedModel:
    """上下限・自動推定・明示初期値・固定を、この順に反映する。

    順序には意味がある。上下限を先に置くことで、自動推定した値が範囲外になった場合に
    範囲内へ収まる。明示初期値は自動推定の後に置くことで、必ず上書きする側になる
    （要件 4.2）。固定は最後に置き、値と変動可否を同時に確定させる（要件 4.5）。
    """
    for name in parameter_names:
        if name not in spec.bounds:
            continue
        lower, upper = spec.bounds[name]
        if lower is not None:
            parameters[name].set(min=float(lower))
        if upper is not None:
            parameters[name].set(max=float(upper))

    _apply_auto_initial(spec, sample, model, parameters, parameter_names)

    for name in parameter_names:
        if name in spec.initial:
            parameters[name].set(value=float(spec.initial[name]))
    for name in parameter_names:
        if name in spec.fixed:
            parameters[name].set(value=float(spec.fixed[name]), vary=False)

    return PreparedModel(
        display_name=spec.name,
        parameter_names=parameter_names,
        applied_defaults=applied_defaults,
        _model=model,
        _parameters=parameters,
    )


def _apply_auto_initial(
    spec: MethodSpec,
    sample: DataSeries | None,
    model: object,
    parameters: object,
    parameter_names: tuple[str, ...],
) -> None:
    """代表データから初期値を推定し、明示指定のないパラメータにのみ適用する（要件 4.1）。

    明示指定のあるパラメータを対象から外すことが、要件 4.2 の優先順位そのものである。

    推定が失敗しても違反にはしない。自動推定はデータに依存する処理であり、実行前
    ゲートが扱う「処理を開始せず報告する」種類の失敗ではない。基盤ライブラリの
    既定初期値のまま当てはめに進み、収束しなければ実行中の失敗として報告される。

    推定した値を用いたか否かは返さない。結果は :attr:`PreparedModel._parameters` の
    初期値そのものに現れ、非収束の報告にはその値が載る（要件 4.7、
    :func:`curvefit.engines.least_squares._initial_values`）。真偽値としての控えは
    実行条件の記録に載らないまま残っていたため、タスク 9.2 で除いた。
    """
    if sample is None or spec.kind != "builtin" or not spec.builtin:
        return
    builtin = resolve_builtin(spec.builtin, location=_location(spec, "builtin"))
    if isinstance(builtin, ConfigViolation) or not builtin.supports_auto_initial:
        return

    targets = [
        name
        for name in parameter_names
        if name not in spec.initial and name not in spec.fixed
    ]
    if not targets:
        return

    try:
        guessed = model.guess(sample.y, x=sample.x)
    except Exception:  # noqa: BLE001 - 推定不能はデータ由来であり違反ではない
        return

    for name in targets:
        parameter = guessed.get(name)
        if parameter is None or not math.isfinite(parameter.value):
            continue
        parameters[name].set(value=float(parameter.value))


def resolve(
    spec: MethodSpec, sample: DataSeries | None
) -> PreparedMethod | tuple[ConfigViolation, ...]:
    """当てはめ手法の指定を、以降の層が由来を意識せずに扱える表現に解決する。

    :param spec: 利用者が記述した手法の指定
    :param sample: 初期値の自動推定に用いる代表データ。``None`` の場合、組込モデル
        であっても自動推定は行わない（要件 4.1 の適用可否を呼び出し側が制御する）
    :return: 解決できた場合は :class:`PreparedModel` または :class:`PreparedSmoother`、
        できなかった場合は検出したすべての :class:`~curvefit.errors.ConfigViolation`。
        最初の 1 件で打ち切らない（要件 3.4）
    """
    if spec.kind == "smoother":
        return _resolve_smoother(spec)
    if spec.kind in _BUILDERS:
        return _resolve_model(spec, sample)
    return (
        _violation(
            ViolationKind.MODEL_UNRESOLVED,
            spec,
            "kind",
            f"モデル指定の経路 {spec.kind!r} は存在しない。"
            f"選択できる経路: {', '.join([*_BUILDERS, 'smoother'])}",
        ),
    )
