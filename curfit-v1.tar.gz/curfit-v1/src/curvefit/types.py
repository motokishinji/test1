"""全層が共有する凍結データ型。

本モジュールはロジックと副作用を持たず、:mod:`curvefit.errors` 以外の自パッケージ
モジュールに依存しない。lmfit / SciPy / matplotlib / pandas の型を一切露出させない。
この制約が、基盤ライブラリの差し替え可能性を型レベルで担保する手段になる。

不変条件の違反は :class:`ValueError` として送出する。これは想定内の失敗ではなく
呼び出し側の誤りであり、値として運ぶ当てはめの失敗（:class:`FitFailure`）とは
別の系統である。
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from typing import TypeAlias

import numpy as np
from numpy.typing import NDArray

from curvefit.errors import FailureReason

FloatArray: TypeAlias = NDArray[np.float64]


def _require_float_array(name: str, array: FloatArray) -> None:
    if array.ndim != 1:
        raise ValueError(f"{name} は一次元配列でなければならない（実際: {array.ndim} 次元）")
    if array.dtype != np.float64:
        raise ValueError(f"{name} は float64 でなければならない（実際: {array.dtype}）")


@dataclass(frozen=True)
class DataSeries:
    """当てはめ対象の 1 系列。入力 3 経路はいずれもこの表現に収束する。

    3 経路が同一の表現に収束することが、要件 1.2 の「同一手順・同一構造」を
    構造的に保証する手段である。
    """

    source_id: str
    """入力の識別子。ファイルパス、または呼び出し元が指定したラベル。"""

    x: FloatArray
    y: FloatArray
    weights: FloatArray | None = None
    """測定誤差 σ の逆数（1/σ）として与えられる重み。未指定なら ``None``（要件 1.3）。

    残差に掛かる乗数であり、大きいほど当該点の寄与が大きい。σ から 1/σ への変換は
    読み込み層だけが行う。当てはめエンジンはこの値をそのまま最小化に用いる。
    """

    def __post_init__(self) -> None:
        _require_float_array("x", self.x)
        _require_float_array("y", self.y)
        if len(self.x) != len(self.y):
            raise ValueError(f"x と y の長さが一致しない（{len(self.x)} と {len(self.y)}）")
        if self.weights is not None:
            _require_float_array("weights", self.weights)
            if len(self.weights) != len(self.x):
                raise ValueError(
                    f"weights の長さが x と一致しない（{len(self.weights)} と {len(self.x)}）"
                )

    def __len__(self) -> int:
        return len(self.x)


@dataclass(frozen=True)
class ParameterEstimate:
    """推定パラメータ 1 個の結果（要件 7.1）。"""

    name: str
    """モデルが定めるパラメータ名。結果出力における識別子となる（要件 3.5）。"""

    value: float
    stderr: float | None
    """標準誤差。ヤコビアンがフルランクでない場合は算出できないため ``None`` を許容する。"""

    fixed: bool
    """固定指定されたパラメータか（要件 4.5）。"""

    def __post_init__(self) -> None:
        if self.fixed and self.stderr is not None:
            raise ValueError(f"固定パラメータ {self.name!r} は標準誤差を持たない")


@dataclass(frozen=True)
class GoodnessOfFit:
    """適合度指標（要件 7.2）。手法によらず残差ベースで統一的に算出する。"""

    r_squared: float
    rmse: float
    n_points: int
    n_varied_params: int
    """変動させたパラメータ数。モデル比較の参照用に保持する。優劣の計算は行わない。"""

    def __post_init__(self) -> None:
        if self.n_points < 0:
            raise ValueError(f"点数は負にできない（実際: {self.n_points}）")
        if self.n_varied_params < 0:
            raise ValueError(f"変動パラメータ数は負にできない（実際: {self.n_varied_params}）")


@dataclass(frozen=True)
class OutlierPoint:
    """外れ値として除外した点 1 個の記録（要件 2.5）。

    x だけでは、利用者は「どんな点が外れ値とされたか」を判断するために元データを引き
    直すことになる。実測値を併せて持つことでその往復がなくなる。反復回数を持つのは、
    1 回目の判定で外れた点と 3 回目で外れた点が同じ確かさではないためである。
    """

    x: float
    """除外した点の独立変数。"""

    y: float
    """その点の**実測値**。暫定当てはめが返した値ではない。

    当てはめ値を記録すると、除外の理由となったずれそのものが記録から消える。
    """

    iteration: int
    """何回目の判定で除外したか。**1 起点**。

    0 起点にすると「1 回目の判定で除外した」を 0 と読ませることになる。
    """

    def __post_init__(self) -> None:
        if self.iteration < 1:
            raise ValueError(f"反復回数は 1 以上でなければならない（実際: {self.iteration}）")


@dataclass(frozen=True)
class PreprocessReport:
    """前処理で何がどれだけ除外されたかの記録（要件 2.2、2.3、2.5）。"""

    n_input: int
    n_dropped_invalid: int
    n_dropped_out_of_range: int
    n_dropped_outlier: int
    outlier_points: tuple[OutlierPoint, ...]
    """外れ値として除外した各点の記録（要件 2.5）。

    並びは**除去順**（反復順、反復内では入力の並び順）であり、x の昇順ではない。
    並べ替えると、どちらの点が先に外れたのかが読めなくなる。順序は入力だけで決まる
    ため、同一入力・同一設定の再実行は同一の並びになる（要件 8.2）。

    行として残すのは外れ値だけである。欠損・数値として解釈できない行・区間外の行は
    件数のみを記録する。これらは入力を見れば分かる一方、外れ値は**ツールが判定した**
    結果であり、どの点をそう判定したのかは入力からは分からない。
    """

    def __post_init__(self) -> None:
        counts = (
            self.n_input,
            self.n_dropped_invalid,
            self.n_dropped_out_of_range,
            self.n_dropped_outlier,
        )
        if any(c < 0 for c in counts):
            raise ValueError(f"件数は負にできない（実際: {counts}）")
        if len(self.outlier_points) != self.n_dropped_outlier:
            raise ValueError(
                f"外れ値の記録件数が一致しない"
                f"（{len(self.outlier_points)} と {self.n_dropped_outlier}）"
            )

    @property
    def n_used(self) -> int:
        """当てはめに実際に使われた点数。"""
        return (
            self.n_input
            - self.n_dropped_invalid
            - self.n_dropped_out_of_range
            - self.n_dropped_outlier
        )


@dataclass(frozen=True)
class CurveData:
    """各データ点の実測値・当てはめ値・残差（要件 7.5）。"""

    x: FloatArray
    y_observed: FloatArray
    y_fit: FloatArray
    residual: FloatArray

    def __post_init__(self) -> None:
        fields = {
            "x": self.x,
            "y_observed": self.y_observed,
            "y_fit": self.y_fit,
            "residual": self.residual,
        }
        for name, array in fields.items():
            _require_float_array(name, array)
        lengths = {name: len(a) for name, a in fields.items()}
        if len(set(lengths.values())) != 1:
            raise ValueError(f"曲線データの配列の長さが揃っていない: {lengths}")

    def __len__(self) -> int:
        return len(self.x)


@dataclass(frozen=True)
class FitSuccess:
    """1 処理単位の成功結果。"""

    source_id: str
    method_name: str
    parameters: tuple[ParameterEstimate, ...]
    """パラメータを持たない手法（移動平均など）では空。適合度は必ず算出される（要件 5.3）。"""

    goodness: GoodnessOfFit
    curve: CurveData | None
    """各データ点の実測値・当てはめ値・残差（要件 7.5）。**解放済みなら ``None``**（要件 10.4）。

    ``None`` は「当てはめが曲線を作らなかった」ことではなく「保持をやめた」ことを表す。
    曲線は当てはめの成功時に必ず作られ、出力の適用（グラフ画像・曲線 CSV）に使われる。
    その後まで抱え続けると、数百件のバッチで常駐メモリが件数に正確に比例して増える
    （1 件あたり 4 配列 × 8 バイト × 点数）。解放するかどうかを決めるのはバッチ制御
    （:func:`curvefit.pipeline.run` の ``retain_curve``）であり、本型は **解放された状態を
    表せること** だけを担う。

    **欄を消さずに ``None`` を許すのは、成功結果の形を経路で分けないためである。**
    単一系列の経路（:func:`curvefit.api.fit_series`）は曲線を保持したまま返す。曲線を持つ
    成功と持たない成功を別の型にすると、要件 5.3 の「手法によらず同一の形式」と同じ理由で
    利用者側の分岐が増え、``writers`` / ``plotting`` が 2 つの型を受ける形になる。

    点数は :attr:`goodness` の ``n_points`` に残る。解放後も件数の突き合わせはできる。
    """

    preprocess: PreprocessReport

    def __post_init__(self) -> None:
        if self.curve is None:
            return
        if self.goodness.n_points != len(self.curve):
            raise ValueError(
                f"適合度の点数が曲線長と一致しない"
                f"（{self.goodness.n_points} と {len(self.curve)}）"
            )

    def without_curve(self) -> FitSuccess:
        """曲線データを手放した同じ成功結果を返す（要件 10.4）。

        凍結データクラスであるため、その場での書き換えはできない。手放す操作を型の側に
        置くのは、**解放が「欄を落とす」ことであって推定値・適合度・成否には触れないこと**
        を 1 か所で保証するためである。呼び出し側が :func:`dataclasses.replace` を直に
        書くと、同じ操作が呼び出し地点ごとに散る。

        既に手放している場合も同じ内容の結果を返す（冪等）。

        :return: :attr:`curve` が ``None`` である新しい成功結果
        """
        if self.curve is None:
            return self
        return replace(self, curve=None)


@dataclass(frozen=True)
class FitFailure:
    """1 処理単位の失敗結果。

    例外ではなく値として運ぶ。既定ではバッチを止めずに集約されるため、握りつぶしが
    起きない形で表現する必要がある。
    """

    source_id: str
    method_name: str
    reason: FailureReason
    message: str
    preprocess: PreprocessReport | None = None
    """前処理に到達する前の失敗では ``None``。"""


FitOutcome: TypeAlias = FitSuccess | FitFailure
