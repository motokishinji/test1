"""入力 3 経路を単一の :class:`~curvefit.types.DataSeries` に正規化する（要件 1.1〜1.7）。

本モジュールが所有するのは次の 5 点である。

1. **3 経路の収束** — 区切り文字つきテキスト、pandas DataFrame、メモリ上の数値配列の
   いずれもが同一の :class:`~curvefit.types.DataSeries` に収束する。3 経路は入口が
   違うだけで、列の解決・数値化・重みの算出・有効性の判定はすべて :func:`_build_series`
   という 1 か所を通る。経路ごとに異なる後続処理を持たせてはならない。要件 1.2 の
   「同一手順・同一構造」は、この構造そのものが保証手段である
2. **区切り文字の決定** — 指定がない場合は拡張子から決める（設計の Postconditions）
3. **誤差から重みへの変換** — 誤差列は測定誤差 σ を保持する。重みは ``1/σ`` であり、
   この変換を行うのは本モジュールだけである（要件 1.3）。詳細は :func:`_weights_from_sigma`
4. **失敗の判定** — 列を解決できない場合（要件 1.4）、有効なデータ点が 1 件もない場合
   （要件 1.5）、見出し行の有無を判断できない場合（要件 1.7）を
   :class:`~curvefit.types.FitFailure` として値で返す
5. **見出し行の解釈** — 先頭行を見出しとして読むかどうかを決める（要件 1.6）。
   詳細は :func:`read_delimited`

**数値として解釈できない値は除去しない。** ``NaN`` として通し、除去と件数の記録は
:mod:`curvefit.preprocess` が単独で担う（要件 2.2）。読み込み層でも除去すると、
「何点落ちたか」の集計が 2 か所に分かれて突き合わせられなくなる。

**想定内の失敗は値として返す。** 例外は送出しない（設計の Error Strategy）。バッチは
既定で個別の失敗をスキップして継続するため、ここで例外を投げるとバッチ全体が落ちる
（要件 6.4）。例外になるのは次の 2 系統に限る。

- **呼び出し側の誤り** — 長さの揃わない配列や一次元でない配列。
  :class:`~curvefit.types.DataSeries` の不変条件違反であり、データ由来の失敗ではない
- **資源・環境の失敗** — 入力ファイルが存在しない、読み取れない（:class:`OSError`）。
  設計の Error Strategy が例外を制御フローに使うのは資源枯渇の捕捉のみと定めており、
  本モジュールは送出したまま返さない。入力の存在確認は実行前ゲートでも行わない。
  存在しないファイルの直接指定は、呼び出し側（``pipeline``）が要件 1.8 の
  ``INPUT_UNREADABLE`` として個別の失敗に変換し、既定ではスキップして継続する

pandas の型は外に出さない。返すのは :class:`~curvefit.types.DataSeries` と
:class:`~curvefit.types.FitFailure` だけであり、内部で用いる ``DataFrame`` / ``Series``
は境界を越えない（設計の Allowed Dependencies）。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from typing import TypeAlias, TypeGuard

import numpy as np
import pandas as pd
from numpy.typing import ArrayLike

from curvefit.errors import FailureReason
from curvefit.types import DataSeries, FitFailure, FloatArray

ColumnKey: TypeAlias = str | int
"""列の指定。文字列は列名、整数は 0 起点の位置を表す（要件 1.1）。"""

COMMA_DELIMITER = ","
TAB_DELIMITER = "\t"

TAB_SUFFIXES: frozenset[str] = frozenset({".tsv"})
"""タブ区切りとみなす拡張子。これ以外はカンマ区切りとする（設計の Postconditions）。"""

_REAL_DTYPE_KINDS = frozenset({"b", "i", "u", "f"})
"""実数として直接扱える dtype の種別。真偽・整数・符号なし整数・浮動小数点。"""

_TEXT_DTYPE_KINDS = frozenset({"O", "S", "U", "T"})
"""文字列を保持しうる dtype の種別。object・バイト列・Unicode・pandas の文字列型。

複素数（``c``）・日時（``M``）・時間差（``m``）は含めない。これらに文字列は入らず、
既存の扱い（:func:`_to_real_array`）を変える理由がない。
"""


@dataclass(frozen=True)
class ColumnSpec:
    """フィット対象として読み出す列の指定（要件 1.1、1.3）。

    各項目は列名（``str``）でも位置（``int``、0 起点）でも指定できる。整数は常に位置で
    あり、列ラベルとしては解釈しない。整数のラベルを持つ表で解釈が二通りになると、
    同じ指定が入力によって別の列を指すことになる。
    """

    x: ColumnKey
    y: ColumnKey
    weight: ColumnKey | None = None
    """測定誤差 σ を保持する列（要件 1.3）。``None`` なら重みなし。

    列が保持するのは σ であり、重み ``1/σ`` ではない。変換は本モジュールが行う。
    """


def resolve_delimiter(path: Path) -> str:
    """拡張子から区切り文字を決める（設計の Postconditions）。

    ``.tsv`` をタブ、それ以外をカンマとする。``.txt`` や未知の拡張子もカンマである。
    拡張子ごとに規則を増やさないのは、判定が増えるほど「どちらで読まれたか」を利用者が
    予測できなくなるためである。中身が拡張子と食い違う入力には ``delimiter`` を明示する。

    大文字小文字は区別しない。``DATA.TSV`` を別の規則で読む理由はない。
    """
    return TAB_DELIMITER if path.suffix.lower() in TAB_SUFFIXES else COMMA_DELIMITER


def _as_real(value: object) -> float:
    """単一の値を実数に直す。直せなければ ``NaN``。

    複素数のように :class:`float` へ落とせない値もここで ``NaN`` になる。数値として
    解釈できない値を ``NaN`` として通す規約（設計の Responsibilities）を、文字列以外の
    型にも同じ形で適用する。
    """
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return float("nan")


def _parse_text_values(values: pd.Series) -> pd.Series:
    """列に含まれる **文字列だけ** を、正しく丸めた実数に直す（設計の Postconditions）。

    ``pandas`` の既定の文字列解釈は速さを優先しており、正しく丸められていない。float64 を
    往復できる最短表記（``repr``）で書かれた値でさえ元のビット列に戻らず、実測
    （pandas 3.0.5、対数正規乱数 20000 点）では 40.7% が変化し最大 7096 ulp ずれる。
    Python 組込の :func:`float` は正しく丸められており、同じ入力の変化率は 0% である。
    :func:`_as_real` がその :func:`float` を包んでいるため、変換の規則を増やさずに済む。

    ``read_delimited`` が ``float_precision="round_trip"`` を指定していても、この関数が
    必要である。列に欠測として認識されない文字列（機器のエラーコードなど）が **1 つ**
    混ざると、その列は数値化されないまま文字列として届き、ここで改めて解釈される。既定の
    解釈のままだと、エラーコードとは無関係な正常値までまとめて劣化する（実測: 2000 点中
    1 セルが ``OVERFLOW`` のとき、他の 39.2% が変化し最大 7275 ulp）。要件 2.2 は
    数値として解釈できない行の混在を想定内としており、想定内の入力が周囲の正常なデータを
    壊してはならない。``N/A`` のように pandas が欠測と認識する綴りでは列が float64 の
    まま届くため、この劣化は「どの文字列が書かれていたか」で決まっていた。

    **文字列以外の要素には触れない。** 複素数と実数が混在する object 列を pandas が
    複素数列に揃える挙動（:func:`_to_real_array`）はそのまま残す。ここで要素ごとに実数へ
    落とすと、複素数でない値だけが生き残って有効な点として通ってしまう。

    実数の dtype を持つ列は文字列を含みえないため、そのまま返して再解釈しない。区切り
    文字つきファイルの正常な列はこの経路を通り、要素ごとの費用を一切払わない。
    """
    if values.dtype.kind not in _TEXT_DTYPE_KINDS:
        return values
    parsed = [_as_real(value) if isinstance(value, str) else value for value in values]
    return pd.Series(parsed, index=values.index, dtype=object)


def _to_real_array(values: pd.Series) -> FloatArray:
    """列を float64 の一次元配列にする。数値にできない値は ``NaN`` として通す。

    除去は行わない。要件 2.2 の除去件数を記録するのは前処理層であり、ここで落とすと
    件数が合わなくなる。

    文字列から実数への変換は往復厳密である（:func:`_parse_text_values`）。3 経路が
    ここに合流するため、ファイル・表形式・配列のいずれで文字列が届いても同じ精度になる
    （要件 1.2）。
    """
    numeric = pd.to_numeric(_parse_text_values(values), errors="coerce")
    if numeric.dtype.kind not in _REAL_DTYPE_KINDS:
        # 複素数など、pandas が数値と認めるが実数ではない列。要素ごとに落とす。
        numeric = numeric.map(_as_real)
    return np.ascontiguousarray(numeric.to_numpy(dtype=np.float64, na_value=np.nan))


def _as_column(name: str, values: ArrayLike) -> pd.Series:
    """メモリ上の配列を、表形式経路と同じ「1 列」の表現に直す。

    3 経路を同じ数値化（:func:`_to_real_array`）に通すための入口であり、配列経路だけが
    別の変換規則を持つことを構造的に防ぐ。

    一次元でない入力はここで拒む。:class:`~curvefit.types.DataSeries` の不変条件違反は
    データ由来の失敗ではなく呼び出し側の誤りであり、値ではなく例外で伝える
    （:mod:`curvefit.types` の規約）。
    """
    array = np.asarray(values)
    if array.ndim != 1:
        raise ValueError(f"{name} は一次元配列でなければならない（実際: {array.ndim} 次元）")
    return pd.Series(array)


def _weights_from_sigma(sigma: FloatArray) -> FloatArray:
    """測定誤差 σ を重み ``1/σ`` に変換する（要件 1.3）。

    当てはめが最小化するのは ``Σ (重み × 残差)²`` であり、重みが大きいほどその点の寄与が
    大きい。σ をそのまま渡すと誤差の大きい点ほど強く効く逆転が起きる。変換を行うのは
    本モジュールだけであり、当てはめエンジンは受け取った重みをそのまま用いる。両方が
    変換すれば二重に掛かり、どちらも行わなければ逆転する。

    ``σ <= 0`` と非有限の σ には逆数が存在しない。これらは重みを **定義できない** 点で
    あって、除去すべき点ではない。数値として解釈できなかったセルと同じく ``NaN`` として
    通し、除去と件数の記録は前処理層に委ねる（要件 2.2）。前処理層は重みが非有限な点を
    無効な点として除去するため、この扱いは「重みの欠けた点は当てはめに寄与できない」と
    いう既存の判定にそのまま乗る。σ が 0 の点だけからなる入力は、有効なデータ点が 1 件も
    ない入力として :attr:`~curvefit.errors.FailureReason.NO_VALID_DATA` になる（要件 1.5）。

    σ が極端に小さい場合、``1/σ`` は有限の範囲を越える。この場合も重みを定めたことには
    ならないため ``NaN`` とする。無限大の重みを通すと、その 1 点だけで残差の総和が
    無限大になり、当てはめが黙って壊れる。
    """
    weights = np.full(sigma.shape, np.nan, dtype=np.float64)
    usable = np.isfinite(sigma) & (sigma > 0.0)
    np.divide(1.0, sigma, out=weights, where=usable)
    weights[~np.isfinite(weights)] = np.nan
    return weights


def _column_not_found(
    source_id: str, method_name: str, missing: tuple[ColumnKey, ...], available: tuple[object, ...]
) -> FitFailure:
    """列を解決できなかった失敗を組み立てる（要件 1.4）。

    対象の入力名と解決できなかった列指定の双方を載せる。数百件のバッチでは、対象を
    特定できない失敗は実質的に無価値である（設計の Error Categories）。解決できなかった
    指定は 1 件目で打ち切らず全件挙げる。次の行動は列指定の見直しであり、1 件ずつ直す
    往復を強いる理由がない。存在する列を併記するのも同じ理由による。
    """
    return FitFailure(
        source_id=source_id,
        method_name=method_name,
        reason=FailureReason.COLUMN_NOT_FOUND,
        message=(
            f"指定された列を解決できない: {', '.join(repr(key) for key in missing)}。"
            f"入力が持つ列: {', '.join(repr(label) for label in available)}"
            f"（列数 {len(available)}、位置指定は 0 以上 {len(available)} 未満）。"
        ),
    )


def _header_ambiguous(
    source_id: str,
    method_name: str,
    first_row: tuple[object, ...],
    positions: tuple[int, ...],
) -> FitFailure:
    """見出し行の有無を決められない入力の失敗を組み立てる（要件 1.7）。

    次の行動は ``header`` の明示であり、どちらを指定すべきかは利用者しか知らない。
    判断の材料となる先頭行の値と、指定すべき両方の値を message に載せる。判定した位置を
    併記するのは、判定の対象が先頭行全体ではなく位置で指定された列だからである。これを
    書かないと、行の中に数値でない値が見えている入力で利用者が判定の根拠を追えない。
    値そのものは先頭行の並びとして既に示しているため、ここでは位置だけを挙げる。
    対象のファイル名を併記するのは、数百件のバッチで対象を特定できない失敗が実質的に
    無価値であるためである（steering ``tech.md``）。
    """
    checked = ", ".join(str(position) for position in positions)
    return FitFailure(
        source_id=source_id,
        method_name=method_name,
        reason=FailureReason.HEADER_AMBIGUOUS,
        message=(
            f"見出し行の有無を判断できない: {source_id} の先頭行"
            f"（{', '.join(repr(value) for value in first_row)}）は、"
            f"位置で指定された列（位置 {checked}、0 起点）の値がすべて数値として解釈でき、"
            "見出しにも測定点にも見える。"
            "位置による列指定でこのまま読むと先頭行が見出しとして消費され、"
            "最初の測定点が黙って失われる。header を明示すること"
            "（見出しを持たない入力なら header=False、持つ入力なら header=True）。"
        ),
    )


def _no_valid_data(source_id: str, method_name: str, n_rows: int, detail: str) -> FitFailure:
    """有効なデータ点が 1 件もない失敗を組み立てる（要件 1.5）。"""
    return FitFailure(
        source_id=source_id,
        method_name=method_name,
        reason=FailureReason.NO_VALID_DATA,
        message=(
            f"有効なデータ点が 1 件も存在しない（読み込んだ行数 {n_rows}）。{detail}"
            "x・y のいずれかが数値として解釈できない行、および重みを定義できない行は"
            "有効な点として数えない。"
        ),
    )


def _resolve_position(frame: pd.DataFrame, key: ColumnKey) -> int | None:
    """列指定を列の位置に解決する。解決できなければ ``None``。

    整数は 0 起点の位置とする。負の値は受け付けない。末尾からの参照を許すと、列数の
    違う入力に同じ指定を与えたときに別の列を指し、バッチが静かに別のデータを読む。

    同名の列が複数ある場合は最初の列を採る。解決結果が入力の並び順だけで決まるため、
    同一入力の再実行が同一結果になる（要件 8.2）。
    """
    if isinstance(key, bool):
        # bool は int の派生型だが、列の位置としては受け付けない。
        return None
    if isinstance(key, int):
        return key if 0 <= key < frame.shape[1] else None
    for position, label in enumerate(frame.columns):
        if label == key:
            return position
    return None


def _select_columns(
    frame: pd.DataFrame, columns: ColumnSpec, source_id: str, method_name: str
) -> tuple[pd.Series, pd.Series, pd.Series | None] | FitFailure:
    """指定された列を取り出す。解決できない指定があれば失敗を返す（要件 1.4）。"""
    requested: list[ColumnKey] = [columns.x, columns.y]
    if columns.weight is not None:
        requested.append(columns.weight)

    positions = [_resolve_position(frame, key) for key in requested]
    missing = tuple(
        key for key, position in zip(requested, positions, strict=True) if position is None
    )
    if missing:
        return _column_not_found(source_id, method_name, missing, tuple(frame.columns))

    selected = [frame.iloc[:, position] for position in positions if position is not None]
    x_values, y_values = selected[0], selected[1]
    sigma_values = selected[2] if len(selected) == 3 else None
    return x_values, y_values, sigma_values


def _build_series(
    source_id: str,
    x: FloatArray,
    y: FloatArray,
    sigma: FloatArray | None,
    *,
    method_name: str,
) -> DataSeries | FitFailure:
    """3 経路が最後に必ず通る合流点。ここだけが :class:`DataSeries` を構成する。

    誤差から重みへの変換と有効性の判定をこの 1 か所に集めることが、3 経路が同一の結果を
    返すこと（要件 1.2）の保証手段である。経路ごとに分ければ、いずれ片側だけが変わる。
    """
    weights = None if sigma is None else _weights_from_sigma(sigma)
    series = DataSeries(source_id=source_id, x=x, y=y, weights=weights)

    valid = np.isfinite(series.x) & np.isfinite(series.y)
    if series.weights is not None:
        valid &= np.isfinite(series.weights)
    if not bool(np.any(valid)):
        detail = "" if sigma is None else "誤差列から重みを算出している。"
        return _no_valid_data(source_id, method_name, len(series), detail)
    return series


def _is_positional(key: ColumnKey) -> TypeGuard[int]:
    """列指定が位置指定であるかを判定する。

    ``bool`` は ``int`` の派生型だが位置としては解決しない（:func:`_resolve_position`）。
    解決されない指定を「位置指定」と数えると、要件 1.7 の検査が実際には起こりえない
    経路に対して作動する。
    """
    return isinstance(key, int) and not isinstance(key, bool)


def _positional_keys(columns: ColumnSpec) -> tuple[int, ...]:
    """列指定に含まれる位置指定を、指定された順に返す（要件 1.7）。

    名前と位置が混在する指定も「位置による列指定」として扱う。位置指定が 1 つでもあれば、
    その列は先頭行を消費した表から読まれる。名前側がたまたま先頭行の値に一致すれば
    読み込みは成功し、最初の測定点は黙って失われる。全指定が位置の場合に限ると、この
    経路が検査から漏れる。誤検出の代償は ``header`` を 1 行書くことに過ぎず、見逃しの
    代償は解析結果が静かに誤ることであるという非対称性に従う。

    名前指定はここに含めない。名前は見出し行を読んで初めて意味を持つ指定であり、
    見出しとして解釈する前の先頭行の位置に対応づける方法がない。
    """
    keys: list[ColumnKey] = [columns.x, columns.y]
    if columns.weight is not None:
        keys.append(columns.weight)
    return tuple(key for key in keys if _is_positional(key))


def _first_row(path: Path, separator: str) -> tuple[object, ...] | None:
    """先頭行を見出しとして解釈せずに 1 行だけ読む。読めなければ ``None``。

    要件 1.7 の判定材料は先頭行そのものであり、見出しとして消費された後では観測できない。
    本読み込みと同じ解釈規則で読むために pandas を用いる。判定を自前の行分割で行うと、
    引用符や区切り文字の扱いが本読み込みと食い違い、判定と実際に読まれる列がずれる。

    1 行だけを要求するが、実測の費用は 1 ファイルあたり 1.1〜3.5 ミリ秒である
    （100 行で 1.1、10,000 行で 3.5。パーサが先頭の読み込み単位をまとめて処理するため、
    入力が大きいほどわずかに増える）。読み込みから当てはめまでの 1 ファイル分に対して
    19〜25%、500 ファイル換算で 0.5〜1.8 秒であり、数分以内という要件 10.2 の水準に
    対して問題にならない。この追加読みが走るのは ``header`` が未指定かつ位置による
    列指定の場合だけであり、``header`` を明示した入力は費用を払わない。

    内容を解釈できない入力（空ファイルなど）では判定材料が存在しない。これは見出しの
    曖昧さではなく要件 1.5 の系統であり、``None`` を返して本読み込みの判断に委ねる。
    資源・環境の失敗（:class:`OSError`）はここでも握り潰さない。
    """
    try:
        probe = pd.read_csv(path, sep=separator, header=None, nrows=1)
    except (MemoryError, OSError):
        raise
    except ValueError:
        return None
    if probe.empty:
        return None
    return tuple(probe.iloc[0].tolist())


def _is_real_value(value: object) -> bool:
    """単一の値が有限の実数として解釈できるかを判定する（要件 1.7）。

    真偽値は数値として数えない。``bool`` を列の位置として受け付けない規約
    （:func:`_resolve_position`）と同じ扱いであり、``TRUE`` / ``FALSE`` を並べた見出しを
    持つ入力が誤って失敗になるのを防ぐ。
    """
    return not isinstance(value, (bool, np.bool_)) and bool(np.isfinite(_as_real(value)))


def _specified_values_are_real(values: tuple[object, ...], positions: tuple[int, ...]) -> bool:
    """位置で指定された列における先頭行の値がすべて実数かを判定する（要件 1.7）。

    判定の対象は先頭行全体ではなく、**位置で指定された列だけ** である。行全体を見ると、
    試料名のラベル列・単位列・末尾カンマが生む空欄・先頭の時刻列といった、装置出力として
    最も普通の形が 1 つあるだけで検査が素通りする。その場合でも x・y は数値のまま読まれ、
    先頭の測定点は黙って失われる。要件 1.7 が消そうとしている誤りがそのまま残る。

    名前指定は判定に加えない（:func:`_positional_keys`）。名前を先頭行の位置に対応づける
    には見出しとしての解釈が要り、その解釈の当否こそがここで判定したい対象である。

    位置指定が 1 つでも先頭行の範囲外にある場合は判定しない。列を先頭行に対応づけられない
    以上、その列の先頭行の値は存在せず、見出しの有無を判断する材料がない。これは要件 1.4 の
    系統であり、本読み込みが :attr:`~curvefit.errors.FailureReason.COLUMN_NOT_FOUND` として
    報告する。先に見出しの曖昧さを返すと、利用者は ``header`` を明示してから改めて列指定の
    誤りを知ることになり、往復が 2 度になる。

    指定された列に 1 つでも空欄や ``nan`` があれば、数値ではない側に落ちる。x・y のいずれかが
    非有限な行は有効な測定点として数えられない（:func:`_build_series`）ため、その先頭行を
    見出しとして読んでも失われる測定点はない。重みを定義できない行も同じく除去される
    （要件 2.2）。守るべき点が存在しない以上、失敗にする理由がない。
    """
    if not positions:
        return False
    if any(not 0 <= position < len(values) for position in positions):
        return False
    return all(_is_real_value(values[position]) for position in positions)


def read_delimited(
    path: Path,
    columns: ColumnSpec,
    delimiter: str | None = None,
    header: bool | None = None,
    *,
    method_name: str,
) -> DataSeries | FitFailure:
    """区切り文字つきテキストファイルから系列を読み込む（要件 1.1、1.6、1.7）。

    ``header`` は 3 状態を取る（設計の readers Postconditions）。

    - ``None``（未指定）— 見出しありとして読む。ただし **位置による列指定** であり、かつ
      **位置で指定された列における** 先頭行の値がすべて数値として解釈できる場合は、読まずに
      :attr:`~curvefit.errors.FailureReason.HEADER_AMBIGUOUS` を返す（要件 1.7）。この
      組み合わせでそのまま読むと先頭の測定点が見出しとして消費され、失敗にも警告にも
      ならないまま最初の 1 点が失われる。静かな誤りを、直せる失敗に変えるための検査である。
      判定の範囲を指定された列に絞るのは、先頭行全体を見るとラベル列・単位列・末尾カンマの
      空欄・先頭の時刻列があるだけで検査が素通りし、装置出力として最も普通の形で先頭の
      測定点が黙って失われるためである（:func:`_specified_values_are_real`）
    - ``True`` — 見出しありとして読み、上記の検査を行わない（要件 1.6）。明示指定が推測に
      優先するという本プロジェクトの規約（明示初期値が ``guess()`` に優先し、CLI 引数が
      設定ファイルに優先するのと同じ）に従う。数値に見える見出しを持つ入力の逃げ道でもある
    - ``False`` — 先頭行をデータとして読む（要件 1.6）。この場合、列は位置でのみ指定できる

    数値の解釈には ``float_precision="round_trip"`` を指定する（**要件 1.9**、設計の
    readers Postconditions）。``pandas`` の既定の解釈器は速さを優先しており、**正しく丸められて
    いない**。float64 を往復できる最短表記（``repr``）で書かれた値でさえ元のビット列に
    戻らず、実測（pandas 3.0.5、各 20000 点）では一様乱数の 36%、対数正規乱数の 41% が
    変化し、最大 7370 ulp ずれる。他の道具が 17 桁で書き出した測定値は、この経路を通る
    だけで 3 割以上が静かに別の値になる。

    条件の悪い当てはめでは、この最終ビットの差が推定値の上位桁まで届く。x∈[1000, 1000.5]
    の 300 点に 3 次多項式を当てはめると、既定の解釈器を通した係数は元データを直接
    当てはめた係数と有効数字 3 桁目で食い違う。本プロジェクトが出力の同一性を判定する
    水準は有効数字 10 桁であり（``writers`` の Validation、要件 8.2）、これを大きく
    上回る。``round_trip`` を指定すれば変化率は 0% になる。

    判定はファイル内容だけに依存するため、同一入力の再実行は同一結果になる（要件 8.2）。
    内容依存であるがゆえに実行前ゲートでは検査できないため、処理単位ごとの失敗として返し、
    バッチの残りは継続する（要件 6.4）。

    :param path: 入力ファイルのパス。識別子（``source_id``）にもこの値を用いる
    :param columns: 読み出す列の指定。名前でも位置でもよい
    :param delimiter: 区切り文字。``None`` なら拡張子から決める（:func:`resolve_delimiter`）
    :param header: 見出し行の有無。``None`` は未指定（上記の検査を行う）
    :param method_name: 失敗の報告に載せる手法の識別名。:class:`FitFailure` が必須と
        するが、読み込み層は手法を知らないため呼び出し側から受け取る。値による分岐は
        行わない（:func:`~curvefit.preprocess.apply_preprocess` と同じ扱い）
    :return: 読み込めた場合は :class:`~curvefit.types.DataSeries`、見出し行の有無を
        判断できない場合は :attr:`~curvefit.errors.FailureReason.HEADER_AMBIGUOUS`、
        列を解決できない場合は :attr:`~curvefit.errors.FailureReason.COLUMN_NOT_FOUND`、
        有効なデータ点が 1 件もない場合は
        :attr:`~curvefit.errors.FailureReason.NO_VALID_DATA` を持つ
        :class:`~curvefit.types.FitFailure`
    :raises OSError: ファイルが存在しない、または読み取れない場合。資源・環境の失敗は
        データの失敗として飲み込まない（設計の Error Strategy）
    """
    source_id = str(path)
    separator = resolve_delimiter(path) if delimiter is None else delimiter

    positions = _positional_keys(columns)
    if header is None and positions:
        first_row = _first_row(path, separator)
        if first_row is not None and _specified_values_are_real(first_row, positions):
            return _header_ambiguous(source_id, method_name, first_row, positions)

    try:
        frame = pd.read_csv(
            path,
            sep=separator,
            header=None if header is False else 0,
            float_precision="round_trip",
        )
    except (MemoryError, OSError):
        # 資源・環境の失敗は要件 10.3 の系統であり、データの失敗として黙らせない。
        raise
    except ValueError as error:
        # 空ファイル・列数の食い違いなど、中身に由来する解釈不能。データ由来の失敗で
        # あり、例外にすると 1 件の壊れたファイルでバッチ全体が落ちる（要件 6.4）。
        return _no_valid_data(source_id, method_name, 0, f"内容を解釈できない（{error}）。")

    return read_frame(frame, columns, source_id=source_id, method_name=method_name)


def read_frame(
    frame: pd.DataFrame,
    columns: ColumnSpec,
    source_id: str,
    *,
    method_name: str,
) -> DataSeries | FitFailure:
    """表形式オブジェクトから系列を読み込む（要件 1.2）。

    ファイル経路もこの関数を経由する。読み込んだ表をどう解釈するかを 1 か所に置くことで、
    ファイルと表形式の結果が食い違いようがなくなる。

    :param frame: 入力の表
    :param columns: 読み出す列の指定。名前でも位置でもよい
    :param source_id: 入力の識別子。失敗の報告と出力の命名に用いる
    :param method_name: 失敗の報告に載せる手法の識別名
    :return: :func:`read_delimited` と同じ
    """
    selected = _select_columns(frame, columns, source_id, method_name)
    if isinstance(selected, FitFailure):
        return selected
    x_values, y_values, sigma_values = selected

    return _build_series(
        source_id,
        _to_real_array(x_values),
        _to_real_array(y_values),
        None if sigma_values is None else _to_real_array(sigma_values),
        method_name=method_name,
    )


def read_arrays(
    x: ArrayLike,
    y: ArrayLike,
    source_id: str,
    sigma: ArrayLike | None = None,
    *,
    method_name: str,
) -> DataSeries | FitFailure:
    """メモリ上の数値配列から系列を読み込む（要件 1.2）。

    第 3 系列は測定誤差 σ であり、重み ``1/σ`` ではない。ファイル経路の誤差列と同じ量を
    受け取ることで、3 経路のいずれで渡しても同一の重みになる（要件 1.2、1.3）。σ から
    重みへの変換を呼び出し側に委ねると、変換の場所が層をまたいで分かれ、要件 1.3 が
    避けようとしている二重変換と未変換の双方が起こりうる。

    :param x: 独立変数の値
    :param y: 観測値
    :param source_id: 入力の識別子。呼び出し元が付けるラベル
    :param sigma: 各点の測定誤差 σ。``None`` なら重みなし（要件 1.3）
    :param method_name: 失敗の報告に載せる手法の識別名
    :return: :func:`read_delimited` と同じ
    :raises ValueError: 配列が一次元でない場合、または長さが揃わない場合。
        :class:`~curvefit.types.DataSeries` の不変条件違反であり、データ由来の失敗では
        なく呼び出し側の誤りである
    """
    return _build_series(
        source_id,
        _to_real_array(_as_column("x", x)),
        _to_real_array(_as_column("y", y)),
        None if sigma is None else _to_real_array(_as_column("sigma", sigma)),
        method_name=method_name,
    )
