"""設定ファイルと実行時引数を統合し、唯一の実行条件表現を構築する（要件 8.1、8.5、9.4）。

本モジュールが所有するのは次の 3 点である。

1. **実行条件の権威的表現** — :class:`RunConfig` が、入力指定・手法一覧・前処理設定・
   出力設定・失敗ポリシーを 1 つの値にまとめる。記録も再実行もこの表現の上でのみ成立する
2. **優先順位** — 同一項目が設定ファイルと実行時引数の双方で指定された場合、**実行時引数を
   優先する**（要件 9.4）。この規則が実装される場所は本モジュールだけであり、さらに
   モジュール内でも :func:`_apply_overrides` の 1 か所に閉じている。組み立て側
   （``_build_*``）は統合済みの写像しか受け取らず、値の出所を知らない
3. **設定不備の報告** — 解釈できない項目・必須項目の欠落・未知のキーを
   :class:`~curvefit.errors.ConfigViolation` として返す。利用者が書いた内容に対して
   例外を送出しない（要件 8.5）

**未知のキーは黙って無視しない**（設計の Postconditions）。無視すると綴り誤りが黙って
効かなくなり、設定ファイルに書いたはずの条件が適用されないまま結果だけが出る。これは
要件 8 の再現性の意図に真っ向から反する。検査は最上位だけでなく **入れ子のすべての表**
に対して行う。

**最初の違反で打ち切らない**（設計の Error Handling）。設定の誤りは全件に等しく影響する
ため、1 件ずつ直しては再実行する往復を利用者に強いる理由がない。

**手法一覧の順序は記述順を保つ**（要件 8.2 の決定性）。上書き記録の並びも
:data:`OVERRIDABLE_KEYS` の順に固定し、実行時引数の与え方に依存させない。

型は既存モジュールのものを再利用する。:class:`~curvefit.readers.ColumnSpec`、
:class:`~curvefit.preprocess.PreprocessSpec`、:class:`~curvefit.models.resolver.MethodSpec`、
:class:`~curvefit.execution.OverrideRecord` を再定義すると、設定ファイルの表現と実行時の
表現が二重管理になり、片方だけが変わる事故が起こる。

依存方向は ``config`` までであり、``preflight`` 以降を import しない（設計の Allowed
Dependencies）。設定ファイルの読み込みには標準ライブラリの :mod:`tomllib` のみを用いる。

**値域の検証は行わない。** 窓長の偶奇、多項式次数の上限、``sigma > 0``、平滑化スプライン
における ``lam`` の必須性と ``lam > 0``、組込モデル名の実在、初期値と上下限の整合は
すべて実行前ゲート（``preflight``）が所有する。
本モジュールは「TOML の値を実行条件の型に写せるか」だけを見て、写せた値はそのまま届ける。
検証を 2 か所に分けると、片方だけが更新されたときに検証を通った設定が実行時に別の値で動く。

TOML の記法
-----------

::

    failure_policy = "skip"          # "skip"（既定）または "fail_fast"

    [input]
    paths = ["data/*.csv"]           # ファイル・ディレクトリ・ワイルドカード
    delimiter = ","                  # 省略時は拡張子から決める
    header = true                    # 省略 / true / false の 3 状態（要件 1.6）

    [input.columns]
    x = "time"                       # 列名（文字列）でも位置（整数、0 起点）でもよい
    y = "signal"
    weight = "sigma"                 # 測定誤差 σ の列。省略可（要件 1.3）

    [[methods]]
    name = "gauss"                   # 出力に現れる識別名
    builtin = "gaussian"             # builtin / expression / smoother のいずれか 1 つ
    initial = { amplitude = 2.0 }
    fixed = { center = 1.0 }
    bounds.amplitude = { min = 0.0, max = 10.0 }
    options = { degree = 3 }

    [preprocess]
    x_min = 0.0
    x_max = 10.0

    [preprocess.outlier]             # 表があれば外れ値除去を行う。無ければ行わない
    sigma = 3.0
    max_iterations = 3

    [output]
    directory = "out"
    write_summary = true
    write_plot = true                # 要件 7.4: 既定で出力する
    write_curve = false              # 要件 7.5: オプトイン

::

    [[methods]]
    name = "spl"
    smoother = "spline"              # linear / polynomial / spline / moving_average
    options = { lam = 0.01 }         # スプラインでは必須（要件 5.5）

手法の指定経路（要件 3.1〜3.3、5.1）は ``builtin`` / ``expression`` / ``smoother`` の
**いずれか 1 つ** を書くことで決まる。``kind`` のような別立ての宣言を持たないのは、
宣言と実体が食い違う設定を表現できないようにするためである。利用者定義関数（要件 3.3）は
ライブラリ経由の指定に限られ、設定ファイルからは指定できない。

上下限を素の配列ではなく ``{ min = ..., max = ... }`` の表で書くのは、TOML に空値の記法が
無く、片側だけの上下限を配列では表せないためである。

**パスは記述をそのまま保持する**。設定ファイルからの相対解決は行わない。実行時引数で
上書きされたパスは現在位置からの相対であり、同じキーが由来によって別の基準を持つと
利用者が結果を予測できなくなる。
"""

from __future__ import annotations

import math
import tomllib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path, PurePath
from typing import TypeAlias

from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.execution import OverrideRecord
from curvefit.models.resolver import Bound, MethodKind, MethodSpec, SmootherKind
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnKey, ColumnSpec

_Document: TypeAlias = dict[str, object]
"""設定ファイルを読み込んだままの写像。実行条件に写す前の中間表現。"""

TOP_LEVEL_KEYS: tuple[str, ...] = ("failure_policy", "input", "methods", "output", "preprocess")
"""最上位に書けるキー。これ以外は綴り誤りとみなす。"""

INPUT_KEYS: tuple[str, ...] = ("columns", "delimiter", "header", "paths")
COLUMNS_KEYS: tuple[str, ...] = ("weight", "x", "y")
METHOD_KEYS: tuple[str, ...] = (
    "bounds",
    "builtin",
    "expression",
    "fixed",
    "initial",
    "name",
    "options",
    "smoother",
)
BOUND_KEYS: tuple[str, ...] = ("max", "min")
PREPROCESS_KEYS: tuple[str, ...] = ("outlier", "x_max", "x_min")
OUTLIER_KEYS: tuple[str, ...] = ("max_iterations", "sigma")
OUTPUT_KEYS: tuple[str, ...] = ("directory", "write_curve", "write_plot", "write_summary")

METHOD_SELECTORS: Mapping[str, MethodKind] = {
    "builtin": "builtin",
    "expression": "expression",
    "smoother": "smoother",
}
"""手法の指定経路を決めるキーと、対応する :data:`~curvefit.models.resolver.MethodKind`。

ちょうど 1 つだけ書く。利用者定義関数（``"callable"``）は設定ファイルから指定できないため
ここに現れない。
"""

OVERRIDABLE_KEYS: tuple[str, ...] = (
    "failure_policy",
    "input.columns.weight",
    "input.columns.x",
    "input.columns.y",
    "input.delimiter",
    "input.header",
    "input.paths",
    "output.directory",
    "output.write_curve",
    "output.write_plot",
    "output.write_summary",
)
"""実行時引数で上書きできる項目（要件 9.4）。

手法一覧は含めない。1 件が複数のキーを持つ入れ子の並びであり、コマンドラインの 1 つの
指定として意味を持つ形にならない。手法を変えるのは設定ファイルの仕事である。

**並びは上書き記録の並びでもある。** 実行時引数の与えられた順ではなくこの順で走査する
ことで、同一の実行条件なら記録も同一になる（要件 8.2）。
"""


class FailurePolicy(StrEnum):
    """個別の失敗が出たときにバッチを続けるか止めるか。"""

    SKIP = "skip"
    """当該対象をスキップして継続する（要件 6.4 の既定）。"""

    FAIL_FAST = "fail_fast"
    """最初の失敗で残りを中止する（要件 6.5）。"""


@dataclass(frozen=True)
class InputSpec:
    """入力の指定（要件 1.1、1.3、1.6）。"""

    paths: tuple[str, ...]
    """入力の位置。ファイル・ディレクトリ・ワイルドカードのいずれでもよい（要件 6.1）。"""

    columns: ColumnSpec
    """読み出す列。名前でも位置でも指定できる。"""

    delimiter: str | None = None
    """区切り文字。``None`` なら拡張子から決める（``readers.resolve_delimiter``）。"""

    header: bool | None = None
    """見出し行の有無（要件 1.6）。

    3 状態を取る。``None`` は未指定であり、``False``（見出しなし）と同じではない。
    未指定のときだけ ``readers`` が曖昧さの検査を行い、位置指定で先頭の測定点が黙って
    失われる形を :attr:`~curvefit.errors.FailureReason.HEADER_AMBIGUOUS` として報告する
    （要件 1.7）。3 状態を 2 状態に潰すとこの検査が成立しない。
    """


@dataclass(frozen=True)
class OutputSpec:
    """出力物の指定（要件 7.3、7.4、7.5）。"""

    directory: Path
    write_summary: bool = True
    write_plot: bool = True
    """要件 7.4: グラフ画像は既定で保存する。"""

    write_curve: bool = False
    """要件 7.5: 曲線・残差 CSV はオプトイン。"""


@dataclass(frozen=True)
class RunConfig:
    """1 回の実行の条件（設計の This Spec Owns）。

    設定ファイルと実行時引数を統合した唯一の実行条件であり、記録と再実行はこの表現の
    上でのみ成立する。生成後に変更されない。実行の途中で条件が書き換わると、記録と
    実際の実行が食い違い、要件 8.2 の再現性が成立しない。
    """

    inputs: InputSpec
    methods: tuple[MethodSpec, ...]
    """適用する手法。**設定ファイルの記述順を保つ**（要件 8.2 の決定性）。"""

    preprocess: PreprocessSpec
    output: OutputSpec
    failure_policy: FailurePolicy = FailurePolicy.SKIP


def _violation(location: str, message: str) -> ConfigViolation:
    """設定不備の違反を 1 件作る（要件 8.5）。

    本モジュールが返す違反はすべて :attr:`~curvefit.errors.ViolationKind.CONFIG_INVALID`
    である。モデル解決や出力先の可否は本モジュールの担当ではない。
    """
    return ConfigViolation(kind=ViolationKind.CONFIG_INVALID, location=location, message=message)


def _join(prefix: str, key: str) -> str:
    """設定ファイル内の位置を表す表記を作る。"""
    return f"{prefix}.{key}" if prefix else key


def _type_name(value: object) -> str:
    """報告に載せる実際の型名。"""
    return type(value).__name__


def _reject_unknown(
    table: Mapping[str, object],
    allowed: Sequence[str],
    prefix: str,
    violations: list[ConfigViolation],
) -> None:
    """未知のキーを違反として積む（設計の Postconditions）。

    並びを固定するためキー名でソートする。指定できるキーの一覧を報告に載せるのは、
    利用者の次の行動が綴りの修正であるため。
    """
    for key in sorted(table):
        if key not in allowed:
            violations.append(
                _violation(
                    _join(prefix, key),
                    f"未知のキー。ここに指定できるのは {', '.join(allowed)} のみ",
                )
            )


def _require(
    table: Mapping[str, object],
    key: str,
    prefix: str,
    violations: list[ConfigViolation],
) -> object | None:
    """必須キーを取り出す。無ければ違反を積んで ``None`` を返す（要件 8.5）。"""
    if key not in table:
        violations.append(_violation(_join(prefix, key), "必須の項目が指定されていない"))
        return None
    return table[key]


def _as_table(
    value: object, location: str, violations: list[ConfigViolation]
) -> Mapping[str, object] | None:
    if isinstance(value, Mapping):
        return value
    violations.append(_violation(location, f"表として記述する（実際: {_type_name(value)}）"))
    return None


def _as_text(
    value: object, location: str, violations: list[ConfigViolation], *, allow_empty: bool = False
) -> str | None:
    if isinstance(value, str) and not isinstance(value, bool):
        if value or allow_empty:
            return value
        violations.append(_violation(location, "空の文字列は指定できない"))
        return None
    violations.append(_violation(location, f"文字列を指定する（実際: {_type_name(value)}）"))
    return None


def _as_path_text(value: object, location: str, violations: list[ConfigViolation]) -> str | None:
    """パスとして扱う文字列。実行時引数からは :class:`~pathlib.Path` も受け取る。"""
    if isinstance(value, PurePath):
        return str(value)
    return _as_text(value, location, violations)


def _as_flag(value: object, location: str, violations: list[ConfigViolation]) -> bool | None:
    if isinstance(value, bool):
        return value
    violations.append(_violation(location, f"true または false を指定する（実際: {_type_name(value)}）"))
    return None


def _as_number(value: object, location: str, violations: list[ConfigViolation]) -> float | None:
    """実数。整数も受け取る。真偽値と非有限な値は拒否する。

    非有限な値を通すと、区間指定や上下限が「常に成立しない条件」として黙って働く。
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        violations.append(_violation(location, f"数値を指定する（実際: {_type_name(value)}）"))
        return None
    number = float(value)
    if not math.isfinite(number):
        violations.append(_violation(location, f"有限の数値を指定する（実際: {value}）"))
        return None
    return number


def _as_integer(value: object, location: str, violations: list[ConfigViolation]) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        violations.append(_violation(location, f"整数を指定する（実際: {_type_name(value)}）"))
        return None
    return value


def _as_option_value(
    value: object, location: str, violations: list[ConfigViolation]
) -> float | int | None:
    """手法固有の選択肢の値。整数は整数のまま保つ（窓長・次数は整数で意味を持つ）。"""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        violations.append(_violation(location, f"数値を指定する（実際: {_type_name(value)}）"))
        return None
    if isinstance(value, float) and not math.isfinite(value):
        violations.append(_violation(location, f"有限の数値を指定する（実際: {value}）"))
        return None
    return value


def _as_column_key(
    value: object, location: str, violations: list[ConfigViolation]
) -> ColumnKey | None:
    """列の指定。文字列は列名、整数は 0 起点の位置（``readers.ColumnKey``）。"""
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        violations.append(
            _violation(location, f"列名（文字列）または位置（整数）を指定する（実際: {_type_name(value)}）")
        )
        return None
    if isinstance(value, str) and not value:
        violations.append(_violation(location, "空の列名は指定できない"))
        return None
    return value


def _number_table(
    value: object, location: str, violations: list[ConfigViolation]
) -> dict[str, float]:
    """パラメータ名 → 実数 の表。初期値と固定値に用いる。"""
    table = _as_table(value, location, violations)
    if table is None:
        return {}
    collected: dict[str, float] = {}
    for name in table:
        number = _as_number(table[name], _join(location, name), violations)
        if number is not None:
            collected[name] = number
    return collected


def _option_table(
    value: object, location: str, violations: list[ConfigViolation]
) -> dict[str, float | int]:
    """選択肢名 → 数値 の表（要件 5.4）。名前と値域の妥当性は実行前ゲートが判定する。"""
    table = _as_table(value, location, violations)
    if table is None:
        return {}
    collected: dict[str, float | int] = {}
    for name in table:
        number = _as_option_value(table[name], _join(location, name), violations)
        if number is not None:
            collected[name] = number
    return collected


def _bound(value: object, location: str, violations: list[ConfigViolation]) -> Bound | None:
    """``{ min = ..., max = ... }`` を下限・上限の組に写す（要件 4.4）。

    片側だけの指定を表せる必要があるが TOML に空値の記法が無いため、配列ではなく表で
    受け取り、書かれていない側を ``None`` とする。両側とも無い表は指定の意味を持たない
    ため違反とする。
    """
    table = _as_table(value, location, violations)
    if table is None:
        return None
    _reject_unknown(table, BOUND_KEYS, location, violations)
    if not any(key in table for key in BOUND_KEYS):
        violations.append(_violation(location, f"{' または '.join(BOUND_KEYS)} の少なくとも一方を指定する"))
        return None
    lower = (
        _as_number(table["min"], _join(location, "min"), violations) if "min" in table else None
    )
    upper = (
        _as_number(table["max"], _join(location, "max"), violations) if "max" in table else None
    )
    return (lower, upper)


def _bounds_table(
    value: object, location: str, violations: list[ConfigViolation]
) -> dict[str, Bound]:
    table = _as_table(value, location, violations)
    if table is None:
        return {}
    collected: dict[str, Bound] = {}
    for name in table:
        bound = _bound(table[name], _join(location, name), violations)
        if bound is not None:
            collected[name] = bound
    return collected


def _build_columns(
    value: object, location: str, violations: list[ConfigViolation]
) -> ColumnSpec | None:
    table = _as_table(value, location, violations)
    if table is None:
        return None
    _reject_unknown(table, COLUMNS_KEYS, location, violations)
    raw_x = _require(table, "x", location, violations)
    raw_y = _require(table, "y", location, violations)
    x = _as_column_key(raw_x, _join(location, "x"), violations) if raw_x is not None else None
    y = _as_column_key(raw_y, _join(location, "y"), violations) if raw_y is not None else None
    weight: ColumnKey | None = None
    if "weight" in table:
        weight = _as_column_key(table["weight"], _join(location, "weight"), violations)
    if x is None or y is None:
        return None
    return ColumnSpec(x=x, y=y, weight=weight)


def _build_paths(
    value: object, location: str, violations: list[ConfigViolation]
) -> tuple[str, ...] | None:
    if isinstance(value, str) or not isinstance(value, Sequence):
        violations.append(
            _violation(location, f"入力の並びとして指定する（実際: {_type_name(value)}）")
        )
        return None
    collected: list[str] = []
    for index, item in enumerate(value):
        text = _as_path_text(item, f"{location}[{index}]", violations)
        if text is not None:
            collected.append(text)
    if not collected:
        violations.append(_violation(location, "入力を少なくとも 1 件指定する"))
        return None
    return tuple(collected)


def _build_input(
    document: Mapping[str, object], violations: list[ConfigViolation]
) -> InputSpec | None:
    raw = _require(document, "input", "", violations)
    if raw is None:
        return None
    table = _as_table(raw, "input", violations)
    if table is None:
        return None
    _reject_unknown(table, INPUT_KEYS, "input", violations)

    raw_paths = _require(table, "paths", "input", violations)
    paths = _build_paths(raw_paths, "input.paths", violations) if raw_paths is not None else None

    raw_columns = _require(table, "columns", "input", violations)
    columns = (
        _build_columns(raw_columns, "input.columns", violations)
        if raw_columns is not None
        else None
    )

    delimiter: str | None = None
    if "delimiter" in table:
        delimiter = _as_text(table["delimiter"], "input.delimiter", violations)

    header: bool | None = None
    if "header" in table:
        header = _as_flag(table["header"], "input.header", violations)

    if paths is None or columns is None:
        return None
    return InputSpec(paths=paths, columns=columns, delimiter=delimiter, header=header)


def _build_method(
    value: object, index: int, violations: list[ConfigViolation]
) -> MethodSpec | None:
    location = f"methods[{index}]"
    table = _as_table(value, location, violations)
    if table is None:
        return None
    _reject_unknown(table, METHOD_KEYS, location, violations)

    raw_name = _require(table, "name", location, violations)
    name = _as_text(raw_name, _join(location, "name"), violations) if raw_name is not None else None

    selected = [key for key in METHOD_SELECTORS if key in table]
    if len(selected) != 1:
        violations.append(
            _violation(
                location,
                f"{', '.join(METHOD_SELECTORS)} のうちちょうど 1 つを指定する"
                f"（実際: {len(selected)} 件）。利用者定義関数はライブラリ経由でのみ指定できる",
            )
        )
        return None
    selector = selected[0]
    kind = METHOD_SELECTORS[selector]
    raw_selector = table[selector]
    selector_location = _join(location, selector)

    builtin: str | None = None
    expression: str | None = None
    smoother: SmootherKind | None = None
    if kind == "builtin":
        builtin = _as_text(raw_selector, selector_location, violations)
    elif kind == "expression":
        expression = _as_text(raw_selector, selector_location, violations)
    else:
        text = _as_text(raw_selector, selector_location, violations)
        if text is not None:
            try:
                smoother = SmootherKind(text)
            except ValueError:
                violations.append(
                    _violation(
                        selector_location,
                        "未知の手法。指定できるのは "
                        f"{', '.join(kind.value for kind in SmootherKind)} のみ",
                    )
                )

    initial = _number_table(table["initial"], _join(location, "initial"), violations) if "initial" in table else {}
    fixed = _number_table(table["fixed"], _join(location, "fixed"), violations) if "fixed" in table else {}
    bounds = _bounds_table(table["bounds"], _join(location, "bounds"), violations) if "bounds" in table else {}
    options = _option_table(table["options"], _join(location, "options"), violations) if "options" in table else {}

    if name is None or (builtin is None and expression is None and smoother is None):
        return None
    return MethodSpec(
        name=name,
        kind=kind,
        builtin=builtin,
        expression=expression,
        smoother=smoother,
        initial=initial,
        bounds=bounds,
        fixed=fixed,
        options=options,
    )


def _build_methods(
    document: Mapping[str, object], violations: list[ConfigViolation]
) -> tuple[MethodSpec, ...] | None:
    raw = _require(document, "methods", "", violations)
    if raw is None:
        return None
    if isinstance(raw, (str, Mapping)) or not isinstance(raw, Sequence):
        violations.append(
            _violation("methods", f"手法の並びとして指定する（実際: {_type_name(raw)}）")
        )
        return None
    if not raw:
        violations.append(_violation("methods", "手法を少なくとも 1 件指定する"))
        return None

    methods: list[MethodSpec] = []
    seen: dict[str, int] = {}
    for index, entry in enumerate(raw):
        method = _build_method(entry, index, violations)
        if method is None:
            continue
        if method.name in seen:
            violations.append(
                _violation(
                    f"methods[{index}].name",
                    f"手法名 {method.name!r} が methods[{seen[method.name]}] と重複している。"
                    "同名の手法があると結果を手法ごとに識別できない",
                )
            )
            continue
        seen[method.name] = index
        methods.append(method)
    if len(methods) != len(raw):
        return None
    return tuple(methods)


def _build_outlier(
    value: object, location: str, violations: list[ConfigViolation]
) -> OutlierSpec | None:
    """外れ値除去の設定（要件 2.3）。表があれば有効、無ければ除去しない。

    ``sigma`` と ``max_iterations`` の値域は実行前ゲートが判定する。ここでは型だけを見て、
    書かれた値をそのまま届ける。
    """
    table = _as_table(value, location, violations)
    if table is None:
        return None
    _reject_unknown(table, OUTLIER_KEYS, location, violations)
    defaults = OutlierSpec()
    sigma = defaults.sigma
    iterations = defaults.max_iterations
    complete = True
    if "sigma" in table:
        parsed = _as_number(table["sigma"], _join(location, "sigma"), violations)
        complete = complete and parsed is not None
        sigma = parsed if parsed is not None else sigma
    if "max_iterations" in table:
        parsed_iterations = _as_integer(
            table["max_iterations"], _join(location, "max_iterations"), violations
        )
        complete = complete and parsed_iterations is not None
        iterations = parsed_iterations if parsed_iterations is not None else iterations
    return OutlierSpec(sigma=sigma, max_iterations=iterations) if complete else None


def _build_preprocess(
    document: Mapping[str, object], violations: list[ConfigViolation]
) -> PreprocessSpec:
    """前処理の設定（要件 2.1、2.3）。表そのものを省略できる。"""
    if "preprocess" not in document:
        return PreprocessSpec()
    table = _as_table(document["preprocess"], "preprocess", violations)
    if table is None:
        return PreprocessSpec()
    _reject_unknown(table, PREPROCESS_KEYS, "preprocess", violations)
    x_min = _as_number(table["x_min"], "preprocess.x_min", violations) if "x_min" in table else None
    x_max = _as_number(table["x_max"], "preprocess.x_max", violations) if "x_max" in table else None
    outlier = (
        _build_outlier(table["outlier"], "preprocess.outlier", violations)
        if "outlier" in table
        else None
    )
    return PreprocessSpec(x_min=x_min, x_max=x_max, outlier=outlier)


def _build_output(
    document: Mapping[str, object], violations: list[ConfigViolation]
) -> OutputSpec | None:
    raw = _require(document, "output", "", violations)
    if raw is None:
        return None
    table = _as_table(raw, "output", violations)
    if table is None:
        return None
    _reject_unknown(table, OUTPUT_KEYS, "output", violations)

    raw_directory = _require(table, "directory", "output", violations)
    directory = (
        _as_path_text(raw_directory, "output.directory", violations)
        if raw_directory is not None
        else None
    )
    defaults = OutputSpec(directory=Path())
    flags: dict[str, bool] = {
        "write_summary": defaults.write_summary,
        "write_plot": defaults.write_plot,
        "write_curve": defaults.write_curve,
    }
    complete = True
    for key in flags:
        if key in table:
            flag = _as_flag(table[key], _join("output", key), violations)
            complete = complete and flag is not None
            flags[key] = flag if flag is not None else flags[key]
    if directory is None or not complete:
        return None
    return OutputSpec(directory=Path(directory), **flags)


def _build_failure_policy(
    document: Mapping[str, object], violations: list[ConfigViolation]
) -> FailurePolicy:
    """失敗ポリシー（要件 6.4、6.5）。省略時はスキップして継続する。"""
    if "failure_policy" not in document:
        return FailurePolicy.SKIP
    text = _as_text(document["failure_policy"], "failure_policy", violations)
    if text is None:
        return FailurePolicy.SKIP
    try:
        return FailurePolicy(text)
    except ValueError:
        violations.append(
            _violation(
                "failure_policy",
                f"未知の値。指定できるのは {', '.join(policy.value for policy in FailurePolicy)} のみ",
            )
        )
        return FailurePolicy.SKIP


def _read_document(path: Path, violations: list[ConfigViolation]) -> _Document | None:
    """設定ファイルを読み込む（要件 8.1）。

    :mod:`tomllib` はバイナリで開いた対象を要求する。文字コードの解釈は TOML 自身の
    規定（UTF-8）に従うため、読み手側で符号化を決めない。

    **読み込めないこと自体も違反として返す。** 構文誤りはもとより、設定ファイルが存在
    しない・ディレクトリである・読み取り権限が無い場合も、利用者が直せる設定の誤りで
    あって資源の枯渇ではない。例外で返すと、実行前の停止（終了コード 2）を導く経路が
    値と例外の 2 本に割れ、CLI と API の双方が同じ判断を二重に持つことになる。

    **UTF-8 以外の符号化も同じく違反として返す。** TOML は UTF-8 を規定するため、
    :mod:`tomllib` は復号に失敗すると :exc:`UnicodeDecodeError` を送出する。これは
    :exc:`~tomllib.TOMLDecodeError` の仲間でも :exc:`OSError` の仲間でもないので、
    別に受け止めなければ素通りしてしまう。本プロジェクトの設定ファイルには日本語の注釈が
    入るため、日本語環境の編集器が既定とする CP932 や「Unicode」（UTF-16）で保存された
    設定ファイルは現実に起こりうる。報告では **UTF-8 で保存し直す** ことまで示す。
    """
    try:
        with path.open("rb") as handle:
            return tomllib.load(handle)
    except tomllib.TOMLDecodeError as error:
        violations.append(_violation(str(path), f"設定ファイルを解釈できない: {error}"))
    except UnicodeDecodeError as error:
        violations.append(
            _violation(
                str(path),
                "設定ファイルの文字コードが UTF-8 ではない"
                f"（先頭から {error.start} バイト目を復号できない）。"
                "TOML は UTF-8 を規定する。編集器で UTF-8（BOM 無し）として保存し直す",
            )
        )
    except OSError as error:
        violations.append(_violation(str(path), f"設定ファイルを読み込めない: {error}"))
    return None


def _apply_overrides(
    document: _Document,
    overrides: Mapping[str, object],
    violations: list[ConfigViolation],
) -> tuple[OverrideRecord, ...]:
    """実行時引数を設定ファイルの内容に **上書きする**（要件 9.4）。

    本関数が、実行時引数が設定ファイルに優先するという規則が実装される唯一の場所である。
    以降の組み立ては統合後の写像だけを受け取り、値がどちらの由来かを知らない。優先順位の
    判断が複数箇所に散ると、項目ごとに順序が食い違っても誰も気付けなくなる。

    上書きした項目は :class:`~curvefit.execution.OverrideRecord` として **前後の値ごと**
    残す（要件 9.4）。走査は :data:`OVERRIDABLE_KEYS` の順に行うため、記録の並びは
    実行時引数の与え方に依存しない（要件 8.2）。

    ``config_value`` が ``None`` であることは **「設定ファイルに該当キーが無い」ことだけ**
    を意味する。TOML には空値の記法が無く、書かれたキーが ``None`` になることはないため、
    この解釈に曖昧さはない（:class:`~curvefit.execution.OverrideRecord` が本モジュールに
    委ねた判断）。

    上書きできない項目を指定された場合は違反とする。黙って捨てると、指定したはずの条件が
    効かないまま結果だけが出る。

    :param document: 設定ファイルを読み込んだ写像。本関数が直接書き換える
    :param overrides: 実行時引数。キーは設定ファイル内の位置を表す表記
    :param violations: 検出した違反の積み先
    :return: 上書きした項目の記録
    """
    records: list[OverrideRecord] = []
    for key in OVERRIDABLE_KEYS:
        if key not in overrides:
            continue
        *parents, leaf = key.split(".")
        table: _Document = document
        for depth, part in enumerate(parents):
            child = table.get(part)
            if child is None:
                child = {}
                table[part] = child
            elif not isinstance(child, dict):
                violations.append(
                    _violation(
                        ".".join(parents[: depth + 1]),
                        f"表として記述する（実際: {_type_name(child)}）。"
                        f"{key} の上書きを適用できない",
                    )
                )
                table = {}
                break
            table = child
        else:
            records.append(
                OverrideRecord(key=key, config_value=table.get(leaf), cli_value=overrides[key])
            )
            table[leaf] = overrides[key]
    for key in sorted(set(overrides) - set(OVERRIDABLE_KEYS)):
        violations.append(
            _violation(
                key,
                "実行時引数として指定できない項目。上書きできるのは "
                f"{', '.join(OVERRIDABLE_KEYS)} のみ",
            )
        )
    return tuple(records)


def load_config(
    path: Path, overrides: Mapping[str, object]
) -> tuple[RunConfig, tuple[OverrideRecord, ...]] | tuple[ConfigViolation, ...]:
    """設定ファイルと実行時引数から実行条件を組み立てる（要件 8.1、8.5、9.4）。

    成功した場合は実行条件と上書き記録の組を返す。設定に不備があった場合は、検出した
    **すべての** 違反を返す（設計の Error Handling）。返り値の判別は先頭要素の型で行う。

    ::

        result = load_config(path, {})
        if isinstance(result[0], RunConfig):
            config, records = result
        else:
            violations = result

    利用者が書いた内容に対して例外を送出しない。設定ファイルが読めない場合も含めて
    値として返す（:func:`_read_document`）。

    :param path: 設定ファイルの位置
    :param overrides: 実行時引数。設定ファイルより優先する（要件 9.4）。キーは
        ``output.directory`` のように設定ファイル内の位置を表す表記
    :return: ``(RunConfig, 上書き記録)`` または違反の並び
    """
    violations: list[ConfigViolation] = []
    document = _read_document(path, violations)
    if document is None:
        return tuple(violations)

    records = _apply_overrides(document, overrides, violations)

    _reject_unknown(document, TOP_LEVEL_KEYS, "", violations)
    inputs = _build_input(document, violations)
    methods = _build_methods(document, violations)
    preprocess = _build_preprocess(document, violations)
    output = _build_output(document, violations)
    failure_policy = _build_failure_policy(document, violations)

    if violations or inputs is None or methods is None or output is None:
        return tuple(violations)
    return (
        RunConfig(
            inputs=inputs,
            methods=methods,
            preprocess=preprocess,
            output=output,
            failure_policy=failure_policy,
        ),
        records,
    )
