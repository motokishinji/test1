"""当てはめ前のデータ整形を固定順序で適用し、除去件数を集計する（要件 2.1〜2.5）。

本モジュールが所有するのは次の 3 点である。

1. **適用順序** — **欠損・不正行の除去 → 区間限定 → 外れ値除去**。この順序は固定であり
   設定で変更できない。外れ値判定は区間内の残差に基づくため、区間限定より後でなければ
   意味が変わる
2. **除去件数の集計** — どの段階で何点が落ちたかを :class:`~curvefit.types.PreprocessReport`
   として記録する。件数の合計は、元の点数と残った点数の差に必ず一致する。外れ値として
   除外した点については、件数に加えて各点の x・実測値・何回目の判定で除外したかを
   :class:`~curvefit.types.OutlierPoint` として除去順に残す（要件 2.5）
3. **点数不足の判定** — 残った点数が呼び出し側の指定する下限を下回る場合、当てはめに
   進まず失敗を返す（要件 2.4）

必要点数（``min_points``）は当てはめ手法の推定パラメータ数から呼び出し側が決める。
本モジュールは手法の内容を知らない。``method_name`` は失敗の報告に載せる識別名として
受け取るだけであり、値による分岐は行わない。

外れ値除去（要件 2.3）は「暫定当てはめ → 残差評価 → 除去」の反復である。当てはめ手段は
``provisional_fit`` コールバックとして受け取る。本モジュールが :mod:`curvefit.engines` を
import しないことが、設計の依存方向を保つ手段であり、この構造がその目的である。

入出力を一切持たない純粋計算として保つ。ファイル・端末・ログに触れない。合成データに
よる検証（steering ``tech.md``）と要件 8.2 の再現性は、この分離に依存する。

想定内の失敗は :class:`~curvefit.types.FitFailure` として値で返す。例外は送出しない。
バッチは既定で個別の失敗をスキップして継続するため、ここで例外を投げるとバッチ全体が
落ちる（設計の Error Strategy）。
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from typing import TypeAlias

import numpy as np
from numpy.typing import NDArray

from curvefit.errors import FailureReason
from curvefit.types import (
    DataSeries,
    FitFailure,
    FloatArray,
    OutlierPoint,
    PreprocessReport,
)

_Mask: TypeAlias = NDArray[np.bool_]
"""各データ点を残すか否かを表す真偽値配列。長さは元の系列と等しい。"""


@dataclass(frozen=True)
class OutlierSpec:
    """外れ値除去の判定条件（要件 2.3）。

    閾値と反復上限を明示的に持ち、既定値を固定する。これを固定しないと同一設定・同一
    入力の再実行で結果が揺れ、要件 8.2 が成立しない。

    値そのものの妥当性（``sigma`` が正であること、``max_iterations`` が負でないこと）は
    ここでは検証しない。データに依存しない設定の誤りは実行前ゲートが ``CONFIG_INVALID``
    として一括で報告する担当であり、前処理層で例外を送出するとバッチ全体が落ちる。
    ``x_min > x_max`` の逆転指定を検証しないのと同じ扱いである。
    """

    sigma: float = 3.0
    """残差の散らばりの何倍を外れ値とみなすか。

    散らばりは残差の二乗平均平方根、すなわち中心を 0 と置いた標準偏差で測る。当てはめの
    残差は 0 の周りに分布するため、中心は残差自身から推定せず 0 に固定する。

    中心を標本平均で置く形との差は 2 か所に現れる。第一に、同程度の大きさの外れ値が
    ``k`` 点ある場合、検出できる範囲が ``n > sigma**2 * k`` と ``n > (sigma**2 + 1) * k``
    に分かれる（``k`` 点幅の差。既定値では ``k=1`` で 10 点、``k=2`` で 19〜20 点が
    食い違う）。第二に、暫定当てはめが全点で一律にずれている場合、標本平均を引く形は
    そのずれを相殺するため、本形式が見逃す突出点を除去する。

    判定は残差の比だけで決まる（``|r_i| / RMS(r)`` は ``sqrt(n)`` を越えない）ため、
    既定値 ``sigma=3.0`` には次の盲点がある。いずれも「外れ値除去を有効にしたのに
    1 点も除去されない」という形で現れ、警告も報告も出ない。

    - **点数が 9 以下（一般に ``n <= sigma**2``）の系列では、単一の外れ値をどれほど
      大きくしても除去しない。** 外れ値自身が判定尺度を同じだけ押し上げるためである
    - **同程度の大きさの外れ値が ``k >= n / sigma**2`` 点あると、その ``k`` 点を除去
      しない。** 既定値では 12 点中の 2 点、20 点中の 3 点が該当する
    - **暫定当てはめが全点で一律にずれている場合、そのずれに対して十分大きくない
      外れ値は除去しない。** 一律のずれ ``c`` に対し、残差 ``u`` の点が除去されるのは
      ``u > c * sigma * sqrt((n-1)/(n - sigma**2))`` のときに限る（既定値・12 点では
      ``c`` の約 5.7 倍）。一律のずれが尺度を押し上げるためである。

    点数の少ない系列や外れ値を複数含む系列で除去を効かせるには、``sigma`` を既定値より
    小さく指定する必要がある。
    """

    max_iterations: int = 3
    """「暫定フィット → 残差評価 → 除去」を繰り返す上限回数。"""


@dataclass(frozen=True)
class PreprocessSpec:
    """利用者が指定できる前処理の条件。

    欠損・不正行の除去はここに現れない。要件 2.2 は無条件の ``shall`` であり、設定で
    無効化できてはならないためである（設計の Invariants）。
    """

    x_min: float | None = None
    """フィット区間の下限。``None`` なら下限を設けない（要件 2.1）。"""

    x_max: float | None = None
    """フィット区間の上限。``None`` なら上限を設けない（要件 2.1）。"""

    outlier: OutlierSpec | None = None
    """外れ値除去の条件。``None`` なら外れ値除去を行わない（要件 2.3）。"""


def _valid_mask(series: DataSeries) -> _Mask:
    """数値として扱える点を選ぶ（要件 2.2）。

    有限でない値（``NaN`` および ``±inf``）を持つ点を除外する。読み込み層は数値として
    解釈できなかったセルを ``NaN`` に落とすため、「欠損値」と「数値として解釈できない
    行」はこの時点で同じ表現になっている。無限大は浮動小数点値ではあるが、残差も適合度
    指標も算出できないため同様に除外する。

    重みを持つ系列では重みも判定に含める。x と y だけを残すと ``DataSeries`` が要求する
    「3 配列の長さが揃う」不変条件を保てないうえ、重みの欠けた点は当てはめに寄与できない。
    """
    mask = np.isfinite(series.x) & np.isfinite(series.y)
    if series.weights is not None:
        mask &= np.isfinite(series.weights)
    return mask


def _in_range_mask(x: FloatArray, spec: PreprocessSpec) -> _Mask:
    """指定された区間内にある点を選ぶ（要件 2.1）。

    上下限はいずれも境界を含む。境界上の点を落とすと、実際に使われる区間が利用者の
    指定より狭くなる。

    上下限の逆転など指定そのものの不備は検証しない。設定の妥当性検証は実行前ゲートの
    担当であり、ここで例外を送出するとバッチ全体が落ちる。逆転した指定では単に残る点が
    なくなり、点数不足の失敗として値で返る。
    """
    mask = np.ones(len(x), dtype=np.bool_)
    if spec.x_min is not None:
        mask &= x >= spec.x_min
    if spec.x_max is not None:
        mask &= x <= spec.x_max
    return mask


def _select(series: DataSeries, mask: _Mask) -> DataSeries:
    """真偽値配列で選んだ点だけを持つ系列を新たに構成する。

    真偽値による索引は常に新しい配列を返すため、呼び出し側の配列とは記憶領域を共有
    しない。入力を書き換えないことは、本モジュールが副作用を持たないという前提の一部
    である。
    """
    return DataSeries(
        source_id=series.source_id,
        x=series.x[mask],
        y=series.y[mask],
        weights=None if series.weights is None else series.weights[mask],
    )


def _provisional_residual(
    provisional_fit: Callable[[DataSeries], FloatArray], series: DataSeries
) -> FloatArray | None:
    """暫定当てはめを 1 回実行し、残差を返す。使える結果が得られなければ ``None``。

    設計の Risks に対応する。暫定当てはめが収束しない場合、外れ値除去は実行できない。
    その場合は失敗にせず ``None`` を返し、呼び出し側が除去をスキップして当てはめに進む。
    ここで失敗にすると、外れ値除去を有効にしただけで成功していたはずのジョブが落ちる。

    「使える結果が得られなかった」と判定するのは次の 4 つである。コールバックは
    当てはめエンジンを束ねた呼び出し側の関数であり、非収束の伝え方を 1 つに強制すると
    エンジン側の都合が前処理層に漏れる。

    1. 例外を送出した（資源枯渇を除く。後述）
    2. ``None`` を返した
    3. 入力と長さの異なる配列を返した
    4. 有限でない値を含む配列を返した（発散した当てはめ）

    1 の捕捉は広く、``provisional_fit`` の契約違反（属性名の誤り、系列に対して定義の
    ない演算、文字列など配列にできない値の返却）も非収束と区別できない。呼び出し側の
    実装上の誤りは、外れ値が 0 件除去されたという結果として現れる。前処理層に両者を
    見分ける手段はなく、見分けようとすると非収束の伝え方をエンジン側に強制することに
    なる。除去が常に 0 件であれば、コールバックの実装を疑う余地がある。

    ただし :class:`MemoryError` と :class:`OSError` は捕捉せず送出させる。設計の Error
    Strategy が例外を制御フローに使うのは資源枯渇の捕捉のみと定めており、これを非収束
    として飲み込むと、中断した対象を明示するという要件 10.3 の報告が成立しなくなる。
    """
    try:
        raw = provisional_fit(series)
        if raw is None:
            return None
        y_fit = np.asarray(raw, dtype=np.float64)
    except (MemoryError, OSError):
        raise
    except Exception:  # noqa: BLE001 - 非収束の伝え方をエンジン側に強制しない境界
        return None
    if y_fit.shape != (len(series),):
        return None
    residual = series.y - y_fit
    if not bool(np.all(np.isfinite(residual))):
        return None
    return residual


def _inlier_mask(residual: FloatArray, sigma: float) -> _Mask:
    """残差の散らばりを基準に、外れ値でない点を選ぶ（要件 2.3）。

    散らばりは残差の二乗平均平方根、すなわち中心を 0 と置いた標準偏差で測る。全点が
    同量ずれているだけの場合、尺度も同じだけ大きくなるため誰も閾値を越えない。

    標本平均を引く形（``|r - 平均| <= sigma * 標準偏差``）との差は小さい。全点が同量
    ずれた場合はその形でも散らばりが 0 となって判定が ``0 <= 0`` になり、やはり全点が
    残る。差は、同程度の外れ値が ``k`` 点ある場合の検出範囲（``n > sigma**2 * k`` と
    ``n > (sigma**2 + 1) * k``）と、一律のずれが乗った場合の扱いに現れる。詳細は
    :class:`OutlierSpec` の ``sigma`` を参照。

    判定は残差の比だけで決まり、``|r_i| / RMS(r)`` は ``sqrt(n)`` を越えない。この
    ため ``n <= sigma**2`` の系列では、どれほど大きな単一の外れ値も除去されない。
    この形の盲点は :class:`OutlierSpec` の ``sigma`` に一覧してある。

    残差が全点 0 の場合、尺度も 0 となり判定は ``0 <= 0`` となって全点が残る。除算を
    含まないため、この場合に場合分けを設ける必要はない。
    """
    scale = float(np.sqrt(np.mean(np.square(residual))))
    return np.abs(residual) <= sigma * scale


def _remove_outliers(
    series: DataSeries,
    outlier: OutlierSpec,
    provisional_fit: Callable[[DataSeries], FloatArray],
    floor: int,
) -> tuple[DataSeries, tuple[OutlierPoint, ...]]:
    """「暫定当てはめ → 残差評価 → 除去」を上限回数まで繰り返す（要件 2.3）。

    反復は次のいずれかで終わる。いずれも入力だけで決まり、乱数も時刻も参照しない。
    同一入力・同一設定の再実行が同一結果になること（要件 8.2）はこの性質に依る。

    - ``max_iterations`` 回に達した
    - 外れ値と判定される点がなくなった
    - 残る点数が ``floor`` を下回った（これ以上当てはめても報告する失敗は変わらない）
    - 暫定当てはめから使える結果が得られなかった（非収束）

    非収束で打ち切る場合、それまでの反復で確定した除外は保持する。各除外は収束した
    暫定当てはめの残差に基づく判定であり、後続の反復が失敗したことは先の判定を無効に
    しない。1 回目から非収束であれば除外は 0 件となり、設計の Risks が定める「除去を
    スキップして 0 件として当てはめに進む」がそのまま成立する。

    :return: 残った系列と、除外した各点の記録（x・実測値・何回目の反復で除外したか。
        要件 2.5）。記録は除外した順（反復順、反復内では入力の並び順）に並ぶ。並び順も
        入力だけで決まる
    """
    removed: list[OutlierPoint] = []
    kept = series
    # 反復番号は 1 起点。要件 2.5 の「何回目の判定で除外したか」をそのまま数える。
    for iteration in range(1, outlier.max_iterations + 1):
        if len(kept) < floor:
            break
        residual = _provisional_residual(provisional_fit, kept)
        if residual is None:
            break
        inlier = _inlier_mask(residual, outlier.sigma)
        if bool(np.all(inlier)):
            break
        # 実測値は除外前の系列から取る。当てはめ値ではなく入力の y であることが、
        # 利用者が元データを引き直さずに判定を確かめられる条件である（要件 2.5）。
        removed.extend(
            OutlierPoint(x=float(x_value), y=float(y_value), iteration=iteration)
            for x_value, y_value in zip(kept.x[~inlier], kept.y[~inlier], strict=True)
        )
        kept = _select(kept, inlier)
    return kept, tuple(removed)


def _insufficient_points(
    series: DataSeries, report: PreprocessReport, min_points: int, method_name: str
) -> FitFailure:
    """点数不足の失敗を組み立てる（要件 2.4）。

    どの対象のどの手法が、何点足りずに落ちたのかを示す。数百件のバッチでは、対象を
    特定できない失敗は実質的に無価値である（設計の Error Categories）。
    """
    return FitFailure(
        source_id=series.source_id,
        method_name=method_name,
        reason=FailureReason.INSUFFICIENT_POINTS,
        message=(
            f"前処理後に残ったデータ点数 {report.n_used} が、必要な点数 {min_points} を"
            f"下回る。入力 {report.n_input} 点のうち、"
            f"欠損・数値として解釈できない点を {report.n_dropped_invalid} 点、"
            f"区間外の点を {report.n_dropped_out_of_range} 点、"
            f"外れ値を {report.n_dropped_outlier} 点除外した。"
        ),
        preprocess=report,
    )


def apply_preprocess(
    series: DataSeries,
    spec: PreprocessSpec,
    min_points: int,
    provisional_fit: Callable[[DataSeries], FloatArray] | None = None,
    *,
    method_name: str,
) -> tuple[DataSeries, PreprocessReport] | FitFailure:
    """当てはめ前のデータ整形を固定順序で適用する。

    適用順序は **欠損・不正行の除去 → 区間限定 → 外れ値除去** に固定されており、設定で
    変更できない。順序は除去件数の内訳にも現れる。区間外かつ欠損している点は、欠損として
    数えられる。

    外れ値除去（要件 2.3）は ``spec.outlier`` と ``provisional_fit`` の双方が与えられた
    場合にのみ実行する。いずれかを欠く場合、および暫定当てはめが収束しない場合は、除去
    0 件として記録して当てはめに進む。要件 2.3 は「外れ値除去が有効な場合」を条件とする
    ``shall`` であり、判定手段を欠くことは失敗ではない。

    :param series: 当てはめ対象の系列。``x`` と ``y`` は同一長であること
    :param spec: 利用者が指定した前処理の条件
    :param min_points: 当てはめに必要な最小点数。当てはめ手法の推定パラメータ数から
        呼び出し側が決める。本モジュールは手法を知らない
    :param provisional_fit: 外れ値判定に用いる暫定当てはめ。系列を受け取り、各点の
        当てはめ値を返す。当てはめエンジンをコールバックとして受け取ることで、前処理層は
        ``engines`` に依存しない。``None`` なら外れ値除去を行わない。収束しなかった場合の
        伝え方は :func:`_provisional_residual` を参照（例外・``None``・長さ不一致・
        非有限値のいずれでもよい）
    :param method_name: 失敗の報告に載せる手法の識別名。値による分岐は行わない
    :return: 整形後の系列と除去件数の記録。残った点数が ``min_points`` を下回る場合は
        :class:`~curvefit.errors.FailureReason.INSUFFICIENT_POINTS` を持つ
        :class:`~curvefit.types.FitFailure`（要件 2.4）
    """
    n_input = len(series)

    # 1 段階目: 欠損・不正行の除去。要件 2.2 は無条件の shall であり、設定で無効化できない。
    valid = _valid_mask(series)
    kept = _select(series, valid)
    n_dropped_invalid = n_input - len(kept)

    # 2 段階目: 区間限定。欠損を除いた後に適用する。
    in_range = _in_range_mask(kept.x, spec)
    before_range = len(kept)
    kept = _select(kept, in_range)
    n_dropped_out_of_range = before_range - len(kept)

    # 3 段階目: 外れ値除去（要件 2.3）。区間限定より後に置くのは、外れ値判定が区間内の
    # 残差に基づくためである。判定条件と暫定当てはめの双方が揃って初めて実行できる。
    outlier_points: tuple[OutlierPoint, ...] = ()
    if spec.outlier is not None and provisional_fit is not None:
        # 反復の下限。当てはめに足りない点数の系列へ暫定当てはめを試みても、エンジン側の
        # 例外を非収束として飲み込むだけで、報告される失敗は同じ点数不足になる。試みない
        # 方が、失敗の原因が欠損・区間指定にあることが除去件数の内訳に残る。min_points が
        # 0 の場合も、点が 1 つもなければ判定する対象がないため 1 を下回らせない。
        kept, outlier_points = _remove_outliers(
            kept, spec.outlier, provisional_fit, floor=max(min_points, 1)
        )
    n_dropped_outlier = len(outlier_points)

    report = PreprocessReport(
        n_input=n_input,
        n_dropped_invalid=n_dropped_invalid,
        n_dropped_out_of_range=n_dropped_out_of_range,
        n_dropped_outlier=n_dropped_outlier,
        outlier_points=outlier_points,
    )

    if len(kept) < min_points:
        return _insufficient_points(kept, report, min_points, method_name)
    return kept, report
