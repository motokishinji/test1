"""実行ログのハンドラ構成と、記録する内容の形（要件 8.4、7.1）。

本モジュールが所有するのは次の 3 点である。

1. **ハンドラの構成と解放** — :func:`configure_run_log` が ``{output_dir}/run.log`` へ
   書くハンドラを ``curvefit`` ロガーに取り付け、:class:`RunLogHandle` として返す。
   取り付けたものは呼び出し側が閉じる
2. **1 対象 1 行の記録** — :func:`log_outcome` が、処理した対象・手法・成否・失敗理由を
   記録する（要件 8.4）。順序は与えられた順序、すなわちジョブ順序に従う
3. **標準誤差の警告** — 標準誤差を算出できなかったパラメータを警告として残す（要件 7.1）

**警告の所在がここになる理由。** 当てはめエンジンは入出力を持たない純粋計算であり
（設計の engines ブロック）、``engines.least_squares`` は算出できない標準誤差を
``stderr=None`` として返すだけである。要件 7.1 の「失敗とせず警告として記録する」を
果たせるのはログを持つ本層だけになる。

**import しただけでは何も起きない。** 大域のログ構成（``logging.basicConfig`` や根ロガーへの
ハンドラ追加）を import 時に行うと、本ライブラリを取り込んだ利用者のアプリケーションの
ログ出力を乗っ取る。要件 9.1 は他のスクリプト・対話環境からの利用を求めており、構成は
明示的な呼び出しに限る。取り付けたハンドラは :meth:`RunLogHandle.close` で外す。ファイル
記述子を開いたままにすると、数百件規模の連続実行（要件 10.1）で資源を食い潰す。

**``curvefit`` ロガーは伝播させない。** 実行ログは出力ディレクトリに残す成果物であり、
利用者のアプリケーションの標準出力に混ざるべきものではない。伝播の設定は
:func:`configure_run_log` が変更し、:meth:`RunLogHandle.close` が元に戻す。根ロガーには
一切触れない。

成否を表す文字列は ``writers`` のサマリ CSV と同じ語を使う。同一層のモジュール同士は
import できない（設計の Allowed Dependencies の依存方向）ため定数は各々が持つが、値は
一致させる。ログとサマリで別の語を使うと、突き合わせのたびに対応表が要る。
"""

from __future__ import annotations

import logging
import time
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from curvefit.types import FitOutcome, FitSuccess

LOGGER_NAME = "curvefit"
"""実行ログを流すロガー名。根ロガーではなく、本パッケージの名前空間に閉じる。"""

RUN_LOG_FILENAME = "run.log"
"""実行ログのファイル名（設計の Batch / Job Contract）。"""

LOG_FORMAT = "%(asctime)s %(levelname)s %(message)s"
"""ログ 1 行の形。水準を残すのは、警告（要件 7.1）と失敗（要件 8.4）を選り分けるため。"""

LOG_DATE_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
"""時刻の表記。実行条件の記録（``execution.json``）と同じ UTC の ISO 8601 に揃える。"""

SUCCESS_STATUS = "success"
"""成功を表す語。``writers`` のサマリ CSV の ``status`` 列と同じ値にする。"""

FAILURE_STATUS = "failure"
"""失敗を表す語。``writers`` のサマリ CSV の ``status`` 列と同じ値にする。"""

STDERR_UNAVAILABLE_STATUS = "stderr_unavailable"
"""標準誤差を算出できなかったことを表す語（要件 7.1）。"""

RUN_START_STATUS = "started"
"""実行開始行を表す語（設計の Monitoring）。"""

RUN_FINISHED_STATUS = "finished"
"""実行終了行を表す語（設計の Monitoring）。"""


class _RunLogHandler(logging.FileHandler):
    """本モジュールが取り付けたハンドラであることを型で示すためのハンドラ。

    :func:`configure_run_log` が二重に呼ばれたとき、前回取り付けたものだけを外して
    閉じるために使う。名前ではなく型で見分けるのは、``logging`` の大域なハンドラ表に
    名前を登録すると、そこからの参照でハンドラが解放されなくなるためである。

    構成前のロガーの状態を自身に持つ。二重に構成したとき、2 回目は 1 回目が控えた値を
    ここから引き継ぐ。2 回目が現在の（1 回目に書き換えられた後の）状態を控えると、
    解放したときに書き換え後の値が「元の状態」として居座り、利用者のロガーが恒久的に
    汚染される。
    """

    def __init__(
        self, path: Path, *, previous_level: int, previous_propagate: bool
    ) -> None:
        super().__init__(path, mode="w", encoding="utf-8")
        self.previous_level = previous_level
        self.previous_propagate = previous_propagate


@dataclass(frozen=True)
class RunLogHandle:
    """取り付けた実行ログのハンドラと、構成前のロガーの状態。

    利用者のアプリケーションから見れば、本ライブラリの呼び出しは一時的なものである。
    構成前の水準と伝播の設定を控えておき、:meth:`close` で元に戻す。

    ``with`` 文で使える。例外で抜ける経路でもファイルを閉じるためである。
    """

    logger: logging.Logger
    handler: logging.FileHandler
    path: Path
    previous_level: int
    previous_propagate: bool

    def close(self) -> None:
        """ハンドラを外して閉じ、ロガーの設定を構成前に戻す。

        二重に呼んでも誤りにしない。``with`` 文と明示的な解放が重なる経路があるため、
        解放は何度でも安全でなければならない。

        既に取り外されている取っ手は設定を戻さない。:func:`configure_run_log` を重ねて
        呼ぶと、古い取っ手のハンドラはその場で外されて閉じられる（構成は常に 1 つに保つ）。
        置き去りになった古い取っ手を後から閉じたとき設定まで戻すと、まだ使われている
        新しい構成の水準と伝播を壊す。2 度目の解放が何も起こさないのも同じ判定による。
        """
        if self.handler not in self.logger.handlers:
            self.handler.close()
            return

        self.logger.removeHandler(self.handler)
        self.handler.close()
        self.logger.setLevel(self.previous_level)
        self.logger.propagate = self.previous_propagate

    def __enter__(self) -> RunLogHandle:
        return self

    def __exit__(self, *exception: object) -> None:
        self.close()


def _formatter() -> logging.Formatter:
    """時刻を UTC で表す整形器を作る。

    地方時で書くと、複数拠点の実行ログを突き合わせたときに順序が入れ替わる。実行条件の
    記録（``execution.json`` の ``started_at``）も UTC であり、両者を揃える。
    """
    formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
    formatter.converter = time.gmtime
    return formatter


def configure_run_log(
    directory: Path,
    *,
    logger_name: str = LOGGER_NAME,
    level: int = logging.INFO,
) -> RunLogHandle:
    """実行ログを ``{directory}/run.log`` に書くハンドラを取り付ける（要件 8.4）。

    既存の同種のハンドラは外して閉じる。二重に構成すると 1 つの対象が 2 行記録され、
    要件 6.6 の成否件数と突き合わせられなくなる。

    構成前のロガーの状態は、既存の同種のハンドラがあればそれが控えた値を引き継ぐ。
    現在の状態を控えると、本関数が既に書き換えた値を「構成前」と誤認し、解放しても
    利用者のロガーが元に戻らなくなる。

    ファイルは実行ごとに作り直す。前回の実行分が残ると、ログの内容がその出力ディレクトリの
    実行結果と一致しなくなる（設計の Idempotency & recovery）。

    根ロガーには触れない。``logging.basicConfig`` も呼ばない。呼び出し側のアプリケーションの
    ログ構成を変えるのは、ライブラリの越権である。

    :param directory: 出力ディレクトリ。存在しなければ作る
    :param logger_name: 取り付け先のロガー名
    :param level: 記録する水準
    :return: 解放のための取っ手。呼び出し側が :meth:`RunLogHandle.close` で閉じる
    :raises OSError: ログファイルを開けない場合。資源・環境の失敗は要件 10.3 の系統であり、
        値として飲み込まない
    """
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / RUN_LOG_FILENAME

    logger = logging.getLogger(logger_name)
    attached = [h for h in logger.handlers if isinstance(h, _RunLogHandler)]
    if attached:
        previous_level = attached[0].previous_level
        previous_propagate = attached[0].previous_propagate
    else:
        previous_level = logger.level
        previous_propagate = logger.propagate

    for existing in attached:
        logger.removeHandler(existing)
        existing.close()

    handler = _RunLogHandler(
        path, previous_level=previous_level, previous_propagate=previous_propagate
    )
    handler.setFormatter(_formatter())
    handler.setLevel(level)
    logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False

    return RunLogHandle(
        logger=logger,
        handler=handler,
        path=path,
        previous_level=previous_level,
        previous_propagate=previous_propagate,
    )


def log_run_start(
    logger: logging.Logger,
    *,
    config_path: str | None,
    resolved_config: Mapping[str, object],
) -> None:
    """実行開始時に、解決済みの実行条件を記録する（設計の Monitoring、要件 8.3）。

    機械可読な完全版は ``execution.json`` であり（``execution`` モジュール）、ここでは
    ログを読む人が実行条件を目で確かめられる形を残す。値は :func:`repr` で書く。改行を
    含む値が行を割って、1 対象 1 行という読み方を壊すのを防ぐ。

    :param logger: 記録先
    :param config_path: 設定ファイルの位置。ライブラリ呼び出しでは ``None``
    :param resolved_config: 解決済みの実行条件。与えられた順序のまま書く
    """
    rendered = " ".join(f"{key}={value!r}" for key, value in resolved_config.items())
    logger.info(
        "status=%s config_path=%s %s", RUN_START_STATUS, config_path, rendered
    )


def _log_missing_stderr(logger: logging.Logger, success: FitSuccess) -> None:
    """標準誤差を算出できなかったパラメータを警告として記録する（要件 7.1）。

    固定パラメータは対象外である。固定した以上その標準誤差が空なのは仕様（要件 4.5）で
    あって異常ではなく、警告にすると本当に算出できなかった場合が埋もれる。

    対象・手法・パラメータ名を必ず書く。数百件のバッチでは、どの対象のどのパラメータかを
    特定できない警告は実質的に無価値である（設計の Error Categories）。
    """
    for parameter in success.parameters:
        if parameter.fixed or parameter.stderr is not None:
            continue
        logger.warning(
            "source_id=%r method=%r parameter=%r status=%s 標準誤差を算出できなかった",
            success.source_id,
            success.method_name,
            parameter.name,
            STDERR_UNAVAILABLE_STATUS,
        )


def log_outcome(logger: logging.Logger, outcome: FitOutcome) -> None:
    """処理単位 1 件の成否を記録する（要件 8.4）。

    成功は 1 行、失敗は理由と説明を添えた 1 行とする。失敗は誤りの水準で書く。既定では
    バッチを止めない失敗であっても（要件 6.4）、利用者が後から拾えなければ握り潰しと
    変わらない。

    並べ替えは行わない。呼び出された順、すなわちジョブ順序（要件 8.2 により決定的）が
    そのままログの順序になる。ここで並べ替えると順序の所有者が 2 か所に分かれる。

    成功の場合は、標準誤差を算出できなかったパラメータの警告を続けて記録する（要件 7.1）。

    外から来る値は :func:`repr` で書く（:func:`log_run_start` と同じ扱い）。失敗の説明は
    利用者が与えた Python 関数の送出した例外（要件 3.3）や当てはめ器の返す文言をそのまま
    含み、改行を持ちうる。生のまま差し込むと 1 件が複数行に割れ、要件 8.4 の「対象ごとの
    成否」を行として数えられなくなる。対象名・手法名も同じ理由で :func:`repr` にする。

    :param logger: 記録先
    :param outcome: 処理単位の結果
    """
    if isinstance(outcome, FitSuccess):
        logger.info(
            "source_id=%r method=%r status=%s",
            outcome.source_id,
            outcome.method_name,
            SUCCESS_STATUS,
        )
        _log_missing_stderr(logger, outcome)
        return

    logger.error(
        "source_id=%r method=%r status=%s reason=%s message=%r",
        outcome.source_id,
        outcome.method_name,
        FAILURE_STATUS,
        outcome.reason.value,
        outcome.message,
    )


def log_summary(logger: logging.Logger, *, n_success: int, n_failure: int) -> None:
    """実行終了時に成功・失敗の件数を記録する（設計の Monitoring、要件 6.6）。

    :param logger: 記録先
    :param n_success: 成功した処理単位の件数
    :param n_failure: 失敗した処理単位の件数
    """
    logger.info(
        "status=%s n_success=%d n_failure=%d", RUN_FINISHED_STATUS, n_success, n_failure
    )
