"""モデル式を前提としない 4 手法の当てはめ（要件 5.1、5.3、5.4、5.5）。

本モジュールが所有するのは次の 3 点である。

1. **4 手法の実行** — 線形回帰・多項式回帰・平滑化スプライン・移動平均を、最小二乗と
   同一の当てはめ契約（:class:`~curvefit.engines.base.FitEngine`）の実装として用意する。
   要件 5.2 の「モデル関数フィットと同一の手順で実行する」は、呼び出し側の分岐ではなく
   この並置によって成立する
2. **手法固有の選択肢の既定値** — 次数・窓長・多項式次数の既定値を、本モジュールの
   公開定数として単独で所有する（:data:`SMOOTHER_OPTION_DEFAULTS`）。実行前ゲートは
   この定数を参照して検証を行い、独自の既定値を持たない。既定値の定義が 2 か所に
   分かれると、検証を通った設定が実行時に別の値で動く。定数を素の整数に保つのは、
   実行前ゲートが基盤ライブラリの値を扱わずに済むようにするためである
3. **失敗の判定** — 点数や x の並びが手法の前提を満たさない場合、および有限でない
   当てはめ値を得た場合を :class:`~curvefit.engines.base.EngineFailure` として値で返す

手法から実装への振り分けは行わない。モデル関数フィットの解決結果を渡された場合は
呼び出し側の誤りとして :class:`TypeError` を送出する。

**パラメータと適合度の形式**（要件 5.3）。線形回帰と多項式回帰は推定パラメータを持ち、
最小二乗と同一の :class:`~curvefit.types.ParameterEstimate` で出力する。標準誤差も
最小二乗と同じ構成、すなわち残差分散 ``Σr² / (n - 係数の個数)`` と設計行列の
擬似逆行列から算出する。同じ名前の量が手法によって別の意味を持つと、サマリ CSV に
並んだ値を利用者が比較できない。残差の自由度がない場合（点数が係数の個数に等しい）は
算出できないため ``None`` とし、失敗にはしない（設計の Risks）。平滑化スプラインと
移動平均は推定パラメータを持たないため空のタプルを返す。適合度はいずれの手法でも
:func:`~curvefit.engines.base.compute_goodness` が残差から算出する。

**重み**（要件 1.3）。:attr:`~curvefit.types.DataSeries.weights` は残差の最小化に効く。
線形回帰と多項式回帰はいずれも最小二乗であるから、最小二乗エンジンと同一の解釈で
重みを用いる。すなわち最小化するのは ``Σ (weights * (y - 当てはめ値))²`` であり、
標準誤差も重み付きの残差分散と重み付きの設計行列から算出する。同じ最小二乗を解く
2 つの経路が別の答えを返せば、要件 6.2 のサマリ CSV には同じ ``slope`` /
``intercept`` という名前で異なる値が並び、利用者にはその差の理由が読めない。

平滑化スプラインも重みを用いる。最小化するのは残差の重み付き二乗和と曲率の和
``Σ w r² + λ∫f''²`` であり、点ごとの重みは前者に入る。**ただし基盤ライブラリの ``w``
は残差の二乗に掛かるため、渡すのは ``weights`` ではなく ``weights ** 2`` である**
（:func:`_fit_spline`）。移動平均だけが重みを用いない。窓内の畳み込み係数は窓長と
多項式次数だけで決まり、残差を最小化する過程そのものがない。

適合度はいずれの手法でも重みを用いない（:func:`~curvefit.engines.base.compute_goodness`）。
手法によって重みの概念の有無が異なるため、指標まで重み付きにすると要件 5.3 の
「同一の形式」が意味の水準で崩れる。効かせる先は推定量に限り、報告する指標は
実測値の尺度に揃える。

**x の並び**。スプラインと移動平均は x の昇順に対して定義される。入力の並びが昇順とは
限らないため、内部で昇順に整えてから当てはめ、当てはめ値は入力の並びに戻して返す。
並び順で結果が変わると、同じデータでも読み込み順の違いで異なる曲線が出る。

**平滑化スプラインの再現性**（要件 5.5、8.2）。本モジュール自身は乱数も実行時可変状態も
持たない。かつては平滑化パラメータを省略でき、その場合の GCV 探索が完全一致を保証
しなかった。同一プロセス内の連続した呼び出しでも、中間配列のメモリ整列の違いで最終反復
が揺れ、当てはめ値が 1e-11 程度ずれる。プロセスを跨いでも同様で、同一の設定と同一の入力
による 12 回の実行でサマリ CSV が 2 種類になることが実測で確認された。サマリ CSV の丸め
はこれを吸収しない。値が丸めの境界付近にあれば、揺れが最終桁の刻みより小さくても表記が
変わるためである（462 データ中 5 件が該当）。

**現在、:data:`SPLINE_LAMBDA_OPTION` は必須である。** 指定された場合の当てはめは直接
解法であり、揺れる余地そのものが無い。自動選択へ落ちる経路は残っていないため、上記の
揺れはもはや到達不能である。未指定のまま届いた場合は当てはめを行わず失敗として返す
（:func:`_fit_spline`）。実行前ゲートが未指定を拒否するため、通常の経路では到達しない。

**数値計算に伴う警告**。SciPy と NumPy は数値的に苦しい入力に対して
:class:`RuntimeWarning` を ``warnings`` 機構で送出することがある。本モジュールはこれを
抑止も出力もしない。抑止すれば利用者が知るべき兆候が消え、エンジン自身が出力すれば
入出力を持たないという制約に反する。警告の扱いは実行ログを持つ層の責務であり、
数値計算が実際に破綻した場合（有限でない当てはめ値）は失敗として値で返す。

SciPy と NumPy の型は公開シグネチャに現れない。当てはめ値は
:data:`~curvefit.types.FloatArray` に正規化してから返す（設計の Allowed Dependencies）。
"""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import TypeAlias

import numpy as np
from numpy.polynomial import Polynomial, polyutils
from scipy.interpolate import make_smoothing_spline
from scipy.signal import savgol_filter

from curvefit.engines.base import EngineFailure, EngineOutcome, EngineSuccess
from curvefit.errors import FailureReason
from curvefit.models.resolver import PreparedMethod, PreparedSmoother, SmootherKind
from curvefit.types import DataSeries, FloatArray, ParameterEstimate

# --- 手法固有の選択肢と既定値 ------------------------------------------------------
#
# 実行前ゲートはここを唯一の出所として検証する。値はすべて素の整数であり、基盤
# ライブラリの型を含まない。

POLYNOMIAL_DEGREE_OPTION = "degree"
"""多項式回帰の次数を指定する選択肢名。"""

DEFAULT_POLYNOMIAL_DEGREE = 2
"""多項式回帰の既定次数。

直線は線形回帰が担うため、次数を指定せずに多項式回帰を選んだ利用者が求めるのは
曲がりを表せる最小の次数である。組込モデルの既定次数（:mod:`curvefit.models.registry`）
とは独立に定義する。両者を共有すると、一方の都合による変更が他方の実行条件を
黙って変える。
"""

MOVING_AVERAGE_WINDOW_OPTION = "window"
"""移動平均の窓長を指定する選択肢名。"""

DEFAULT_MOVING_AVERAGE_WINDOW = 5
"""移動平均の既定窓長。奇数でなければ中心が定まらない。"""

MOVING_AVERAGE_POLYORDER_OPTION = "polyorder"
"""移動平均の多項式次数を指定する選択肢名。"""

DEFAULT_MOVING_AVERAGE_POLYORDER = 0
"""移動平均の既定多項式次数。

0 のとき窓内の単純平均、すなわち移動平均そのものになる。次数を上げると
Savitzky-Golay 平滑化となり、ピーク形状を保ったまま平滑化できる（``research.md``）。
窓長より小さくなければならない。
"""

SPLINE_LAMBDA_OPTION = "lam"
"""平滑化スプラインの平滑化パラメータを指定する選択肢名。**指定は必須**（要件 5.5）。

既定値を持たない。ここでいう「既定値を持たない」は、他の選択肢とは意味が違う。窓長や
次数には手法として妥当な既定があり、未指定なら :data:`SMOOTHER_OPTION_DEFAULTS` の値を
適用して記録すれば済む（要件 5.4）。平滑化の強さにはそれが無い。どの値を選んでも、
データによっては過度に平滑化するか、まったく平滑化しない。

かといって未指定を基盤ライブラリの自動選択に委ねることもできない。自動選択は同一の
入力に対して同一の結果を返さず、要件 8.2 が成立しなくなる（本モジュールの docstring）。
残るのは利用者に決めてもらう道だけであり、未指定は実行前ゲートが拒否する。
"""

MIN_SPLINE_POINTS = 5
"""平滑化スプラインが必要とする最小点数。

基盤ライブラリの制約をそのまま写している。事前に判定するのは、点数不足という
理由を利用者に伝えるためである。
"""

SMOOTHER_OPTION_NAMES: Mapping[SmootherKind, tuple[str, ...]] = MappingProxyType(
    {
        SmootherKind.LINEAR: (),
        SmootherKind.POLYNOMIAL: (POLYNOMIAL_DEGREE_OPTION,),
        SmootherKind.SPLINE: (SPLINE_LAMBDA_OPTION,),
        SmootherKind.MOVING_AVERAGE: (
            MOVING_AVERAGE_WINDOW_OPTION,
            MOVING_AVERAGE_POLYORDER_OPTION,
        ),
    }
)
"""手法ごとに指定できる選択肢名。実行前ゲートが未知の選択肢を検出するために参照する。"""

SMOOTHER_EMITS_PARAMETERS: Mapping[SmootherKind, bool] = MappingProxyType(
    {
        SmootherKind.LINEAR: True,
        SmootherKind.POLYNOMIAL: True,
        SmootherKind.SPLINE: False,
        SmootherKind.MOVING_AVERAGE: False,
    }
)
"""手法が推定結果として名前付きパラメータを返すか（要件 5.3）。

``linear`` は ``slope`` / ``intercept``、``polynomial`` は ``c0`` 以降を返す。
``spline`` と ``moving_average`` は当てはめ後の系列だけを返し、パラメータを 1 つも
持たない。

**この区別は利用者への説明に要る。** 平滑化手法にパラメータの指定を書いたとき、
実行前ゲートが理由を述べる（要件 4.4、4.5、8.5）。「パラメータは推定の結果として
得られる」という説明は前 2 者には正しいが、後 2 者には誤りになる。ここで区別を
持たずに一律の文言を出すと、利用者は存在しないパラメータの出どころを探すことになる。
"""

SMOOTHER_USES_WEIGHTS: Mapping[SmootherKind, bool] = MappingProxyType(
    {
        SmootherKind.LINEAR: True,
        SmootherKind.POLYNOMIAL: True,
        SmootherKind.SPLINE: True,
        SmootherKind.MOVING_AVERAGE: False,
    }
)
"""手法が :attr:`~curvefit.types.DataSeries.weights` を当てはめに反映するか（要件 1.3）。

``linear`` と ``polynomial`` は重み付き最小二乗そのものであり、``spline`` は残差の
重み付き二乗和と曲率の和 ``Σ w r² + λ∫f''²`` を最小化する。いずれも点ごとの重みが
効く場所を持つ。``moving_average`` だけが持たない。:func:`scipy.signal.savgol_filter`
に重みの引数は無く、窓内の畳み込み係数は **窓長と多項式次数だけ** で決まるためである。
Savitzky-Golay は窓内の最小二乗多項式当てはめではあるが、その当てはめは重みを持たない
形で係数へ畳み込み済みであり、実行時に点ごとの重みを差し込む場所が残っていない。

**この宣言が拒否の唯一の出所である**（要件 1.10）。誤差列を指定したうえで重みを
扱えない手法を選んだ設定は、実行前ゲートが拒否する
（:func:`~curvefit.preflight._weight_support_violations`）。黙って無視すると、測定誤差
を与えた利用者がそれを反映した結果として読む。

**対象を呼び出し側で列挙しない。** かつて ``pipeline`` が同じ内容を独自の集合として
持っており、スプラインが重みを扱うようになった際（タスク 11.1）に両方を直す必要が
生じた。当てはめの実装を変える者が必ず目にする位置に宣言を 1 つだけ置き、実行前ゲート
と実行ログの双方がここを読む。``tests/unit/test_engines_smoothing.py`` が 4 手法を
重みあり・重みなしの双方で実際に当てはめ、この宣言と突き合わせる。
"""

NO_WEIGHT_SUPPORT_REASONS: Mapping[SmootherKind, str] = MappingProxyType(
    {
        SmootherKind.MOVING_AVERAGE: (
            "窓内の畳み込み係数は窓長と多項式次数だけで決まり、"
            "点ごとの重みを与える場所が無い"
        ),
    }
)
"""重みを扱えない理由。:data:`SMOOTHER_USES_WEIGHTS` が偽とする手法をすべて覆う。

**宣言と同じ場所に置く。** 理由の文言を実行前ゲートと実行ログの 2 か所に書くと、
片方だけが更新される。実際に起きた — Savitzky-Golay を「残差を最小化しない」と
説明していた誤りをタスク 11.2 が訂正したとき、訂正されたのは実行前ゲート側だけで、
利用者に出る警告文には撤回した説明が残った。
"""

SMOOTHER_OPTION_DEFAULTS: Mapping[SmootherKind, Mapping[str, int]] = MappingProxyType(
    {
        SmootherKind.LINEAR: MappingProxyType({}),
        SmootherKind.POLYNOMIAL: MappingProxyType(
            {POLYNOMIAL_DEGREE_OPTION: DEFAULT_POLYNOMIAL_DEGREE}
        ),
        SmootherKind.SPLINE: MappingProxyType({}),
        SmootherKind.MOVING_AVERAGE: MappingProxyType(
            {
                MOVING_AVERAGE_WINDOW_OPTION: DEFAULT_MOVING_AVERAGE_WINDOW,
                MOVING_AVERAGE_POLYORDER_OPTION: DEFAULT_MOVING_AVERAGE_POLYORDER,
            }
        ),
    }
)
"""未指定の場合に適用する既定値（要件 5.4）。

選択肢名の一覧との差は「既定値を持たない選択肢」である。スプラインの平滑化パラメータ
がそれに当たり、こちらは未指定を実行前ゲートが拒否する（要件 5.5、
:data:`SPLINE_LAMBDA_OPTION`）。
"""


# --- 失敗の組み立て ----------------------------------------------------------------


def _not_converged(message: str) -> EngineFailure:
    """当てはめが成立しなかったことを値として返す。

    ``initial_values`` は常に空である。回帰・平滑化は反復の出発点を持たず、要件 4.7 が
    求める初期値の報告は最小二乗に固有のものである。
    """
    return EngineFailure(reason=FailureReason.NOT_CONVERGED, message=message)


def _insufficient_points(message: str) -> EngineFailure:
    """点数（または異なる x の個数）が手法の前提に満たないことを値として返す。"""
    return EngineFailure(reason=FailureReason.INSUFFICIENT_POINTS, message=message)


# --- 選択肢の読み取り --------------------------------------------------------------


def _int_option(
    kind: SmootherKind,
    name: str,
    options: Mapping[str, float | int],
    applied_defaults: dict[str, float | int],
) -> int:
    """指定があればその値を、なければ既定値を用いる（要件 5.4）。

    既定値を用いた場合にのみ ``applied_defaults`` に記録する。利用者が明示した値まで
    記録すると、実行条件の記録から「書いていないのに効いた値」を区別できなくなる。

    値域（窓長が奇数であること、次数が窓長より小さいこと）は検証しない。検証は
    実行前ゲートが本モジュールの定数を参照して行い、エンジンは検証済みを前提に動作する
    （設計の Implementation Notes）。
    """
    if name in options:
        return int(options[name])
    default = SMOOTHER_OPTION_DEFAULTS[kind][name]
    applied_defaults[name] = default
    return default


# --- 回帰（線形・多項式） ----------------------------------------------------------


@dataclass(frozen=True)
class _Regression:
    """多項式回帰の結果。係数は昇冪（``c0 + c1 x + ...``）で並ぶ。"""

    coefficients: tuple[float, ...]
    stderr: tuple[float | None, ...]
    y_fit: FloatArray


def _basis_transform(fitted: Polynomial, degree: int) -> FloatArray:
    """当てはめに用いた尺度変換後の基底から、標準基底への変換行列を求める。

    当てはめは独立変数を ``[-1, 1]`` に写してから行う（:meth:`Polynomial.fit` の既定
    動作）。数値条件を保つためであるが、係数の共分散もその尺度で得られる。利用者に
    返すのは標準基底の係数であるから、共分散も同じ基底へ移す必要がある。

    変換は係数について線形であり、その行列は基底ベクトルを 1 本ずつ変換すれば得られる。
    展開の代数を自前で書かないのは、当てはめ側と変換側で式が食い違う余地を残さない
    ためである。
    """
    transform = np.zeros((degree + 1, degree + 1), dtype=np.float64)
    for column in range(degree + 1):
        unit = np.zeros(degree + 1, dtype=np.float64)
        unit[column] = 1.0
        converted = Polynomial(unit, domain=fitted.domain, window=fitted.window).convert().coef
        transform[: converted.size, column] = converted
    return transform


def _standard_error(variance: float) -> float | None:
    """分散から標準誤差を求める。求まらない場合は ``None``（要件 7.1）。"""
    if not math.isfinite(variance) or variance < 0.0:
        return None
    return math.sqrt(variance)


def _standard_errors(
    series: DataSeries, fitted: Polynomial, y_fit: FloatArray, degree: int
) -> tuple[float | None, ...]:
    """最小二乗と同一の構成で係数の標準誤差を算出する（要件 5.3、7.1）。

    残差分散 ``Σr² / (n - 係数の個数)`` と設計行列の擬似逆行列の積を共分散とする。
    これは最小二乗エンジンが基盤ライブラリから受け取る標準誤差と同じ量であり、
    同じ列に並べて比較できる。

    重みがある場合は残差と設計行列の双方に掛ける（要件 1.3）。最小化する量が
    ``Σ (w r)²`` である以上、その解のばらつきも重み付きの残差と重み付きの設計行列から
    しか出ない。当てはめだけに重みを効かせて標準誤差を素の残差から出すと、推定値は
    重み付き・標準誤差は非重み付きという、どの最小二乗問題にも対応しない組が出力される。

    残差の自由度がない場合は算出できないため、すべて ``None`` とする。失敗にはしない
    （設計の Risks）。
    """
    n_coefficients = degree + 1
    degrees_of_freedom = len(series) - n_coefficients
    if degrees_of_freedom <= 0:
        return (None,) * n_coefficients

    residual = series.y - y_fit
    scaled_x = polyutils.mapdomain(series.x, fitted.domain, fitted.window)
    design = np.vander(scaled_x, n_coefficients, increasing=True)
    if series.weights is not None:
        residual = residual * series.weights
        design = design * series.weights[:, np.newaxis]
    variance = float(np.sum(np.square(residual))) / degrees_of_freedom
    scaled_covariance = variance * np.linalg.pinv(design.T @ design)
    transform = _basis_transform(fitted, degree)
    covariance = transform @ scaled_covariance @ transform.T
    return tuple(_standard_error(float(value)) for value in np.diag(covariance))


def _regress(series: DataSeries, degree: int) -> _Regression | EngineFailure:
    """指定次数の多項式を重み付き最小二乗で当てはめる（要件 1.3）。

    異なる x の個数が係数の個数に満たない場合は失敗として返す。係数が一意に定まらず、
    どの解を選んでも利用者の意図とは無関係な値になる。点数そのものではなく異なる x の
    個数で判定するのは、同一の x に複数の観測があっても自由度が増えないためである。

    重みは変換せずにそのまま渡す。基盤ライブラリの ``w`` は二乗前の残差に掛かる乗数で
    あり、これは最小二乗エンジンが lmfit に渡す重みと同じ規約である。両者が同じ規約で
    あることによって、同一データに対する ``smoother linear`` と ``builtin linear`` が
    同じ推定値を返す。重みが ``None`` の場合は基盤ライブラリの既定と一致する。
    """
    n_coefficients = degree + 1
    distinct = int(np.unique(series.x).size)
    if distinct < n_coefficients:
        return _insufficient_points(
            f"{degree} 次の回帰は異なる x を {n_coefficients} 個以上必要とする"
            f"（実際: {distinct} 個、点数 {len(series)}）。"
        )

    fitted = Polynomial.fit(series.x, series.y, degree, w=series.weights)
    y_fit = np.asarray(fitted(series.x), dtype=np.float64)
    standard = fitted.convert().coef
    coefficients = np.zeros(n_coefficients, dtype=np.float64)
    coefficients[: standard.size] = standard
    return _Regression(
        coefficients=tuple(float(value) for value in coefficients),
        stderr=_standard_errors(series, fitted, y_fit, degree),
        y_fit=y_fit,
    )


def _estimate(name: str, regression: _Regression, index: int) -> ParameterEstimate:
    """係数 1 個を、最小二乗と同一の共有型に写し替える（要件 5.3）。

    ``fixed`` は常に偽である。固定は利用者の指定に基づく概念（要件 4.5）であり、
    回帰の係数はすべて推定対象である。
    """
    return ParameterEstimate(
        name=name,
        value=regression.coefficients[index],
        stderr=regression.stderr[index],
        fixed=False,
    )


# --- 手法ごとの当てはめ ------------------------------------------------------------

_FitResult: TypeAlias = tuple[tuple[ParameterEstimate, ...], FloatArray] | EngineFailure
"""手法の当てはめ結果。成立した場合は推定パラメータと当てはめ値の組。"""

_Fitter: TypeAlias = Callable[
    [DataSeries, Mapping[str, float | int], dict[str, float | int]], _FitResult
]


def _fit_linear(
    series: DataSeries,
    options: Mapping[str, float | int],
    applied_defaults: dict[str, float | int],
) -> _FitResult:
    """線形回帰（要件 5.1）。重みを用いる（要件 1.3）。

    パラメータ名は組込の linear モデルに合わせる。同じ量に手法ごとに別の名前を与えると、
    複数手法を横並びにしたサマリ CSV で同じ列に並ばない（要件 6.2）。名前を合わせる以上、
    中身も合っていなければならない。本手法と組込 linear は同じ重み付き最小二乗であり、
    同一データに対して同一の推定値と標準誤差を返す。
    """
    regression = _regress(series, degree=1)
    if isinstance(regression, EngineFailure):
        return regression
    estimates = (
        _estimate("slope", regression, 1),
        _estimate("intercept", regression, 0),
    )
    return estimates, regression.y_fit


def _fit_polynomial(
    series: DataSeries,
    options: Mapping[str, float | int],
    applied_defaults: dict[str, float | int],
) -> _FitResult:
    """多項式回帰（要件 5.1、5.4）。重みを用いる（要件 1.3）。

    パラメータ名は組込の polynomial モデルに合わせ、昇冪の ``c0`` から順に並べる。
    """
    degree = _int_option(
        SmootherKind.POLYNOMIAL, POLYNOMIAL_DEGREE_OPTION, options, applied_defaults
    )
    regression = _regress(series, degree)
    if isinstance(regression, EngineFailure):
        return regression
    estimates = tuple(
        _estimate(f"c{index}", regression, index) for index in range(degree + 1)
    )
    return estimates, regression.y_fit


def _ascending(series: DataSeries) -> FloatArray:
    """x の昇順に並べ替える添字。

    同値の x に対する順序を安定させるのは、要件 8.2 の再現性のためである。
    """
    return np.argsort(series.x, kind="stable")


def _fit_spline(
    series: DataSeries,
    options: Mapping[str, float | int],
    applied_defaults: dict[str, float | int],
) -> _FitResult:
    """平滑化スプライン（要件 5.1）。

    推定パラメータを持たない。節点ごとの係数は手法の内部表現であり、利用者が
    モデル間で比較できる量ではない（要件 5.3 の「推定パラメータを持つ場合」に
    当たらない）。

    平滑化パラメータ（:data:`SPLINE_LAMBDA_OPTION`）は **必須** である（要件 5.5）。
    通常は実行前ゲートが未指定を拒否するため、ここへ届く選択肢は必ずこれを含む。
    それでも値として失敗を返すのは、ゲートを経ない呼び出しが自動選択へ落ちるのを
    防ぐためである。自動選択は呼び出しごとに結果が揺れ、要件 8.2 が成立しない。

    :attr:`~curvefit.types.DataSeries.weights` を用いる（要件 1.3）。本手法が最小化
    するのは残差の **重み付き** 二乗和と曲率の和 ``Σ w r² + λ∫f''²`` であり、点ごとの
    重みは前者に入る。

    **渡すのは重みの二乗である。** 本パッケージの ``weights`` は残差に掛かる ``1/σ``
    であり（最小二乗エンジンと同じ規約。最小化するのは ``Σ (weights r)²``）、
    基盤ライブラリの ``w`` は残差の **二乗** に掛かる。同じ統計的重み付けを得るには
    ``weights ** 2`` を渡す必要がある。同じ配列をそのまま渡すと、同一のデータと同一の
    誤差列でも手法によって測定誤差の効き方が変わり、要件 6.2 のサマリ CSV に意味の
    違う値が並ぶ（設計の engines.smoothing / Integration）。

    重みは当てはめ値と同じく x の昇順へ並べ替えてから渡す。並べ替えを当てはめ側だけに
    かけると、各点に別の点の重みが割り当たる。
    """
    lam = options.get(SPLINE_LAMBDA_OPTION)
    if lam is None:
        return _not_converged(
            f"平滑化スプラインは選択肢 {SPLINE_LAMBDA_OPTION!r}（平滑化の強さ）の"
            "指定を必須とする。省略した場合の自動選択は同一の入力に対して同一の"
            "結果を返さないため、当てはめを行わない。"
        )

    n_points = len(series)
    if n_points < MIN_SPLINE_POINTS:
        return _insufficient_points(
            f"平滑化スプラインは {MIN_SPLINE_POINTS} 点以上を必要とする"
            f"（実際: {n_points} 点）。"
        )

    order = _ascending(series)
    x_sorted = series.x[order]
    if bool(np.any(np.diff(x_sorted) <= 0.0)):
        return _not_converged(
            "平滑化スプラインは x が重複しない系列を必要とする。"
            "同一の x に複数の観測がある場合は、事前に代表値へまとめる。"
        )

    spline_weights = (
        None if series.weights is None else np.square(series.weights[order])
    )
    spline = make_smoothing_spline(
        x_sorted, series.y[order], w=spline_weights, lam=float(lam)
    )
    return (), np.asarray(spline(series.x), dtype=np.float64)


def _fit_moving_average(
    series: DataSeries,
    options: Mapping[str, float | int],
    applied_defaults: dict[str, float | int],
) -> _FitResult:
    """移動平均（要件 5.1、5.4）。

    推定パラメータを持たない。多項式次数 0 の Savitzky-Golay 平滑化は窓内の単純平均に
    一致し、端点では窓内に当てはめた多項式で補うため、当てはめ値は入力と同じ点数になる。

    :attr:`~curvefit.types.DataSeries.weights` は用いない。窓内の畳み込み係数は窓長と
    多項式次数だけで決まり、残差を最小化する過程がない。重みを与えられた系列でも
    与えられない系列と同じ曲線を返す（設計の engines.smoothing / Integration）。
    4 手法のうち重みを持ち込む場所が無いのはこの手法だけである。
    """
    window = _int_option(
        SmootherKind.MOVING_AVERAGE, MOVING_AVERAGE_WINDOW_OPTION, options, applied_defaults
    )
    polyorder = _int_option(
        SmootherKind.MOVING_AVERAGE,
        MOVING_AVERAGE_POLYORDER_OPTION,
        options,
        applied_defaults,
    )
    n_points = len(series)
    if n_points < window:
        return _insufficient_points(
            f"窓長 {window} の移動平均は {window} 点以上を必要とする（実際: {n_points} 点）。"
        )

    order = _ascending(series)
    smoothed = np.asarray(savgol_filter(series.y[order], window, polyorder), dtype=np.float64)
    y_fit = np.empty(n_points, dtype=np.float64)
    y_fit[order] = smoothed
    return (), y_fit


_FITTERS: Mapping[SmootherKind, _Fitter] = MappingProxyType(
    {
        SmootherKind.LINEAR: _fit_linear,
        SmootherKind.POLYNOMIAL: _fit_polynomial,
        SmootherKind.SPLINE: _fit_spline,
        SmootherKind.MOVING_AVERAGE: _fit_moving_average,
    }
)


@dataclass(frozen=True)
class SmoothingEngine:
    """回帰・スムージングを実行する :class:`~curvefit.engines.base.FitEngine`。

    状態を持たない。当てはめのたびに解決済みの手法を受け取る形にすることで、同じ
    エンジン実体を複数のジョブで使い回しても結果が互いに影響しない（要件 8.2）。
    """

    def fit(self, series: DataSeries, method: PreparedMethod) -> EngineOutcome:
        """前処理済みの系列に、モデル式を前提としない手法を当てはめる。

        :param series: 前処理済みの系列。欠損を含まない。``weights`` は線形回帰・
            多項式回帰・平滑化スプラインの残差最小化に効き、移動平均では用いられない
            （要件 1.3）
        :param method: 解決済みの平滑化手法。手法固有の選択肢は利用者の指定のみを含み、
            既定値の補完は本エンジンが行う（要件 5.4）
        :return: 成功なら :class:`~curvefit.engines.base.EngineSuccess`、当てはめが
            成立しない場合は :class:`~curvefit.engines.base.EngineFailure`
        :raises TypeError: モデル関数フィットを渡された場合。振り分けは呼び出し側の
            責務である
        """
        if not isinstance(method, PreparedSmoother):
            raise TypeError(
                f"平滑化エンジンは回帰・スムージングのみを扱う"
                f"（実際: {type(method).__name__}）"
            )

        fitter = _FITTERS[method.kind]
        applied_defaults: dict[str, float | int] = {}
        try:
            result = fitter(series, method.options, applied_defaults)
        except (MemoryError, OSError):
            # 資源枯渇は要件 10.3 の系統であり、当てはめの失敗として黙らせない
            # （設計の Error Strategy）。
            raise
        except Exception as error:  # noqa: BLE001 - 基盤ライブラリの例外を外に漏らさない
            # 基盤ライブラリは前提を満たさない入力に例外を送出する。素通しすると
            # 1 件の入力でバッチ全体が落ちる（要件 6.4）。
            return _not_converged(
                f"{method.kind.value} の当てはめを完了できなかった"
                f"（{type(error).__name__}: {error}）。"
            )

        if isinstance(result, EngineFailure):
            return result
        estimates, y_fit = result

        # 有限でない結果は失敗として返す。適合度の算出はこれを素通しするため、ここで
        # 止めなければ NaN や無限大が指標として出力される
        # （:func:`~curvefit.engines.base.compute_goodness` の規約）。
        diverged = [e.name for e in estimates if not math.isfinite(e.value)]
        if diverged:
            return _not_converged(f"推定値が有限でない値になった（{', '.join(diverged)}）。")
        if not bool(np.all(np.isfinite(y_fit))):
            return _not_converged("当てはめ値に有限でない値が含まれる。")

        return EngineSuccess(
            parameters=estimates, y_fit=y_fit, applied_defaults=applied_defaults
        )
