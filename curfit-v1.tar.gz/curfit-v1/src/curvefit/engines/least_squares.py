"""非線形最小二乗による当てはめと、その結果の正規化（要件 1.3、4.1、4.4、4.5、4.7、5.4、7.1）。

本モジュールが所有するのは次の 3 点である。

1. **当てはめの実行** — 解決済みモデル（:class:`~curvefit.models.resolver.PreparedModel`）が
   保持する実体に、系列と重みを渡して最小二乗を実行する。初期値・上下限・固定は解決の
   時点で実体に織り込まれており、ここで組み立て直さない。組み立てが 2 か所に分かれると、
   実行前ゲートが検証した条件と実際に走る条件が食い違う
2. **結果の正規化** — 基盤ライブラリ固有の結果型を :class:`~curvefit.engines.base.EngineSuccess`
   に写し替える。lmfit の ``ModelResult`` は本モジュールの外に出ない（設計の
   Allowed Dependencies）
3. **失敗の判定** — 収束しなかった場合、有限でない結果を得た場合、および当てはめ値が
   各データ点に対応しない場合を :class:`~curvefit.engines.base.EngineFailure` として
   値で返す（要件 4.7、6.4）

手法から実装への振り分けは行わない。平滑化の解決結果を渡された場合は呼び出し側の誤りと
して :class:`TypeError` を送出する。

**適用された既定値**（要件 5.4）。組込モデルの手法固有の選択肢（多項式の次数）は、
モデル実体の組み立てに要るため解決の時点で既定値が確定している。本モジュールはその
記録（:attr:`~curvefit.models.resolver.PreparedModel.applied_defaults`）を
:class:`~curvefit.engines.base.EngineSuccess` に載せて中継するだけで、既定値そのものは
持たない。持つと登録簿と 2 か所に分かれ、検証を通った設定が実行時に別の値で動く。
平滑化エンジンは既定値を自分で所有するが、そちらは当てはめの時点で選択肢を読むため
確定の場所が違う。

**重みの解釈**（要件 1.3）。:attr:`~curvefit.types.DataSeries.weights` は残差に掛かる
乗数としてそのまま基盤ライブラリに渡す。すなわち最小化されるのは
``Σ (weights * (y - model))²`` であり、測定誤差 σ を持つ点の重みは ``1/σ`` に相当する。
本モジュールは一切の変換を行わない。誤差列から重みへの変換は、列の意味を知る読み込み層
が単独で担う。両方が変換すると二重に効き、どちらも変換しなければ誤差の大きい点ほど強く
効く逆転が起きる。変換の場所を 1 つに保つことが、この解釈の要点である。なお重みは残差の
最小化にのみ効き、適合度指標には用いない（:func:`~curvefit.engines.base.compute_goodness`）。

**標準誤差が算出できない場合**（要件 7.1）。失敗にはせず :attr:`ParameterEstimate.stderr`
を ``None`` にする。エンジンは入出力を持たないため、ここで警告を記録することはできない。
``None`` そのものが「算出できなかった」という記録であり、サマリ CSV の空欄と実行ログの
警告は、この値を受け取る出力層が担う（設計の Monitoring）。

基盤ライブラリの型注釈は現れない。解決済みモデルが :class:`object` として保持する実体を、
次の属性だけを通じて扱う。これが本モジュールが依存する唯一の外部表面である。

- モデル実体: ``fit(data, params, weights=..., <独立変数>=...)``
- パラメータ束: ``[name]`` による参照と、その ``value`` / ``vary``
- 当てはめ結果: ``success`` / ``message`` / ``errorbars`` / ``params`` / ``best_fit``
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass

import numpy as np

from curvefit.engines.base import EngineFailure, EngineOutcome, EngineSuccess
from curvefit.errors import FailureReason
from curvefit.models.expression import INDEPENDENT_VARIABLE
from curvefit.models.resolver import PreparedMethod, PreparedModel
from curvefit.types import DataSeries, FloatArray, ParameterEstimate


def _initial_values(method: PreparedModel) -> dict[str, float]:
    """当てはめに実際に用いる初期値を、実行前に控える（要件 4.7）。

    失敗の報告には「どの初期値から出発したか」が要る。当てはめ後のパラメータ束から
    読むと、収束の有無にかかわらず出発点が失われる。
    """
    parameters = method._parameters
    return {name: float(parameters[name].value) for name in method.parameter_names}


def _is_fixed(method: PreparedModel, name: str) -> bool:
    """固定指定されたパラメータか（要件 4.5）。

    判定は解決済みの束縛から行う。固定は利用者の指定であり、当てはめ結果の側から
    推し量る性質のものではない。
    """
    return not method._parameters[name].vary


def _stderr(raw: object, *, available: bool) -> float | None:
    """標準誤差を正規化する（要件 7.1）。

    ``available`` は共分散行列が得られたかを表す。得られていない場合、基盤ライブラリは
    パラメータによって ``None`` を返すことも ``0.0`` を残すこともある。後者をそのまま
    出すと「誤差 0 の完璧な推定」に見えるため、算出できなかったこととして扱う。
    """
    if not available or raw is None:
        return None
    value = float(raw)
    return value if math.isfinite(value) else None


def _estimates(method: PreparedModel, result: object) -> tuple[ParameterEstimate, ...]:
    """推定結果を共有型に写し替える（要件 7.1、4.5）。

    対象は解決済みモデルが確定させた推定対象パラメータに限る（要件 3.5）。基盤
    ライブラリは当てはめの過程で派生量（半値全幅など）をパラメータ束に加えるため、
    結果の側の名前を数えると識別子の集合が変わってしまう。
    """
    errorbars = bool(result.errorbars)
    fitted = result.params
    estimates: list[ParameterEstimate] = []
    for name in method.parameter_names:
        parameter = fitted[name]
        fixed = _is_fixed(method, name)
        estimates.append(
            ParameterEstimate(
                name=name,
                value=float(parameter.value),
                # 固定パラメータは推定していないため標準誤差を持たない（要件 4.5）。
                stderr=None if fixed else _stderr(parameter.stderr, available=errorbars),
                fixed=fixed,
            )
        )
    return tuple(estimates)


def _fitted_values(series: DataSeries, result: object) -> tuple[FloatArray | None, str | None]:
    """各データ点の当てはめ値を、系列と同じ形の配列に整える。

    定数モデル（利用者定義関数が独立変数によらない値を返す場合）では、基盤ライブラリの
    当てはめ値がスカラになる。各点の値としては同一値の並びであるため、系列の長さに
    展開する。

    整えられない場合は ``(None, 理由)`` を返す。利用者定義関数（要件 3.3）は 1 点 1 値を
    返すとは限らず、``np.array([a])`` や ``np.full((len(x), 1), a)`` のような形も書ける。
    これは実行時に届く指定由来の失敗であり、例外にすると 1 件の関数定義でバッチ全体が
    落ちる（要件 6.4、設計の Error Strategy）。理由の文言をここで組み立てるのは、
    食い違った形を知っているのがこの関数だけだからである。

    :return: 成功なら ``(当てはめ値, None)``、整えられない場合は ``(None, 理由)``
    """
    values = np.asarray(result.best_fit, dtype=np.float64)
    if values.ndim == 0:
        return np.full(len(series), float(values), dtype=np.float64), None
    if values.shape != (len(series),):
        return None, (
            f"モデルが各データ点に対応しない当てはめ値を返した"
            f"（{values.shape} と {(len(series),)}）。"
        )
    return values, None


def _not_converged(message: str, initial_values: Mapping[str, float]) -> EngineFailure:
    return EngineFailure(
        reason=FailureReason.NOT_CONVERGED,
        message=message,
        initial_values=initial_values,
    )


@dataclass(frozen=True)
class LeastSquaresEngine:
    """モデル関数フィットを最小二乗で実行する :class:`~curvefit.engines.base.FitEngine`。

    状態を持たない。当てはめのたびに解決済みモデルを受け取る形にすることで、同じ
    エンジン実体を複数のジョブで使い回しても結果が互いに影響しない（要件 8.2）。
    """

    def fit(self, series: DataSeries, method: PreparedMethod) -> EngineOutcome:
        """前処理済みの系列にモデル関数を当てはめる。

        :param series: 前処理済みの系列。欠損を含まない。``weights`` があれば残差の
            乗数として用いる（要件 1.3）
        :param method: 解決済みのモデル。初期値・上下限・固定は反映済み
        :return: 成功なら :class:`~curvefit.engines.base.EngineSuccess`、収束しなかった
            場合や有限でない結果を得た場合は
            :class:`~curvefit.engines.base.EngineFailure`（要件 4.7）
        :raises TypeError: 平滑化手法を渡された場合。振り分けは呼び出し側の責務である
        """
        if not isinstance(method, PreparedModel):
            raise TypeError(
                f"最小二乗エンジンはモデル関数フィットのみを扱う（実際: {type(method).__name__}）"
            )

        initial_values = _initial_values(method)
        try:
            result = method._model.fit(
                series.y,
                method._parameters,
                weights=series.weights,
                **{INDEPENDENT_VARIABLE: series.x},
            )
        except (MemoryError, OSError):
            # 資源枯渇は要件 10.3 の系統であり、当てはめの失敗として黙らせない
            # （設計の Error Strategy）。
            raise
        except Exception as error:  # noqa: BLE001 - 基盤ライブラリの例外を外に漏らさない
            # 発散して有限でない値が生じた場合など、基盤ライブラリは例外を送出する。
            # 素通しすると 1 件の入力でバッチ全体が落ちる（要件 6.4）。
            return _not_converged(
                f"最小二乗を完了できなかった（{type(error).__name__}: {error}）。",
                initial_values,
            )

        if not result.success:
            return _not_converged(
                f"最小二乗が収束しなかった（{result.message}）。", initial_values
            )

        estimates = _estimates(method, result)
        y_fit, shape_mismatch = _fitted_values(series, result)
        if shape_mismatch is not None:
            # 利用者定義関数が 1 点 1 値を返さない場合（要件 3.3）。呼び出し側では防げず、
            # 例外にすると 1 件の関数定義でバッチ全体が落ちる（要件 6.4）。
            return _not_converged(shape_mismatch, initial_values)

        # 有限でない結果は失敗として返す。適合度の算出はこれを素通しするため、ここで
        # 止めなければ NaN や無限大が指標として出力される
        # （:func:`~curvefit.engines.base.compute_goodness` の規約）。
        diverged = [e.name for e in estimates if not math.isfinite(e.value)]
        if diverged:
            return _not_converged(
                f"推定値が有限でない値に発散した（{', '.join(diverged)}）。", initial_values
            )
        if not bool(np.all(np.isfinite(y_fit))):
            return _not_converged("当てはめ値に有限でない値が含まれる。", initial_values)

        # 補われた既定値は解決済みモデルが運んでくる（要件 5.4）。多項式の次数のように
        # モデル実体の組み立てに要る選択肢は、解決の時点で既定値が消費されており、
        # ここでは補われた事実を観測できない。値を作らずそのまま中継する。
        return EngineSuccess(
            parameters=estimates, y_fit=y_fit, applied_defaults=method.applied_defaults
        )
