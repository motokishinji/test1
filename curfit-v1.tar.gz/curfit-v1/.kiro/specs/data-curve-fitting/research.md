# Research & Design Decisions

## Summary

- **Feature**: `data-curve-fitting`
- **Discovery Scope**: New Feature（グリーンフィールド。既存実装コードなし）
- **Key Findings**:
  - lmfit は要件 3・4 が求める機能（名前付きパラメータ、上下限、固定、組込モデルの初期値自動推定、数式文字列モデル、標準誤差）をほぼそのまま提供する。自前実装すると要件 4 の大半を再発明することになる
  - lmfit が依存する asteval には sandbox escape の既知脆弱性（GHSA-vp47-9734-prjw、1.0.5 以下）があり 1.0.6 で修正済み。lmfit 自身の下限は `asteval>=1.0` と緩いため、本プロジェクト側で `>=1.0.6` を明示的に固定する必要がある
  - matplotlib を数百件のループで使うとバックエンド次第でメモリが線形増加する事例が報告されている。要件 10 の「数百件を数分以内」を満たすには Agg バックエンドの明示と Figure の再利用・明示的解放が設計上の必須事項になる
  - `tomllib` が Python 3.11 以降の標準ライブラリに含まれるため、設定ファイル形式に TOML を選べば依存を増やさずに要件 8.1 を満たせる
  - 入力ファイルの走査順は OS・ファイルシステム依存であり、ソートを設計に組み込まないと要件 8.2（同一設定・同一入力で同一結果）が出力行順のレベルで破れる

## Research Log

### 非線形最小二乗フィットの実装基盤（lmfit vs 素の scipy）

- **Context**: 要件 4 が初期値の自動推定・明示指定、パラメータ上下限、特定パラメータの固定を要求している。要件 7.1 は標準誤差を要求している。これらを `scipy.optimize.curve_fit` だけで実現できるかの判断が必要だった
- **Sources Consulted**:
  - [lmfit-py 公式ドキュメント / Model interface](https://lmfit.github.io/lmfit-py/model.html)
  - [lmfit Parameter and Parameters](https://lmfit.github.io/lmfit-py/parameters.html)
  - [lmfit Built-in Fitting Models](https://lmfit.github.io/lmfit-py/builtin_models.html)
  - [scipy.optimize.curve_fit マニュアル](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html)
  - [lmfit-py pyproject.toml](https://raw.githubusercontent.com/lmfit/lmfit-py/master/pyproject.toml)
- **Findings**:
  - lmfit の `Parameter` は `name` を持ち、`vary` 属性で固定/変動を切り替えられ、`min` / `max` で上下限を設定できる。要件 4.4・4.5 に直接対応する
  - 組込モデル（Gaussian、Exponential、Polynomial 等）は `guess()` メソッドを持ち、データから妥当な初期値を推定する。要件 4.1 が求める「組込モデルのみ初期値を自動推定」という区別は、lmfit の `guess()` の有無とそのまま一致する
  - `curve_fit` も `bounds` は扱えるが、パラメータは位置引数の配列であり名前を持たない。個別パラメータの固定は関数を再定義するか `functools.partial` で包む必要があり、パラメータ名を結果の識別子に使う要件 3.5 とも噛み合わない
  - `curve_fit` の標準誤差は `perr = np.sqrt(np.diag(pcov))` で得られるが、ヤコビアンがフルランクでない場合 `lm` 法は `inf` 行列を返す。lmfit は `uncertainties` 経由で stderr を提供し、算出不能な場合は `None` になる
  - lmfit 依存関係: `requires-python >= 3.10`、`numpy>=2.0.0`、`scipy>=1.14.0`、`asteval>=1.0`、`uncertainties>=3.2.2`、`dill>=0.3.4`。ライセンスは BSD-3-Clause
- **Implications**: lmfit を採用する。要件 4 のパラメータ制御と要件 7.1 の不確かさは lmfit の機能をそのまま境界として使い、本プロジェクトは設定からの変換と結果の正規化のみを担う

### 数式文字列の解釈と安全性

- **Context**: 要件 3.2 が「数式を文字列として指定し、未知記号をパラメータとして扱う」ことを求めている。文字列を式として評価する以上、任意コード実行の可否を確認する必要があった
- **Sources Consulted**:
  - [asteval リポジトリ](https://github.com/lmfit/asteval)
  - [ASTEVAL: Motivation](https://lmfit.github.io/asteval/motivation.html)
  - [GHSA-vp47-9734-prjw: Malicious Tampering of Exposed AST Nodes Leads to Sandbox Escape](https://github.com/lmfit/asteval/security/advisories/GHSA-vp47-9734-prjw)
- **Findings**:
  - lmfit の `ExpressionModel` は asteval で式を評価する。asteval は `ast` モジュールベースの制限付きインタプリタで、`getattr`/`setattr`、`import`、`class` 文などを禁止しており `eval()` より安全
  - ただし作者自身が「完全に安全であることは保証できない」と明記している
  - GHSA-vp47-9734-prjw（CVSS 8.4 High）は `on_attribute` の TOCTOU により `Procedure` オブジェクトの AST を書き換えてサンドボックスを脱出できる脆弱性。**1.0.5 以下が影響、1.0.6 で修正**。攻撃条件は「asteval への入力を攻撃者が制御できること」
  - asteval のドキュメントは 2025-12 時点で 1.0.8 が確認できる
- **Implications**:
  - 依存下限を `asteval>=1.0.6` として固定する。lmfit の `asteval>=1.0` に任せると脆弱版が解決されうる
  - 脅威モデルを設計に明記する。設定ファイルは実行者自身が記述する前提であり信頼境界の内側にある。第三者から受け取った設定ファイルをそのまま実行することは、任意コード実行と同等のリスクを持つ

### 回帰・スムージングの実装手段

- **Context**: 要件 5.1 が線形回帰・多項式回帰・スプライン・移動平均の 4 手法を要求している
- **Sources Consulted**:
  - [scipy.interpolate.UnivariateSpline](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.UnivariateSpline.html)
  - [scipy.interpolate.make_smoothing_spline](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.make_smoothing_spline.html)
  - [SciPy Smoothing splines チュートリアル](https://docs.scipy.org/doc/scipy/tutorial/interpolate/smoothing_splines.html)
- **Findings**:
  - `UnivariateSpline` は legacy 扱いとなり、今後の更新予定がない。新規コードには `make_splrep` / `make_smoothing_spline` が推奨されている
  - `make_smoothing_spline` は GCV 基準による平滑化スプラインを構築する
  - `savgol_filter` は窓長が奇数、多項式次数が窓長未満という制約を持つ。ピーク形状を保つ平滑化に適している
  - 多項式回帰は `numpy.polynomial.Polynomial.fit` で完結し、追加依存を必要としない
- **Implications**: スプラインは `make_smoothing_spline` を採用し、legacy API は使わない。要件 5.4 が求める「必須設定が未指定なら既定値を適用して記録」は、`savgol_filter` の窓長・次数制約の検証と組み合わせて実装する

### バッチ実行時のグラフ生成の負荷

- **Context**: 要件 7.4 がグラフ画像を既定出力とし、要件 10.1・10.2 が数百件を数分以内に処理することを求めている。両者が同時に成立するかの確認が必要だった
- **Sources Consulted**:
  - [matplotlib issue #20300: Memory leak in plt.close()](https://github.com/matplotlib/matplotlib/issues/20300)
  - [matplotlib issue #27138: Memory not freed as expected after plotting heavy plot involving looping](https://github.com/matplotlib/matplotlib/issues/27138)
  - [Handling Memory Leaks in Matplotlib](https://www.geeksforgeeks.org/data-visualization/handling-memory-leaks-in-matplotlib/)
- **Findings**:
  - ループ内で Figure を生成・保存・close しても、バックエンドによってはプロセスのメモリが反復ごとに増加する報告が複数ある
  - 大きな Figure を繰り返し生成する夜間バッチが 60GB の RAM を消費した実例が報告されている
  - `matplotlib.use("Agg")` に切り替えるとメモリ挙動が正常化した事例が複数ある
  - `plt.close()` に加えて明示的な `gc.collect()` を併用するのがバッチ処理での定石とされている
- **Implications**:
  - プロット担当モジュールのインポート時点で Agg バックエンドを強制する
  - Figure をジョブごとに作らず 1 つ再利用し、内容をクリアして描き直す
  - 要件 10.3（リソース制約で継続不能）は理論上の懸念ではなく、この経路で現実に起こりうる。性能テストにメモリ頭打ちの確認を含める

### 設定ファイル形式

- **Context**: 要件 8.1 が実行条件を設定ファイルとして記述可能にすることを求めている
- **Sources Consulted**:
  - [tomllib — Parse TOML files（Python 公式ドキュメント）](https://docs.python.org/3/library/tomllib.html)
  - [Python 3.11 Preview: TOML and tomllib](https://realpython.com/python311-tomllib/)
- **Findings**:
  - `tomllib` は Python 3.11 で標準ライブラリに追加され、TOML 1.0.0 のパースに対応する。書き込みは非対応
  - `tomllib.load()` はバイナリモードで開いたファイルオブジェクトを要求する
  - 3.10 以下では `tomli` がバックポートとして使える
- **Implications**: 設定ファイルは TOML とし `tomllib` で読む。追加依存が発生しない。ただし Python 3.11 以上が前提になる（lmfit の下限 3.10 より厳しい方を採用）

### 再現性を破る要因の洗い出し

- **Context**: 要件 8.2 が「同一の設定ファイルと同一の入力データで再実行したとき同一の推定結果を返す」ことを求めている。何が再現性を破るかを設計前に特定する必要があった
- **Findings**:
  - `glob` / `Path.iterdir` の返す順序はファイルシステム依存であり保証されない。ジョブの実行順が変われば、サマリ CSV の行順とログの記録順が実行ごとに変わる
  - lmfit の最小二乗は初期値が同一なら決定的。組込モデルの `guess()` もデータのみに依存する決定的な処理であり、乱数を使わない
  - 外れ値除去を残差に基づく反復で行う場合、収束条件（最大反復回数と閾値）を固定しなければ結果が揺れうる
  - 浮動小数点演算の結果は BLAS 実装やライブラリのバージョンに依存しうるため、「同一環境で」という前提が必要
- **追記（タスク 8.2 の検証で判明）**: `scipy.interpolate.make_smoothing_spline` の GCV による平滑化パラメータ探索は、呼び出しごとに 2 つの状態のいずれかに倒れる。**同一プロセス内でも揺れる**（当初「プロセス間のみ」と記していたが誤り）。RMSE の絶対差は 6e-14〜2e-12。サマリ CSV を有効数字 10 桁に丸めても、値が境界付近にあれば表記が変わるため再現性は担保されない（実測: 462 データ中 5 件、12 回実行で summary.csv が 2 種類）。`lam` を明示すると直接解法となり完全に一致する
- **Implications**:
  - 入力の走査結果は必ずソートしてからジョブ展開する。これを設計上の明示的な決定として記録する
  - 外れ値除去の反復回数上限と閾値を設定項目として持ち、既定値を実行条件に記録する
  - 実行条件にツール自身と主要ライブラリのバージョンを記録し、環境差を後から判別できるようにする

### 除外した点の報告先（要件 2.5）

- **Context**: 外れ値と判定した点の x が、どの出力ファイルにも載っていなかった。`PreprocessReport.outlier_x` は正しく埋まるが `writers` が一度も読んでいない。CLI だけを使う利用者は件数しか知れず、入力 CSV と曲線 CSV を突き合わせて再構成するしかなかった
- **Findings**:
  - サマリ CSV は 1 行 1 パラメータの long 形式であり、可変長の値列を載せられない
  - **曲線 CSV に混ぜる案を検討したが退けた。** 設計レビューで 2 つの欠陥が実測で判明した
    - 曲線 CSV は**成功した処理単位にしか書かれない**（`pipeline._apply_outputs` が `FitSuccess` を受け取る）。外れ値を除いた結果として点数不足で落ちる場合を再現したところ、`n_dropped_outlier=1` / `outlier_x=(5.0,)` は記録されるのに曲線 CSV は存在しなかった。**x を最も知りたい場面で届かない**
    - 曲線 CSV はオプトインである（要件 7.5）。外れ値除去だけを有効にした利用者に届けるには自動有効化が要るが、1 万行 1 件で 740 KiB、要件 10.1 の上限規模（500 件）で **361 MiB** が利用者の指定なく生じる（実測）。`writers.py` はオプトインの理由を「数百件規模でファイル数とサイズが膨れ上がるため」と明記しており、その判断を打ち消す
  - **専用 CSV にすると設計が単純になる。** 除外点だけを並べるため、曲線の行と合流させる必要がなくなる。位置による突き合わせ（区間外・無効値の除去後の添字を追跡する仕組み）が丸ごと不要になり、曲線 CSV の列構成も変えずに済む。`CURVE_COLUMNS` を契約として写している検査 5 ファイルに手を入れる必要もない
  - 規模の問題も消える。1 万行の入力で数点が除外される通常の場合、数百バイトに収まる
  - `_remove_outliers` は既に除去順（反復順、反復内では入力順）で返しており、順序は入力だけで決まる（要件 8.2）。並べ替えの規則を新たに決める必要がない
- **Implications**:
  - `{output_dir}/preprocess/{stem}.csv` を新設し、**成否によらず**除外が 1 点以上あれば書く
  - 「出力物を書き出すのは成功した場合に限る」という既存の規則から外れる唯一の出力になる。図と曲線 CSV は**当てはめの結果**だが、前処理 CSV は**前処理が何をしたかの説明**であり、当てはめの成否とは独立に成立する
  - `outlier_x`（x のみ）を `outlier_points`（x・実測値・反復回数）に置き換える。実測値がないと利用者は元データを引かなければ判断できない。反復回数を持つのは、1 回目で外れた点と 3 回目で外れた点が同じ確かさではないためである
  - 除外 0 件の処理単位はファイルを作らない。存在そのものが「この対象には除外があった」を意味する形にする

## Architecture Pattern Evaluation

| Option | Description | Strengths | Risks / Limitations | Notes |
|--------|-------------|-----------|---------------------|-------|
| 単方向レイヤ構成（採用） | 型 → 手法 → 入出力 → 設定 → パイプライン → API → CLI の一方向依存 | steering の依存方向規則をそのまま表現できる。ライブラリが CLI を知らない構造を静的に保てる | レイヤ数が増えると迂回が起きやすい | structure.md の「出力 → 当てはめ → 入力 の逆流を避ける」に一致 |
| ヘキサゴナル（ポート＆アダプタ） | 当てはめコアをポートで包み、入出力をアダプタ化 | 入力形式・出力形式の追加に強い | 現要件の入力は 3 経路・出力は 4 種で固定。ポート層が実装 1 つに対する空の間接層になる | 却下。design-synthesis の Simplification に反する |
| プラグイン方式のモデル登録 | entry_points で外部からモデルを追加可能にする | 拡張性が高い | 要件はモデル指定の 3 経路のみを要求しており、外部配布モデルの要求はない | 却下。辞書ベースのレジストリで足りる |
| ジョブ並列実行 | multiprocessing でファイル単位に並列化 | 大規模バッチで高速 | 要件 10 の規模（数百件）は逐次で目標を満たせる見込み。ログ順序と失敗集約が複雑化し、要件 8.2 の再現性検証も難しくなる | 現時点では却下。規模が桁で増えた場合の再検討事項として記録 |

## Design Decisions

### Decision: 非線形フィットの基盤に lmfit を採用する

- **Context**: 要件 4 のパラメータ制御（自動初期値・明示初期値・上下限・固定）と要件 7.1 の標準誤差を、どの基盤の上に構築するか
- **Alternatives Considered**:
  1. `scipy.optimize.curve_fit` / `least_squares` の上に独自のパラメータ管理層を構築する
  2. lmfit を採用し、その `Model` / `Parameters` を内部の共通表現として使う
- **Selected Approach**: 2 を採用。設定から lmfit の `Parameters` を組み立てる変換層と、lmfit の `ModelResult` を本プロジェクトの結果型に正規化する層のみを自作する
- **Rationale**: 名前付きパラメータ、`vary=False` による固定、`min`/`max` による制約、組込モデルの `guess()` はいずれも要件と 1 対 1 で対応する。1 を選ぶとこれらをすべて再実装することになり、しかも要件 3.5（パラメータ名を結果の識別子とする）と `curve_fit` の位置引数配列は構造的に噛み合わない
- **Trade-offs**: 依存が増える（lmfit + asteval + uncertainties + dill）。lmfit の `Model` クラスが内部表現として広く漏れると差し替えが困難になるため、公開 API の型には lmfit の型を露出させない
- **Follow-up**: 実装時に stderr が `None` になる条件（ヤコビアン不足）を確認し、サマリ CSV での空欄表現を決める

### Decision: モデル関数フィットと回帰・スムージングを単一の当てはめ抽象に統合する

- **Context**: 要件 5.2 が「モデル関数フィットと同一の入力指定・出力指定の手順で実行する」ことを明示的に求めている
- **Alternatives Considered**:
  1. 2 種類を別系統として実装し、CLI とライブラリでそれぞれ入口を分ける
  2. 「データ系列 + 手法指定 → 予測値・任意のパラメータ・適合度」という 1 つの契約に統合し、2 種類をその実装として並べる
- **Selected Approach**: 2 を採用。`FitEngine` プロトコルを定義し、最小二乗エンジンと平滑化エンジンを実装として並置する
- **Rationale**: 要件 5.2・5.3 は「同じ手順」「同じ形式」を要求しており、これは設計上 2 つが同一問題の変種であることの宣言に等しい。統合しておけば、前処理・バッチ展開・出力・ログの各層は手法の違いを知らずに済む
- **Trade-offs**: 平滑化はパラメータを持たない場合があるため、結果型のパラメータ配列が空になるケースを許容する必要がある
- **Follow-up**: 移動平均・スプラインで適合度指標（R²、RMSE）をどう定義するかを実装時に確定する（残差ベースで統一する方針）

### Decision: 入力の多重性とモデルの多重性を単一のジョブ展開に一般化する

- **Context**: 要件 6.1（複数ファイル）と要件 6.2（同一データに複数モデル）が別々の受入基準として存在する
- **Alternatives Considered**:
  1. ファイルのループとモデルのループを別々に実装する
  2. 入力集合とモデル集合の直積を「ジョブ一覧」として先に展開し、以降は 1 種類のループで処理する
- **Selected Approach**: 2 を採用
- **Rationale**: 進捗表示（6.3）、失敗のスキップ（6.4）、fail-fast（6.5）、成功/失敗サマリ（6.6）はいずれもジョブ単位で定義できる。直積に展開しておけば、これらを 1 か所で実装でき、ファイル軸とモデル軸で挙動が食い違う余地がなくなる
- **Trade-offs**: ジョブ数が入力数 × モデル数になるため、進捗の分母が利用者の直感（ファイル数）とずれる。進捗表示にはジョブ数とファイル数の両方を出す
- **Follow-up**: 出力ファイル名にモデル名を含める規則を writers 側で確定する（要件 7.6 の衝突回避）

### Decision: 実行前検証と実行中失敗を明確に分離する

- **Context**: 要件には「処理を開始せず報告する」種類のエラー（5.5、7.7、8.5、3.4、4.3、4.6）と「当該データを失敗として記録して継続する」種類のエラー（1.4、1.5、2.4、4.7）が混在している
- **Selected Approach**: 設定・モデル・出力先に関する検証をすべて実行前ゲート（pre-flight）に集約し、1 件でも違反があればジョブを 1 つも実行せずに終了する。データ個別の失敗は例外ではなく結果値（`FitFailure`）として運び、集約する
- **Rationale**: 数百件のバッチにおいて、設定ミスは全件に等しく影響するため即座に止めるのが正しい。一方、データ個別の問題で全体を止めると要件 6.4 の意図（1 件の失敗で数百件の実行を無駄にしない）に反する。この 2 つを同じ例外機構で扱うと境界が曖昧になる
- **Trade-offs**: 入力ファイルごとに列構成が異なる場合、列の欠損は実行前に検出できない。これは実行中失敗（1.4）として扱う
- **Follow-up**: pre-flight で検出した違反を一括提示する（最初の 1 件で止めない）

### Decision: 設定ファイル形式に TOML を採用する

- **Context**: 要件 8.1 の設定ファイル形式の選定
- **Alternatives Considered**:
  1. YAML（PyYAML 依存の追加が必要）
  2. JSON（コメントが書けず、実行条件の意図を残せない）
  3. TOML（Python 3.11 以降は標準ライブラリで読める）
- **Selected Approach**: 3 を採用し、Python の下限を 3.11 とする
- **Rationale**: 追加依存なしで要件を満たせる。コメントが書けるため、設定ファイル自体が解析手順の記録として機能し、要件 8 の属人化解消の意図に沿う。数値と文字列が明確に区別されるため、初期値や上下限の記述で型の曖昧さが生じない
- **Trade-offs**: Python 3.10 以下を切り捨てる。`tomllib` は読み込み専用のため、設定ファイルを生成する機能が将来必要になった場合は別途書き出し実装が要る
- **Follow-up**: 実行条件の記録（要件 8.3）は TOML ではなく JSON で出力する（機械可読性と追記の容易さを優先）

### Decision: ジョブ展開前に入力を必ずソートする

- **Context**: 要件 8.2 の再現性要求と、ファイルシステムの走査順が非決定的であるという調査結果
- **Selected Approach**: ディレクトリ・ワイルドカード指定から得たパス集合を、正規化した文字列としてソートしてからジョブ一覧を確定する。モデルは設定ファイルの記述順を保持する
- **Rationale**: 走査順の非決定性は推定値そのものは変えないが、サマリ CSV の行順とログの記録順を変える。「同一の結果」を出力物の同一性として検証可能にするには、順序まで決定的である必要がある
- **Trade-offs**: 利用者が意図した処理順（例: 測定順）とは異なる順序になりうる。順序が意味を持つ用途は現要件にない
- **Follow-up**: 再現性の E2E テストで、サマリ CSV がタイムスタンプ列を除いて完全一致することを検証する

### Decision: 逐次実行とし、並列化を導入しない

- **Context**: 要件 10.1・10.2 の性能目標と、要件 8.2 の再現性要求
- **Selected Approach**: ジョブを逐次実行する。並列化は行わない
- **Rationale**: 数百件 × 数千〜数万行の規模では、フィット自体はミリ秒オーダーであり、支配的なコストはグラフ描画である。Figure 再利用と Agg バックエンドで描画コストを抑えれば逐次でも数分以内に収まる見込み。並列化はログ順序・進捗表示・失敗集約・再現性検証のすべてを複雑にする
- **Trade-offs**: 規模が桁で増えた場合は目標を満たせなくなる
- **Follow-up**: 性能テストで実測し、目標を超える場合はグラフ出力の既定値（要件 7.4）を含めて要件側の再検討に戻す

## Risks & Mitigations

- **asteval 経由の任意コード実行** — 依存下限を `asteval>=1.0.6` に固定し、既知の sandbox escape を解決対象から外す。設定ファイルは実行者自身が用意する前提であることをドキュメントに明記し、第三者由来の設定ファイルをそのまま実行しないよう警告する
- **matplotlib のメモリ増加によるバッチ中断** — Agg バックエンドを強制し、Figure を再利用し、明示的に解放する。性能テストにメモリ頭打ちの検証を含める。要件 10.3 の経路として実際に到達しうる前提で設計する
- **性能目標の未達** — グラフ描画が支配的コストであるため、実測が目標を超える場合はグラフ出力の既定値そのものが要件レベルの再検討対象になる。設計段階で並列化に逃げない
- **lmfit の型が内部に漏れる** — 公開 API の入出力型には lmfit の型を露出させない。`ModelResult` はエンジン層の内部で本プロジェクトの結果型に正規化する
- **平滑化手法での適合度指標の意味の希薄化** — R² と RMSE は残差ベースで機械的に算出するが、移動平均のように自由度が定義しにくい手法では解釈が異なる。出力に手法名を必ず併記し、指標だけが独り歩きしないようにする
- **stderr が算出できないケース** — ヤコビアンがフルランクでない場合、標準誤差は得られない。要件 7.1 は標準誤差を要求しているが、算出不能を失敗として扱うと過剰に厳しい。空値として出力し、その旨をログに残す方針とする

## References

- [lmfit-py 公式ドキュメント](https://lmfit.github.io/lmfit-py/) — 採用する基盤ライブラリの契約
- [lmfit Built-in Fitting Models](https://lmfit.github.io/lmfit-py/builtin_models.html) — 組込モデルと `guess()` の対応表
- [lmfit-py pyproject.toml](https://raw.githubusercontent.com/lmfit/lmfit-py/master/pyproject.toml) — 依存関係とサポート Python バージョンの一次情報
- [GHSA-vp47-9734-prjw](https://github.com/lmfit/asteval/security/advisories/GHSA-vp47-9734-prjw) — asteval の sandbox escape。1.0.6 で修正
- [ASTEVAL: Motivation](https://lmfit.github.io/asteval/motivation.html) — asteval の安全性の範囲と限界に関する作者の記述
- [scipy.optimize.curve_fit](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html) — 却下した代替案の一次情報
- [scipy.interpolate.make_smoothing_spline](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.make_smoothing_spline.html) — スプライン平滑化の推奨 API
- [SciPy Smoothing splines チュートリアル](https://docs.scipy.org/doc/scipy/tutorial/interpolate/smoothing_splines.html) — `UnivariateSpline` が legacy である旨の記述
- [tomllib（Python 公式ドキュメント）](https://docs.python.org/3/library/tomllib.html) — 設定ファイル読み込みの標準手段
- [matplotlib issue #27138](https://github.com/matplotlib/matplotlib/issues/27138) — ループ描画時のメモリ非解放の報告
