# Project Structure

## Organization Philosophy

**仕様駆動。** すべての機能は `.kiro/specs/{feature}/` の requirements → design → tasks を経てから実装される。`.kiro/steering/` はプロジェクト横断の前提、spec は個別機能についての合意。両者が食い違ったら steering を更新して先に整合させる。

コードは関心の分離で構成する。要件が課している分離は次の 3 軸:

- **フィッティングのロジック（ライブラリ）** ↔ **コマンドラインの配線（CLI）**
- **データの取得**（読み込み・前処理） ↔ **当てはめ**（フィット・回帰） ↔ **結果の出力**（CSV・画像・ログ）
- **モデルの定義** ↔ **モデルの実行**

**理由**: モデルを 1 つ増やすときはモデル定義だけを、入力形式を 1 つ増やすときは読み込みだけを触れば済む状態を保つため。要件上、モデル種別も入力経路も出力形式も今後増える前提になっている。

## Directory Patterns

### 仕様 (`.kiro/specs/{feature}/`)
**Purpose**: 機能ごとの `requirements.md` / `design.md` / `tasks.md` と、進捗を持つ `spec.json`
**Naming**: 機能名は kebab-case（例: `data-curve-fitting`）

### プロジェクトメモリ (`.kiro/steering/`)
**Purpose**: 全 spec に共通する前提・決定・規約
**原則**: 個別機能の詳細は spec 側に置く。ここには「新しいコードが既存パターンに従う限り更新不要」な内容のみを書く

### 実装コード (`src/{package}/`)
**Purpose**: ライブラリ本体。1 モジュール 1 責務で、**依存が一方向に流れる層**として並べる

`data-curve-fitting` で確定した並びは次のとおり。各モジュールは **左側からのみ import する**。

```
errors → types → models → preprocess → engines
      → readers / writers / plotting / execution / logging_setup
      → config → preflight → pipeline → api → cli
```

読み方は「後ろほど文脈を多く知る」。`types` は何も知らず、`cli` はすべてを知る。
**ライブラリ側のモジュールが `cli` を import してはならない。**

外部ライブラリも 1 モジュールに閉じる（pandas は `readers`、matplotlib は `plotting`、
lmfit は `models`、SciPy は `engines.smoothing`、`tomllib` は `config`）。閉じ込めが崩れると、
差し替えの影響範囲が読めなくなる。

### テストコード (`tests/`)
**Purpose**: 単体 / 統合 / E2E / 性能の 4 層。層ごとに「何が壊れたか」の粒度を変える

- `unit/` — モジュール 1 つの契約
- `integration/` — 層をまたぐ結線（`api` → `pipeline` → `engines` など）
- `e2e/` — **導入済みのコンソールスクリプトを別プロセスで起動する。** `curvefit` を import しない
- `performance/` — 規模と応答性。全規模は `performance` マーカーで既定から除外し、安価な見張りだけを既定に残す

## Naming Conventions

- **モジュール・パッケージ**: snake_case
- **関数・変数**: snake_case / **クラス**: PascalCase / **定数**: UPPER_SNAKE_CASE
- **spec の機能名**: kebab-case
- **利用者に見える名前**（組込モデル名、設定ファイルのキー、CLI オプション）: 英小文字。**要件で定めた語をそのまま使い、実装都合で言い換えない**。要件・設計・実装・出力・ドキュメントで同じ概念が別名になると、再現性の追跡が崩れる

## Import Organization

```python
# 1. 標準ライブラリ
from pathlib import Path

# 2. サードパーティ
import numpy as np

# 3. 自パッケージ（絶対 import を既定とする）
from <package>.models import ...
```

グループ間は空行で区切る。

**依存の向きの規則**: CLI モジュールはライブラリを import してよいが、**ライブラリが CLI モジュールを import してはならない**。この向きが逆転すると、ライブラリ単体での利用（要件 9）が壊れる。

## Code Organization Principles

- **依存の逆流を避ける** — 出力は当てはめを、当てはめは入力を知ってよいが、その逆は持たない
- **実行条件は 1 か所に集約する** — 利用者が指定できるもの（モデル、初期値、パラメータ制約、前処理、出力設定）は単一の実行条件として扱う。設定ファイル読み込み・CLI 引数の上書き・結果への記録・再実行がすべて同じ表現の上で成立する必要があるため、指定項目を各所に散らさない
- **数値計算の内側と外側を混ぜない** — ファイル走査、設定解決、ログ出力といった副作用は外側に置き、推定そのものは入出力を持たない計算として保つ。合成データによる検証（tech.md 参照）はこの分離に依存する
- **失敗は値として運ぶ** — バッチは既定で失敗をスキップして継続するため、個別の失敗は処理全体を止める例外ではなく、対象と理由を持つ結果として集約できる形で扱う

## Documentation Conventions

- `.kiro/specs/` 配下の Markdown は `spec.json.language` の言語で書く（本プロジェクトは日本語）
- `.kiro/steering/` も日本語で記述する
- コード内の識別子は英語。docstring・コメントは日本語で可（利用者・開発者ともに日本語話者を想定）

## Current Status

`data-curve-fitting` の実装が完了し、上記の構成が実在する。

**依存方向は各モジュールの単体テストが自分で検査する**（`Test依存の露出`）。逆流を持ち込むと
赤くなることを実測で確認してある。1 か所にまとめた検査ではなく、モジュールごとに「自分が
何に依存してよいか」を持つ形である。新しいモジュールを足すときは、この検査も一緒に足す。

---
_Document patterns, not file trees. New files following patterns shouldn't require updates_
