"""ジョブ展開と決定的な実行順序の統合テスト（要件 6.1、6.2、8.2）。

本テストは `curvefit.pipeline.expand_jobs` が次を満たすことを検証する。

- **直積**: 入力集合 × 手法集合を処理単位の一覧に展開すること。3 入力 × 2 手法が
  6 件になり、複数ファイル処理（要件 6.1）と複数手法の適用（要件 6.2）が
  ファイル軸・手法軸で分岐しない単一の経路で扱われること
- **決定的な順序**: 同じファイル集合であれば、**指定の与え方によらず** 常に同一の
  ジョブ列になること（要件 8.2）。`glob` と `Path.iterdir` の返す順序は
  ファイルシステム依存であり保証されない（`research.md` の「再現性を破る要因の
  洗い出し」）。ソートしなければ、推定値そのものは同一でもサマリ CSV の行順と
  実行ログの記録順が実行ごとに変わり、要件 8.2 が出力物の水準で破れる
- **手法の順序**: 設定の記述順を保つこと。ソートしない
- **重複の排除**: ディレクトリ指定とワイルドカードが同じファイルを指しても、
  1 ファイルにつき手法ごとに 1 件だけ処理すること
- **存在確認をしない**こと。存在しないファイルの直接指定もジョブになり、
  要件 1.4/1.5 の個別失敗として扱われる

本テストが対象とするのはタスク 7.1 の範囲、すなわち `Job` 型と `expand_jobs` に限る。
1 件の実行（7.2）とバッチ制御（7.3）は対象外である。

設計の Testing Strategy が `pipeline` の結線を統合テストに置いているため、単体では
なく `tests/integration/` に置く。
"""

from __future__ import annotations

import ast
import os
import stat
import subprocess
import sys
from dataclasses import FrozenInstanceError, fields
from pathlib import Path

import pytest

from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.pipeline import Job, expand_jobs, expand_sources
from curvefit.preprocess import PreprocessSpec
from curvefit.readers import ColumnSpec
from curvefit.writers import build_output_stem

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src" / "curvefit"

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
"""root は権限ビットを無視して読めるため、読み取り不能の検証が成立しない。"""

requires_permission_bits = pytest.mark.skipif(
    IS_ROOT, reason="root では権限ビットによる読み取り不能を再現できない"
)

ZETA = MethodSpec(name="zeta", kind="builtin", builtin="gaussian")
ALPHA = MethodSpec(name="alpha", kind="smoother", smoother=SmootherKind.LINEAR)
"""手法の順序が記述順であることを示すための 2 件。

**名前の辞書順と記述順が食い違う** ように選んである。`("zeta", "alpha")` の順で
渡したとき結果が `("alpha", "zeta")` になれば、手法をソートしていることが分かる。
"""

ORDER_SCRIPT = '''
import sys
from pathlib import Path

from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.pipeline import expand_jobs
from curvefit.preprocess import PreprocessSpec
from curvefit.readers import ColumnSpec

base = Path(sys.argv[1])
config = RunConfig(
    inputs=InputSpec(
        paths=(str(base / "data"), str(base / "data" / "*.csv"), str(base / "other" / "z.tsv")),
        columns=ColumnSpec(x="time", y="signal"),
    ),
    methods=(
        MethodSpec(name="zeta", kind="builtin", builtin="gaussian"),
        MethodSpec(name="alpha", kind="smoother", smoother=SmootherKind.LINEAR),
    ),
    preprocess=PreprocessSpec(),
    output=OutputSpec(directory=base / "out"),
)
for job in expand_jobs(config):
    print(job.index, Path(job.source).name, job.method.name, sep="\\t")
'''
"""別プロセスでジョブの並びを書き出す小さな台本。

`PYTHONHASHSEED` を変えて実行し、出力が一致することで、重複排除に用いる集合の
走査順に依存していないことを示す（要件 8.2）。
"""


def _config(
    paths: tuple[str, ...],
    *,
    methods: tuple[MethodSpec, ...] = (ZETA, ALPHA),
    directory: Path | None = None,
) -> RunConfig:
    """展開対象の実行条件を組み立てる。入力指定と手法一覧以外は既定で埋める。"""
    return RunConfig(
        inputs=InputSpec(paths=paths, columns=ColumnSpec(x="time", y="signal")),
        methods=methods,
        preprocess=PreprocessSpec(),
        output=OutputSpec(directory=directory if directory is not None else Path("out")),
    )


def _make(directory: Path, *names: str) -> None:
    """入力ファイルを作る。中身は読まないため空でよい（本タスクは読み込みを行わない）。"""
    directory.mkdir(parents=True, exist_ok=True)
    for name in names:
        (directory / name).write_text("", encoding="utf-8")


def _names(jobs: tuple[Job, ...]) -> list[tuple[str, str]]:
    """対象のファイル名と手法名の組。異なる一時ディレクトリ間で比較するための射影。"""
    return [(Path(job.source).name, job.method.name) for job in jobs]


class Test直積の展開:
    """要件 6.1、6.2: 入力集合 × 手法集合を単一の一覧として扱う。"""

    def test_3入力かける2手法が6件になる(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert len(jobs) == 6

    def test_ジョブ番号が0起点の連番で最終順序に一致する(self, tmp_path: Path) -> None:
        """`build_output_stem` が番号を出力名に使うため、番号は最終順序で確定する（要件 7.6）。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert [job.index for job in jobs] == list(range(len(jobs)))

    def test_同一対象の手法が隣り合う(self, tmp_path: Path) -> None:
        """要件 6.2: モデルごとの結果を横並びで比較できるよう、対象を外側の軸にする。"""
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert _names(jobs) == [
            ("a.csv", "zeta"),
            ("a.csv", "alpha"),
            ("b.csv", "zeta"),
            ("b.csv", "alpha"),
        ]

    def test_手法の順序は記述順を保つ(self, tmp_path: Path) -> None:
        """手法はソートしない（要件 8.2 の決定性は記述順の保存で満たす）。"""
        _make(tmp_path / "data", "a.csv")

        forward = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA, ALPHA)))
        backward = expand_jobs(_config((str(tmp_path / "data"),), methods=(ALPHA, ZETA)))

        assert [job.method.name for job in forward] == ["zeta", "alpha"]
        assert [job.method.name for job in backward] == ["alpha", "zeta"]

    def test_手法の指定をそのまま持つ(self, tmp_path: Path) -> None:
        """解決前の指定をそのまま運ぶ。ジョブごとの解決は 7.2 の担当である。"""
        _make(tmp_path / "data", "a.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert jobs[0].method is ZETA

    def test_入力が0件ならジョブも0件(self, tmp_path: Path) -> None:
        """ディレクトリにファイルが無い場合は正常な空の実行（設計の Risks）。"""
        (tmp_path / "data").mkdir()

        assert expand_jobs(_config((str(tmp_path / "data"),))) == ()

    def test_ジョブ番号から一意な出力名が得られる(self, tmp_path: Path) -> None:
        """要件 7.6: 別ディレクトリの同名ファイルでも出力が互いを上書きしない。"""
        _make(tmp_path / "run1", "sample.csv")
        _make(tmp_path / "run2", "sample.csv")

        jobs = expand_jobs(_config((str(tmp_path / "run1"), str(tmp_path / "run2"))))
        stems = {build_output_stem(job.source, job.method.name, job.index) for job in jobs}

        assert len(stems) == len(jobs) == 4


class Test決定的な順序:
    """要件 8.2: 同じファイル集合なら、与え方によらず常に同一のジョブ列になる。"""

    def test_指定の並びを変えても同一になる(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")
        forward = tuple(str(tmp_path / "data" / name) for name in ("a.csv", "b.csv", "c.csv"))
        backward = tuple(reversed(forward))

        assert expand_jobs(_config(forward)) == expand_jobs(_config(backward))

    def test_ディレクトリと明示列挙とワイルドカードが同一になる(self, tmp_path: Path) -> None:
        """走査経路が違っても、同じファイル集合なら同じジョブ列になる。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")
        listed = tuple(str(tmp_path / "data" / name) for name in ("c.csv", "a.csv", "b.csv"))

        by_directory = expand_jobs(_config((str(tmp_path / "data"),)))
        by_list = expand_jobs(_config(listed))
        by_wildcard = expand_jobs(_config((str(tmp_path / "data" / "*.csv"),)))

        assert by_directory == by_list == by_wildcard
        assert len(by_directory) == 6

    def test_ファイルの作成順に依存しない(self, tmp_path: Path) -> None:
        """`Path.iterdir` の返す順序はファイルシステム依存である（research.md）。"""
        _make(tmp_path / "forward", "a.csv", "b.csv", "c.csv")
        _make(tmp_path / "backward", "c.csv", "b.csv", "a.csv")

        forward = expand_jobs(_config((str(tmp_path / "forward"),)))
        backward = expand_jobs(_config((str(tmp_path / "backward"),)))

        assert _names(forward) == _names(backward)
        assert [name for name, _ in _names(forward)] == [
            "a.csv",
            "a.csv",
            "b.csv",
            "b.csv",
            "c.csv",
            "c.csv",
        ]

    def test_冗長な表記が同一に正規化される(self, tmp_path: Path, monkeypatch) -> None:
        """`./data/a.csv` と `data/../data/a.csv` は同じ対象である。"""
        _make(tmp_path / "data", "a.csv")
        monkeypatch.chdir(tmp_path)

        plain = expand_jobs(_config(("data/a.csv",)))
        redundant = expand_jobs(_config(("./data/../data/a.csv",)))

        assert plain == redundant

    def test_相対指定も絶対パスとして展開される(self, tmp_path: Path, monkeypatch) -> None:
        """対象の識別子は絶対パスに揃える。実行位置の表記の差を出力に持ち込まない。"""
        _make(tmp_path / "data", "a.csv")
        monkeypatch.chdir(tmp_path)

        jobs = expand_jobs(_config(("data/a.csv",)))

        assert jobs[0].source == str(tmp_path / "data" / "a.csv")

    def test_ハッシュ種を変えても並びが変わらない(self, tmp_path: Path) -> None:
        """重複排除に用いる集合の走査順に依存していないことを別プロセスで確かめる。"""
        _make(tmp_path / "data", "a.csv", "b.csv")
        _make(tmp_path / "other", "z.tsv")
        script = tmp_path / "order.py"
        script.write_text(ORDER_SCRIPT, encoding="utf-8")
        outputs = set()
        for seed in ("0", "1", "12345"):
            environment = {**os.environ, "PYTHONHASHSEED": seed, "PYTHONPATH": str(ROOT / "src")}
            completed = subprocess.run(
                [sys.executable, str(script), str(tmp_path)],
                capture_output=True,
                text=True,
                env=environment,
                check=True,
            )
            outputs.add(completed.stdout)

        assert len(outputs) == 1, outputs
        assert len(outputs.pop().strip().splitlines()) == 6


class Test重複の排除:
    """同じファイルを 2 通りで指定しても、処理は 1 回だけである。"""

    def test_ディレクトリとワイルドカードの重なりを排除する(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(
            _config((str(tmp_path / "data"), str(tmp_path / "data" / "*.csv")))
        )

        assert len(jobs) == 4
        assert _names(jobs) == [
            ("a.csv", "zeta"),
            ("a.csv", "alpha"),
            ("b.csv", "zeta"),
            ("b.csv", "alpha"),
        ]

    def test_表記の違う同一ファイルを排除する(self, tmp_path: Path, monkeypatch) -> None:
        _make(tmp_path / "data", "a.csv")
        monkeypatch.chdir(tmp_path)

        jobs = expand_jobs(_config(("data/a.csv", "./data/a.csv", str(tmp_path / "data" / "a.csv"))))

        assert len(jobs) == 2

    def test_symlink_と実体を融合しない(self, tmp_path: Path) -> None:
        """正規化で symlink を解決しない。どちらも利用者が明示した別々の対象である。

        融合すると、指定したはずのファイルが結果に 1 件も現れない。重複を残す代償
        （同じ処理が 2 回走る）と釣り合わない。
        """
        _make(tmp_path / "data", "a.csv")
        link = tmp_path / "data" / "link.csv"
        try:
            link.symlink_to(tmp_path / "data" / "a.csv")
        except (OSError, NotImplementedError):  # pragma: no cover - 環境依存
            pytest.skip("この環境では symlink を作成できない")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv", "link.csv"]

    def test_同じ指定を重ねても増えない(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv")
        target = str(tmp_path / "data" / "a.csv")

        assert len(expand_jobs(_config((target, target)))) == 2


class Test入力の分類:
    """指定はファイル・ディレクトリ・ワイルドカードの 3 通りを取る（要件 6.1）。"""

    def test_存在しない明示指定もジョブになる(self, tmp_path: Path) -> None:
        """存在確認は行わない。不存在は要件 1.4/1.5 の個別失敗として扱う（設計の Risks）。"""
        jobs = expand_jobs(_config((str(tmp_path / "missing.csv"),)))

        assert len(jobs) == 2
        assert jobs[0].source == str(tmp_path / "missing.csv")

    def test_ディレクトリはデータ拡張子だけを対象にする(self, tmp_path: Path) -> None:
        """一括指定に紛れ込んだ付随ファイルを、直せない失敗として報告しない。"""
        _make(tmp_path / "data", "a.csv", "b.tsv", "c.txt", "README.md", ".DS_Store", "run.log")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv", "b.tsv", "c.txt"]

    def test_ディレクトリ指定は再帰しない(self, tmp_path: Path) -> None:
        """再帰は `**` を含むワイルドカードでの明示指定に限る。"""
        _make(tmp_path / "data", "a.csv")
        _make(tmp_path / "data" / "nested", "deep.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv"]

    def test_ワイルドカードは再帰指定を受け付ける(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv")
        _make(tmp_path / "data" / "nested", "deep.csv")

        jobs = expand_jobs(
            _config((str(tmp_path / "data" / "**" / "*.csv"),), methods=(ZETA,))
        )

        assert [name for name, _ in _names(jobs)] == ["a.csv", "deep.csv"]

    def test_ワイルドカードは拡張子で絞り込まない(self, tmp_path: Path) -> None:
        """並びを列挙したのは利用者自身であり、こちらで間引く理由がない。"""
        _make(tmp_path / "data", "a.dat")

        jobs = expand_jobs(_config((str(tmp_path / "data" / "*.dat"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.dat"]

    def test_ワイルドカードに一致したディレクトリは対象にしない(self, tmp_path: Path) -> None:
        """ディレクトリを読み込もうとすると、利用者に直しようのない失敗になる。"""
        _make(tmp_path / "data", "a.csv")
        (tmp_path / "data" / "nested").mkdir()

        jobs = expand_jobs(_config((str(tmp_path / "data" / "*"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv"]

    def test_一致のないワイルドカードは0件になる(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv")

        assert expand_jobs(_config((str(tmp_path / "data" / "*.tsv"),))) == ()

    def test_角括弧を含む実在ファイルの直接指定が対象になる(self, tmp_path: Path) -> None:
        """存在する綴りはワイルドカードより優先し、文字どおりの 1 件として扱う。

        `[` は `glob` の文字クラスの開始でもあるため、実在するファイルをパターンとして
        解釈すると一致 0 件になり、利用者が明示したファイルが何の報告もなく消える。
        測定日をファイル名に括弧書きする慣習（`[2024]run.csv`）は珍しくない。
        """
        _make(tmp_path / "data", "[2024]run.csv")
        target = tmp_path / "data" / "[2024]run.csv"

        jobs = expand_jobs(_config((str(target),)))

        assert _names(jobs) == [("[2024]run.csv", "zeta"), ("[2024]run.csv", "alpha")]
        assert jobs[0].source == str(target)

    def test_角括弧を含む実在ディレクトリの中身が展開される(self, tmp_path: Path) -> None:
        """分類はワイルドカードを先に見るため、存在確認を挟まないとディレクトリに到達しない。"""
        _make(tmp_path / "da[t]a", "x.csv")

        jobs = expand_jobs(_config((str(tmp_path / "da[t]a"),), methods=(ZETA,)))

        assert _names(jobs) == [("x.csv", "zeta")]
        assert jobs[0].source == str(tmp_path / "da[t]a" / "x.csv")

    def test_実在しない文字クラスはワイルドカードとして働く(self, tmp_path: Path) -> None:
        """存在優先はパターン解釈を止めない。実在しない綴りは従来どおり `glob` に渡る。"""
        _make(tmp_path / "data", "a1.csv", "b1.csv", "c1.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data" / "[ab]1.csv"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a1.csv", "b1.csv"]

    def test_大文字の拡張子も対象にする(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "A.CSV")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["A.CSV"]

    @requires_permission_bits
    def test_読めないディレクトリは例外になる(self, tmp_path: Path) -> None:
        """0 件として黙らせない。1 ディレクトリ分の入力が黙って消えるのは最悪の結末である。

        資源・環境の失敗であり利用者が設定で直せるものではないため、`expand_jobs` の
        返り値（ジョブ一覧）では表せない。捕捉と中断の判断はバッチ制御（7.3）が持つ。
        """
        locked = tmp_path / "locked"
        _make(locked, "a.csv")
        locked.chmod(stat.S_IWUSR | stat.S_IXUSR)
        try:
            with pytest.raises(OSError):
                expand_jobs(_config((str(locked),)))
        finally:
            locked.chmod(stat.S_IRWXU)


class Test純粋な展開:
    """設計の Responsibilities: 走査以外の入出力を持たず、実行条件を書き換えない。"""

    def test_実行条件を書き換えない(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv")
        config = _config((str(tmp_path / "data"),))
        before = config.inputs.paths

        expand_jobs(config)

        assert config.inputs.paths == before
        assert config.methods == (ZETA, ALPHA)

    def test_同じ実行条件なら何度呼んでも同じ結果(self, tmp_path: Path) -> None:
        _make(tmp_path / "data", "a.csv", "b.csv")
        config = _config((str(tmp_path / "data"),))

        assert expand_jobs(config) == expand_jobs(config)

    def test_入力の数を別に数えられる(self, tmp_path: Path) -> None:
        """進捗通知（要件 6.3）は総ジョブ数と総入力数の両方を必要とする。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")

        sources = expand_sources((str(tmp_path / "data"),))

        assert len(sources) == 3
        assert sources == tuple(sorted(sources))


class Test処理単位の型:
    """設計の Contracts: `Job` は凍結され、フィールドは index / source / method / series。"""

    def test_フィールドが設計どおり(self) -> None:
        assert tuple(field.name for field in fields(Job)) == (
            "index",
            "source",
            "method",
            "series",
        )

    def test_走査で組み立てた処理単位は系列を伴わない(self, tmp_path: Path) -> None:
        """`series` は要件 9.1 のライブラリ経路の差込口であり、走査は使わない。

        走査で系列を載せてしまうと、読み込みを省いた処理単位がファイル入力にも
        紛れ込み、`run_job` が入力の位置を読まなくなる。
        """
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert len(jobs) == 4
        assert all(job.series is None for job in jobs)

    def test_生成後に変更できない(self) -> None:
        job = Job(index=0, source="a.csv", method=ZETA)

        with pytest.raises(FrozenInstanceError):
            job.index = 1  # type: ignore[misc]

    def test_呼び出し元のラベルも対象にできる(self) -> None:
        """設計の注記どおり `source` はファイルパスに限らない（要件 1.2 のライブラリ経路）。"""
        job = Job(index=0, source="in-memory", method=ZETA)

        assert job.source == "in-memory"


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が上位層やライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse((SRC / "pipeline.py").read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class Test依存の露出:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_上位層を_import_しない(self) -> None:
        assert not (_imported_modules() & {"curvefit.api", "curvefit.cli"})

    def test_層の限られた基盤ライブラリを直接_import_しない(self) -> None:
        """pandas は readers/writers、matplotlib は plotting、lmfit と SciPy はエンジンに閉じる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval"}, (
                f"pipeline.py が {imported} を import している"
            )
