"""単一処理単位の実行を結線する統合テスト（要件 4.1、7.4、7.5）。

本テストは `curvefit.pipeline.run_job` が次を満たすことを検証する。

- **段階の連結**: 読み込み → モデル解決 → 前処理 → 当てはめ → 出力の適用を順に通し、
  成功時は結果と出力ファイルが得られること
- **読み込み済みの系列の受け取り**（要件 9.1、9.3）: 処理単位が系列を伴う場合は
  読み込みの 1 段だけを省き、以降の段階は同一の手順を通ること。省略が読み込みに
  限られることは、ファイル経由の結果と最終ビットまで一致することで示す
- **短絡**: いずれかの段階が失敗結果を返したら、以降の段階に進まずその結果を
  そのまま処理単位の結果とすること。後続の段階が走っていないことは、出力物が
  1 件も生成されないことと、後続の段階が返すはずの失敗にならないことで示す
- **処理単位ごとのモデル解決**（要件 4.1）: 組込モデルの初期値を **その対象の** データ
  から推定すること。設定解決時に一度だけ推定して使い回すと、スケールの異なるデータで
  収束が悪化することを、同一の解決済みモデルを別スケールのデータに当てた結果で示す
- **最小点数の供給**: 前処理に渡す最小点数を解決済み手法の **推定対象** パラメータ数
  から導出すること（要件 2.4 の判定材料はこの層が供給する）。固定したパラメータは
  当てはめが動かさないため数に含めない（要件 4.5）
- **適用された既定値の中継**（要件 5.4）: 当てはめが補った既定値を `JobResult` に載せて
  返すこと。どの選択肢に既定値が効いたかは当てはめが走って初めて確定するため、
  `MethodSpec` からは再計算できない
- **重みが効かない手法の記録**: 誤差列が与えられているのにスプライン・移動平均が
  選ばれた場合、その旨を実行ログに残すこと。`FitOutcome` は重みの由来を持たないため、
  `DataSeries` と解決済み手法を同時に持つこの層でしか判定できない
- **出力の既定**: グラフ画像は既定で保存し（要件 7.4）、曲線・残差 CSV は有効化された
  場合にのみ生成すること（要件 7.5）

バッチの逐次実行・失敗集約・進捗通知・資源枯渇の扱い（タスク 7.3）は対象外である。

設計の Testing Strategy が `pipeline` の結線を統合テストに置いているため、単体では
なく `tests/integration/` に置く。
"""

from __future__ import annotations

import csv
import logging
import math
from collections.abc import Sequence
from pathlib import Path

import numpy as np
import pytest

from curvefit import pipeline as pipeline_module
from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.engines import EngineFailure, select_engine
from curvefit.engines.smoothing import (
    NO_WEIGHT_SUPPORT_REASONS,
    MOVING_AVERAGE_WINDOW_OPTION,
    SMOOTHER_OPTION_DEFAULTS,
)
from curvefit.errors import FailureReason
from curvefit.logging_setup import LOGGER_NAME
from curvefit.models.registry import DEFAULT_POLYNOMIAL_DEGREE, POLYNOMIAL_DEGREE_OPTION
from curvefit.models.resolver import MethodSpec, SmootherKind, resolve
from curvefit.pipeline import (
    CURVE_SUBDIRECTORY,
    PLOT_SUBDIRECTORY,
    PREPROCESS_SUBDIRECTORY,
    Job,
    JobResult,
    UnexpectedConfigViolation,
    expand_jobs,
    run_job,
)
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec, read_delimited
from curvefit.types import DataSeries, FitFailure, FitOutcome, FitSuccess
from curvefit.writers import CURVE_COLUMNS, PREPROCESS_COLUMNS, build_output_stem

GAUSSIAN = MethodSpec(name="gauss", kind="builtin", builtin="gaussian")
"""初期値を明示しない組込モデル。要件 4.1 の自動推定が働く経路である。"""

LINEAR = MethodSpec(name="lin", kind="builtin", builtin="linear")
BUILTIN_POLYNOMIAL = MethodSpec(name="bpoly", kind="builtin", builtin="polynomial")
"""次数を明示しない組込の多項式。次数の既定値（要件 5.4）が効く経路である。"""
SPLINE = MethodSpec(
    name="sp", kind="smoother", smoother=SmootherKind.SPLINE, options={"lam": 1e-2}
)
"""平滑化スプライン。平滑化パラメータの指定は必須である（要件 5.5）。"""
MOVING_AVERAGE = MethodSpec(name="ma", kind="smoother", smoother=SmootherKind.MOVING_AVERAGE)
SMOOTHER_LINEAR = MethodSpec(name="slin", kind="smoother", smoother=SmootherKind.LINEAR)
SMOOTHER_POLYNOMIAL = MethodSpec(name="spoly", kind="smoother", smoother=SmootherKind.POLYNOMIAL)


def gaussian_values(x: np.ndarray, height: float, center: float, sigma: float) -> np.ndarray:
    """合成データの生成元。基盤ライブラリを使わずに定義する。"""
    return height * np.exp(-((x - center) ** 2) / (2.0 * sigma**2))


def write_csv(
    path: Path,
    x: Sequence[object],
    y: Sequence[object],
    sigma: Sequence[object] | None = None,
) -> Path:
    """見出し行を持つ CSV を書き出す。値は文字列としてそのまま並べる。"""
    header = "x,y" if sigma is None else "x,y,sigma"
    lines = [header]
    for index, (x_value, y_value) in enumerate(zip(x, y, strict=True)):
        row = f"{x_value},{y_value}"
        if sigma is not None:
            row = f"{row},{sigma[index]}"
        lines.append(row)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_gaussian_csv(
    path: Path, *, height: float, center: float, sigma: float, n_points: int = 41
) -> Path:
    """既知のガウシアンから合成データを書き出す。"""
    x = np.linspace(center - 4.0 * sigma, center + 4.0 * sigma, n_points)
    return write_csv(path, x.tolist(), gaussian_values(x, height, center, sigma).tolist())


def make_config(
    directory: Path,
    paths: Sequence[str],
    methods: Sequence[MethodSpec],
    *,
    columns: ColumnSpec | None = None,
    preprocess: PreprocessSpec | None = None,
    write_plot: bool = True,
    write_curve: bool = False,
) -> RunConfig:
    return RunConfig(
        inputs=InputSpec(
            paths=tuple(paths),
            columns=columns if columns is not None else ColumnSpec(x="x", y="y"),
        ),
        methods=tuple(methods),
        preprocess=preprocess if preprocess is not None else PreprocessSpec(),
        output=OutputSpec(
            directory=directory, write_plot=write_plot, write_curve=write_curve
        ),
    )


def single_job(config: RunConfig) -> Job:
    jobs = expand_jobs(config)
    assert len(jobs) == 1
    return jobs[0]


def run_outcome(job: Job, config: RunConfig) -> FitOutcome:
    """処理単位を実行し、当てはめ結果だけを取り出す。

    既定値の中継（要件 5.4）を検証しない試験のための補助である。
    """
    result = run_job(job, config)
    assert isinstance(result, JobResult)
    return result.outcome


def plot_path(config: RunConfig, job: Job) -> Path:
    stem = build_output_stem(job.source, job.method.name, job.index)
    return config.output.directory / PLOT_SUBDIRECTORY / f"{stem}.png"


def curve_path(config: RunConfig, job: Job) -> Path:
    stem = build_output_stem(job.source, job.method.name, job.index)
    return config.output.directory / CURVE_SUBDIRECTORY / f"{stem}.csv"


def assert_no_outputs(config: RunConfig) -> None:
    """出力物が 1 件も生成されていないこと。後続段階が走っていないことの証拠になる。"""
    directory = config.output.directory
    produced = sorted(str(p) for p in directory.rglob("*") if p.is_file())
    assert produced == []


def parameter(success: FitSuccess, name: str) -> float:
    return next(estimate.value for estimate in success.parameters if estimate.name == name)


class Test成功時の結線:
    """1 件の入力と 1 つの手法で、結果と出力ファイルが得られること。"""

    def test_既知のパラメータを復元する(self, tmp_path: Path) -> None:
        source = write_gaussian_csv(
            tmp_path / "peak.csv", height=10.0, center=5.0, sigma=1.0
        )
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.source_id == job.source
        assert outcome.method_name == "gauss"
        assert parameter(outcome, "center") == pytest.approx(5.0, abs=1e-6)
        assert parameter(outcome, "sigma") == pytest.approx(1.0, abs=1e-6)
        assert parameter(outcome, "amplitude") == pytest.approx(
            10.0 * 1.0 * math.sqrt(2.0 * math.pi), rel=1e-6
        )

    def test_適合度と曲線が結果に含まれる(self, tmp_path: Path) -> None:
        source = write_gaussian_csv(
            tmp_path / "peak.csv", height=10.0, center=5.0, sigma=1.0, n_points=41
        )
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.goodness.r_squared == pytest.approx(1.0, abs=1e-9)
        assert outcome.goodness.n_points == 41
        assert outcome.goodness.n_varied_params == 3
        assert len(outcome.curve) == 41
        assert outcome.curve.residual == pytest.approx(
            outcome.curve.y_observed - outcome.curve.y_fit
        )
        assert outcome.preprocess.n_input == 41
        assert outcome.preprocess.n_used == 41

    def test_グラフ画像を既定で保存する(self, tmp_path: Path) -> None:
        """要件 7.4: グラフ画像は既定で保存する。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        assert plot_path(config, job).is_file()
        assert plot_path(config, job).stat().st_size > 0

    def test_曲線CSVは既定では生成しない(self, tmp_path: Path) -> None:
        """要件 7.5: 曲線・残差 CSV はオプトインである。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        assert not curve_path(config, job).exists()
        assert not (config.output.directory / CURVE_SUBDIRECTORY).exists()

    def test_曲線CSVは有効化された場合に生成する(self, tmp_path: Path) -> None:
        """要件 7.5。"""
        source = write_gaussian_csv(
            tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5, n_points=21
        )
        config = make_config(
            tmp_path / "out", [str(source)], [GAUSSIAN], write_curve=True
        )
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        written = curve_path(config, job)
        assert written.is_file()
        lines = written.read_text(encoding="utf-8").splitlines()
        assert lines[0] == ",".join(CURVE_COLUMNS)
        assert len(lines) == 1 + 21

    def test_グラフを無効化すると生成しない(self, tmp_path: Path) -> None:
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out", [str(source)], [GAUSSIAN], write_plot=False
        )
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        assert not (config.output.directory / PLOT_SUBDIRECTORY).exists()

    def test_出力名にジョブ番号が入り互いを上書きしない(self, tmp_path: Path) -> None:
        """要件 7.6 の命名がそのまま出力先に反映されること。"""
        first = tmp_path / "run1"
        second = tmp_path / "run2"
        first.mkdir()
        second.mkdir()
        write_gaussian_csv(first / "sample.csv", height=4.0, center=1.0, sigma=0.4)
        write_gaussian_csv(second / "sample.csv", height=6.0, center=3.0, sigma=0.7)
        config = make_config(
            tmp_path / "out",
            [str(first / "sample.csv"), str(second / "sample.csv")],
            [GAUSSIAN],
            write_curve=True,
        )

        jobs = expand_jobs(config)
        assert len(jobs) == 2
        for job in jobs:
            assert isinstance(run_outcome(job, config), FitSuccess)

        plots = sorted(p.name for p in (config.output.directory / PLOT_SUBDIRECTORY).iterdir())
        curves = sorted(p.name for p in (config.output.directory / CURVE_SUBDIRECTORY).iterdir())
        assert plots == ["sample__gauss__0000.png", "sample__gauss__0001.png"]
        assert curves == ["sample__gauss__0000.csv", "sample__gauss__0001.csv"]

    def test_同じ処理単位を繰り返しても同一の結果になる(self, tmp_path: Path) -> None:
        """要件 8.2: 同一入力・同一条件の再実行は同一結果になる。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=8.0, center=4.0, sigma=1.2)
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        first = run_outcome(job, config)
        second = run_outcome(job, config)

        assert isinstance(first, FitSuccess)
        assert isinstance(second, FitSuccess)
        assert first.parameters == second.parameters
        assert first.goodness == second.goodness


class Test段階ごとの短絡:
    """各段階の失敗結果がそのまま処理単位の結果になり、以降の段階に進まないこと。"""

    def test_列を解決できない場合は読み込みで止まる(self, tmp_path: Path) -> None:
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [GAUSSIAN],
            columns=ColumnSpec(x="time", y="signal"),
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.COLUMN_NOT_FOUND
        assert outcome.source_id == job.source
        assert outcome.method_name == "gauss"
        assert outcome.preprocess is None
        assert_no_outputs(config)

    def test_読み込みの失敗はモデル解決より先に返る(self, tmp_path: Path) -> None:
        """短絡の証拠。解決できない手法でも、読み込みが先に失敗すればそれが結果になる。

        解決まで進めば :class:`UnexpectedConfigViolation` が送出されるため、失敗結果が
        返ることは読み込みで止まったことを意味する。
        """
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [MethodSpec(name="unknown", kind="builtin", builtin="no_such_model")],
            columns=ColumnSpec(x="time", y="signal"),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.COLUMN_NOT_FOUND

    def test_点数不足は前処理で止まる(self, tmp_path: Path) -> None:
        source = write_csv(tmp_path / "few.csv", [1.0, 2.0], [1.0, 2.0])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert outcome.preprocess is not None
        assert outcome.preprocess.n_used == 2
        assert_no_outputs(config)

    def test_当てはめの失敗がそのまま結果になる(self, tmp_path: Path) -> None:
        """スプラインは x の重複した系列に当てはめられない（非収束）。"""
        source = write_csv(
            tmp_path / "dup.csv",
            [1.0, 1.0, 2.0, 3.0, 4.0, 5.0],
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        )
        config = make_config(tmp_path / "out", [str(source)], [SPLINE])
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert outcome.source_id == job.source
        assert outcome.method_name == "sp"
        assert outcome.preprocess is not None
        assert_no_outputs(config)

    def test_非収束の報告に使用した初期値が残る(self, tmp_path: Path) -> None:
        """要件 4.7: 使用した初期値を報告する。

        :class:`~curvefit.types.FitFailure` は初期値の欄を持たないため、この層が説明に
        織り込まなければ報告が失われる。
        """

        def broken(x: np.ndarray, a: float) -> np.ndarray:
            return np.full(x.shape, np.nan)

        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [
                MethodSpec(
                    name="broken", kind="callable", function=broken, initial={"a": 2.5}
                )
            ],
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert "a" in outcome.message
        assert "2.5" in outcome.message

    def test_有効なデータ点がなければ読み込みで止まる(self, tmp_path: Path) -> None:
        source = write_csv(tmp_path / "text.csv", ["a", "b"], ["c", "d"])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NO_VALID_DATA
        assert_no_outputs(config)


def random_arrays(n_points: int = 120, seed: int = 20260816) -> tuple[np.ndarray, np.ndarray]:
    """短い十進表記を持たない合成データ。

    **二進で厳密に表せる値では、経路の一致の主張が空になる。** そのような値は往復の
    丸めが正しくなくても元に戻るため、読み込みを省く経路と通す経路の差に対して
    構造的に盲目になる。x を 1000 付近の狭い幅に取り、当てはめを条件の悪い側に置く。
    """
    rng = np.random.default_rng(seed)
    x = np.sort(rng.uniform(1000.0, 1000.5, n_points))
    shifted = x - 1000.0
    y = 1.0 + 2.0 * shifted - 0.5 * shifted**2 + rng.normal(0.0, 1.0e-3, n_points)
    return x, y


def values(success: FitSuccess) -> dict[str, float]:
    return {estimate.name: estimate.value for estimate in success.parameters}


class Test読み込み済みの系列の受け取り:
    """要件 9.1、9.3: メモリ上の系列を、読み込み以降の同一手順にそのまま載せること。

    差込口は :class:`~curvefit.pipeline.Job` の ``series`` である。当てはめ専用の経路を
    作らず、省くのは読み込みの 1 段だけであることを、対照（系列を渡さない同一の処理単位）
    とファイル経由との厳密一致の双方で示す。
    """

    def _series(self, source_id: str = "memory", n_points: int = 41) -> DataSeries:
        x = np.linspace(1.0, 9.0, n_points)
        return DataSeries(source_id=source_id, x=x, y=gaussian_values(x, 10.0, 5.0, 1.0))

    def test_読み込みを行わずに当てはめる(self, tmp_path: Path) -> None:
        """入力の位置に読めるものが無くても当てはめが成立すること。"""
        config = make_config(
            tmp_path / "out", [str(tmp_path / "無い.csv")], [GAUSSIAN], write_plot=False
        )
        series = self._series()
        job = Job(index=0, source=series.source_id, method=GAUSSIAN, series=series)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.source_id == "memory"
        assert parameter(outcome, "center") == pytest.approx(5.0, abs=1e-6)
        assert parameter(outcome, "sigma") == pytest.approx(1.0, abs=1e-6)

    def test_系列を伴わない同じ処理単位は読み込みで失敗する(self, tmp_path: Path) -> None:
        """対照。差込口が効いていなければ前の試験も同じ失敗になる（要件 1.8）。"""
        config = make_config(
            tmp_path / "out", [str(tmp_path / "無い.csv")], [GAUSSIAN], write_plot=False
        )
        job = Job(index=0, source="memory", method=GAUSSIAN)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INPUT_UNREADABLE

    def test_ファイル経由と最終ビットまで一致する(self, tmp_path: Path) -> None:
        """要件 9.3: 読み込みを省いても値が動かないこと。全桁の乱数で確かめる。"""
        x, y = random_arrays()
        source = write_csv(tmp_path / "random.csv", x.tolist(), y.tolist())
        method = MethodSpec(
            name="poly", kind="builtin", builtin="polynomial", options={"degree": 3}
        )
        config = make_config(tmp_path / "out", [str(source)], [method], write_plot=False)

        from_file = run_outcome(single_job(config), config)
        from_memory = run_outcome(
            Job(
                index=0,
                source="memory",
                method=method,
                series=DataSeries(source_id="memory", x=x, y=y),
            ),
            config,
        )

        assert isinstance(from_file, FitSuccess)
        assert isinstance(from_memory, FitSuccess)
        assert values(from_memory) == values(from_file)
        assert from_memory.goodness == from_file.goodness

    def test_誤差列を伴う場合もファイル経由と一致する(self, tmp_path: Path) -> None:
        """要件 1.3: 重みは σ の逆数として当てはめに効く。"""
        x, y = random_arrays(n_points=60)
        rng = np.random.default_rng(20260817)
        sigma = rng.lognormal(0.0, 1.0, x.size)
        source = write_csv(
            tmp_path / "weighted.csv", x.tolist(), y.tolist(), sigma.tolist()
        )
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=ColumnSpec(x="x", y="y", weight="sigma"),
            write_plot=False,
        )
        weights = 1.0 / sigma

        from_file = run_outcome(single_job(config), config)
        from_memory = run_outcome(
            Job(
                index=0,
                source="memory",
                method=LINEAR,
                series=DataSeries(source_id="memory", x=x, y=y, weights=weights),
            ),
            config,
        )

        assert isinstance(from_file, FitSuccess)
        assert isinstance(from_memory, FitSuccess)
        assert values(from_memory) == values(from_file)

    def test_処理単位ごとにモデルを解決し直す(self, tmp_path: Path) -> None:
        """要件 4.1: 初期値の推定はその処理単位の系列から行われること。

        スケールの異なる 2 件がいずれも復元されることは、解決が使い回されていない
        ことを意味する（:class:`Test処理単位ごとのモデル解決` と同じ根拠）。
        """
        config = make_config(tmp_path / "out", [], [GAUSSIAN], write_plot=False)
        x_small = np.linspace(1.0, 9.0, 41)
        small = DataSeries(
            source_id="small", x=x_small, y=gaussian_values(x_small, 10.0, 5.0, 1.0)
        )
        x_large = np.linspace(3800.0, 6200.0, 41)
        large = DataSeries(
            source_id="large", x=x_large, y=gaussian_values(x_large, 20000.0, 5000.0, 300.0)
        )

        outcomes = [
            run_outcome(
                Job(index=index, source=series.source_id, method=GAUSSIAN, series=series),
                config,
            )
            for index, series in enumerate((small, large))
        ]

        assert all(isinstance(outcome, FitSuccess) for outcome in outcomes)
        assert parameter(outcomes[0], "center") == pytest.approx(5.0, rel=1e-6)  # type: ignore[arg-type]
        assert parameter(outcomes[1], "center") == pytest.approx(5000.0, rel=1e-6)  # type: ignore[arg-type]
        assert parameter(outcomes[1], "sigma") == pytest.approx(300.0, rel=1e-6)  # type: ignore[arg-type]

    def test_最小点数の判定が同じ規則で効く(self, tmp_path: Path) -> None:
        """要件 2.4、4.5: 前処理への供給も読み込みを省いた経路で同じであること。"""
        config = make_config(tmp_path / "out", [], [GAUSSIAN], write_plot=False)
        series = DataSeries(
            source_id="memory", x=np.array([1.0, 2.0]), y=np.array([1.0, 2.0])
        )

        outcome = run_outcome(
            Job(index=0, source=series.source_id, method=GAUSSIAN, series=series), config
        )

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 3" in outcome.message

    def test_重みを使えない手法の記録が残る(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """誤差列の警告も読み込みを省いた経路で同じであること。

        対象は移動平均である。畳み込み係数は窓長と多項式次数だけで決まり、点ごとの
        重みを持ち込む場所が無い。
        """
        config = make_config(tmp_path / "out", [], [MOVING_AVERAGE], write_plot=False)
        x = np.linspace(1.0, 7.0, 7)
        series = DataSeries(
            source_id="memory", x=x, y=gaussian_values(x, 3.0, 4.0, 1.5), weights=np.ones(7)
        )

        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = run_outcome(
                Job(index=0, source=series.source_id, method=MOVING_AVERAGE, series=series),
                config,
            )

        assert isinstance(outcome, FitSuccess)
        messages = [
            record.getMessage() for record in caplog.records if "重み" in record.getMessage()
        ]
        assert len(messages) == 1
        assert "memory" in messages[0]

    def test_出力名が同じ規則で決まる(self, tmp_path: Path) -> None:
        """要件 7.6: 出力名は対象・手法・処理単位番号から決定的に導かれること。"""
        config = make_config(tmp_path / "out", [], [GAUSSIAN], write_curve=True)
        series = self._series(source_id="実験A")
        job = Job(index=3, source=series.source_id, method=GAUSSIAN, series=series)

        assert isinstance(run_outcome(job, config), FitSuccess)

        assert plot_path(config, job).name == "実験A__gauss__0003.png"
        assert plot_path(config, job).is_file()
        assert curve_path(config, job).is_file()

    def test_系列は処理単位の同一性に含めない(self) -> None:
        """処理単位を識別するのは対象と手法である。

        数値配列は要素ごとの比較を返すため、比較に含めると処理単位同士の比較が
        真偽値にならず :exc:`ValueError` になる。
        """
        with_series = Job(index=0, source="memory", method=GAUSSIAN, series=self._series())
        other = Job(
            index=0, source="memory", method=GAUSSIAN, series=self._series(n_points=61)
        )
        without = Job(index=0, source="memory", method=GAUSSIAN)

        assert with_series == without
        assert with_series == other


class Test処理単位ごとのモデル解決:
    """要件 4.1: 組込モデルの初期値を、その対象のデータから推定する。"""

    def test_スケールの異なる2件がいずれも収束する(self, tmp_path: Path) -> None:
        small = write_gaussian_csv(
            tmp_path / "small.csv", height=10.0, center=5.0, sigma=1.0
        )
        large = write_gaussian_csv(
            tmp_path / "large.csv", height=20000.0, center=5000.0, sigma=300.0
        )
        config = make_config(tmp_path / "out", [str(small), str(large)], [GAUSSIAN])

        outcomes = {}
        for job in expand_jobs(config):
            outcome = run_outcome(job, config)
            assert isinstance(outcome, FitSuccess)
            outcomes[Path(job.source).name] = outcome

        assert parameter(outcomes["small.csv"], "center") == pytest.approx(5.0, rel=1e-6)
        assert parameter(outcomes["small.csv"], "sigma") == pytest.approx(1.0, rel=1e-6)
        assert parameter(outcomes["large.csv"], "center") == pytest.approx(5000.0, rel=1e-6)
        assert parameter(outcomes["large.csv"], "sigma") == pytest.approx(300.0, rel=1e-6)

    def test_解決を使い回すと別スケールのデータで復元できない(self, tmp_path: Path) -> None:
        """使い回しが成立しないことの実証。処理単位ごとに解決を呼び直す根拠である。

        小さいスケールのデータから推定した初期値のまま大きいスケールのデータに当てると、
        当てはめは初期値からほとんど動かず、中心も幅も復元されない。
        """
        x_small = np.linspace(1.0, 9.0, 41)
        small = DataSeries(
            source_id="small",
            x=x_small,
            y=gaussian_values(x_small, 10.0, 5.0, 1.0),
        )
        x_large = np.linspace(3800.0, 6200.0, 41)
        large = DataSeries(
            source_id="large",
            x=x_large,
            y=gaussian_values(x_large, 20000.0, 5000.0, 300.0),
        )

        shared = resolve(GAUSSIAN, sample=small)
        reused = select_engine(shared).fit(large, shared)

        recovered = {
            estimate.name: estimate.value for estimate in getattr(reused, "parameters", ())
        }
        assert recovered.get("center", 0.0) != pytest.approx(5000.0, rel=1e-3)


class Test最小点数の導出:
    """前処理に渡す最小点数を、解決済み手法の推定パラメータ数から導出すること。"""

    def test_パラメータ数が最小点数になる(self, tmp_path: Path) -> None:
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [1.0, 2.0])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 3" in outcome.message

    def test_パラメータ数の少ない手法は同じ点数で通る(self, tmp_path: Path) -> None:
        """同一データでも手法のパラメータ数によって判定が変わること。"""
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [2.0, 4.0])
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        assert parameter(outcome, "slope") == pytest.approx(2.0, abs=1e-9)

    def test_多項式の次数が最小点数に反映される(self, tmp_path: Path) -> None:
        """次数 4 の多項式回帰は係数 5 個を持つ。"""
        source = write_csv(
            tmp_path / "four.csv", [1.0, 2.0, 3.0, 4.0], [1.0, 2.0, 3.0, 4.0]
        )
        method = MethodSpec(
            name="poly",
            kind="smoother",
            smoother=SmootherKind.POLYNOMIAL,
            options={"degree": 4},
        )
        config = make_config(tmp_path / "out", [str(source)], [method])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 5" in outcome.message

    def test_パラメータを持たない手法でも1点を下限とする(self, tmp_path: Path) -> None:
        """区間限定で 1 点も残らない場合、当てはめに進まず点数不足として報告する。"""
        source = write_csv(
            tmp_path / "range.csv",
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        )
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [SPLINE],
            preprocess=PreprocessSpec(x_min=100.0),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert outcome.preprocess is not None
        assert outcome.preprocess.n_used == 0


class Test固定パラメータと最小点数:
    """要件 2.4、4.5: 最小点数は推定対象の数であり、固定したパラメータを含めない。"""

    FIXED_SIGMA = MethodSpec(
        name="gfix", kind="builtin", builtin="gaussian", fixed={"sigma": 1.0}
    )
    """``sigma`` を固定したガウシアン。パラメータ名は 3 個だが推定対象は 2 個である。"""

    def test_固定したパラメータは最小点数に数えない(self, tmp_path: Path) -> None:
        """固定した分まで数えると、当てはめられる処理単位が点数不足と誤報される。

        同じデータと同じ解決済みモデルで当てはめは成立する（推定対象は 2 個）。
        """
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [3.0, 5.0])
        config = make_config(tmp_path / "out", [str(source)], [self.FIXED_SIGMA])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.goodness.n_points == 2
        assert outcome.goodness.n_varied_params == 2
        assert parameter(outcome, "sigma") == pytest.approx(1.0, abs=1e-12)

    def test_推定対象の数は下限として働く(self, tmp_path: Path) -> None:
        """固定しても推定対象が 2 個であることは変わらず、1 点では点数不足になる。"""
        source = write_csv(tmp_path / "one.csv", [1.0], [3.0])
        config = make_config(tmp_path / "out", [str(source)], [self.FIXED_SIGMA])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 2" in outcome.message
        assert_no_outputs(config)

    def test_固定しなければ同じデータで点数不足になる(self, tmp_path: Path) -> None:
        """対照。固定の有無だけで判定が変わることを、同一データで示す。"""
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [3.0, 5.0])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 3" in outcome.message


class Test外れ値除去の暫定当てはめ:
    """暫定当てはめの手段をこの層がコールバックとして供給すること（要件 2.3）。"""

    def test_外れ値が除去され件数と位置が記録される(self, tmp_path: Path) -> None:
        x = np.linspace(0.0, 19.0, 20)
        y = 2.0 * x + 1.0
        y[7] = y[7] + 300.0
        source = write_csv(tmp_path / "outlier.csv", x.tolist(), y.tolist())
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=3.0, max_iterations=3)),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        # 混入させた点が最初の反復で除外されること。以降の反復では、外れ値を除いた
        # 残差が丸め誤差の水準まで小さくなり、その中の相対的な突出が除外されうる
        # （`OutlierSpec.sigma` の非ロバストな尺度）。除外の総数は固定しない。
        assert outcome.preprocess.outlier_points[0].x == 7.0
        assert outcome.preprocess.n_dropped_outlier == len(outcome.preprocess.outlier_points)
        assert outcome.goodness.n_points == 20 - outcome.preprocess.n_dropped_outlier
        assert parameter(outcome, "slope") == pytest.approx(2.0, abs=1e-9)

    def test_暫定当てはめが収束しなければ除去0件で当てはめに進む(
        self, tmp_path: Path
    ) -> None:
        """当てはめの失敗を ``None`` として前処理層に伝える経路（設計の Risks）。

        x の重複した系列にスプラインは当てはめられない。暫定当てはめは失敗を値
        （`EngineFailure`）で返し、この層はそれを ``None`` に写して渡す。前処理層は
        除去をスキップし、当てはめまで進む。例外として投げ直すと、前処理層は実装上の
        誤りと非収束を見分けられなくなる。
        """
        source = write_csv(
            tmp_path / "dup.csv",
            [1.0, 1.0, 2.0, 3.0, 4.0, 5.0],
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        )
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [SPLINE],
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=3.0, max_iterations=3)),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert outcome.preprocess is not None
        assert outcome.preprocess.n_dropped_outlier == 0
        assert outcome.preprocess.n_used == 6


class Test重みを使えない手法の記録:
    """誤差列があるのに重みを使えない手法が選ばれた場合、実行ログに残すこと。"""

    def _weighted_source(self, tmp_path: Path) -> Path:
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
        y = [1.0, 2.1, 2.9, 4.2, 5.1, 5.8, 7.2]
        return write_csv(tmp_path / "weighted.csv", x, y, [1.0] * len(x))

    def _run(
        self, tmp_path: Path, method: MethodSpec, caplog: pytest.LogCaptureFixture
    ) -> list[str]:
        source = self._weighted_source(tmp_path)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [method],
            columns=ColumnSpec(x="x", y="y", weight="sigma"),
        )
        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = run_outcome(single_job(config), config)
        assert isinstance(outcome, FitSuccess)
        return [
            record.getMessage()
            for record in caplog.records
            if record.name == LOGGER_NAME and "重み" in record.getMessage()
        ]

    def test_移動平均では記録が残る(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        messages = self._run(tmp_path, MOVING_AVERAGE, caplog)
        assert len(messages) == 1
        assert "ma" in messages[0]
        assert "weighted.csv" in messages[0]

    def test_警告の理由は実行前ゲートと同じ出所から来る(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """理由の文言が 2 か所に書かれていないこと（要件 1.3、1.10）。

        実行前ゲートの違反文と実行ログの警告文が別々に書かれていた頃、Savitzky-Golay の
        誤った説明を訂正した際に片方だけが直り、利用者に出る警告には撤回した説明が
        残った。文言の所有は宣言と同じ場所（``engines.smoothing``）に 1 つだけ置く。
        """
        messages = self._run(tmp_path, MOVING_AVERAGE, caplog)

        assert len(messages) == 1
        assert (
            NO_WEIGHT_SUPPORT_REASONS[SmootherKind.MOVING_AVERAGE]
            in messages[0]
        ), "警告の理由が宣言側の文言と一致していない（二重所有に戻っている）"

    def test_スプラインでは記録が残らない(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """要件 1.3: スプラインは重みを反映するため、無視した旨を記録してはならない。

        記録が残ると、実際には推定に効いている重みを利用者が「効いていない」と読む。
        """
        assert self._run(tmp_path, SPLINE, caplog) == []

    def test_線形回帰では記録が残らない(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        assert self._run(tmp_path, SMOOTHER_LINEAR, caplog) == []

    def test_多項式回帰では記録が残らない(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        assert self._run(tmp_path, SMOOTHER_POLYNOMIAL, caplog) == []

    def test_モデル関数フィットでは記録が残らない(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        assert self._run(tmp_path, LINEAR, caplog) == []

    def test_誤差列がなければ記録は残らない(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        source = write_gaussian_csv(
            tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5
        )
        config = make_config(tmp_path / "out", [str(source)], [SPLINE])
        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = run_outcome(single_job(config), config)
        assert isinstance(outcome, FitSuccess)
        assert [r for r in caplog.records if "重み" in r.getMessage()] == []


class Test適用された既定値の中継:
    """要件 5.4: 当てはめが補った既定値を `JobResult` として呼び出し元へ渡すこと。

    どの選択肢に既定値が効いたかを決めるのは当てはめ層である（`_int_option`）。この層が
    運ばなければ、実行条件の記録（`execution.collect_applied_defaults`）に渡す材料が
    どこにも存在せず、要件 5.4 の「適用した値を実行条件として記録する」が満たせない。
    期待値は `SMOOTHER_OPTION_DEFAULTS` から読む。ここに値を書き写すと、既定値の所有が
    当てはめ層と試験の 2 か所に分かれる。
    """

    def _linear_source(self, tmp_path: Path, n_points: int = 10) -> Path:
        x = np.linspace(0.0, float(n_points - 1), n_points)
        return write_csv(tmp_path / "line.csv", x.tolist(), (2.0 * x + 1.0).tolist())

    def _run(
        self,
        tmp_path: Path,
        method: MethodSpec,
        *,
        n_points: int = 10,
        columns: ColumnSpec | None = None,
        preprocess: PreprocessSpec | None = None,
    ) -> JobResult:
        source = self._linear_source(tmp_path, n_points)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [method],
            columns=columns,
            preprocess=preprocess,
            write_plot=False,
        )
        return run_job(single_job(config), config)

    def test_移動平均の既定値が呼び出し元に届く(self, tmp_path: Path) -> None:
        result = self._run(tmp_path, MOVING_AVERAGE)

        assert isinstance(result.outcome, FitSuccess)
        expected = dict(SMOOTHER_OPTION_DEFAULTS[SmootherKind.MOVING_AVERAGE])
        assert expected  # 既定値を持つ手法であることの裏取り
        assert dict(result.applied_defaults) == expected

    def test_既定値は書き換えられない(self, tmp_path: Path) -> None:
        """記録が実行と食い違わないよう、返した写像は凍結する。"""
        result = self._run(tmp_path, MOVING_AVERAGE)
        name = next(iter(SMOOTHER_OPTION_DEFAULTS[SmootherKind.MOVING_AVERAGE]))

        with pytest.raises(TypeError):
            result.applied_defaults[name] = 99  # type: ignore[index]

    def test_明示した選択肢は既定値として記録しない(self, tmp_path: Path) -> None:
        """記録に載せるのは「利用者が書いていないのに効いた値」だけである。"""
        defaults = SMOOTHER_OPTION_DEFAULTS[SmootherKind.MOVING_AVERAGE]
        explicit = MethodSpec(
            name="ma7",
            kind="smoother",
            smoother=SmootherKind.MOVING_AVERAGE,
            options={MOVING_AVERAGE_WINDOW_OPTION: 7},
        )

        result = self._run(tmp_path, explicit)

        assert isinstance(result.outcome, FitSuccess)
        assert MOVING_AVERAGE_WINDOW_OPTION not in result.applied_defaults
        assert dict(result.applied_defaults) == {
            name: value for name, value in defaults.items() if name != MOVING_AVERAGE_WINDOW_OPTION
        }

    def test_多項式回帰の次数の既定値が届く(self, tmp_path: Path) -> None:
        result = self._run(tmp_path, SMOOTHER_POLYNOMIAL)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == dict(
            SMOOTHER_OPTION_DEFAULTS[SmootherKind.POLYNOMIAL]
        )

    def test_スプラインは既定値を持たない(self, tmp_path: Path) -> None:
        """平滑化量に既定値は無い。未指定は実行前ゲートが拒否する（要件 5.5）。

        利用者が明示した値を ``applied_defaults`` に載せないことを併せて示している。
        載せると、実行条件の記録から「書いていないのに効いた値」を区別できなくなる。
        """
        result = self._run(tmp_path, SPLINE)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {}
        assert dict(SMOOTHER_OPTION_DEFAULTS[SmootherKind.SPLINE]) == {}

    def test_選択肢を持たない組込モデルは既定値を持たない(self, tmp_path: Path) -> None:
        result = self._run(tmp_path, LINEAR)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {}

    def test_組込モデルの次数の既定値が届く(self, tmp_path: Path) -> None:
        """要件 5.4 は手法の書き方を問わない。組込の多項式も次数の既定値を持つ。"""
        result = self._run(tmp_path, BUILTIN_POLYNOMIAL)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {
            POLYNOMIAL_DEGREE_OPTION: DEFAULT_POLYNOMIAL_DEGREE
        }

    def test_次数を明示した組込モデルは既定値を記録しない(self, tmp_path: Path) -> None:
        explicit = MethodSpec(
            name="bpoly3",
            kind="builtin",
            builtin="polynomial",
            options={POLYNOMIAL_DEGREE_OPTION: 3},
        )
        result = self._run(tmp_path, explicit)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {}

    def test_同じ利用者入力なら手法の書き方によらず記録が一致する(self, tmp_path: Path) -> None:
        """要件 8.5: 記録が実行を説明するには、同じ入力に同じ記録が対応する必要がある。

        「多項式・次数の指定なし」という同一の利用者入力を、組込モデルと平滑化手法の
        両方の書き方で与える。片方だけが記録すると、記録の意味が書き方に依存する。
        """
        builtin = self._run(tmp_path, BUILTIN_POLYNOMIAL)
        smoother = self._run(tmp_path, SMOOTHER_POLYNOMIAL)

        assert isinstance(builtin.outcome, FitSuccess)
        assert isinstance(smoother.outcome, FitSuccess)
        assert dict(builtin.applied_defaults) == dict(smoother.applied_defaults)
        assert dict(builtin.applied_defaults)  # 双方が空では一致に意味がない

    def test_読み込みで失敗した場合は記録しない(self, tmp_path: Path) -> None:
        result = self._run(
            tmp_path, MOVING_AVERAGE, columns=ColumnSpec(x="time", y="signal")
        )

        assert isinstance(result.outcome, FitFailure)
        assert result.outcome.reason is FailureReason.COLUMN_NOT_FOUND
        assert dict(result.applied_defaults) == {}

    def test_前処理で失敗した場合は記録しない(self, tmp_path: Path) -> None:
        result = self._run(
            tmp_path, MOVING_AVERAGE, preprocess=PreprocessSpec(x_min=100.0)
        )

        assert isinstance(result.outcome, FitFailure)
        assert result.outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert dict(result.applied_defaults) == {}

    def test_当てはめで失敗した場合は記録しない(self, tmp_path: Path) -> None:
        """窓長に満たない点数では当てはめが失敗する。

        当てはめ層は失敗を返す前に既定値を読み取っている。それでも記録が空になるのは、
        既定値が実際に効いた当てはめが存在しないためである。
        """
        result = self._run(tmp_path, MOVING_AVERAGE, n_points=3)

        assert isinstance(result.outcome, FitFailure)
        assert result.outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert dict(result.applied_defaults) == {}


class Test実行前検証を経ていない手法:
    """`resolve` が違反を返すのは実行前ゲートを通っていない場合に限る。"""

    def test_解決できない手法は違反として送出される(self, tmp_path: Path) -> None:
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [MethodSpec(name="unknown", kind="builtin", builtin="no_such_model")],
        )

        with pytest.raises(UnexpectedConfigViolation) as error:
            run_job(single_job(config), config)

        assert error.value.violations
        assert "no_such_model" in str(error.value)
        assert_no_outputs(config)


# --- 前処理 CSV の書き出し（要件 2.5、9.1）------------------------------------------


def preprocess_path(config: RunConfig, job: Job) -> Path:
    stem = build_output_stem(job.source, job.method.name, job.index)
    return config.output.directory / PREPROCESS_SUBDIRECTORY / f"{stem}.csv"


def preprocess_rows(path: Path) -> tuple[tuple[str, ...], list[list[str]]]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        return tuple(next(reader)), [row for row in reader]


def write_outlier_csv(path: Path, *, spike: bool, n_points: int = 20) -> Path:
    """既知の直線に微小なばらつきを載せた系列。``spike`` で 1 点だけ突出させる。

    ばらつきを 0 にしない。残差が丸め誤差の水準になると、その中の相対的な突出が
    外れ値として除外されうる（``OutlierSpec.sigma`` の非ロバストな尺度）。
    """
    x = [float(index) * 0.5 for index in range(n_points)]
    y = [
        2.0 * value + 1.0 + (0.01 if index % 2 == 0 else -0.01)
        for index, value in enumerate(x)
    ]
    if spike:
        y[7] += 300.0
    return write_csv(path, x, y)


def write_collapsing_csv(path: Path, n_points: int = 8) -> Path:
    """外れ値を除いた結果として点数不足に落ちる系列（要件 2.4、2.5）。"""
    x = [float(index) for index in range(n_points)]
    y = [2.0 * value + 1.0 for value in x]
    y[2] += 50.0
    y[5] -= 40.0
    return write_csv(path, x, y)


OUTLIER = PreprocessSpec(outlier=OutlierSpec(sigma=3.0, max_iterations=3))
"""既定の閾値。20 点の系列で単一の突出を除去できる規模である。"""

AGGRESSIVE_OUTLIER = PreprocessSpec(outlier=OutlierSpec(sigma=1.0, max_iterations=3))
"""8 点の系列で判定を効かせる閾値（``OutlierSpec.sigma`` の盲点: ``n <= sigma**2``）。"""

POLYNOMIAL_4 = MethodSpec(
    name="poly4", kind="builtin", builtin="polynomial", options={"degree": 4}
)
"""推定対象 5 個。8 点から 4 点が除外されると点数不足になる。"""


class Test前処理CSVの書き出し:
    """要件 2.5: 外れ値として除外した各点を、処理対象を識別できる形で記録すること。

    **この出力だけが「出力物を書き出すのは成功した場合に限る」から外れる。** 図と曲線
    CSV は当てはめの結果だが、前処理 CSV は前処理が何をしたかの説明であり、当てはめの
    成否とは独立に成立する。
    """

    def test_成功した処理単位に書かれる(self, tmp_path: Path) -> None:
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 1
        header, rows = preprocess_rows(preprocess_path(config, job))
        assert header == PREPROCESS_COLUMNS
        assert rows == [[repr(3.5), repr(307.99), "1"]]

    def test_書き出しは処理単位あたりちょうど_1_回である(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """書き出しの地点が 2 つあるため、どちらも通る形になっていないこと（要件 2.5）。

        成功する場合は当てはめ結果より先に :func:`_run_stages` の中で書き、それ以外は
        :func:`run_job` が書く。2 地点が排他でなくなると、同じ内容を 2 度書く（無駄な
        書き込み）か、どちらも通らない（記録の欠落）。前者は内容が同じであるため
        出力を見ても気付けない。

        逆向きの退行（どちらも通らない）は、この検査が 0 回を捉えることで塞ぐ。
        """
        calls: list[str] = []
        original = pipeline_module.write_preprocess

        def counting(outcome: FitOutcome, path: Path) -> None:
            calls.append(type(outcome).__name__)
            original(outcome, path)

        monkeypatch.setattr(pipeline_module, "write_preprocess", counting)

        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess), "成功する入力でなければ 2 地点を試せない"
        assert calls == ["FitSuccess"], f"書き出しが {len(calls)} 回になっている"

    def test_前処理で失敗した処理単位にも書かれる(self, tmp_path: Path) -> None:
        """外れ値を除いた結果として点数不足で落ちる場合こそ、除外点を知りたい場面である。"""
        source = write_collapsing_csv(tmp_path / "spike.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [POLYNOMIAL_4],
            preprocess=AGGRESSIVE_OUTLIER,
            write_plot=False,
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        header, rows = preprocess_rows(preprocess_path(config, job))
        assert header == PREPROCESS_COLUMNS
        assert len(rows) == outcome.preprocess.n_dropped_outlier
        # 意図的に外した 2 点が記録されていること。実測値は入力の y そのままである。
        recorded = {float(row[0]): float(row[1]) for row in rows}
        assert recorded[2.0] == 55.0
        assert recorded[5.0] == -29.0

    def test_当てはめで失敗した処理単位にも書かれる(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """3 つ目の返り口（エンジンの失敗）も同じ書き出しを通ること。

        暫定当てはめと本当てはめは同じエンジンを通るため、収束する暫定当てはめの後で
        本当てはめだけが失敗する系列は作れない。前処理を終えた後の 1 回だけを失敗に
        差し替えて、返り口ごとの取りこぼしがないことを見る。
        """
        real_preprocess = pipeline_module.apply_preprocess
        state = {"armed": False}

        class _FailAfterPreprocess:
            def __init__(self, inner: object) -> None:
                self.inner = inner

            def fit(self, series: DataSeries, method: object) -> object:
                if state["armed"]:
                    return EngineFailure(
                        reason=FailureReason.NOT_CONVERGED, message="試験用の失敗"
                    )
                return self.inner.fit(series, method)  # type: ignore[attr-defined]

        def wrapped_preprocess(*args: object, **kwargs: object) -> object:
            result = real_preprocess(*args, **kwargs)
            state["armed"] = True
            return result

        monkeypatch.setattr(
            pipeline_module,
            "select_engine",
            lambda method: _FailAfterPreprocess(select_engine(method)),
        )
        monkeypatch.setattr(pipeline_module, "apply_preprocess", wrapped_preprocess)

        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        _, rows = preprocess_rows(preprocess_path(config, job))
        assert rows == [[repr(3.5), repr(307.99), "1"]]

    def test_除外_0_件では作らない(self, tmp_path: Path) -> None:
        """存在そのものが「この対象には除外があった」を意味する形にする。"""
        source = write_outlier_csv(tmp_path / "steady.csv", spike=False)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 0
        assert not preprocess_path(config, job).exists()
        # 下位ディレクトリも作らない。書かない対象のために階層を作ると、除外のあった
        # 対象を探す手掛かりが消える。
        assert not (config.output.directory / PREPROCESS_SUBDIRECTORY).exists()

    def test_外れ値除去が無効なら作らない(self, tmp_path: Path) -> None:
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], write_plot=False
        )
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)
        assert not (config.output.directory / PREPROCESS_SUBDIRECTORY).exists()

    def test_前処理に到達しない失敗では作らない(self, tmp_path: Path) -> None:
        """読み込みで止まった処理単位は ``preprocess`` を持たない（要件 1.4）。"""
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=ColumnSpec(x="time", y="signal"),
            preprocess=OUTLIER,
            write_plot=False,
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.preprocess is None
        assert_no_outputs(config)

    def test_系列を直接渡された処理単位では書かない(self, tmp_path: Path) -> None:
        """要件 9.1、9.3: 出力先を持たない経路が利用者の領域に書き込まないこと。

        `api.fit_series` の出力先は共有の一時領域である。この出力はオプトインの
        フラグを持たないため、抑止の軸は `Job.series` の有無に置く。
        """
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        directory = tmp_path / "out"
        directory.mkdir()
        config = make_config(
            directory, [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        loaded = read_delimited(
            source, config.inputs.columns, None, True, method_name=LINEAR.name
        )
        assert isinstance(loaded, DataSeries)
        job = Job(index=0, source="memory", method=LINEAR, series=loaded)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 1
        assert list(directory.rglob("*")) == []
