"""実行前の一括検証ゲートの統合テスト（要件 3.4、4.3、4.6、5.4、7.7、8.5、2.1）。

本テストは `curvefit.preflight` が次を満たすことを検証する。

- 「処理を開始せず報告する」種類の検査がすべてこのゲートに集約されていること。
  モデル解決（3.4）、組込以外のモデルにおける初期値の必須性（4.3）、初期値と上下限の
  整合（4.6）、平滑化オプションの制約（5.4）、出力先の書き込み可否（7.7）、
  設定構造の妥当性（8.5、2.1）
- **最初の違反で打ち切らない**。全項目を検査してから違反を一括で返すこと
- 違反の並びが実行のたびに変わらないこと（要件 8.2 の決定性）
- 平滑化オプションの制約検証が `engines.smoothing` の所有する定数のみを出所とすること
- モデル解決をデータなし（`sample=None`）で試み、データに依存しない違反だけを
  検出すること
- **入力パスの存在確認を行わない**こと。ファイルが 0 件なら処理対象 0 件として正常に
  終わり、存在しないファイルの直接指定は要件 1.4/1.5 の個別失敗として扱う

設計の Testing Strategy が `config` + `preflight` を統合テストに置いているため、
単体ではなく `tests/integration/` に置く。
"""

from __future__ import annotations

import ast
import os
import stat
import subprocess
import sys
from collections import Counter
from dataclasses import FrozenInstanceError
from pathlib import Path

import pytest

from curvefit.config import InputSpec, OutputSpec, RunConfig, load_config
from curvefit import preflight as preflight_module
from curvefit.engines import smoothing
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.preflight import PreflightResult, validate
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src" / "curvefit"

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
"""root は権限ビットを無視して書き込めるため、書き込み不能の検証が成立しない。"""

requires_permission_bits = pytest.mark.skipif(
    IS_ROOT, reason="root では権限ビットによる書き込み不能を再現できない"
)

GAUSSIAN = MethodSpec(name="gauss", kind="builtin", builtin="gaussian")
"""正常な手法指定。組込モデルは初期値を与えなくてもよい（要件 4.1）。"""

ORDER_SCRIPT = '''
import sys
from pathlib import Path

from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.preflight import validate
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec

base = Path(sys.argv[1])
config = RunConfig(
    inputs=InputSpec(paths=("data/a.csv",), columns=ColumnSpec(x="time", y="signal")),
    methods=(
        MethodSpec(name="u", kind="builtin", builtin="nope"),
        MethodSpec(name="expr", kind="expression", expression="a * x + b"),
        MethodSpec(
            name="mav",
            kind="smoother",
            smoother=SmootherKind.MOVING_AVERAGE,
            options={"window": 4, "polyorder": -1, "zeta": 1, "alpha": 2},
        ),
        MethodSpec(name="gauss", kind="builtin", builtin="gaussian", initial={"sigma": -1.0}),
    ),
    preprocess=PreprocessSpec(
        x_min=10.0, x_max=0.0, outlier=OutlierSpec(sigma=0.0, max_iterations=-1)
    ),
    output=OutputSpec(directory=base / "no" / "such" / "dir"),
)
for violation in validate(config).violations:
    print(violation.kind.value, violation.location, violation.message, sep="\\t")
'''
"""別プロセスで違反の並びを書き出す小さな台本。

`PYTHONHASHSEED` を変えて実行し、出力が一致することで写像の走査順に依存していない
ことを示す（要件 8.2）。
"""


def _config(
    directory: Path,
    *,
    methods: tuple[MethodSpec, ...] = (GAUSSIAN,),
    preprocess: PreprocessSpec | None = None,
    paths: tuple[str, ...] = ("data/a.csv",),
    weight: str | int | None = None,
) -> RunConfig:
    """検証対象の実行条件を組み立てる。既定は違反を 1 件も含まない。

    ``weight`` は測定誤差を表す列の指定である（要件 1.3）。既定の ``None`` は
    「誤差列を指定していない」を意味し、要件 1.10 の検査対象にならない。
    """
    return RunConfig(
        inputs=InputSpec(
            paths=paths, columns=ColumnSpec(x="time", y="signal", weight=weight)
        ),
        methods=methods,
        preprocess=preprocess if preprocess is not None else PreprocessSpec(),
        output=OutputSpec(directory=directory),
    )


def _kinds(result: PreflightResult) -> list[ViolationKind]:
    return [violation.kind for violation in result.violations]


def _locations(result: PreflightResult) -> list[str]:
    return [violation.location for violation in result.violations]


def _only(result: PreflightResult) -> ConfigViolation:
    """違反がちょうど 1 件であることを確かめて取り出す。"""
    assert len(result.violations) == 1, f"違反が 1 件ではない: {result.violations}"
    return result.violations[0]


def _smoother(
    kind: SmootherKind, options: dict[str, float | int], name: str = "sm"
) -> MethodSpec:
    return MethodSpec(name=name, kind="smoother", smoother=kind, options=options)


class Test正常な設定:
    """完了状態: 正常な設定では検査を通過する。"""

    def test_違反が無ければ_ok(self, tmp_path: Path) -> None:
        result = validate(_config(tmp_path))

        assert result.ok is True
        assert result.violations == ()

    def test_結果は生成後に変更できない(self, tmp_path: Path) -> None:
        result = validate(_config(tmp_path))

        with pytest.raises(FrozenInstanceError):
            result.violations = ()  # type: ignore[misc]

    def test_違反が_1_件でもあれば_ok_は偽(self, tmp_path: Path) -> None:
        result = validate(
            _config(tmp_path, methods=(MethodSpec(name="u", kind="builtin", builtin="nope"),))
        )

        assert result.ok is False

    def test_3_経路と_4_手法をすべて含む設定が通過する(self, tmp_path: Path) -> None:
        def model(x: float, a: float) -> float:
            return a * x

        methods = (
            GAUSSIAN,
            MethodSpec(name="expr", kind="expression", expression="a * x + b", initial={"a": 1.0, "b": 0.0}),
            MethodSpec(name="func", kind="callable", function=model, initial={"a": 1.0}),
            _smoother(SmootherKind.LINEAR, {}, name="lin"),
            _smoother(SmootherKind.POLYNOMIAL, {"degree": 3}, name="poly"),
            _smoother(SmootherKind.SPLINE, {"lam": 0.5}, name="spl"),
            _smoother(SmootherKind.MOVING_AVERAGE, {"window": 7, "polyorder": 2}, name="mav"),
        )

        result = validate(_config(tmp_path, methods=methods))

        assert result.violations == ()

    def test_選択肢を省略した平滑化は通過する(self, tmp_path: Path) -> None:
        """既定値が適用される形は違反ではない（要件 5.4）。

        平滑化スプラインは既定値を持たず、省略できない（要件 5.5）。ここに並べない
        のはそのためである。
        """
        methods = (
            _smoother(SmootherKind.POLYNOMIAL, {}, name="poly"),
            _smoother(SmootherKind.MOVING_AVERAGE, {}, name="mav"),
        )

        assert validate(_config(tmp_path, methods=methods)).violations == ()


class Testモデル解決の可否:
    """要件 3.4: 解決できないモデル指定は処理を開始せず報告する。"""

    def test_未知の組込モデル名は違反(self, tmp_path: Path) -> None:
        result = validate(
            _config(tmp_path, methods=(MethodSpec(name="u", kind="builtin", builtin="nope"),))
        )

        violation = _only(result)
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED
        assert "nope" in violation.message
        assert violation.location == "method[u].builtin"

    def test_解釈できない数式は違反(self, tmp_path: Path) -> None:
        method = MethodSpec(name="bad", kind="expression", expression="a * (x +")

        result = validate(_config(tmp_path, methods=(method,)))

        assert ViolationKind.MODEL_UNRESOLVED in _kinds(result)

    def test_平滑化手法が未指定なら違反(self, tmp_path: Path) -> None:
        method = MethodSpec(name="sm", kind="smoother", smoother=None)

        result = validate(_config(tmp_path, methods=(method,)))

        assert _only(result).kind is ViolationKind.MODEL_UNRESOLVED

    def test_解決できない手法の選択肢は検査しない(self, tmp_path: Path) -> None:
        """手法が定まらなければ選択肢の制約も定まらない。無関係な違反を増やさない。"""
        method = MethodSpec(name="sm", kind="smoother", smoother=None, options={"window": 4})

        result = validate(_config(tmp_path, methods=(method,)))

        assert _kinds(result) == [ViolationKind.MODEL_UNRESOLVED]


class Test初期値の必須性:
    """要件 4.3: 組込以外のモデルでは初期値の指定が必須である。"""

    def test_初期値のない数式モデルは違反(self, tmp_path: Path) -> None:
        method = MethodSpec(name="expr", kind="expression", expression="a * x + b")

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_REQUIRED
        assert violation.location == "method[expr].initial"

    def test_初期値のない利用者定義関数は違反(self, tmp_path: Path) -> None:
        def model(x: float, a: float, b: float) -> float:
            return a * x + b

        method = MethodSpec(name="func", kind="callable", function=model)

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.INITIAL_REQUIRED
        )

    def test_一部のパラメータだけの初期値も違反(self, tmp_path: Path) -> None:
        """残りが基盤ライブラリの既定値になり、当てはめ時に異常終了する。"""
        method = MethodSpec(
            name="expr", kind="expression", expression="a * x + b", initial={"a": 1.0}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_REQUIRED
        assert "b" in violation.message

    def test_組込モデルは初期値がなくても違反にならない(self, tmp_path: Path) -> None:
        """自動推定を持つため必須ではない（要件 4.1）。データは実行時に与えられる。"""
        assert validate(_config(tmp_path)).violations == ()


class Test初期値と上下限の整合:
    """要件 4.6: 初期値が上下限の外にあれば処理を開始せず報告する。"""

    def test_指定された上下限の外にある初期値は違反(self, tmp_path: Path) -> None:
        method = MethodSpec(
            name="gauss",
            kind="builtin",
            builtin="gaussian",
            initial={"amplitude": 20.0},
            bounds={"amplitude": (0.0, 10.0)},
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_OUT_OF_BOUNDS
        assert "amplitude" in violation.message

    def test_モデル固有の上下限の外にある初期値も違反(self, tmp_path: Path) -> None:
        """ガウシアンの幅は負を取れない。基盤ライブラリは黙って丸めるため先に止める。"""
        method = MethodSpec(
            name="gauss", kind="builtin", builtin="gaussian", initial={"sigma": -1.0}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_OUT_OF_BOUNDS
        assert "sigma" in violation.message


class Test平滑化オプションの制約:
    """要件 5.4: 手法固有の選択肢は当てはめエンジンの定数を出所として検証する。"""

    def test_未知の選択肢名は違反(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.POLYNOMIAL, {"windows": 5})

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert "windows" in violation.message
        assert violation.location == "method[sm].options"

    def test_選択肢を持たない手法への指定も違反(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.LINEAR, {"degree": 2})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    @pytest.mark.parametrize("window", [4, 0, -3, 2.0, 5.5])
    def test_窓長は正の奇数でなければ違反(self, tmp_path: Path, window: float | int) -> None:
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": window})

        violations = validate(_config(tmp_path, methods=(method,))).violations

        assert violations, f"窓長 {window} が通過した"
        assert all(v.kind is ViolationKind.SMOOTHER_OPTION_INVALID for v in violations)

    @pytest.mark.parametrize("window", [1, 3, 5, 11])
    def test_正の奇数の窓長は通過する(self, tmp_path: Path, window: int) -> None:
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": window})

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_多項式次数が負なら違反(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 5, "polyorder": -1})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    def test_多項式次数が窓長以上なら違反(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 5, "polyorder": 5})

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert "polyorder" in violation.message

    def test_窓長未指定でも既定値との比較で判定する(self, tmp_path: Path) -> None:
        """既定の窓長が適用されるため、それを超える次数は実行時に破綻する。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"polyorder": 6})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    def test_多項式次数が整数でなければ違反(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 5, "polyorder": 1.5})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    @pytest.mark.parametrize("degree", [-1, 2.5])
    def test_多項式回帰の次数は非負整数(self, tmp_path: Path, degree: float | int) -> None:
        method = _smoother(SmootherKind.POLYNOMIAL, {"degree": degree})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    def test_次数_0_の多項式回帰は通過する(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.POLYNOMIAL, {"degree": 0})

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    @pytest.mark.parametrize("lam", [0, -1.0])
    def test_平滑化パラメータは正でなければ違反(
        self, tmp_path: Path, lam: float | int
    ) -> None:
        method = _smoother(SmootherKind.SPLINE, {"lam": lam})

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert "lam" in violation.message

    def test_平滑化パラメータの未指定は違反(self, tmp_path: Path) -> None:
        """要件 5.5: 未指定のスプラインは実行前に拒否する。

        未指定だと基盤ライブラリの GCV 探索が働き、同一設定・同一入力の再実行で
        当てはめ値が揺れる（要件 8.2 が成立しない）。報告は「不正」ではなく、
        何を指定すべきかと、なぜ必須なのかを伝える。
        """
        violation = _only(
            validate(_config(tmp_path, methods=(_smoother(SmootherKind.SPLINE, {}),)))
        )

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert violation.location == "method[sm].options"
        assert smoothing.SPLINE_LAMBDA_OPTION in violation.message
        assert "必須" in violation.message
        assert "再現性" in violation.message

    def test_平滑化パラメータを指定したスプラインは通過する(self, tmp_path: Path) -> None:
        assert validate(
            _config(tmp_path, methods=(_smoother(SmootherKind.SPLINE, {"lam": 1e-2}),))
        ).violations == ()

    def test_平滑化パラメータの未指定は他の違反を打ち切らない(self, tmp_path: Path) -> None:
        """要件 5.5 の検査も、最初の違反で打ち切らないという契約の内側にある。"""
        methods = (
            _smoother(SmootherKind.SPLINE, {}, name="spl"),
            _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4}, name="mav"),
            MethodSpec(name="u", kind="builtin", builtin="nope"),
        )

        result = validate(
            _config(
                tmp_path,
                methods=methods,
                preprocess=PreprocessSpec(x_min=10.0, x_max=0.0),
            )
        )

        assert _kinds(result) == [
            ViolationKind.SMOOTHER_OPTION_INVALID,
            ViolationKind.SMOOTHER_OPTION_INVALID,
            ViolationKind.MODEL_UNRESOLVED,
            ViolationKind.CONFIG_INVALID,
        ]

    def test_未指定と未知の選択肢が同時に報告される(self, tmp_path: Path) -> None:
        """未知の選択肢名を弾いても、必須の選択肢が欠けている事実は消えない。"""
        method = _smoother(SmootherKind.SPLINE, {"smooth": 1.0})

        result = validate(_config(tmp_path, methods=(method,)))

        assert len(result.violations) == 2
        assert all(
            violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
            for violation in result.violations
        )
        assert [("必須" in v.message) for v in result.violations].count(True) == 1

    def test_同一手法の複数の選択肢違反が一度に返る(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4, "polyorder": -1})

        assert len(validate(_config(tmp_path, methods=(method,))).violations) == 2

    def test_組込モデルの次数はモデル解決層が判定する(self, tmp_path: Path) -> None:
        """平滑化の制約検証が組込モデルにまで及ばないことを確かめる（検査の二重化防止）。"""
        method = MethodSpec(
            name="poly", kind="builtin", builtin="polynomial", options={"degree": -1}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.CONFIG_INVALID


class Test平滑化手法へのパラメータ指定:
    """要件 4.4、4.5、8.5: 平滑化手法はパラメータの指定を受け付けない。

    平滑化手法も推定結果としては名前付きパラメータを返す（要件 5.3）。受け付けないのは
    解き方の側の理由であり、閉形式で解く以上、パラメータは結果として出てくるもので
    あって探索の出発点や範囲として与えられるものではない。

    `initial` / `bounds` / `fixed` は当てはめに一切効かないため、黙って捨てず実行前に
    拒否する。捨てると `smoother = "linear"` に `bounds` を添えた設定が exit=0 で
    上限の 985 倍の推定値を返し、同じ指定を `builtin = "linear"` に書いた場合
    （exit=2）と結果が食い違う。タスク 6.3 が `expression` に添えた `options` を
    拒否したのと同じ扱いである。
    """

    @pytest.mark.parametrize(
        ("field", "value"),
        [
            ("initial", {"slope": 99.0}),
            ("bounds", {"slope": (0.0, 0.001)}),
            ("fixed", {"slope": 1.0}),
        ],
    )
    def test_パラメータ指定は単独でも違反(
        self, tmp_path: Path, field: str, value: dict[str, object]
    ) -> None:
        method = MethodSpec(
            name="sm", kind="smoother", smoother=SmootherKind.LINEAR, **{field: value}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == f"method[sm].{field}"
        assert "slope" in violation.message
        assert SmootherKind.LINEAR.value in violation.message

    def test_3_つの指定がすべて報告される(self, tmp_path: Path) -> None:
        """最初の 1 件で打ち切らない。3 か所を 1 回の実行で直せる。"""
        method = MethodSpec(
            name="sm",
            kind="smoother",
            smoother=SmootherKind.LINEAR,
            initial={"slope": 99.0},
            bounds={"slope": (0.0, 0.001)},
            fixed={"intercept": 1.0},
        )

        result = validate(_config(tmp_path, methods=(method,)))

        assert _locations(result) == [
            "method[sm].initial",
            "method[sm].bounds",
            "method[sm].fixed",
        ]
        assert _kinds(result) == [ViolationKind.CONFIG_INVALID] * 3

    def test_パラメータ名は名前順に並ぶ(self, tmp_path: Path) -> None:
        """要件 8.2 の決定性: 写像の走査順に報告内容が左右されない。"""
        method = MethodSpec(
            name="sm",
            kind="smoother",
            smoother=SmootherKind.LINEAR,
            initial={"slope": 1.0, "intercept": 0.0, "amplitude": 2.0},
        )

        message = _only(validate(_config(tmp_path, methods=(method,)))).message

        assert message.index("amplitude") < message.index("intercept")
        assert message.index("intercept") < message.index("slope")

    def test_選択肢の違反と同時に報告される(self, tmp_path: Path) -> None:
        """選択肢の検査を打ち切らない（全項目を検査してから返すという契約）。"""
        method = MethodSpec(
            name="sm",
            kind="smoother",
            smoother=SmootherKind.SPLINE,
            initial={"slope": 1.0},
        )

        result = validate(_config(tmp_path, methods=(method,)))

        assert _kinds(result) == [
            ViolationKind.CONFIG_INVALID,
            ViolationKind.SMOOTHER_OPTION_INVALID,
        ]

    def test_他の手法の違反を打ち切らない(self, tmp_path: Path) -> None:
        methods = (
            MethodSpec(
                name="sm",
                kind="smoother",
                smoother=SmootherKind.LINEAR,
                bounds={"slope": (0.0, 0.001)},
            ),
            MethodSpec(name="u", kind="builtin", builtin="nope"),
        )

        result = validate(_config(tmp_path, methods=methods))

        assert _kinds(result) == [
            ViolationKind.CONFIG_INVALID,
            ViolationKind.MODEL_UNRESOLVED,
        ]

    @pytest.mark.parametrize(
        ("kind", "options"),
        [
            (SmootherKind.LINEAR, {}),
            (SmootherKind.POLYNOMIAL, {"degree": 2}),
            (SmootherKind.SPLINE, {"lam": 1e-2}),
            (SmootherKind.MOVING_AVERAGE, {"window": 5}),
        ],
    )
    def test_パラメータを書かない平滑化は通過する(
        self, tmp_path: Path, kind: SmootherKind, options: dict[str, float | int]
    ) -> None:
        """誤検出の回帰止め。4 手法のいずれも従来どおり実行できる。"""
        assert validate(_config(tmp_path, methods=(_smoother(kind, options),))).violations == ()

    def test_組込モデルはパラメータ指定を引き続き受け付ける(self, tmp_path: Path) -> None:
        """要件 4.2、4.4、4.5 の経路を塞がない。"""
        method = MethodSpec(
            name="lin",
            kind="builtin",
            builtin="linear",
            initial={"slope": 0.5},
            bounds={"slope": (0.0, 1.0)},
            fixed={"intercept": 0.0},
        )

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_数式モデルはパラメータ指定を引き続き受け付ける(self, tmp_path: Path) -> None:
        method = MethodSpec(
            name="expr",
            kind="expression",
            expression="a * x + b",
            initial={"a": 1.0},
            bounds={"a": (0.0, 2.0)},
            fixed={"b": 0.0},
        )

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_解決できない手法のパラメータ指定は検査しない(self, tmp_path: Path) -> None:
        """手法が定まらなければ、何を指定できるかも定まらない（選択肢と同じ扱い）。"""
        method = MethodSpec(
            name="sm", kind="smoother", smoother=None, initial={"slope": 1.0}
        )

        result = validate(_config(tmp_path, methods=(method,)))

        assert _kinds(result) == [ViolationKind.MODEL_UNRESOLVED]


class Test重みを扱えない手法への誤差列指定:
    """要件 1.10: 点ごとの重みを扱えない手法に誤差列を与えた設定を実行前に拒否する。

    黙って無視すると、測定誤差を与えた利用者がそれを反映した結果として読む。実行ログの
    警告は `summary.csv` だけを読む利用者に届かない。平滑化手法へのパラメータ指定を
    拒否するのと同じ扱いである（要件 4.4、4.5）。

    **対象は列挙ではなく `engines.smoothing` の宣言から導く。** 拒否する手法の一覧を
    ここが独自に持つと、スプラインが重みを扱えるようになったとき（タスク 11.1）と同じ
    形で、宣言と拒否対象が食い違う。
    """

    def test_重みを扱えない手法には個別の理由が用意されている(self) -> None:
        """宣言に手法が加わったとき、理由の追加漏れに気づけること（要件 1.10）。

        理由が漏れると一般化した説明に落ちる。利用者には「なぜこの手法では駄目なのか」が
        伝わらず、次の一手も選べない。宣言側には `test_全手法について宣言がある` があるが、
        理由側には対応する検査が無かった。
        """
        weightless = {
            kind
            for kind, uses in smoothing.SMOOTHER_USES_WEIGHTS.items()
            if not uses
        }

        reasons = set(preflight_module._NO_WEIGHT_SUPPORT_REASONS)
        assert weightless <= reasons, (
            "重みを扱えないと宣言した手法に個別の理由が無い: "
            f"{sorted(k.value for k in weightless - reasons)}"
        )

    WEIGHT_COLUMN = "err"

    def test_移動平均と誤差列の組み合わせは違反(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        violation = _only(
            validate(
                _config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN)
            )
        )

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == "method[sm].smoother"

    def test_報告は手法と設定箇所と次の一手を伝える(self, tmp_path: Path) -> None:
        """「反映できない」で終えない。理由・場所・直し方の 3 つを載せる。

        `_why_not_applicable` の precedent に倣う。理由の分からない拒否は、設定の
        書き直しではなく手法の乗り換えを招く。
        """
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        message = _only(
            validate(
                _config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN)
            )
        ).message

        # 当該手法を名指しする
        assert SmootherKind.MOVING_AVERAGE.value in message
        # 直すべき設定箇所を名指しする
        assert "input.columns.weight" in message
        # 「重みを扱えない」の実体を述べる。畳み込み係数が窓長と多項式次数だけで
        # 決まる以上、点ごとの重みを置く場所が無い
        assert "窓長" in message
        assert "多項式次数" in message
        # 取れる道を両方示す
        assert "削除" in message
        assert SmootherKind.SPLINE.value in message

    @pytest.mark.parametrize(
        ("kind", "options"),
        [
            (SmootherKind.LINEAR, {}),
            (SmootherKind.POLYNOMIAL, {"degree": 2}),
            (SmootherKind.SPLINE, {"lam": 1e-2}),
        ],
    )
    def test_重みを扱う平滑化は誤差列を指定しても通過する(
        self, tmp_path: Path, kind: SmootherKind, options: dict[str, float | int]
    ) -> None:
        """誤検出の回帰止め。タスク 11.1 でスプラインが重みを扱うようになった。"""
        method = _smoother(kind, options)

        result = validate(
            _config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN)
        )

        assert result.violations == ()

    @pytest.mark.parametrize(
        "method",
        [
            MethodSpec(name="lin", kind="builtin", builtin="linear"),
            MethodSpec(name="gauss", kind="builtin", builtin="gaussian"),
            MethodSpec(
                name="expr",
                kind="expression",
                expression="a * x + b",
                initial={"a": 1.0, "b": 0.0},
            ),
        ],
    )
    def test_モデル関数フィットは誤差列を指定しても通過する(
        self, tmp_path: Path, method: MethodSpec
    ) -> None:
        """要件 1.3 の主たる経路を塞がない。最小二乗はいずれも重みを用いる。"""
        result = validate(
            _config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN)
        )

        assert result.violations == ()

    def test_誤差列を指定しない移動平均は通過する(self, tmp_path: Path) -> None:
        """完了状態: 指定しなければ従来どおり実行できる。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_位置で指定された誤差列も対象になる(self, tmp_path: Path) -> None:
        """列指定は名前でも位置でもよい（`ColumnSpec`）。0 は偽値だが指定である。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        result = validate(_config(tmp_path, methods=(method,), weight=0))

        assert _kinds(result) == [ViolationKind.CONFIG_INVALID]

    def test_同一手法の選択肢違反を打ち切らない(self, tmp_path: Path) -> None:
        """全項目を検査してから返すという本ゲートの契約は手法 1 件の内側でも成り立つ。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4})

        result = validate(
            _config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN)
        )

        assert _kinds(result) == [
            ViolationKind.SMOOTHER_OPTION_INVALID,
            ViolationKind.CONFIG_INVALID,
        ]

    def test_他の手法と出力先と前処理の違反を打ち切らない(self, tmp_path: Path) -> None:
        methods = (
            _smoother(SmootherKind.MOVING_AVERAGE, {}, name="mav"),
            MethodSpec(name="u", kind="builtin", builtin="nope"),
        )

        result = validate(
            RunConfig(
                inputs=InputSpec(
                    paths=("data/a.csv",),
                    columns=ColumnSpec(x="time", y="signal", weight="err"),
                ),
                methods=methods,
                preprocess=PreprocessSpec(x_min=10.0, x_max=0.0),
                output=OutputSpec(directory=tmp_path / "no" / "such" / "dir"),
            )
        )

        assert _locations(result) == [
            "method[mav].smoother",
            "method[u].builtin",
            "output_dir",
            "preprocess.x_min",
        ]

    def test_解決できない手法は検査しない(self, tmp_path: Path) -> None:
        """手法が定まらなければ重みを扱えるかも定まらない（選択肢と同じ扱い）。"""
        method = MethodSpec(name="sm", kind="smoother", smoother=None)

        result = validate(
            _config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN)
        )

        assert _kinds(result) == [ViolationKind.MODEL_UNRESOLVED]

    def test_拒否する手法は宣言から導かれる(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """宣言を書き換えれば拒否の対象も変わる。列挙の二重所有を排除した証拠。

        `SMOOTHER_USES_WEIGHTS` を差し替えて、線形回帰が拒否側・移動平均が通過側に
        入れ替わることを確かめる。ゲートが独自の一覧を持っていればここで落ちる。
        """
        from curvefit import preflight

        flipped = {
            **smoothing.SMOOTHER_USES_WEIGHTS,
            SmootherKind.LINEAR: False,
            SmootherKind.MOVING_AVERAGE: True,
        }
        monkeypatch.setattr(preflight, "SMOOTHER_USES_WEIGHTS", flipped)

        linear = validate(
            _config(
                tmp_path,
                methods=(_smoother(SmootherKind.LINEAR, {}),),
                weight=self.WEIGHT_COLUMN,
            )
        )
        moving = validate(
            _config(
                tmp_path,
                methods=(_smoother(SmootherKind.MOVING_AVERAGE, {}),),
                weight=self.WEIGHT_COLUMN,
            )
        )

        assert _kinds(linear) == [ViolationKind.CONFIG_INVALID]
        assert moving.violations == ()


class Test既定値の出所:
    """既定値は `engines.smoothing` が単独で所有する。preflight は独自に持たない。"""

    def test_定数をそのまま参照している(self) -> None:
        from curvefit import preflight

        assert preflight.SMOOTHER_OPTION_DEFAULTS is smoothing.SMOOTHER_OPTION_DEFAULTS
        assert preflight.SMOOTHER_OPTION_NAMES is smoothing.SMOOTHER_OPTION_NAMES

    def test_既定値を差し替えると判定も変わる(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """既定値を写し取っていれば、エンジン側の定数を替えても判定は変わらない。"""
        from curvefit import preflight

        method = _smoother(SmootherKind.MOVING_AVERAGE, {"polyorder": 6})
        assert validate(_config(tmp_path, methods=(method,))).violations != ()

        widened = {**smoothing.SMOOTHER_OPTION_DEFAULTS}
        widened[SmootherKind.MOVING_AVERAGE] = {
            smoothing.MOVING_AVERAGE_WINDOW_OPTION: 9,
            smoothing.MOVING_AVERAGE_POLYORDER_OPTION: 0,
        }
        monkeypatch.setattr(preflight, "SMOOTHER_OPTION_DEFAULTS", widened)

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_既定値そのものは違反にならない(self, tmp_path: Path) -> None:
        """エンジンが適用する既定値の組が、本ゲートの制約を満たすことの回帰検出。

        スプラインの平滑化パラメータは既定値を持たない必須の選択肢であり（要件 5.5）、
        既定値の妥当性という問いの対象外である。ここでは正当な値を補って比較する。
        """
        for kind, defaults in smoothing.SMOOTHER_OPTION_DEFAULTS.items():
            options = dict(defaults)
            if kind is SmootherKind.SPLINE:
                options[smoothing.SPLINE_LAMBDA_OPTION] = 1e-2
            method = _smoother(kind, options)

            assert validate(_config(tmp_path, methods=(method,))).violations == (), kind


class Test出力先の書き込み可否:
    """要件 7.7: 書き込めない出力先は処理を開始せず報告する。"""

    @requires_permission_bits
    def test_書き込めないディレクトリは違反(self, tmp_path: Path) -> None:
        directory = tmp_path / "locked"
        directory.mkdir()
        directory.chmod(stat.S_IRUSR | stat.S_IXUSR)
        try:
            result = validate(_config(directory))
        finally:
            directory.chmod(stat.S_IRWXU)

        violation = _only(result)
        assert violation.kind is ViolationKind.OUTPUT_NOT_WRITABLE
        assert str(directory) in violation.message

    def test_親ごと存在しない出力先は違反(self, tmp_path: Path) -> None:
        result = validate(_config(tmp_path / "no" / "such" / "dir"))

        assert _only(result).kind is ViolationKind.OUTPUT_NOT_WRITABLE

    def test_親が存在すれば未作成でも違反にならない(self, tmp_path: Path) -> None:
        assert validate(_config(tmp_path / "out")).violations == ()


class Test設定構造の妥当性:
    """要件 8.5、2.1: データに依存しない設定の誤りは実行前に止める。"""

    def test_フィット区間の逆転は違反(self, tmp_path: Path) -> None:
        """前処理層は検証しない。通すと点数不足として黙って失敗する。"""
        spec = PreprocessSpec(x_min=10.0, x_max=0.0)

        violation = _only(validate(_config(tmp_path, preprocess=spec)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location.startswith("preprocess")

    def test_上下限が等しい区間は違反ではない(self, tmp_path: Path) -> None:
        spec = PreprocessSpec(x_min=1.0, x_max=1.0)

        assert validate(_config(tmp_path, preprocess=spec)).violations == ()

    def test_片側だけの区間指定は違反ではない(self, tmp_path: Path) -> None:
        spec = PreprocessSpec(x_min=10.0)

        assert validate(_config(tmp_path, preprocess=spec)).violations == ()

    @pytest.mark.parametrize("sigma", [0.0, -1.0])
    def test_外れ値判定の閾値は正でなければ違反(self, tmp_path: Path, sigma: float) -> None:
        """0 以下では残差が 0 でない全点が外れ値になる。"""
        spec = PreprocessSpec(outlier=OutlierSpec(sigma=sigma))

        violation = _only(validate(_config(tmp_path, preprocess=spec)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == "preprocess.outlier.sigma"

    def test_反復上限が負なら違反(self, tmp_path: Path) -> None:
        spec = PreprocessSpec(outlier=OutlierSpec(max_iterations=-1))

        violation = _only(validate(_config(tmp_path, preprocess=spec)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == "preprocess.outlier.max_iterations"

    def test_反復上限_0_は違反ではない(self, tmp_path: Path) -> None:
        spec = PreprocessSpec(outlier=OutlierSpec(max_iterations=0))

        assert validate(_config(tmp_path, preprocess=spec)).violations == ()

    def test_外れ値除去が無効なら値域は検査しない(self, tmp_path: Path) -> None:
        assert validate(_config(tmp_path, preprocess=PreprocessSpec(outlier=None))).violations == ()

    def test_外れ値設定の複数の違反が一度に返る(self, tmp_path: Path) -> None:
        spec = PreprocessSpec(outlier=OutlierSpec(sigma=0.0, max_iterations=-1))

        assert len(validate(_config(tmp_path, preprocess=spec)).violations) == 2


class Test入力パスの存在確認:
    """入力パスの存在は検査しない。0 件は正常、不存在は個別の失敗（要件 1.4/1.5）。"""

    def test_存在しないファイルの直接指定は通過する(self, tmp_path: Path) -> None:
        config = _config(tmp_path, paths=(str(tmp_path / "missing.csv"),))

        assert validate(config).ok is True

    def test_存在しないディレクトリの指定も通過する(self, tmp_path: Path) -> None:
        config = _config(tmp_path, paths=(str(tmp_path / "no_such_dir"),))

        assert validate(config).ok is True

    def test_空のディレクトリ指定も通過する(self, tmp_path: Path) -> None:
        empty = tmp_path / "empty"
        empty.mkdir()

        assert validate(_config(tmp_path, paths=(str(empty),))).ok is True


class Testデータに依存しない解決:
    """設計の Implementation Notes: モデル解決は `sample=None` で行う。"""

    def test_解決にデータを渡さない(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from curvefit import preflight

        samples: list[object] = []
        original = preflight.resolve

        def spy(spec: MethodSpec, sample: object) -> object:
            samples.append(sample)
            return original(spec, None)

        monkeypatch.setattr(preflight, "resolve", spy)
        validate(_config(tmp_path, methods=(GAUSSIAN, _smoother(SmootherKind.LINEAR, {}))))

        assert samples == [None, None]

    def test_自動推定の可否はここでは判定しない(self, tmp_path: Path) -> None:
        """データが無くても組込モデルは通過する。推定はジョブ実行時に行う。"""
        result = validate(_config(tmp_path, methods=(GAUSSIAN,)))

        assert result.ok is True


class Test違反の一括収集:
    """完了状態: 複数の違反を含む設定に対して全違反が一度に返る。"""

    def _every_category(self, tmp_path: Path) -> RunConfig:
        """6 種類の違反分類すべてを 1 つの設定に含める。"""
        def model(x: float, a: float) -> float:
            return a * x

        methods = (
            MethodSpec(name="unknown", kind="builtin", builtin="nope"),
            MethodSpec(name="expr", kind="expression", expression="a * x + b"),
            MethodSpec(
                name="gauss", kind="builtin", builtin="gaussian", initial={"sigma": -1.0}
            ),
            _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4}, name="mav"),
        )
        return RunConfig(
            inputs=InputSpec(paths=("data/a.csv",), columns=ColumnSpec(x="time", y="signal")),
            methods=methods,
            preprocess=PreprocessSpec(x_min=10.0, x_max=0.0),
            output=OutputSpec(directory=tmp_path / "no" / "such" / "dir"),
        )

    def test_全分類の違反が一度に返る(self, tmp_path: Path) -> None:
        result = validate(self._every_category(tmp_path))

        assert Counter(_kinds(result)) == Counter(
            [
                ViolationKind.MODEL_UNRESOLVED,
                ViolationKind.INITIAL_REQUIRED,
                ViolationKind.INITIAL_OUT_OF_BOUNDS,
                ViolationKind.SMOOTHER_OPTION_INVALID,
                ViolationKind.OUTPUT_NOT_WRITABLE,
                ViolationKind.CONFIG_INVALID,
            ]
        )

    def test_件数は分類の数と一致する(self, tmp_path: Path) -> None:
        assert len(validate(self._every_category(tmp_path)).violations) == 6

    def test_全分類が網羅されている(self, tmp_path: Path) -> None:
        """検査項目の抜けを検出する。分類を増やしたら本テストが落ちる。"""
        assert set(_kinds(validate(self._every_category(tmp_path)))) == set(ViolationKind)

    def test_最初の手法で打ち切らない(self, tmp_path: Path) -> None:
        methods = (
            MethodSpec(name="a", kind="builtin", builtin="nope"),
            MethodSpec(name="b", kind="builtin", builtin="also_nope"),
            MethodSpec(name="c", kind="builtin", builtin="still_nope"),
        )

        result = validate(_config(tmp_path, methods=methods))

        assert _locations(result) == ["method[a].builtin", "method[b].builtin", "method[c].builtin"]

    def test_どの分類でも例外を送出しない(self, tmp_path: Path) -> None:
        """利用者が書いた内容に対して例外を送出しない（設計の Error Strategy）。"""
        methods = (
            MethodSpec(name="x", kind="smoother", smoother=SmootherKind.SPLINE, options={"lam": "近い"}),  # type: ignore[dict-item]
            MethodSpec(name="y", kind="smoother", smoother=SmootherKind.MOVING_AVERAGE, options={"window": None}),  # type: ignore[dict-item]
        )

        result = validate(_config(tmp_path, methods=methods))

        assert not result.ok


class Test違反の並びの決定性:
    """要件 8.2: 同一の実行条件なら違反の並びも同一になる。"""

    def test_繰り返し呼んでも並びが変わらない(self, tmp_path: Path) -> None:
        config = _config(
            tmp_path / "no" / "such" / "dir",
            methods=(
                MethodSpec(name="u", kind="builtin", builtin="nope"),
                _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4, "polyorder": -1}),
            ),
            preprocess=PreprocessSpec(x_min=10.0, x_max=0.0, outlier=OutlierSpec(sigma=-1.0)),
        )

        first = validate(config).violations

        assert all(validate(config).violations == first for _ in range(5))

    def test_未知の選択肢名の並びも固定される(self, tmp_path: Path) -> None:
        method = _smoother(SmootherKind.LINEAR, {"zeta": 1, "alpha": 2, "mu": 3})

        result = validate(_config(tmp_path, methods=(method,)))

        assert [v.message for v in result.violations] == sorted(
            v.message for v in result.violations
        ), "未知の選択肢は名前順に並べる"

    def test_ハッシュ種を変えても並びが変わらない(self, tmp_path: Path) -> None:
        """写像の走査順に依存していないことを、別プロセスで確かめる（要件 8.2）。"""
        script = tmp_path / "order.py"
        script.write_text(ORDER_SCRIPT, encoding="utf-8")
        outputs = set()
        for seed in ("0", "1", "12345"):
            environment = {**os.environ, "PYTHONHASHSEED": seed, "PYTHONPATH": str(ROOT / "src")}
            completed = subprocess.run(
                [sys.executable, str(script), str(tmp_path)],
                capture_output=True,
                text=True,
                env=environment,
                check=True,
            )
            outputs.add(completed.stdout)

        assert len(outputs) == 1, outputs
        assert outputs.pop().strip(), "違反が 1 件も出ていない"


class Test設定ファイルからの経路:
    """`config` が値域の検証を委ねた項目を、本ゲートが受け取って判定する。"""

    def _load(self, tmp_path: Path, text: str) -> RunConfig:
        path = tmp_path / "config.toml"
        path.write_text(text, encoding="utf-8")
        result = load_config(path, {})
        assert isinstance(result[0], RunConfig), result
        return result[0]

    def test_設定ファイルの値域違反を本ゲートが捕まえる(self, tmp_path: Path) -> None:
        text = f"""
[input]
paths = ["data/a.csv"]

[input.columns]
x = "time"
y = "signal"

[[methods]]
name = "mav"
smoother = "moving_average"
options = {{ window = 4 }}

[preprocess]
x_min = 10.0
x_max = 0.0

[preprocess.outlier]
sigma = 0.0

[output]
directory = {str(tmp_path)!r}
"""
        result = validate(self._load(tmp_path, text))

        assert Counter(_kinds(result)) == Counter(
            [
                ViolationKind.SMOOTHER_OPTION_INVALID,
                ViolationKind.CONFIG_INVALID,
                ViolationKind.CONFIG_INVALID,
            ]
        )

    def test_数式モデルに添えた選択肢を本ゲートが捕まえる(self, tmp_path: Path) -> None:
        """数式・関数の経路に選択肢の意味はない（要件 8.5）。黙って捨てると、設定
        ファイルの記述と実際の実行条件が食い違ったまま当てはめが成功する。"""
        text = f"""
[input]
paths = ["data/a.csv"]

[input.columns]
x = "time"
y = "signal"

[[methods]]
name = "decay"
expression = "a * exp(-b * x) + c"
initial = {{ a = 1.0, b = 0.1, c = 0.0 }}
options = {{ degree = 3, window = 7, totally_bogus = 1 }}

[output]
directory = {str(tmp_path / "out")!r}
"""
        result = validate(self._load(tmp_path, text))

        assert result.ok is False
        assert _kinds(result) == [ViolationKind.CONFIG_INVALID]
        assert _locations(result) == ["method[decay].options"]
        message = result.violations[0].message
        assert message.index("degree") < message.index("totally_bogus") < message.index("window")

    def test_正しい設定ファイルは通過する(self, tmp_path: Path) -> None:
        text = f"""
[input]
paths = ["data/*.csv"]

[input.columns]
x = 0
y = 1

[[methods]]
name = "gauss"
builtin = "gaussian"

[[methods]]
name = "mav"
smoother = "moving_average"
options = {{ window = 7, polyorder = 2 }}

[output]
directory = {str(tmp_path / "out")!r}
"""
        assert validate(self._load(tmp_path, text)).ok is True


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が上位層やライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse((SRC / "preflight.py").read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class Test依存の露出:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_上位層を_import_しない(self) -> None:
        forbidden = {"curvefit.pipeline", "curvefit.api", "curvefit.cli"}

        assert not (_imported_modules() & forbidden)

    def test_基盤ライブラリを直接_import_しない(self) -> None:
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval", "numpy"}, (
                f"preflight.py が {imported} を import している"
            )

    def test_検証の出所を既存モジュールから取り込む(self) -> None:
        expected = {
            "curvefit.config",
            "curvefit.engines.smoothing",
            "curvefit.errors",
            "curvefit.models.resolver",
            "curvefit.preprocess",
            "curvefit.writers",
        }

        assert expected <= _imported_modules()

    def test_既定値を自前で定義しない(self) -> None:
        """モジュール変数に数値の既定値を持たないことを構文木で確かめる。

        注釈を付けるだけで検査をすり抜けないよう、`ast.Assign` と `ast.AnnAssign` の
        両方を見る。
        """
        tree = ast.parse((SRC / "preflight.py").read_text(encoding="utf-8"))
        for node in tree.body:
            if not isinstance(node, (ast.Assign, ast.AnnAssign)):
                continue
            numbers = [
                inner.value
                for inner in ast.walk(node)
                if isinstance(inner, ast.Constant)
                and isinstance(inner.value, (int, float))
                and not isinstance(inner.value, bool)
            ]

            assert not numbers, f"モジュール変数に数値の既定値がある: {ast.unparse(node)}"
