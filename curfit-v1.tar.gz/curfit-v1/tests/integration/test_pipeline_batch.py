"""バッチ制御と失敗集約の統合テスト（要件 6.3、6.4、6.5、6.6、8.4、10.1、10.3）。

本テストは :func:`curvefit.pipeline.run` が次を満たすことを検証する。

- **逐次実行と集約**（要件 6.6、10.1）: 展開された処理単位を順に実行し、成功件数と
  失敗件数を含む集計結果を返すこと。サマリ表に全処理単位が現れること
- **既定はスキップ継続**（要件 6.4）: 個別の失敗が残りの処理を止めないこと
- **読めない入力ファイル**（要件 1.8、10.1）: 存在しない・読み取れない入力を
  :attr:`~curvefit.errors.FailureReason.INPUT_UNREADABLE` の個別失敗として記録し、
  後続の処理単位を実行すること。1 件の綴り誤りで数百件のバッチが終わってはならない
- **fail-fast**（要件 6.5）: 明示指定時は最初の失敗で中止し、それまでの結果を保持すること
- **進捗通知**（要件 6.3）: 総処理単位数と総入力数の双方を通知すること。処理単位数は
  入力数 × 手法数であり、利用者が把握するファイル数と一致しない。端末への描画は
  行わないこと
- **0 件に解決された入力指定の警告**（要件 6.1、8.4）: その指定を明示して実行ログに
  残すこと。黙って正常終了すると 1 ディレクトリ分の入力が無報告で消える
- **資源枯渇**（要件 10.3）: ジョブ展開時の :exc:`OSError`、実行中の
  :exc:`MemoryError` / :exc:`OSError` を捕捉し、中断した対象を明示したうえで
  それまでの結果とサマリを保持して終了すること
- **適用既定値の記録**（要件 5.4）: 各処理単位が返した既定値を手法ごとに畳み込み、
  実行条件の記録に反映すること
- **決定性**（要件 8.2）: ログの順序が処理単位の順序に一致し、同一入力の再実行が
  同一のサマリ表を生むこと
- **メモリ上の系列の実行**（要件 9.1、9.3）: 読み込み済みの系列を受け取った実行が、
  入力の走査を行わず、出力先を持たないこと。それ以外の制御（処理単位の並び・進捗通知・
  適用既定値の畳み込み・資源枯渇の扱い）はファイル経由と同一であること

呼び出し側の誤りである :class:`~curvefit.pipeline.UnexpectedConfigViolation` は
捕捉しない。捕捉すべきは資源枯渇に限る（設計の Error Strategy）。

設計の Testing Strategy が `pipeline` の結線を統合テストに置いているため、単体では
なく `tests/integration/` に置く。
"""

from __future__ import annotations

import dataclasses
import csv
import json
import logging
import os
import stat
from collections.abc import Iterator, Sequence
from dataclasses import FrozenInstanceError
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pytest

from curvefit.config import FailurePolicy, InputSpec, OutputSpec, RunConfig
from curvefit.errors import ConfigViolation, FailureReason, ViolationKind
from curvefit.execution import (
    EXECUTION_RECORD_FILENAME,
    ExecutionRecord,
    build_execution_record,
)
from curvefit import pipeline
from curvefit.logging_setup import LOGGER_NAME, RUN_LOG_FILENAME
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.pipeline import (
    PLOT_SUBDIRECTORY,
    PREPROCESS_SUBDIRECTORY,
    CURVE_SUBDIRECTORY,
    CURVE_SUFFIX,
    EMPTY_INPUT_STATUS,
    SUMMARY_FILENAME,
    BatchReport,
    Job,
    JobResult,
    UnexpectedConfigViolation,
    expand_jobs,
    run,
)
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec
from curvefit.types import DataSeries, FitFailure, FitOutcome, FitSuccess

LINEAR = MethodSpec(name="lin", kind="builtin", builtin="linear")
POLYNOMIAL = MethodSpec(
    name="poly", kind="builtin", builtin="polynomial", options={"degree": 2}
)
MOVING_AVERAGE = MethodSpec(name="ma", kind="smoother", smoother=SmootherKind.MOVING_AVERAGE)

FIXED_MOMENT = datetime(2026, 1, 2, 3, 4, 5, tzinfo=UTC)
"""実行日時は実行ごとに正当に変わる唯一の値であるため、試験からは固定する（要件 8.2）。"""


def write_linear_csv(path: Path, *, n_points: int = 11, slope: float = 2.0) -> Path:
    """既知の直線から合成データを書き出す。見出し行を持つ。"""
    x = np.linspace(0.0, 10.0, n_points)
    y = slope * x + 1.0
    lines = ["x,y"]
    lines.extend(
        f"{x_value!r},{y_value!r}"
        for x_value, y_value in zip(x.tolist(), y.tolist(), strict=True)
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_broken_csv(path: Path) -> Path:
    """y 列を持たない CSV。要件 1.4 の ``COLUMN_NOT_FOUND`` になる。"""
    path.write_text("x,z\n0.0,1.0\n1.0,2.0\n2.0,3.0\n", encoding="utf-8")
    return path


def write_spiked_csv(path: Path, *, n_points: int = 11) -> Path:
    """外れ値を 1 点だけ含む直線データ。前処理が実際に除外を生む入力を作る。"""
    lines = ["x,y"]
    for index in range(n_points):
        x = float(index)
        y = 2.0 * x + (60.0 if index == n_points // 2 else 0.0)
        lines.append(f"{x!r},{y!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def make_config(
    directory: Path,
    paths: Sequence[str],
    methods: Sequence[MethodSpec],
    *,
    failure_policy: FailurePolicy = FailurePolicy.SKIP,
    write_summary: bool = True,
    write_plot: bool = False,
    write_curve: bool = False,
) -> RunConfig:
    """試験用の実行条件。グラフ出力は既定で切る（本試験の対象外であり実行が遅くなる）。

    ``write_curve`` を有効にすると、処理単位ごとの出力がファイルとして残る。集計の件数
    だけでは「実際にその処理単位が走ったか」を区別できない場面で用いる。
    """
    return RunConfig(
        inputs=InputSpec(paths=tuple(paths), columns=ColumnSpec(x="x", y="y")),
        methods=tuple(methods),
        preprocess=PreprocessSpec(),
        output=OutputSpec(
            directory=directory,
            write_summary=write_summary,
            write_plot=write_plot,
            write_curve=write_curve,
        ),
        failure_policy=failure_policy,
    )


def make_record() -> ExecutionRecord:
    """実行前に組み立てた実行条件の記録。適用既定値はまだ空である。"""
    return build_execution_record(
        resolved_config={"input": "test"},
        clock=lambda: FIXED_MOMENT,
        tool_version="0.0.0-test",
        library_versions={},
    )


def read_log(config: RunConfig) -> str:
    return (config.output.directory / RUN_LOG_FILENAME).read_text(encoding="utf-8")


def summary_rows(config: RunConfig) -> list[dict[str, str]]:
    path = config.output.directory / SUMMARY_FILENAME
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def identities(outcomes: Sequence[FitOutcome]) -> list[tuple[str, str]]:
    return [(outcome.source_id, outcome.method_name) for outcome in outcomes]


def curve_outputs(config: RunConfig) -> list[str]:
    """出力先に実際に残った曲線 CSV の名前。

    集計の件数は「後続が走ったか」を保証しない。中断していても、その時点までの結果は
    同じ件数になりうる。実行の痕跡はファイルシステムで確かめる。
    """
    directory = config.output.directory / CURVE_SUBDIRECTORY
    if not directory.exists():
        return []
    return sorted(path.name for path in directory.glob(f"*{CURVE_SUFFIX}"))


def job_identities(config: RunConfig) -> list[tuple[str, str]]:
    return [(job.source, job.method.name) for job in expand_jobs(config)]


def logged_identities(config: RunConfig) -> list[str]:
    """実行ログに現れた対象を、記録順のまま取り出す。"""
    collected: list[str] = []
    for line in read_log(config).splitlines():
        marker = "source_id="
        if marker not in line or "status=weights_ignored" in line:
            continue
        collected.append(line.split(marker, 1)[1].split(" ", 1)[0])
    return collected


class Recorder:
    """進捗通知の記録。:class:`~curvefit.pipeline.ProgressObserver` の試験実装。"""

    def __init__(self) -> None:
        self.started: list[tuple[int, int]] = []
        self.done: list[tuple[int, int, FitOutcome]] = []
        self.finished: list[BatchReport] = []

    def on_start(self, total_jobs: int, total_sources: int) -> None:
        self.started.append((total_jobs, total_sources))

    def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None:
        self.done.append((done, total, outcome))

    def on_finish(self, report: BatchReport) -> None:
        self.finished.append(report)


class Test逐次実行と集約:
    """展開された処理単位を順に実行し、集計結果を返すこと（要件 6.6、10.1）。"""

    def test_3_入力かつ_2_手法で_6_件の結果になる(self, tmp_path: Path) -> None:
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        report = run(config, make_record())

        assert len(report.outcomes) == 6
        assert report.n_success == 6
        assert report.n_failure == 0
        assert report.aborted is False
        assert all(isinstance(outcome, FitSuccess) for outcome in report.outcomes)

    def test_結果の並びが処理単位の並びに一致する(self, tmp_path: Path) -> None:
        """順序の所有者は :func:`expand_jobs` であり、集約は並べ替えない（要件 8.2）。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        report = run(config, make_record())

        assert identities(report.outcomes) == job_identities(config)

    def test_サマリ表に全処理単位が現れる(self, tmp_path: Path) -> None:
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        report = run(config, make_record())

        written = {(row["source_id"], row["method_name"]) for row in summary_rows(config)}
        assert written == set(identities(report.outcomes))

    def test_サマリ出力を無効にすると書き出さない(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR], write_summary=False
        )

        report = run(config, make_record())

        assert report.n_success == 1
        assert not (config.output.directory / SUMMARY_FILENAME).exists()

    def test_実行ログに開始と終了の件数が残る(self, tmp_path: Path) -> None:
        """要件 8.4: 処理した対象と成否を実行ログとして出力する。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        run(config, make_record())

        text = read_log(config)
        assert "status=started" in text
        assert "status=finished n_success=1 n_failure=0" in text

    def test_実行ログの順序が処理単位の順序に一致する(self, tmp_path: Path) -> None:
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        run(config, make_record())

        assert logged_identities(config) == [
            repr(source) for source, _ in job_identities(config)
        ]

    def test_同一入力の再実行が同一のサマリ表を生む(self, tmp_path: Path) -> None:
        """要件 8.2: 同一設定・同一入力なら出力物が逐字一致する。"""
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        first = make_config(tmp_path / "out1", [str(tmp_path / "*.csv")], [LINEAR])
        second = make_config(tmp_path / "out2", [str(tmp_path / "*.csv")], [LINEAR])

        run(first, make_record())
        run(second, make_record())

        assert (first.output.directory / SUMMARY_FILENAME).read_bytes() == (
            second.output.directory / SUMMARY_FILENAME
        ).read_bytes()


class Test規模と資源の解放:
    """要件 10.1: 1 回の実行で多数の入力を逐次処理する。"""

    def test_多数の処理単位を取りこぼさずに集計する(self, tmp_path: Path) -> None:
        sources = tmp_path / "data"
        sources.mkdir()
        for index in range(25):
            write_linear_csv(sources / f"m{index:03d}.csv")
        config = make_config(tmp_path / "out", [str(sources)], [LINEAR, POLYNOMIAL])

        recorder = Recorder()
        report = run(config, make_record(), recorder)

        assert recorder.started == [(50, 25)]
        assert report.n_success == 50
        assert report.n_failure == 0
        assert len({row["source_id"] for row in summary_rows(config)}) == 25

    def test_実行ログのハンドラを終了時に解放する(self, tmp_path: Path) -> None:
        """開いたままにすると、連続実行でファイル記述子を食い潰す（要件 10.1）。"""
        write_linear_csv(tmp_path / "a.csv")
        logger = logging.getLogger(LOGGER_NAME)
        before = list(logger.handlers)

        for index in range(3):
            config = make_config(
                tmp_path / f"out{index}", [str(tmp_path / "a.csv")], [LINEAR]
            )
            run(config, make_record())

        assert list(logger.handlers) == before

    def test_中止した実行でもハンドラを解放する(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """例外で抜ける経路でも取っ手を閉じる（``with`` 文を使う理由）。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        logger = logging.getLogger(LOGGER_NAME)
        before = list(logger.handlers)
        stub_run_job(monkeypatch, UnexpectedConfigViolation(()), at_index=0)

        with pytest.raises(UnexpectedConfigViolation):
            run(config, make_record())

        assert list(logger.handlers) == before


class Test曲線データの解放:
    """要件 10.4: 集計結果は曲線データを保持せず、常駐メモリが件数に比例して増えない。

    保持していた頃は 1 件あたり 4 配列 × 8 バイト × 点数（2 万行で 625 KiB）が実行終了まで
    解放されず、要件 10.1 の上限規模（500 件 × 5 万行）で約 800 MB に達していた。曲線は
    ``curves/*.csv`` として既にディスクにあり、メモリ上の保持は重複である。

    **常駐メモリそのものの推移は ``tests/performance/`` が見る。** ここで固定するのは、
    解放が起きること・出力より後に起きること・推定値に触れないことの 3 点である。
    """

    def test_成功結果から曲線データが外れる(self, tmp_path: Path) -> None:
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path)], [LINEAR, POLYNOMIAL])

        report = run(config, make_record())

        successes = [outcome for outcome in report.outcomes if isinstance(outcome, FitSuccess)]
        assert len(successes) == 4
        assert all(outcome.curve is None for outcome in successes)

    def test_解放は曲線_CSV_を書いた後に起きる(self, tmp_path: Path) -> None:
        """出力の適用より前に手放すと、要件 7.5 の出力が空になる。

        件数だけでは順序を固定できない。書かれた行数が点数と一致することまで見る。
        """
        source = write_linear_csv(tmp_path / "a.csv", n_points=11)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], write_curve=True, write_plot=True
        )

        report = run(config, make_record())

        assert [outcome.curve for outcome in report.outcomes] == [None]
        written = curve_outputs(config)
        assert len(written) == 1
        path = config.output.directory / CURVE_SUBDIRECTORY / written[0]
        with path.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        assert len(rows) == 11
        assert all(row["y_fit"] for row in rows)
        # グラフ画像も同じ順序に依存する（要件 7.4）。
        assert len(list((config.output.directory / "plots").glob("*.png"))) == 1

    def test_保持を指定した実行では曲線が残る(self, tmp_path: Path) -> None:
        """要件 9.1: 単一系列の経路（``api.fit_series``）が使う指定。

        曲線を返す経路が残っていることを ``pipeline`` の水準で固定する。ここが失われると
        ``fit_series`` の利用者は各点の当てはめ値と残差を受け取る手段を失う。
        """
        source = write_linear_csv(tmp_path / "a.csv", n_points=11)
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        report = run(config, make_record(), retain_curve=True)

        (outcome,) = report.outcomes
        assert isinstance(outcome, FitSuccess)
        assert outcome.curve is not None
        assert len(outcome.curve) == outcome.goodness.n_points == 11

    def test_解放しても推定値と適合度は変わらない(self, tmp_path: Path) -> None:
        """手放すのは曲線の欄だけである。集計に使う値に触れていないこと。"""
        source = write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        released = run(config, make_record())
        retained = run(make_config(tmp_path / "out2", [str(source)], [LINEAR]),
                       make_record(), retain_curve=True)

        (left,) = released.outcomes
        (right,) = retained.outcomes
        assert isinstance(left, FitSuccess) and isinstance(right, FitSuccess)
        assert left.parameters == right.parameters
        assert left.goodness == right.goodness
        assert left.preprocess == right.preprocess
        assert left == right.without_curve()

    def test_進捗通知にも解放済みの結果が渡る(self, tmp_path: Path) -> None:
        """通知と集計で別の値を渡すと、進捗で見た結果と後から読む結果が食い違う。"""
        source = write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        recorder = Recorder()
        report = run(config, make_record(), recorder)

        assert [outcome for _, _, outcome in recorder.done] == list(report.outcomes)
        assert all(
            outcome.curve is None
            for _, _, outcome in recorder.done
            if isinstance(outcome, FitSuccess)
        )


class Test集計結果の不変条件:
    """``len(outcomes) == n_success + n_failure``（設計の Postconditions）。"""

    def test_件数が結果の総数と一致しない記録は作れない(self) -> None:
        with pytest.raises(ValueError):
            BatchReport(
                outcomes=(),
                n_success=1,
                n_failure=0,
                aborted=False,
                execution=make_record(),
            )

    def test_生成後に変更できない(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        report = run(config, make_record())

        with pytest.raises(FrozenInstanceError):
            report.aborted = True  # type: ignore[misc]


class Test既定はスキップして継続:
    """要件 6.4: 個別の失敗は残りの処理を止めない。"""

    def test_1_件失敗しても残りが処理される(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        report = run(config, make_record())

        assert report.aborted is False
        assert len(report.outcomes) == 3
        assert report.n_success == 2
        assert report.n_failure == 1
        assert isinstance(report.outcomes[1], FitFailure)

    def test_失敗の対象と理由が実行ログに残る(self, tmp_path: Path) -> None:
        """要件 6.4、8.4: 失敗した対象と失敗理由を記録する。"""
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        run(config, make_record())

        text = read_log(config)
        assert str(tmp_path / "b.csv") in text
        assert FailureReason.COLUMN_NOT_FOUND.value in text

    def test_失敗もサマリ表に載る(self, tmp_path: Path) -> None:
        """要件 6.6: 成否件数とサマリ表を突き合わせられること。"""
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        report = run(config, make_record())

        statuses = [row["status"] for row in summary_rows(config)]
        assert statuses.count("failure") == report.n_failure
        assert "success" in statuses


class Test中止指定:
    """要件 6.5: fail-fast では最初の失敗で残りを中止し、それまでの結果を保持する。"""

    def test_最初の失敗で以降を実行しない(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "*.csv")],
            [LINEAR],
            failure_policy=FailurePolicy.FAIL_FAST,
        )

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 2
        assert report.n_success == 1
        assert report.n_failure == 1
        assert str(tmp_path / "c.csv") not in [o.source_id for o in report.outcomes]

    def test_中止時もそれまでの結果がサマリ表に残る(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "*.csv")],
            [LINEAR],
            failure_policy=FailurePolicy.FAIL_FAST,
        )

        report = run(config, make_record())

        written = {row["source_id"] for row in summary_rows(config)}
        assert written == {str(tmp_path / "a.csv"), str(tmp_path / "b.csv")}
        assert report.n_success + report.n_failure == len(report.outcomes)


class Test進捗通知:
    """要件 6.3: 処理済み件数と全体件数が分かる進捗を通知する。"""

    def test_総処理単位数と総入力数の双方を受け取る(self, tmp_path: Path) -> None:
        """処理単位数は入力数 × 手法数であり、利用者が数えるファイル数と一致しない。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )
        recorder = Recorder()

        run(config, make_record(), recorder)

        assert recorder.started == [(6, 3)]

    def test_処理単位ごとに_1_回ずつ処理単位の順序で通知する(self, tmp_path: Path) -> None:
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )
        recorder = Recorder()

        report = run(config, make_record(), recorder)

        assert [done for done, _, _ in recorder.done] == [1, 2, 3, 4]
        assert {total for _, total, _ in recorder.done} == {4}
        assert [outcome for _, _, outcome in recorder.done] == list(report.outcomes)

    def test_終了通知は_1_回で集計結果を伴う(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        recorder = Recorder()

        report = run(config, make_record(), recorder)

        assert recorder.finished == [report]

    def test_通知先が無くても実行できる(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        report = run(config, make_record(), None)

        assert report.n_success == 1

    def test_端末へ描画しない(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        """通知までが責任範囲であり、描画は CLI が持つ（設計の cli ブロック）。"""
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        run(config, make_record())

        captured = capsys.readouterr()
        assert captured.out == ""
        assert captured.err == ""


class Test入力指定が_0_件に解決された場合:
    """要件 6.1、8.4: 0 件になった指定を明示して実行ログに警告を残す。"""

    def test_拡張子が一致しないディレクトリを警告する(self, tmp_path: Path) -> None:
        directory = tmp_path / "measurements"
        directory.mkdir()
        (directory / "notes.dat").write_text("x,y\n0,1\n", encoding="utf-8")
        config = make_config(tmp_path / "out", [str(directory)], [LINEAR])

        report = run(config, make_record())

        text = read_log(config)
        assert EMPTY_INPUT_STATUS in text
        assert repr(str(directory)) in text
        assert report.outcomes == ()
        assert report.aborted is False

    def test_一致しないワイルドカードを警告する(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        pattern = str(tmp_path / "*.tsv")
        config = make_config(
            tmp_path / "out", [str(tmp_path / "a.csv"), pattern], [LINEAR]
        )

        report = run(config, make_record())

        text = read_log(config)
        assert repr(pattern) in text
        assert EMPTY_INPUT_STATUS in text
        assert report.n_success == 1

    def test_解決できた指定は警告しない(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        run(config, make_record())

        assert EMPTY_INPUT_STATUS not in read_log(config)

    def test_存在しないファイルの直接指定は警告しない(self, tmp_path: Path) -> None:
        """存在確認は行わない。1 件の処理単位として個別失敗になる（要件 1.8）。

        件数だけを見ると、中断していても同じ 1 件になる。0 件の警告を出さない根拠は
        「個別の失敗として報告され、処理は継続する」ことであるため、中断していないことと
        失敗理由の双方を確かめる。
        """
        missing = str(tmp_path / "missing.csv")
        config = make_config(tmp_path / "out", [missing], [LINEAR])

        report = run(config, make_record())

        assert EMPTY_INPUT_STATUS not in read_log(config)
        assert report.n_failure == 1
        assert report.aborted is False
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INPUT_UNREADABLE


class Test読めない入力ファイル:
    """要件 1.8、6.4、10.1: 読めない 1 件を個別の失敗として記録し、残りを継続する。

    綴り誤り 1 つ、あるいは共有先から実行中に消えた 1 ファイルで数百件のバッチが終わって
    はならない。中断してよいのは、対象を替えても解消しない失敗（出力先の不備・記憶領域の
    枯渇）に限る。
    """

    def test_途中の欠損ファイルが後続の処理単位を止めない(self, tmp_path: Path) -> None:
        """5 入力の 3 番目が存在しない場合でも、4 番目以降が実行されること。

        件数だけでは中断と区別できないため、後続の出力物が実際に残っているかを
        ファイルシステムで確かめる。
        """
        for name in ("a.csv", "b.csv", "d.csv", "e.csv"):
            write_linear_csv(tmp_path / name)
        paths = [str(tmp_path / name) for name in ("a.csv", "b.csv", "c.csv", "d.csv", "e.csv")]
        config = make_config(tmp_path / "out", paths, [LINEAR], write_curve=True)

        report = run(config, make_record())

        assert report.aborted is False
        assert report.n_success == 4
        assert report.n_failure == 1
        assert [outcome.source_id for outcome in report.outcomes] == paths
        failure = report.outcomes[2]
        assert isinstance(failure, FitFailure)
        assert failure.reason is FailureReason.INPUT_UNREADABLE
        assert curve_outputs(config) == [
            "a__lin__0000.csv",
            "b__lin__0001.csv",
            "d__lin__0003.csv",
            "e__lin__0004.csv",
        ]

    def test_読めない対象と理由を報告する(self, tmp_path: Path) -> None:
        """要件 1.8: 識別子と読み取れない理由の双方を載せる。"""
        missing = tmp_path / "missing.csv"
        config = make_config(tmp_path / "out", [str(missing)], [LINEAR])

        report = run(config, make_record())

        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.source_id == str(missing)
        assert outcome.method_name == "lin"
        assert "FileNotFoundError" in outcome.message
        assert str(missing) in outcome.message

    def test_実行ログに個別失敗として残る(self, tmp_path: Path) -> None:
        """要件 8.4: 中断ではなく個別失敗として記録されること。"""
        missing = tmp_path / "missing.csv"
        write_linear_csv(tmp_path / "z.csv")
        config = make_config(
            tmp_path / "out", [str(missing), str(tmp_path / "z.csv")], [LINEAR]
        )

        run(config, make_record())

        text = read_log(config)
        assert FailureReason.INPUT_UNREADABLE.value in text
        assert str(missing) in text
        assert "status=finished n_success=1 n_failure=1" in text

    def test_サマリ表に失敗として現れる(self, tmp_path: Path) -> None:
        """要件 6.6: 読めなかった対象もサマリ表から辿れること。"""
        missing = tmp_path / "missing.csv"
        write_linear_csv(tmp_path / "z.csv")
        config = make_config(
            tmp_path / "out", [str(missing), str(tmp_path / "z.csv")], [LINEAR]
        )

        run(config, make_record())

        written = {(row["source_id"], row["status"]) for row in summary_rows(config)}
        assert (str(missing), "failure") in written
        assert (str(tmp_path / "z.csv"), "success") in written

    def test_fail_fast_なら最初の欠損で中止する(self, tmp_path: Path) -> None:
        """要件 6.5: 明示指定時は個別失敗でも中止する。既定との違いを固定する。"""
        for name in ("b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        paths = [str(tmp_path / name) for name in ("a.csv", "b.csv", "c.csv")]
        config = make_config(
            tmp_path / "out",
            paths,
            [LINEAR],
            failure_policy=FailurePolicy.FAIL_FAST,
            write_curve=True,
        )

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        assert curve_outputs(config) == []

    @pytest.mark.skipif(
        hasattr(os, "geteuid") and os.geteuid() == 0,
        reason="root は読み取り権限の無いファイルも読めるため、この分岐を再現できない",
    )
    def test_読み取り権限の無いファイルも個別失敗として継続する(self, tmp_path: Path) -> None:
        """存在しても読めない場合（要件 1.8 の後半）。後続は実行される。"""
        locked = write_linear_csv(tmp_path / "b.csv")
        for name in ("a.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        locked.chmod(0o000)
        paths = [str(tmp_path / name) for name in ("a.csv", "b.csv", "c.csv")]
        config = make_config(tmp_path / "out", paths, [LINEAR], write_curve=True)

        try:
            report = run(config, make_record())
        finally:
            locked.chmod(stat.S_IRUSR | stat.S_IWUSR)

        assert report.aborted is False
        assert report.n_success == 2
        failure = report.outcomes[1]
        assert isinstance(failure, FitFailure)
        assert failure.reason is FailureReason.INPUT_UNREADABLE
        assert "PermissionError" in failure.message
        assert curve_outputs(config) == ["a__lin__0000.csv", "c__lin__0002.csv"]


@pytest.mark.skipif(
    hasattr(os, "geteuid") and os.geteuid() == 0,
    reason="root は読み取り権限の無いディレクトリも読めるため、この分岐を再現できない",
)
class Test展開時の資源枯渇:
    """要件 10.3: 読み取れないディレクトリを ``RESOURCE_EXHAUSTED`` として扱う。"""

    @pytest.fixture
    def unreadable(self, tmp_path: Path) -> Iterator[Path]:
        directory = tmp_path / "locked"
        directory.mkdir()
        (directory / "a.csv").write_text("x,y\n0,1\n", encoding="utf-8")
        directory.chmod(0o000)
        yield directory
        directory.chmod(stat.S_IRWXU)

    def test_中断として報告し結果は空になる(self, tmp_path: Path, unreadable: Path) -> None:
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])

        report = run(config, make_record())

        assert report.aborted is True
        assert report.outcomes == ()
        assert report.n_success == 0
        assert report.n_failure == 0

    def test_中断した対象と理由を実行ログに残す(self, tmp_path: Path, unreadable: Path) -> None:
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])

        run(config, make_record())

        text = read_log(config)
        assert FailureReason.RESOURCE_EXHAUSTED.value in text
        assert str(unreadable) in text

    def test_サマリ表は保持される(self, tmp_path: Path, unreadable: Path) -> None:
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])

        run(config, make_record())

        assert (config.output.directory / SUMMARY_FILENAME).exists()
        assert summary_rows(config) == []

    def test_開始は通知せず終了は通知する(self, tmp_path: Path, unreadable: Path) -> None:
        """総数が確定していないため開始を通知できない。集計結果は必ず届ける。"""
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])
        recorder = Recorder()

        report = run(config, make_record(), recorder)

        assert recorder.started == []
        assert recorder.done == []
        assert recorder.finished == [report]


def stub_run_job(
    monkeypatch: pytest.MonkeyPatch, error: BaseException, *, at_index: int
) -> None:
    """指定した処理単位で例外を送出する :func:`run_job` に差し替える。

    実運用でメモリ枯渇や書き込み不能を再現する手段が無いため、境界の外側から注入する。
    """
    original = pipeline.run_job

    def stubbed(job: Job, config: RunConfig) -> JobResult:
        if job.index == at_index:
            raise error
        return original(job, config)

    monkeypatch.setattr(pipeline, "run_job", stubbed)


class Test実行中の資源枯渇:
    """要件 10.3: 中断した対象を明示し、それまでの結果とサマリを保持する。"""

    @pytest.mark.parametrize(
        "error", [MemoryError("記憶領域が尽きた"), OSError("書き込みに失敗した")]
    )
    def test_それまでの結果を保持して中断する(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, error: BaseException
    ) -> None:
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, error, at_index=1)

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 2
        assert isinstance(report.outcomes[0], FitSuccess)
        assert report.outcomes[0].source_id == str(tmp_path / "a.csv")
        assert report.n_success == 1
        assert report.n_failure == 1

    def test_中断した対象を明示する(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, MemoryError("記憶領域が尽きた"), at_index=1)

        report = run(config, make_record())

        aborted_outcome = report.outcomes[-1]
        assert isinstance(aborted_outcome, FitFailure)
        assert aborted_outcome.source_id == str(tmp_path / "b.csv")
        assert aborted_outcome.method_name == "lin"
        assert aborted_outcome.reason is FailureReason.RESOURCE_EXHAUSTED
        assert str(tmp_path / "b.csv") in read_log(config)

    def test_サマリ表を書き出す(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, OSError("書き込みに失敗した"), at_index=1)

        run(config, make_record())

        written = {(row["source_id"], row["status"]) for row in summary_rows(config)}
        assert (str(tmp_path / "a.csv"), "success") in written
        assert (str(tmp_path / "b.csv"), "failure") in written
        assert str(tmp_path / "c.csv") not in {source for source, _ in written}

    def test_中断後の処理単位は実行しない(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, MemoryError("記憶領域が尽きた"), at_index=1)
        recorder = Recorder()

        run(config, make_record(), recorder)

        assert [done for done, _, _ in recorder.done] == [1, 2]
        assert len(recorder.finished) == 1

    def test_出力を書けない場合は中断する(self, tmp_path: Path) -> None:
        """注入ではなく実物の書き込み失敗で中断すること（要件 10.3）。

        入力を読めない場合（要件 1.8）と対になる分岐である。出力先の不備は対象を替えても
        解消しないため、個別の失敗として飲み込んではならない。``curves`` を通常ファイルに
        しておくと、最初の処理単位の出力書き込みが :exc:`OSError` になる。
        """
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR], write_curve=True
        )
        config.output.directory.mkdir(parents=True)
        (config.output.directory / CURVE_SUBDIRECTORY).write_text("not a dir", encoding="utf-8")

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.RESOURCE_EXHAUSTED
        assert outcome.source_id == str(tmp_path / "a.csv")

    def test_前処理_CSV_を書けない場合も中断する(self, tmp_path: Path) -> None:
        """前処理 CSV の書き込み失敗も資源・環境の失敗として扱うこと（要件 10.3、2.5）。

        この出力は成否によらず書かれる唯一のものであり（要件 2.5）、しかもオプトインの
        フラグを持たない。書けない事態を個別の失敗として飲み込むと、出力先の不備が
        対象を替えても解消しないまま数百件を走り切ることになる。

        ``preprocess`` を通常ファイルにしておくと、除外の生じた最初の処理単位で
        :exc:`OSError` になる。
        """
        write_spiked_csv(tmp_path / "a.csv")
        write_spiked_csv(tmp_path / "b.csv")
        config = dataclasses.replace(
            make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR]),
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=1.5, max_iterations=3)),
        )
        config.output.directory.mkdir(parents=True)
        (config.output.directory / PREPROCESS_SUBDIRECTORY).write_text(
            "not a dir", encoding="utf-8"
        )

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.RESOURCE_EXHAUSTED
        assert outcome.source_id == str(tmp_path / "a.csv")

    def test_図を書けなくても前処理の記録は残る(self, tmp_path: Path) -> None:
        """当てはめ結果の書き込み失敗が、前処理の記録まで道連れにしないこと（要件 2.5、10.3）。

        前処理 CSV は「前処理が何をしたか」の記録であり、当てはめ結果とは独立に成立する。
        図や曲線 CSV の書き込みが :exc:`OSError` で落ちたとき、その処理単位で何点を
        どう除外したのかまで失われると、中断の原因を追う手がかりが減る。

        ``plots`` を通常ファイルにしておくと図の書き込みが失敗する。
        """
        write_spiked_csv(tmp_path / "a.csv")
        config = dataclasses.replace(
            make_config(
                tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR], write_plot=True
            ),
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=1.5, max_iterations=3)),
        )
        config.output.directory.mkdir(parents=True)
        (config.output.directory / PLOT_SUBDIRECTORY).write_text(
            "not a dir", encoding="utf-8"
        )

        report = run(config, make_record())

        assert report.aborted is True
        assert report.outcomes[0].reason is FailureReason.RESOURCE_EXHAUSTED
        written = config.output.directory / PREPROCESS_SUBDIRECTORY
        assert written.is_dir(), "図を書けなかったせいで前処理の記録まで失われている"
        (recorded,) = sorted(written.iterdir())
        assert len(recorded.read_text(encoding="utf-8").splitlines()) >= 2

    def test_サマリ表を書けない場合も結果を保持して中断する(self, tmp_path: Path) -> None:
        """書き込み不能は資源・環境の失敗であり、握り潰さない（要件 10.3）。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        (config.output.directory / SUMMARY_FILENAME).mkdir(parents=True)

        report = run(config, make_record())

        assert report.aborted is True
        assert report.n_success == 1
        assert FailureReason.RESOURCE_EXHAUSTED.value in read_log(config)

    def test_サマリ表を書けなくても実行条件の記録は残る(self, tmp_path: Path) -> None:
        """要件 8.3: 片方が書けないことは他方を捨てる理由にならない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [MOVING_AVERAGE])
        (config.output.directory / SUMMARY_FILENAME).mkdir(parents=True)

        report = run(config, make_record())

        assert report.aborted is True
        written = json.loads(
            (config.output.directory / EXECUTION_RECORD_FILENAME).read_text(
                encoding="utf-8"
            )
        )
        assert written["applied_defaults"] == {"ma": {"window": 5, "polyorder": 0}}


class Test呼び出し側の誤りは捕捉しない:
    """実行前ゲートを通っていない指定は、値ではなく例外で伝える（設計の Error Strategy）。"""

    def test_UnexpectedConfigViolation_を素通しする(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        violation = ConfigViolation(
            kind=ViolationKind.MODEL_UNRESOLVED, location="methods[0]", message="未知"
        )
        stub_run_job(monkeypatch, UnexpectedConfigViolation((violation,)), at_index=0)

        with pytest.raises(UnexpectedConfigViolation):
            run(config, make_record())


class Test適用既定値の記録:
    """要件 5.4: 当てはめが補った既定値を手法ごとに畳み込み、実行条件に反映する。"""

    def test_実行条件の記録に手法ごとの既定値が入る(self, tmp_path: Path) -> None:
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [MOVING_AVERAGE])

        report = run(config, make_record())

        assert report.n_success == 2
        assert dict(report.execution.applied_defaults) == {
            "ma": {"window": 5, "polyorder": 0}
        }

    def test_渡された記録は書き換えない(self, tmp_path: Path) -> None:
        """実行条件は読むだけであり、呼び出し側の値を変更しない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [MOVING_AVERAGE])
        record = make_record()

        report = run(config, record)

        assert dict(record.applied_defaults) == {}
        assert report.execution is not record
        assert report.execution.started_at == record.started_at

    def test_既定値を適用しない手法は記録に現れない(self, tmp_path: Path) -> None:
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        report = run(config, make_record())

        assert dict(report.execution.applied_defaults) == {}

    def test_実行条件の記録が出力先に残る(self, tmp_path: Path) -> None:
        """要件 8.3、5.4: 適用した値を実行条件として記録する。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [MOVING_AVERAGE])

        run(config, make_record())

        written = json.loads(
            (config.output.directory / EXECUTION_RECORD_FILENAME).read_text(
                encoding="utf-8"
            )
        )
        assert written["applied_defaults"] == {"ma": {"window": 5, "polyorder": 0}}


# --- メモリ上の系列の実行（要件 9.1、9.3）------------------------------------------


def memory_series(source_id: str = "memory", *, n_points: int = 11) -> DataSeries:
    """バッチ制御の試験に用いる、読み込み済みの系列。"""
    x = np.linspace(0.0, 10.0, n_points)
    return DataSeries(source_id=source_id, x=x, y=2.0 * x + 1.0)


class Testメモリ上の系列の実行:
    """要件 9.1: 読み込み済みの系列を、ファイル経由と同一のバッチ制御で実行すること。

    入力の走査を行わないこと以外は同じである。処理単位は 1 対象 × 手法数、結果の並びは
    手法の記述順（要件 8.2）、適用既定値の畳み込み（要件 5.4）も同じ経路を通る。

    **出力先を持たない実行である。** 結果は返り値でのみ渡るため、実行ログ（要件 8.4）と
    実行条件の記録（要件 8.3）を書く先が無い。書けば、対話環境からの当てはめが呼び出し
    ごとに痕跡を残す。
    """

    def test_手法ごとに_1_件ずつ実行する(self, tmp_path: Path) -> None:
        config = make_config(tmp_path / "out", [], [LINEAR, POLYNOMIAL])

        report = run(config, make_record(), series=memory_series())

        assert len(report.outcomes) == 2
        assert report.n_success == 2
        assert report.aborted is False
        assert identities(report.outcomes) == [("memory", "lin"), ("memory", "poly")]

    def test_入力の位置を参照しない(self, tmp_path: Path) -> None:
        """走査も読み込みも行わないこと。存在しない指定が結果に影響しない。"""
        config = make_config(tmp_path / "out", [str(tmp_path / "無い.csv")], [LINEAR])

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert identities(report.outcomes) == [("memory", "lin")]

    def test_実行ログも実行条件の記録も書き出さない(self, tmp_path: Path) -> None:
        """出力先を持たない実行であること。出力ディレクトリ自体が作られない。"""
        directory = tmp_path / "out"
        config = make_config(directory, [], [LINEAR])

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert not directory.exists()

    def test_適用既定値を記録に畳み込む(self, tmp_path: Path) -> None:
        """要件 5.4: 記録の組み立てはファイル経由と同一である。"""
        config = make_config(tmp_path / "out", [], [MOVING_AVERAGE])

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert dict(report.execution.applied_defaults) == {
            "ma": {"window": 5, "polyorder": 0}
        }

    def test_ファイル経由と同一の推定値になる(self, tmp_path: Path) -> None:
        """要件 9.3: 経路の違いが値に現れないこと。"""
        source = write_linear_csv(tmp_path / "a.csv")
        file_config = make_config(tmp_path / "out", [str(source)], [LINEAR])
        memory_config = make_config(tmp_path / "out", [], [LINEAR])
        x = np.linspace(0.0, 10.0, 11)
        series = DataSeries(source_id="memory", x=x, y=2.0 * x + 1.0)

        from_file = run(file_config, make_record()).outcomes[0]
        from_memory = run(memory_config, make_record(), series=series).outcomes[0]

        assert isinstance(from_file, FitSuccess)
        assert isinstance(from_memory, FitSuccess)
        assert [estimate.value for estimate in from_memory.parameters] == [
            estimate.value for estimate in from_file.parameters
        ]

    def test_総入力数を_1_件として通知する(self, tmp_path: Path) -> None:
        """要件 6.3: 処理単位数は手法数であり、入力は 1 件である。"""
        config = make_config(tmp_path / "out", [], [LINEAR, POLYNOMIAL])
        recorder = Recorder()

        report = run(config, make_record(), recorder, series=memory_series())

        assert recorder.started == [(2, 1)]
        assert [done for done, _, _ in recorder.done] == [1, 2]
        assert recorder.finished == [report]

    @pytest.mark.parametrize(
        "error", [MemoryError("記憶領域が尽きた"), OSError("書き込みに失敗した")]
    )
    def test_資源枯渇を中断として報告する(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, error: BaseException
    ) -> None:
        """要件 10.3: 中断した対象を明示すること。出力先が無くても値として返る。"""
        config = make_config(tmp_path / "out", [], [LINEAR])
        stub_run_job(monkeypatch, error, at_index=0)

        report = run(config, make_record(), series=memory_series())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.source_id == "memory"
        assert outcome.reason is FailureReason.RESOURCE_EXHAUSTED

    def test_ファイル経由の実行は出力を書き続ける(self, tmp_path: Path) -> None:
        """対照。出力を書かないのはメモリ上の系列を受け取った実行に限る。"""
        source = write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        run(config, make_record())

        assert (config.output.directory / RUN_LOG_FILENAME).is_file()
        assert (config.output.directory / EXECUTION_RECORD_FILENAME).is_file()
        assert (config.output.directory / SUMMARY_FILENAME).is_file()
