"""設定ファイルの読み込みと実行時上書きの統合テスト（要件 8.1、8.5、9.4、1.6）。

本テストは `curvefit.config` が次を満たすことを検証する。

- 設定ファイル 1 つから、入力指定・手法一覧・前処理設定・出力設定・失敗ポリシーの
  5 要素を備えた実行条件（`RunConfig`）が構築できる（要件 8.1）
- 実行時引数が設定ファイルより優先し、上書き記録が残る（要件 9.4）
- 未知のキー・必須項目の欠落・解釈できない値が、例外ではなく設定違反として
  **一度にまとめて** 返る（要件 8.5）
- 見出し行の指定が 3 状態（未指定 / あり / なし）のまま実行条件に載る（要件 1.6）

設計の Testing Strategy が `config` を統合テストに置いているため、単体ではなく
`tests/integration/` に置く。
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

import pytest

from curvefit.config import (
    FailurePolicy,
    InputSpec,
    OutputSpec,
    RunConfig,
    load_config,
)
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.execution import OverrideRecord
from curvefit.models.resolver import SmootherKind
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

FULL_CONFIG = """
failure_policy = "fail_fast"

[input]
paths = ["data/a.csv", "data/b.csv"]
delimiter = ","
header = true

[input.columns]
x = "time"
y = "signal"
weight = "sigma"

[[methods]]
name = "gauss"
builtin = "gaussian"
initial = { amplitude = 2.0, center = 1.0 }
fixed = { sigma = 0.5 }
bounds.amplitude = { min = 0.0, max = 10.0 }
bounds.center = { max = 5.0 }

[[methods]]
name = "poly"
smoother = "polynomial"
options = { degree = 3 }

[[methods]]
name = "expr"
expression = "a * x + b"
initial = { a = 1.0, b = 0.0 }

[preprocess]
x_min = 0.0
x_max = 10.0

[preprocess.outlier]
sigma = 2.5
max_iterations = 4

[output]
directory = "out"
write_summary = true
write_plot = false
write_curve = true
"""

MINIMAL_CONFIG = """
[input]
paths = ["a.csv"]

[input.columns]
x = 0
y = 1

[[methods]]
name = "line"
builtin = "linear"

[output]
directory = "out"
"""


def _top_level(line: str) -> str:
    """最上位のキーを足した設定を作る。TOML では最上位のキーは表より前に書く。"""
    return f"{line}\n{MINIMAL_CONFIG}"


def _write(tmp_path: Path, text: str) -> Path:
    path = tmp_path / "config.toml"
    path.write_text(text, encoding="utf-8")
    return path


def _load(
    tmp_path: Path, text: str, overrides: dict[str, object] | None = None
) -> tuple[Any, ...]:
    return load_config(_write(tmp_path, text), overrides or {})


def _load_bytes(tmp_path: Path, data: bytes) -> tuple[Any, ...]:
    """バイト列をそのまま設定ファイルとして読ませる。

    `_load` は必ず UTF-8 で書き出すため、UTF-8 以外の符号化で保存された設定ファイルを
    表現できない。文字コードの取り違えは日本語環境で最も起きやすい設定不備であり、
    バイト単位で書ける経路を別に用意しないと検証できない。
    """
    path = tmp_path / "config.toml"
    path.write_bytes(data)
    return load_config(path, {})


def _ok(result: tuple[Any, ...]) -> tuple[RunConfig, tuple[OverrideRecord, ...]]:
    """成功結果として取り出す。違反が返っていればその場で落とす。"""
    assert isinstance(result[0], RunConfig), f"違反が返った: {result}"
    config, records = result
    assert all(isinstance(record, OverrideRecord) for record in records)
    return config, records


def _violations(result: tuple[Any, ...]) -> tuple[ConfigViolation, ...]:
    """違反結果として取り出す。成功していればその場で落とす。"""
    assert result, "違反も実行条件も返っていない"
    assert all(isinstance(item, ConfigViolation) for item in result), f"成功が返った: {result}"
    return result


def _locations(result: tuple[Any, ...]) -> set[str]:
    return {violation.location for violation in _violations(result)}


class Test実行条件の構築:
    """要件 8.1: 設定ファイルに実行条件を記述できる。"""

    def test_5_要素がすべて構築される(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert isinstance(config.inputs, InputSpec)
        assert isinstance(config.methods, tuple)
        assert isinstance(config.preprocess, PreprocessSpec)
        assert isinstance(config.output, OutputSpec)
        assert config.failure_policy is FailurePolicy.FAIL_FAST

    def test_入力指定が読み取られる(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert config.inputs.paths == ("data/a.csv", "data/b.csv")
        assert config.inputs.delimiter == ","
        assert config.inputs.columns == ColumnSpec(x="time", y="signal", weight="sigma")

    def test_列は位置でも指定できる(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.inputs.columns == ColumnSpec(x=0, y=1, weight=None)

    def test_手法の指定が_MethodSpec_に写る(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))
        gauss, poly, expr = config.methods

        assert (gauss.name, gauss.kind, gauss.builtin) == ("gauss", "builtin", "gaussian")
        assert dict(gauss.initial) == {"amplitude": 2.0, "center": 1.0}
        assert dict(gauss.fixed) == {"sigma": 0.5}
        assert dict(gauss.bounds) == {"amplitude": (0.0, 10.0), "center": (None, 5.0)}
        assert (poly.kind, poly.smoother) == ("smoother", SmootherKind.POLYNOMIAL)
        assert dict(poly.options) == {"degree": 3}
        assert (expr.kind, expr.expression) == ("expression", "a * x + b")

    def test_前処理設定が読み取られる(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert config.preprocess.x_min == 0.0
        assert config.preprocess.x_max == 10.0
        assert config.preprocess.outlier == OutlierSpec(sigma=2.5, max_iterations=4)

    def test_外れ値の表がなければ外れ値除去は行わない(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.preprocess == PreprocessSpec()
        assert config.preprocess.outlier is None

    def test_外れ値の表があれば既定値のまま有効になる(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG + "\n[preprocess.outlier]\n"))

        assert config.preprocess.outlier == OutlierSpec()

    def test_出力設定が読み取られる(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert config.output.directory == Path("out")
        assert (config.output.write_summary, config.output.write_plot) == (True, False)
        assert config.output.write_curve is True

    def test_出力の既定はサマリとプロットのみ(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert (config.output.write_summary, config.output.write_plot) == (True, True)
        assert config.output.write_curve is False

    def test_失敗ポリシーの既定はスキップ(self, tmp_path: Path) -> None:
        """要件 6.4 の既定。設定ファイルに書かなければ継続する。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.failure_policy is FailurePolicy.SKIP

    def test_実行条件は生成後に変更できない(self, tmp_path: Path) -> None:
        """要件 8.2: 実行の途中で実行条件が書き換わると再現性が成立しない。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        with pytest.raises(Exception):
            config.failure_policy = FailurePolicy.FAIL_FAST  # type: ignore[misc]


class Test手法一覧の順序:
    """要件 8.2 の決定性: 記述順を保持する。"""

    def test_記述順を保持する(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert [method.name for method in config.methods] == ["gauss", "poly", "expr"]

    def test_逆順に書けば逆順になる(self, tmp_path: Path) -> None:
        text = """
[input]
paths = ["a.csv"]
[input.columns]
x = 0
y = 1
[[methods]]
name = "z"
builtin = "linear"
[[methods]]
name = "a"
builtin = "linear"
[output]
directory = "out"
"""
        config, _ = _ok(_load(tmp_path, text))

        assert [method.name for method in config.methods] == ["z", "a"]


class Test実行時引数の優先:
    """要件 9.4: 同一項目が双方で指定された場合は実行時引数を優先し、記録に残す。"""

    def test_実行時引数が設定ファイルに優先する(self, tmp_path: Path) -> None:
        config, _ = _ok(
            _load(tmp_path, FULL_CONFIG, {"output.directory": "cli-out"}),
        )

        assert config.output.directory == Path("cli-out")

    def test_上書き記録に前後の値が残る(self, tmp_path: Path) -> None:
        _, records = _ok(_load(tmp_path, FULL_CONFIG, {"output.directory": "cli-out"}))

        assert len(records) == 1
        assert records[0].key == "output.directory"
        assert records[0].config_value == "out"
        assert records[0].cli_value == "cli-out"

    def test_入力パスも上書きできる(self, tmp_path: Path) -> None:
        config, records = _ok(
            _load(tmp_path, FULL_CONFIG, {"input.paths": ["cli.csv"]}),
        )

        assert config.inputs.paths == ("cli.csv",)
        assert records[0].config_value == ["data/a.csv", "data/b.csv"]

    def test_失敗ポリシーも上書きできる(self, tmp_path: Path) -> None:
        config, records = _ok(_load(tmp_path, MINIMAL_CONFIG, {"failure_policy": "fail_fast"}))

        assert config.failure_policy is FailurePolicy.FAIL_FAST
        assert records[0].config_value is None

    def test_設定ファイルに無い項目の上書きは前の値を_None_として記録する(
        self, tmp_path: Path
    ) -> None:
        """TOML は空値を書けないため、``config_value=None`` は「キーが無い」だけを意味する。"""
        _, records = _ok(_load(tmp_path, MINIMAL_CONFIG, {"input.delimiter": "\t"}))

        assert records[0] == OverrideRecord(
            key="input.delimiter", config_value=None, cli_value="\t"
        )

    def test_TOML_に空値の構文が無いことを確認する(self, tmp_path: Path) -> None:
        """``config_value=None`` の一意性の根拠。空値を書こうとすると構文誤りになる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace('x = 0', 'x = null'))

        assert _violations(result)

    def test_複数項目を同時に上書きできる(self, tmp_path: Path) -> None:
        config, records = _ok(
            _load(
                tmp_path,
                FULL_CONFIG,
                {"output.directory": "cli-out", "input.paths": ["cli.csv"]},
            )
        )

        assert config.output.directory == Path("cli-out")
        assert config.inputs.paths == ("cli.csv",)
        assert {record.key for record in records} == {"output.directory", "input.paths"}

    def test_上書き記録の並びは実行時引数の与え方に依存しない(self, tmp_path: Path) -> None:
        """要件 8.2: 同一の実行条件なら記録も同一でなければならない。"""
        forward = {"output.directory": "cli-out", "input.paths": ["cli.csv"]}
        backward = {"input.paths": ["cli.csv"], "output.directory": "cli-out"}

        _, first = _ok(_load(tmp_path, FULL_CONFIG, forward))
        _, second = _ok(_load(tmp_path, FULL_CONFIG, backward))

        assert first == second

    def test_上書きが無ければ記録も空(self, tmp_path: Path) -> None:
        _, records = _ok(_load(tmp_path, FULL_CONFIG))

        assert records == ()

    def test_上書きできない項目は違反になる(self, tmp_path: Path) -> None:
        """手法一覧は実行時引数で差し替えられない。黙って無視すると効かない指定が残る。"""
        result = _load(tmp_path, MINIMAL_CONFIG, {"methods": []})

        assert "methods" in _locations(result)

    def test_見出し行の指定も上書きできる(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, FULL_CONFIG, {"input.header": False}))

        assert config.inputs.header is False


class Test見出し行の_3_状態:
    """要件 1.6 とタスク 5.5 の carry-over: 未指定 / あり / なしを潰さない。"""

    def test_未指定は_None(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.inputs.header is None

    def test_真は_True(self, tmp_path: Path) -> None:
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = true")))

        assert config.inputs.header is True

    def test_偽は_False(self, tmp_path: Path) -> None:
        config, _ = _ok(
            _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = false"))
        )

        assert config.inputs.header is False

    def test_3_状態は互いに区別できる(self, tmp_path: Path) -> None:
        absent, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))
        present, _ = _ok(
            _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = true"))
        )
        missing, _ = _ok(
            _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = false"))
        )

        assert len({absent.inputs.header, present.inputs.header, missing.inputs.header}) == 3

    def test_真偽値以外は違反(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = 1"))

        assert "input.header" in _locations(result)


class Test未知のキー:
    """要件 8.5: 未知のキーを黙って無視しない。綴り誤りが黙って効かなくなるため。"""

    def test_最上位の未知キーが違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, _top_level('failure_polcy = "skip"'))

        assert "failure_polcy" in _locations(result)

    def test_入力表の未知キーが違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace("[input]", '[input]\nseparator = ","'))

        assert "input.separator" in _locations(result)

    def test_手法の未知キーが違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace('name = "line"', 'name = "line"\nkind = "builtin"'))

        assert "methods[0].kind" in _locations(result)

    def test_列指定の未知キーが違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace("x = 0", "x = 0\nsigma = 2"))

        assert "input.columns.sigma" in _locations(result)

    def test_前処理の未知キーが違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG + "\n[preprocess]\nxmin = 0.0\n")

        assert "preprocess.xmin" in _locations(result)

    def test_外れ値設定の未知キーが違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG + "\n[preprocess.outlier]\nthreshold = 3.0\n")

        assert "preprocess.outlier.threshold" in _locations(result)

    def test_出力の未知キーが違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace('directory = "out"', 'directory = "out"\nwrite_log = true'))

        assert "output.write_log" in _locations(result)

    def test_上下限の未知キーが違反になる(self, tmp_path: Path) -> None:
        text = MINIMAL_CONFIG.replace(
            'builtin = "linear"', 'builtin = "linear"\nbounds.slope = { lower = 0.0 }'
        )

        assert "methods[0].bounds.slope.lower" in _locations(_load(tmp_path, text))

    def test_違反の種別は設定不備(self, tmp_path: Path) -> None:
        result = _load(tmp_path, _top_level('failure_polcy = "skip"'))

        assert {violation.kind for violation in _violations(result)} == {
            ViolationKind.CONFIG_INVALID
        }

    def test_違反の説明に指定可能なキーが載る(self, tmp_path: Path) -> None:
        """利用者の次の行動は綴りの修正であるため、選択肢を提示する。"""
        result = _load(tmp_path, _top_level('failure_polcy = "skip"'))
        violation = next(v for v in _violations(result) if v.location == "failure_polcy")

        assert "failure_policy" in violation.message


class Test必須項目の欠落:
    """要件 8.5: 必須項目の欠落を報告し、処理を開始しない。"""

    @pytest.mark.parametrize(
        ("removed", "location"),
        [
            ('paths = ["a.csv"]', "input.paths"),
            ("[input.columns]", "input.columns"),
            ("x = 0", "input.columns.x"),
            ("y = 1", "input.columns.y"),
            ('directory = "out"', "output.directory"),
            ('name = "line"', "methods[0].name"),
        ],
    )
    def test_必須項目を落とすと違反になる(
        self, tmp_path: Path, removed: str, location: str
    ) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace(removed, ""))

        assert location in _locations(result)

    def test_入力表そのものの欠落が違反になる(self, tmp_path: Path) -> None:
        text = "\n".join(MINIMAL_CONFIG.splitlines()[7:])

        assert "input" in _locations(_load(tmp_path, text))

    def test_手法一覧の欠落が違反になる(self, tmp_path: Path) -> None:
        result = _load(
            tmp_path, MINIMAL_CONFIG.replace('[[methods]]\nname = "line"\nbuiltin = "linear"', "")
        )

        assert "methods" in _locations(result)

    def test_手法一覧が空でも違反になる(self, tmp_path: Path) -> None:
        text = """
methods = []

[input]
paths = ["a.csv"]

[input.columns]
x = 0
y = 1

[output]
directory = "out"
"""

        assert "methods" in _locations(_load(tmp_path, text))

    def test_入力パスが空配列でも違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace('paths = ["a.csv"]', "paths = []"))

        assert "input.paths" in _locations(result)

    def test_出力表そのものの欠落が違反になる(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace('[output]\ndirectory = "out"', ""))

        assert "output" in _locations(result)


class Test手法の指定経路:
    """組込モデル・数式・平滑化のいずれか 1 つを選ぶ。関数は設定ファイルからは指定できない。"""

    def test_指定経路が_0_件なら違反(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace('builtin = "linear"', ""))

        assert "methods[0]" in _locations(result)

    def test_指定経路が_2_件なら違反(self, tmp_path: Path) -> None:
        result = _load(
            tmp_path, MINIMAL_CONFIG.replace('builtin = "linear"', 'builtin = "linear"\nsmoother = "spline"')
        )

        assert "methods[0]" in _locations(result)

    def test_未知の平滑化手法は違反(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace('builtin = "linear"', 'smoother = "median"'))

        assert "methods[0].smoother" in _locations(result)

    def test_組込モデル名の妥当性は本モジュールでは判定しない(self, tmp_path: Path) -> None:
        """要件 3.4 のモデル解決は実行前ゲート（タスク 6.2）が担う。ここは素通しする。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG.replace("linear", "no_such_model")))

        assert config.methods[0].builtin == "no_such_model"

    def test_手法名の重複は違反(self, tmp_path: Path) -> None:
        """要件 6.2 の比較は手法名で行うため、同名が 2 つあると結果を区別できない。"""
        text = MINIMAL_CONFIG.replace(
            '[[methods]]\nname = "line"\nbuiltin = "linear"',
            '[[methods]]\nname = "line"\nbuiltin = "linear"\n[[methods]]\nname = "line"\nbuiltin = "gaussian"',
        )

        assert "methods[1].name" in _locations(_load(tmp_path, text))


class Test値の型:
    """要件 8.5: 解釈できない項目を例外ではなく違反として返す。"""

    @pytest.mark.parametrize(
        ("original", "replacement", "location"),
        [
            ('paths = ["a.csv"]', 'paths = "a.csv"', "input.paths"),
            ('paths = ["a.csv"]', "paths = [1]", "input.paths[0]"),
            ("x = 0", "x = 1.5", "input.columns.x"),
            ("x = 0", "x = true", "input.columns.x"),
            ('directory = "out"', "directory = 1", "output.directory"),
            ('directory = "out"', 'directory = "out"\nwrite_plot = "yes"', "output.write_plot"),
            ('name = "line"', "name = 1", "methods[0].name"),
            ('name = "line"', 'name = ""', "methods[0].name"),
            ('builtin = "linear"', "builtin = 3", "methods[0].builtin"),
            ('builtin = "linear"', 'builtin = "linear"\ninitial = { a = "x" }', "methods[0].initial.a"),
            ('builtin = "linear"', 'builtin = "linear"\ninitial = 1', "methods[0].initial"),
            ('builtin = "linear"', 'builtin = "linear"\nbounds.a = [0, 1]', "methods[0].bounds.a"),
            ('builtin = "linear"', 'builtin = "linear"\nbounds.a = { min = "x" }', "methods[0].bounds.a.min"),
            ('builtin = "linear"', 'builtin = "linear"\nbounds.a = { }', "methods[0].bounds.a"),
            ('builtin = "linear"', 'builtin = "linear"\noptions = { window = true }', "methods[0].options.window"),
            ('builtin = "linear"', 'builtin = "linear"\nfixed = { a = "x" }', "methods[0].fixed.a"),
        ],
    )
    def test_型の合わない値が違反になる(
        self, tmp_path: Path, original: str, replacement: str, location: str
    ) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace(original, replacement))

        assert location in _locations(result)

    @pytest.mark.parametrize(
        ("added", "location"),
        [
            ('\n[preprocess]\nx_min = "zero"\n', "preprocess.x_min"),
            ("\n[preprocess]\nx_max = [1]\n", "preprocess.x_max"),
            ("\n[preprocess]\nx_min = nan\n", "preprocess.x_min"),
            ('\n[preprocess.outlier]\nsigma = "3"\n', "preprocess.outlier.sigma"),
            ("\n[preprocess.outlier]\nmax_iterations = 1.5\n", "preprocess.outlier.max_iterations"),
            ("\n[preprocess.outlier]\nmax_iterations = true\n", "preprocess.outlier.max_iterations"),
        ],
    )
    def test_前処理の型違いが違反になる(self, tmp_path: Path, added: str, location: str) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG + added)

        assert location in _locations(result)

    def test_失敗ポリシーの未知の値は違反(self, tmp_path: Path) -> None:
        result = _load(tmp_path, _top_level('failure_policy = "abort"'))

        assert "failure_policy" in _locations(result)

    def test_区切り文字が空文字なら違反(self, tmp_path: Path) -> None:
        result = _load(tmp_path, MINIMAL_CONFIG.replace("[input]", '[input]\ndelimiter = ""'))

        assert "input.delimiter" in _locations(result)

    def test_整数の初期値は実数として受け取る(self, tmp_path: Path) -> None:
        text = MINIMAL_CONFIG.replace('builtin = "linear"', 'builtin = "linear"\ninitial = { a = 1 }')
        config, _ = _ok(_load(tmp_path, text))

        assert config.methods[0].initial["a"] == pytest.approx(1.0)

    def test_手法固有オプションの値域は本モジュールでは判定しない(self, tmp_path: Path) -> None:
        """窓長の偶奇や次数の値域は実行前ゲート（タスク 6.2）が判定する。素通しして届ける。"""
        text = MINIMAL_CONFIG.replace(
            'builtin = "linear"', 'smoother = "moving_average"\noptions = { window = 4, polyorder = 9 }'
        )
        config, _ = _ok(_load(tmp_path, text))

        assert dict(config.methods[0].options) == {"window": 4, "polyorder": 9}

    def test_外れ値設定の値域は本モジュールでは判定しない(self, tmp_path: Path) -> None:
        """``sigma <= 0`` と ``max_iterations < 0`` の拒否は実行前ゲートの担当。"""
        text = MINIMAL_CONFIG + "\n[preprocess.outlier]\nsigma = -1.0\nmax_iterations = -3\n"
        config, _ = _ok(_load(tmp_path, text))

        assert config.preprocess.outlier == OutlierSpec(sigma=-1.0, max_iterations=-3)


class Test違反の一括収集:
    """設計の Error Handling: 最初の 1 件で打ち切らず、全違反を一度に提示する。"""

    def test_複数の違反が一度に返る(self, tmp_path: Path) -> None:
        text = """
failure_polcy = "skip"

[input]
paths = []
separator = ","

[input.columns]
y = 1

[[methods]]
builtin = "linear"

[preprocess]
x_min = "zero"

[output]
write_log = true
"""
        locations = _locations(_load(tmp_path, text))

        assert {
            "failure_polcy",
            "input.paths",
            "input.separator",
            "input.columns.x",
            "methods[0].name",
            "preprocess.x_min",
            "output.write_log",
            "output.directory",
        } <= locations

    def test_同一の表の中の複数の型違いが一度に返る(self, tmp_path: Path) -> None:
        text = MINIMAL_CONFIG.replace(
            'directory = "out"', 'directory = "out"\nwrite_plot = "yes"\nwrite_curve = 1'
        )

        assert {"output.write_plot", "output.write_curve"} <= _locations(_load(tmp_path, text))

    def test_外れ値設定の複数の型違いが一度に返る(self, tmp_path: Path) -> None:
        text = MINIMAL_CONFIG + '\n[preprocess.outlier]\nsigma = "3"\nmax_iterations = 1.5\n'

        assert {
            "preprocess.outlier.sigma",
            "preprocess.outlier.max_iterations",
        } <= _locations(_load(tmp_path, text))

    def test_違反があれば実行条件は返らない(self, tmp_path: Path) -> None:
        result = _load(tmp_path, _top_level("unknown = 1"))

        assert not any(isinstance(item, RunConfig) for item in result)

    def test_違反の並びは実行ごとに変わらない(self, tmp_path: Path) -> None:
        """要件 8.2: 同一設定なら報告も同一でなければ差分を追えない。"""
        text = _top_level("unknown_a = 1\nunknown_b = 2")

        assert _load(tmp_path, text) == _load(tmp_path, text)


class Test読み込み自体の失敗:
    """設計の Responsibilities: 利用者由来の設定内容で例外を送出しない。"""

    def test_構文誤りは違反として返る(self, tmp_path: Path) -> None:
        result = _load(tmp_path, "[input\npaths = [")

        assert _violations(result)

    def test_構文誤りの報告に設定ファイルの位置が載る(self, tmp_path: Path) -> None:
        violations = _violations(_load(tmp_path, "[input\n"))

        assert any("config.toml" in violation.location for violation in violations)

    def test_存在しない設定ファイルは違反として返る(self, tmp_path: Path) -> None:
        """CLI は終了コード 2 で全違反を提示する。ここで例外にすると経路が 2 本になる。"""
        result = load_config(tmp_path / "no_such.toml", {})

        assert _violations(result)

    def test_ディレクトリを指定しても違反として返る(self, tmp_path: Path) -> None:
        result = load_config(tmp_path, {})

        assert _violations(result)

    @pytest.mark.parametrize(
        "text",
        [
            "",
            "input = 1",
            "[input]\npaths = 1",
            "methods = 1",
            "methods = [1]",
            "[[methods]]\n",
            "[output]\ndirectory = []",
            "[preprocess]\noutlier = 1",
            "[input]\ncolumns = 1",
            "[input.columns]\nx = 1970-01-01",
        ],
    )
    def test_どのような設定内容でも例外を送出しない(self, tmp_path: Path, text: str) -> None:
        assert _violations(_load(tmp_path, text))


class Test設定ファイルの文字コード:
    """要件 8.5: TOML は UTF-8 を規定する。それ以外の符号化も違反として返す。

    本プロジェクトの設定ファイルには日本語の注釈が入る。Windows の日本語環境で
    編集器の既定（CP932）や「Unicode」（UTF-16）として保存すると復号自体が失敗するが、
    これは利用者が保存し直せる設定の不備であって資源の枯渇ではない。
    """

    # 日本語の注釈を含む、UTF-8 で保存されていれば成立する設定。
    JA_CONFIG = f"# 実行条件\n{MINIMAL_CONFIG}"

    @pytest.mark.parametrize("encoding", ["cp932", "utf-16", "shift_jis", "euc_jp"])
    def test_UTF_8_以外で保存された設定ファイルは違反として返る(
        self, tmp_path: Path, encoding: str
    ) -> None:
        result = _load_bytes(tmp_path, self.JA_CONFIG.encode(encoding))

        assert _violations(result)

    def test_latin_1_の注釈も違反として返る(self, tmp_path: Path) -> None:
        result = _load_bytes(tmp_path, f"# données\n{MINIMAL_CONFIG}".encode("latin-1"))

        assert _violations(result)

    def test_復号できない設定ファイルでも例外を送出しない(self, tmp_path: Path) -> None:
        """例外で返すと実行前の停止を導く経路が値と例外の 2 本に割れる。"""
        result = _load_bytes(tmp_path, b"\x82\xa0\x82\xa2\n")

        assert isinstance(result, tuple)
        assert _violations(result)

    def test_報告に設定ファイルの位置と_UTF_8_での保存し直しが載る(
        self, tmp_path: Path
    ) -> None:
        """どの対象が・何が原因かを利用者が直せる形で示す。"""
        violations = _violations(_load_bytes(tmp_path, self.JA_CONFIG.encode("cp932")))

        assert any("config.toml" in violation.location for violation in violations)
        assert any("UTF-8" in violation.message for violation in violations)

    def test_文字コードの違反も設定不備として返る(self, tmp_path: Path) -> None:
        violations = _violations(_load_bytes(tmp_path, self.JA_CONFIG.encode("cp932")))

        assert all(
            violation.kind is ViolationKind.CONFIG_INVALID for violation in violations
        )

    def test_BOM_付きの_UTF_8_も違反として返る(self, tmp_path: Path) -> None:
        """Windows の編集器が付ける BOM も、例外ではなく違反として返る。"""
        result = _load_bytes(tmp_path, self.JA_CONFIG.encode("utf-8-sig"))

        assert _violations(result)

    def test_BOM_無しの_UTF_8_は従来どおり読める(self, tmp_path: Path) -> None:
        """文字コードの検査が、正しく保存された設定ファイルを巻き込まないことを確かめる。"""
        config, _ = _ok(_load_bytes(tmp_path, self.JA_CONFIG.encode("utf-8")))

        assert config.inputs.paths == ("a.csv",)


class Test優先順位の実装箇所:
    """要件 9.4: 優先順位が実装される箇所を本モジュールのみに限定する。"""

    def test_実行時引数を読む関数は_1_つに閉じている(self) -> None:
        """設定の組み立て側が実行時引数を知らないことを、構文木で確かめる。"""
        tree = ast.parse((SRC / "config.py").read_text(encoding="utf-8"))
        readers = {
            node.name
            for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef)
            and any(
                isinstance(inner, ast.Name) and inner.id == "overrides"
                for inner in ast.walk(node)
            )
        }

        assert readers == {"load_config", "_apply_overrides"}, readers


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse((SRC / "config.py").read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class Test依存の露出:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_上位層を_import_しない(self) -> None:
        forbidden = {
            "curvefit.preflight",
            "curvefit.pipeline",
            "curvefit.api",
            "curvefit.cli",
        }

        assert not (_imported_modules() & forbidden)

    def test_基盤ライブラリを_import_しない(self) -> None:
        """設定の読み込みは標準ライブラリの tomllib で足りる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval", "numpy"}, (
                f"config.py が {imported} を import している"
            )

    def test_設定ファイルの読み込みに標準ライブラリを使う(self) -> None:
        assert "tomllib" in _imported_modules()

    def test_型を再定義せず既存モジュールから取り込む(self) -> None:
        expected = {
            "curvefit.errors",
            "curvefit.execution",
            "curvefit.models.resolver",
            "curvefit.preprocess",
            "curvefit.readers",
        }

        assert expected <= _imported_modules()
