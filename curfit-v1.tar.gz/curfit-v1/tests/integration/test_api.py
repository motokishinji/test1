"""公開ファサードの統合テスト（要件 1.2、9.1、9.3）。

本テストは :mod:`curvefit.api` が次を満たすことを検証する。

- **単一系列の当てはめ**（要件 9.1）: メモリ上の系列から既知のパラメータを復元すること。
  一時ファイルを 1 つも作らないこと。往復の道具（一時ディレクトリ）と読み込み段の双方を
  取り上げても当てはめが成立することで示す
- **単一の実行経路**（要件 9.3）: :func:`~curvefit.api.fit_series` が
  :mod:`curvefit.pipeline` を **実際に通る** こと。専用の近道を持たないことは、
  ``pipeline`` の内部（:func:`~curvefit.pipeline.run_job`）を差し替えて到達を観測する
  ことで確かめる。同一性をテストの比較ではなく **構造** で保証するのが設計の判断であり、
  近道が入り込めば CLI とライブラリの結果が食い違いうる
- **入力 3 経路の同一性**（要件 1.2）: 同じ数値データを CSV・NumPy 配列・DataFrame の
  いずれで与えても、公開 API を通した推定値が一致すること
- **記録の届き先**（要件 8.4）: 出力先を持たない単一系列の経路では、実行ログのファイルを
  持たない代わりに記録が呼び出し元のログ構成に届くこと。ロガーの状態を握ったままにしない
  こと
- **実行前ゲート**（要件 8.5、9.1）: 違反のある実行条件では処理単位を 1 件も実行せず、
  出力先に何も生成しないこと
- **設定ファイルからの一括実行**（要件 8.1、9.1）: 読み込みから当てはめ・結果取得までを
  1 回の呼び出しで通せること。読めない設定ファイルは例外ではなく違反として返ること
- **公開面**（要件 9.1）: ``import curvefit`` が意図した名前だけを露出し、公開
  シグネチャに基盤ライブラリ固有の型が現れないこと。取り込みがプロセス大域の描画
  バックエンドを変えないこと

設計の Testing Strategy が結線の検証を統合テストに置いているため、``tests/integration/``
に置く。

数値の一致について
------------------

:func:`~curvefit.api.fit_series` は系列をそのまま処理単位に載せる。ファイル経由との一致は、
読み込み側が値を保つこと（CSV は :func:`repr` で書き、読み込みは
``float_precision="round_trip"``）に依る。

**二進で厳密に表せる値だけで試験してはならない。** そのような値は短い十進表記を持ち、
読み込みの丸めが正しくなくてもたまたま元に戻るため、経路の食い違いに対して構造的に
盲目になる。:class:`Test経路の違いが値を変えないこと` は ``default_rng`` の全桁の値を用い、
:func:`~curvefit.api.fit_series` の結果を、メモリ上の系列への直接の当てはめとファイル経由の
一括処理の双方と比較する。既定の解釈器では、条件の悪い当てはめで係数が有効数字 3 桁目から
食い違う。
"""

from __future__ import annotations

import ast
import inspect
import json
import logging
import subprocess
import sys
import tempfile
import textwrap
import typing
from collections.abc import Iterator, Sequence
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import curvefit
from curvefit import pipeline
from curvefit.api import (
    PreflightAborted,
    fit_series,
    run_batch,
    run_from_config,
)
from curvefit.config import FailurePolicy, InputSpec, OutputSpec, RunConfig
from curvefit.errors import FailureReason, ViolationKind
from curvefit.engines.least_squares import LeastSquaresEngine
from curvefit.execution import EXECUTION_RECORD_FILENAME, ExecutionRecord
from curvefit.logging_setup import LOGGER_NAME, RUN_LOG_FILENAME
from curvefit.models.resolver import MethodSpec, PreparedModel, SmootherKind, resolve
from curvefit.pipeline import (
    BatchReport,
    Job,
    JobResult,
    SUMMARY_FILENAME,
)
from curvefit.plotting import PLOT_FONT_KEY, selected_japanese_font
from curvefit.preflight import PreflightResult
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec, read_arrays, read_delimited, read_frame
from curvefit.types import DataSeries, FitFailure, FitOutcome, FitSuccess

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

LINEAR = MethodSpec(name="lin", kind="builtin", builtin="linear")
"""比較に用いる手法。線形回帰は解が閉形式で定まり、反復解法の揺れが入り込まない。"""

GAUSSIAN = MethodSpec(name="gauss", kind="builtin", builtin="gaussian")

SLOPE = 2.5
INTERCEPT = 1.25
"""二進で厳密に表せる係数。生成した ``y`` も厳密に表せる値になる。"""

RESIDUALS = np.array([0.25, -0.5, 0.125, 0.5, -0.25, 0.375, -0.125, 0.0])
"""直線からのずれ。いずれも 2 の冪の和であり二進で厳密に表せる。

**ずれを与えるのは比較に意味を持たせるためである。** 完全に直線上に乗るデータでは残差が
0 になり、推定値が重みにも点の取捨にも反応しない。経路が食い違っていても一致してしまい、
一致の主張が空になる。
"""


# --- 試験データ --------------------------------------------------------------------


def linear_arrays(n_points: int = 11) -> tuple[np.ndarray, np.ndarray]:
    """既知の直線からのずれを持つ、二進で厳密に表せる合成データを作る。

    刻みも係数もずれも 2 の冪の和で表せる。**これは経路の一致を検査しない試験データで
    ある**。短い十進表記を持つ値は、丸めの正しくない解釈器でも元に戻ってしまう。経路の
    一致そのものは :class:`Test経路の違いが値を変えないこと` が全桁の乱数で検査する。
    """
    x = np.arange(n_points, dtype=np.float64) * 0.5
    y = SLOPE * x + INTERCEPT + RESIDUALS[np.arange(n_points) % RESIDUALS.size]
    return x, y


def write_csv(path: Path, x: np.ndarray, y: np.ndarray, sigma: np.ndarray | None = None) -> Path:
    """配列を見出し行つきの CSV に書き出す。

    値は ``repr`` で書く。往復するのは 1 回だけであり、比較する各経路が同じ 1 回を
    通るため、経路間の一致はテキスト表現の精度に依存しない。
    """
    names = ["x", "y"] if sigma is None else ["x", "y", "sigma"]
    columns = [x, y] if sigma is None else [x, y, sigma]
    lines = [",".join(names)]
    for row in zip(*(column.tolist() for column in columns), strict=True):
        lines.append(",".join(repr(float(value)) for value in row))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _assert_csv_roundtrip_is_exact(path: Path, x: np.ndarray, y: np.ndarray) -> None:
    """CSV 往復が最終ビットまで厳密であることを確かめる。

    厳密一致の比較は、この前提の上でのみ意味を持つ。
    """
    series = read_delimited(path, ColumnSpec(x="x", y="y"), method_name="check")
    assert isinstance(series, DataSeries)
    assert np.array_equal(series.x, x)
    assert np.array_equal(series.y, y)


def make_config(
    directory: Path,
    paths: Sequence[str],
    methods: Sequence[MethodSpec],
    *,
    columns: ColumnSpec | None = None,
    write_plot: bool = False,
) -> RunConfig:
    """試験用の実行条件。グラフ出力は既定で切る（本試験の対象外であり実行が遅い）。"""
    return RunConfig(
        inputs=InputSpec(
            paths=tuple(paths),
            columns=columns if columns is not None else ColumnSpec(x="x", y="y"),
            header=True,
        ),
        methods=tuple(methods),
        preprocess=PreprocessSpec(),
        output=OutputSpec(
            directory=directory,
            write_summary=True,
            write_plot=write_plot,
            write_curve=False,
        ),
        failure_policy=FailurePolicy.SKIP,
    )


def estimates(outcome: FitOutcome) -> dict[str, float]:
    """成功した当てはめのパラメータ推定値を、名前で引ける形にする。"""
    assert isinstance(outcome, FitSuccess), outcome
    return {estimate.name: estimate.value for estimate in outcome.parameters}


def only_outcome(report: BatchReport | PreflightResult) -> FitOutcome:
    """1 件だけの処理単位を含む集計結果から、その結果を取り出す。"""
    assert isinstance(report, BatchReport), report
    assert len(report.outcomes) == 1, report.outcomes
    return report.outcomes[0]


CONFIG_TEMPLATE = """\
[input]
paths = [{paths}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "lin"
builtin = "linear"

[output]
directory = {directory}
write_plot = {write_plot}
"""


def write_config(path: Path, data: Path, directory: Path, *, write_plot: bool = False) -> Path:
    path.write_text(
        CONFIG_TEMPLATE.format(
            paths=repr(str(data)),
            directory=repr(str(directory)),
            write_plot="true" if write_plot else "false",
        ),
        encoding="utf-8",
    )
    return path


# --- 単一系列の当てはめ（要件 9.1）--------------------------------------------------


class Test単一系列の当てはめ:
    """要件 9.1: 自身の解析スクリプトからライブラリとして呼び出せること。"""

    def test_既知のパラメータを復元する(self) -> None:
        x = np.linspace(-4.0, 4.0, 81)
        y = 3.0 * np.exp(-((x - 0.5) ** 2) / (2.0 * 1.5**2)) / (1.5 * np.sqrt(2.0 * np.pi))
        series = read_arrays(x, y, source_id="memory", method_name=GAUSSIAN.name)
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, GAUSSIAN)

        values = estimates(outcome)
        assert values["center"] == pytest.approx(0.5, abs=1e-6)
        assert values["sigma"] == pytest.approx(1.5, abs=1e-6)
        assert values["amplitude"] == pytest.approx(3.0, abs=1e-6)

    def test_呼び出し元が付けた識別子を結果に保つ(self) -> None:
        """一時的な作業経路が結果の識別子に漏れてはならない。"""
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="実験A", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, LINEAR)

        assert outcome.source_id == "実験A"
        assert outcome.method_name == LINEAR.name

    def test_曲線データを保持したまま返す(self) -> None:
        """要件 7.5、10.4: 単一系列の経路だけが曲線を返す。

        この経路は曲線 CSV を書かない（出力物を 1 つも生成しない）。手放せば、各点の
        当てはめ値と残差を受け取る手段が利用者から失われる。件数が 1 件である以上、
        保持しても常駐メモリが処理件数に比例して増える形にはならない。
        """
        x, y = linear_arrays(n_points=11)
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, LINEAR)

        assert isinstance(outcome, FitSuccess)
        assert outcome.curve is not None, "単一系列の経路が曲線を手放している"
        assert len(outcome.curve) == outcome.goodness.n_points == 11
        assert np.array_equal(outcome.curve.x, x)
        assert outcome.curve.residual == pytest.approx(
            outcome.curve.y_observed - outcome.curve.y_fit
        )

    def test_一括処理の返り値は曲線データを保持しない(self, tmp_path: Path) -> None:
        """要件 10.4: 手放すのはバッチ経路に限る、という区別が実際に効いていること。

        同じ系列を 2 つの入口に通す。片方だけが曲線を返すことが、この区別が
        ``series`` の有無ではなく明示の指定（``_execute`` の ``retain_curve``）で
        決まっていることの現れである。
        """
        x, y = linear_arrays(n_points=11)
        data = write_csv(tmp_path / "a.csv", x, y)

        report = run_batch(make_config(tmp_path / "out", [str(data)], [LINEAR]))

        outcome = only_outcome(report)
        assert isinstance(outcome, FitSuccess)
        assert outcome.curve is None
        # 推定値・適合度・成否は残る（集計は従来どおり成立する）。
        assert outcome.goodness.n_points == 11
        assert set(estimates(outcome)) == {"slope", "intercept"}

    def test_前処理の指定が適用される(self) -> None:
        """要件 2.1: 区間指定が単一系列の経路でも効くこと。"""
        x, y = linear_arrays(n_points=21)
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, LINEAR, PreprocessSpec(x_min=1.0, x_max=4.0))

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_out_of_range > 0
        assert outcome.goodness.n_points < len(x)

    def test_作業用の一時ファイルを残さない(self, tmp_path: Path, monkeypatch) -> None:
        """要件 9.1: 対話環境からの利用で作業ディレクトリを汚さないこと。"""
        monkeypatch.chdir(tmp_path)
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        fit_series(series, LINEAR)

        assert list(tmp_path.iterdir()) == []

    def test_一時領域にも何も残さない(self, tmp_path: Path, monkeypatch) -> None:
        """要件 9.1: 一時領域も汚さないこと。

        一時領域を試験専用の空ディレクトリに向けて観測する。既定の一時領域は他の
        プロセスと共有されており、増減を当てはめに帰属できない。
        """
        monkeypatch.setattr(tempfile, "tempdir", str(tmp_path))
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        assert isinstance(fit_series(series, LINEAR), FitSuccess)

        assert list(tmp_path.rglob("*")) == []

    def test_外れ値を除いても一時領域に何も残さない(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """要件 9.1、2.5: 除外の記録も一時領域に書き出されないこと。

        前処理 CSV（要件 2.5）はオプトインではなく、成否も条件にしない出力である。
        この経路の出力先は :func:`~curvefit.api._unwritten_output_directory` が返す
        **共有の一時領域** であり、抑止が働かなければ利用者の一時領域に書き込む。
        書かれないことは、一時領域を試験専用の空ディレクトリに向けて観測する。

        **除外が実際に起きていることを併せて表明する。** 除外 0 件では書くものが無く、
        抑止が外れていても空のままになり、この検査が空振りする。
        """
        monkeypatch.setattr(tempfile, "tempdir", str(tmp_path))
        x, y = linear_arrays(n_points=20)
        y = y.copy()
        y[7] += 300.0
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        outcome = fit_series(
            series, LINEAR, PreprocessSpec(outlier=OutlierSpec(sigma=3.0))
        )

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier >= 1
        assert list(tmp_path.rglob("*")) == []

    def test_解決できない手法は実行前に中止される(self) -> None:
        """要件 3.4: 違反は当てはめを試みる前に報告される。"""
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name="unknown")
        assert isinstance(series, DataSeries)
        unknown = MethodSpec(name="unknown", kind="builtin", builtin="存在しないモデル")

        with pytest.raises(PreflightAborted) as caught:
            fit_series(series, unknown)

        kinds = {violation.kind for violation in caught.value.violations}
        assert ViolationKind.MODEL_UNRESOLVED in kinds

    def test_出力物を書かない実行条件で呼ぶ(self, monkeypatch) -> None:
        """結果は返り値で受け取る。表も図も曲線 CSV も生成しない。

        書き出しの有無を決めるのは実行条件であり、``pipeline`` に届く時点で 3 つとも
        無効であることを確かめる。作業領域を持たない経路では、出力先を走査して不在を
        示すことができない。
        """
        seen: list[RunConfig] = []
        original = pipeline.run

        def spy(
            config: RunConfig,
            execution: ExecutionRecord,
            observer: object | None = None,
            **keywords: object,
        ) -> BatchReport:
            seen.append(config)
            return original(config, execution, observer, **keywords)  # type: ignore[arg-type]

        monkeypatch.setattr(pipeline, "run", spy)
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        fit_series(series, LINEAR)

        assert len(seen) == 1
        assert seen[0].output.write_summary is False
        assert seen[0].output.write_plot is False
        assert seen[0].output.write_curve is False


# --- 一時ファイルを経由しないこと（要件 9.1）----------------------------------------


class Test一時ファイルを経由しないこと:
    """要件 9.1: 対話環境からの利用で、系列をテキストに往復させないこと。

    かつては系列を一時 CSV に書き出して読み直していた。往復は値を変えないよう作られて
    いたが（``repr`` と ``float_precision="round_trip"``）、系列 1 件ごとに書き出し・
    読み込み・作業領域の生成破棄を伴う。差込口は ``pipeline`` の側にあり、本モジュールは
    それを使うだけである（当てはめ専用の近道を持たない）。

    **痕跡の不在では往復の不在を示せない。** 作業領域は呼び出しの終わりに消えるため、
    前後の走査だけでは往復していた実装も通る。往復に使う道具そのものを取り上げて示す。
    """

    def test_一時ディレクトリを作らない(self, monkeypatch) -> None:
        def refuse(*arguments: object, **keywords: object) -> None:
            raise AssertionError("一時ディレクトリを作ってはならない")

        monkeypatch.setattr(tempfile, "TemporaryDirectory", refuse)
        monkeypatch.setattr(tempfile, "mkdtemp", refuse)
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        assert isinstance(fit_series(series, LINEAR), FitSuccess)

    def test_入力の読み込みを経由しない(self, monkeypatch) -> None:
        """読み込み段が呼ばれないこと。読み込み済みの系列がそのまま当てはめに渡る。"""

        def refuse(*arguments: object, **keywords: object) -> None:
            raise AssertionError("読み込み段を経由してはならない")

        monkeypatch.setattr(pipeline, "read_delimited", refuse)
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        assert isinstance(fit_series(series, LINEAR), FitSuccess)

    def test_ファイル経由の実行は読み込みを通る(self, tmp_path: Path, monkeypatch) -> None:
        """対照。読み込みを省くのは単一系列の経路に限る。"""
        calls: list[object] = []
        original = pipeline.read_delimited

        def spy(*arguments: object, **keywords: object) -> object:
            calls.append(arguments[0])
            return original(*arguments, **keywords)  # type: ignore[arg-type]

        monkeypatch.setattr(pipeline, "read_delimited", spy)
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()

        run_batch(make_config(output, [str(data)], [LINEAR]))

        assert len(calls) == 1


class Test記録の届き先:
    """出力先を持たない経路で、記録が呼び出し元のログ構成に委ねられること（要件 8.4）。

    **本クラスは、重みを反映できない旨の警告が到達不能でないことの拠り所でもある。**
    要件 1.10 の拒否は「誤差列の指定（`input.columns.weight`）× 重みを扱えない手法」と
    いう **設定上の** 組み合わせを実行前ゲートが止めるものである。`fit_series` は列指定を
    当てはめに使わず（`api.UNUSED_COLUMNS`）、重みは `DataSeries` が既に持っている。
    実行前ゲートは系列を受け取らないためこの重みを見られない。したがってこの経路では
    警告が唯一の告知であり、`pipeline._log_ignored_weights` は防御ではなく現役の経路である。
    """

    SPLINE = MethodSpec(
        name="sp", kind="smoother", smoother=SmootherKind.SPLINE, options={"lam": 1e-2}
    )
    """平滑化パラメータの指定は必須である（要件 5.5）。"""

    MOVING_AVERAGE = MethodSpec(
        name="ma", kind="smoother", smoother=SmootherKind.MOVING_AVERAGE
    )
    """重みを持ち込む場所が無い唯一の手法（要件 1.3、``engines.smoothing``）。"""

    def test_スプラインでは警告が出ない(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """要件 1.3: スプラインは重みを反映するため、無視した旨の警告は出ない（タスク 11.1）。

        出せば偽の報告になる。利用者は実際には効いている測定誤差を「効いていない」と読む。
        警告の対象を手法ごとに正しく選べていることを、単一系列の経路でも固定する。
        """
        x, y = linear_arrays()
        series = read_arrays(
            x, y, source_id="memory", sigma=np.full(x.size, 0.5), method_name="sp"
        )
        assert isinstance(series, DataSeries)

        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = fit_series(series, self.SPLINE)

        assert isinstance(outcome, FitSuccess)
        assert [
            record.getMessage() for record in caplog.records if "重み" in record.getMessage()
        ] == []

    def test_重みを使えない手法の警告が呼び出し元に届く(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """要件 1.3: 誤差列が推定に反映されないことを利用者が知れること。

        単一系列の経路は実行ログのファイルを持たない。作業領域に書いて消していた頃、
        この警告は書かれた直後に作業領域ごと消えており、誰にも届かなかった。
        """
        x, y = linear_arrays()
        series = read_arrays(
            x, y, source_id="memory", sigma=np.full(x.size, 0.5), method_name="ma"
        )
        assert isinstance(series, DataSeries)

        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = fit_series(series, self.MOVING_AVERAGE)

        assert isinstance(outcome, FitSuccess)
        messages = [
            record.getMessage() for record in caplog.records if "重み" in record.getMessage()
        ]
        assert len(messages) == 1
        assert "memory" in messages[0]

    def test_呼び出し元のログ構成を書き換えない(self) -> None:
        """ライブラリがロガーの状態を握ったままにしないこと（``logging_setup``）。"""
        logger = logging.getLogger(LOGGER_NAME)
        before = (logger.level, logger.propagate, list(logger.handlers))
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        fit_series(series, LINEAR)

        assert (logger.level, logger.propagate, list(logger.handlers)) == before


# --- 単一の実行経路（要件 9.3）------------------------------------------------------


class Test単一の実行経路:
    """要件 9.3: CLI とライブラリが同一の実行経路を共有すること。"""

    def test_単一系列の当てはめが一括処理の経路を通る(self, monkeypatch) -> None:
        """``pipeline`` の内部に到達することを、差し替えて観測する。

        「同じ結果になった」ではなく「同じ経路を通った」ことを確かめる。値の比較だけでは
        たまたま一致した近道を見逃す。
        """
        calls: list[Job] = []
        original = pipeline.run_job

        def spy(job: Job, config: RunConfig) -> JobResult:
            calls.append(job)
            return original(job, config)

        monkeypatch.setattr(pipeline, "run_job", spy)
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, LINEAR)

        assert isinstance(outcome, FitSuccess)
        assert len(calls) == 1
        assert calls[0].method == LINEAR

    def test_単一系列と一括処理が同一の推定値を返す(self, tmp_path: Path) -> None:
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        _assert_csv_roundtrip_is_exact(data, x, y)
        output = tmp_path / "out"
        output.mkdir()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        batch = estimates(only_outcome(run_batch(make_config(output, [str(data)], [LINEAR]))))
        single = estimates(fit_series(series, LINEAR))

        assert single == batch

    def test_誤差列を伴う場合も同一の推定値を返す(self, tmp_path: Path) -> None:
        """要件 1.3: 重みが単一系列の経路でも同じ値で効くこと。

        σ には 2 の冪を用いる。``DataSeries`` が保持するのは σ ではなく重み ``1/σ`` で
        あり、単一系列の経路はそこから σ を復元する。2 の冪であれば逆数も厳密であるため、
        復元が値を動かさないことまで含めて比較できる。
        """
        x, y = linear_arrays()
        sigma = np.array([0.5, 1.0, 2.0, 0.25, 4.0, 1.0, 0.5, 2.0, 1.0, 0.25, 8.0])
        data = write_csv(tmp_path / "data.csv", x, y, sigma)
        output = tmp_path / "out"
        output.mkdir()
        series = read_arrays(x, y, source_id="memory", sigma=sigma, method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        config = make_config(
            output, [str(data)], [LINEAR], columns=ColumnSpec(x="x", y="y", weight="sigma")
        )
        batch = estimates(only_outcome(run_batch(config)))
        single = estimates(fit_series(series, LINEAR))

        assert single == batch


# --- 入力 3 経路の同一性（要件 1.2）------------------------------------------------


class Test入力経路の同一性:
    """要件 1.2: 配列・DataFrame も CSV と同一の手順・同一の構造で扱われること。"""

    def test_CSV_配列_DataFrame_が同一の推定値を返す(self, tmp_path: Path) -> None:
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        _assert_csv_roundtrip_is_exact(data, x, y)
        output = tmp_path / "out"
        output.mkdir()

        from_csv = estimates(only_outcome(run_batch(make_config(output, [str(data)], [LINEAR]))))

        arrays = read_arrays(x, y, source_id="arrays", method_name=LINEAR.name)
        assert isinstance(arrays, DataSeries)
        from_arrays = estimates(fit_series(arrays, LINEAR))

        frame = read_frame(
            pd.DataFrame({"x": x, "y": y}),
            ColumnSpec(x="x", y="y"),
            source_id="frame",
            method_name=LINEAR.name,
        )
        assert isinstance(frame, DataSeries)
        from_frame = estimates(fit_series(frame, LINEAR))

        assert from_arrays == from_csv
        assert from_frame == from_csv

    def test_3_経路が同一の構造の結果を返す(self, tmp_path: Path) -> None:
        """同一手順であることは、返る型と欄立てが同じであることにも現れる。"""
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()
        arrays = read_arrays(x, y, source_id="arrays", method_name=LINEAR.name)
        assert isinstance(arrays, DataSeries)

        from_csv = only_outcome(run_batch(make_config(output, [str(data)], [LINEAR])))
        from_arrays = fit_series(arrays, LINEAR)

        assert type(from_csv) is type(from_arrays)
        assert isinstance(from_csv, FitSuccess)
        assert isinstance(from_arrays, FitSuccess)
        assert [p.name for p in from_csv.parameters] == [p.name for p in from_arrays.parameters]
        assert from_csv.goodness.n_points == from_arrays.goodness.n_points


# --- 経路の違いが値を変えないこと（要件 1.2、9.1、9.3）------------------------------


POLYNOMIAL = MethodSpec(
    name="poly", kind="builtin", builtin="polynomial", options={"degree": 3}
)
"""条件の悪い当てはめ。設計行列が強く相関し、入力の最終ビットが係数の上位桁に届く。"""


def random_series(
    n_points: int = 300, low: float = 1000.0, high: float = 1000.5
) -> tuple[np.ndarray, np.ndarray]:
    """短い十進表記を持たない合成データを作る。

    ``linear_arrays`` の 2 の冪と違い、``repr`` は 17 桁前後になる。値が最終ビットまで
    保たれなければ、経路ごとの推定値は食い違う。

    既定の区間を x≈1000 の狭い幅に取るのは、多項式の当てはめをわざと条件の悪い側に
    置くためである。最終ビットの差が上位桁まで届く場面でこそ、経路の一致が問われる。
    """
    rng = np.random.default_rng(20260811)
    x = np.sort(rng.uniform(low, high, n_points))
    shifted = x - low
    y = 1.0 + 2.0 * shifted - 0.5 * shifted**2 + rng.normal(0.0, 1.0e-3, n_points)
    return x, y


def fit_in_memory(series: DataSeries, method: MethodSpec) -> dict[str, float]:
    """テキストを一切経由せず、系列をそのまま当てはめエンジンに渡す。

    :func:`~curvefit.api.fit_series` の比較相手である。往復が値を変えれば、両者の
    推定値は食い違う。
    """
    prepared = resolve(method, series)
    assert isinstance(prepared, PreparedModel), prepared
    outcome = LeastSquaresEngine().fit(series, prepared)
    return {estimate.name: estimate.value for estimate in outcome.parameters}


class Test経路の違いが値を変えないこと:
    """要件 9.1、9.3: 単一系列の経路が、直接の当てはめともファイル経由とも一致する。

    :class:`Test入力経路の同一性` は 2 の冪のデータを用いており、値が最終ビットまで
    保たれなくても通る。本クラスは全桁の乱数を用いる。比較相手は 2 つある。

    1. **メモリ上の系列への直接の当てはめ** — 単一系列の経路が値に手を加えていないこと
    2. **ファイル経由の一括処理** — 要件 9.3 の同一性が、条件の悪い当てはめでも
       最終ビットまで成立すること。CSV は ``repr`` で書き、読み込みは
       ``float_precision="round_trip"`` である（``readers`` の Postconditions）。
       ``pandas`` の既定の解釈器では、下の多項式の係数が有効数字 3 桁目から食い違う
    """

    def test_全桁の乱数でも直接の当てはめと一致する(self) -> None:
        x, y = random_series()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        assert estimates(fit_series(series, LINEAR)) == fit_in_memory(series, LINEAR)

    def test_条件の悪い当てはめでも直接の当てはめと一致する(self) -> None:
        """最終ビットの差が上位桁に増幅される場面。"""
        x, y = random_series()
        series = read_arrays(x, y, source_id="memory", method_name=POLYNOMIAL.name)
        assert isinstance(series, DataSeries)

        assert estimates(fit_series(series, POLYNOMIAL)) == fit_in_memory(series, POLYNOMIAL)

    def test_全桁の誤差列でも直接の当てはめと一致する(self) -> None:
        """要件 1.3: 重みは σ の逆数として効く。σ が 1 ulp 違えば重みも違う。"""
        x, y = random_series()
        rng = np.random.default_rng(20260812)
        sigma = rng.lognormal(0.0, 1.0, x.size)
        series = read_arrays(x, y, source_id="memory", sigma=sigma, method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        assert estimates(fit_series(series, LINEAR)) == fit_in_memory(series, LINEAR)

    def test_全桁の乱数でもファイル経由と一致する(self, tmp_path: Path) -> None:
        """要件 9.3: 同一の数値データを与えた 2 経路が同一の推定値を返す。"""
        x, y = random_series()
        data = write_csv(tmp_path / "data.csv", x, y)
        _assert_csv_roundtrip_is_exact(data, x, y)
        output = tmp_path / "out"
        output.mkdir()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        batch = estimates(only_outcome(run_batch(make_config(output, [str(data)], [LINEAR]))))

        assert estimates(fit_series(series, LINEAR)) == batch

    def test_条件の悪い当てはめでもファイル経由と一致する(self, tmp_path: Path) -> None:
        """最終ビットの差が上位桁に増幅される場面での要件 9.3。"""
        x, y = random_series()
        data = write_csv(tmp_path / "data.csv", x, y)
        _assert_csv_roundtrip_is_exact(data, x, y)
        output = tmp_path / "out"
        output.mkdir()
        series = read_arrays(x, y, source_id="memory", method_name=POLYNOMIAL.name)
        assert isinstance(series, DataSeries)

        batch = estimates(
            only_outcome(run_batch(make_config(output, [str(data)], [POLYNOMIAL])))
        )

        assert estimates(fit_series(series, POLYNOMIAL)) == batch

    def test_全桁の誤差列でもファイル経由と一致する(self, tmp_path: Path) -> None:
        """要件 1.3、9.3: 重みも 2 経路で同一に効くこと。"""
        x, y = random_series()
        rng = np.random.default_rng(20260812)
        sigma = rng.lognormal(0.0, 1.0, x.size)
        data = write_csv(tmp_path / "data.csv", x, y, sigma)
        output = tmp_path / "out"
        output.mkdir()
        series = read_arrays(x, y, source_id="memory", sigma=sigma, method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        config = make_config(
            output, [str(data)], [LINEAR], columns=ColumnSpec(x="x", y="y", weight="sigma")
        )
        batch = estimates(only_outcome(run_batch(config)))

        assert estimates(fit_series(series, LINEAR)) == batch


# --- 平滑化スプラインの再現性（要件 5.5、8.2）--------------------------------------


SPLINE_LAM = 1e-2
"""検査に用いる平滑化パラメータ。要件 5.5 により指定は必須である。"""


def gcv_drifter(n_points: int = 36) -> tuple[np.ndarray, np.ndarray]:
    """平滑化パラメータの自動選択（GCV）が揺れることを実測した配置。

    種を固定した乱数から作る。平滑化パラメータを指定せずにこの系列を当てはめると、
    基盤ライブラリの GCV 探索が呼び出しごとに 2 つの状態のいずれかに倒れ、同一設定・
    同一入力の 12 回実行で ``summary.csv`` が 2 種類になった。サマリ CSV の有効数字
    10 桁の丸めはこれを吸収しない（値が丸めの境界付近にあるため）。要件 5.5 が
    平滑化パラメータを必須にした根拠そのものである。
    """
    rng = np.random.default_rng(3)
    x = np.sort(rng.uniform(0.0, 10.0, n_points))
    y = np.sin(x) + rng.normal(0.0, 0.05, n_points)
    return x, y


class Test平滑化スプラインの再現性:
    """要件 5.5、8.2: 平滑化パラメータを必須にすることで揺れそのものが消える。

    元の欠陥を捕まえる位置に置く。丸めで隠れないよう、比較は ``summary.csv`` の
    バイト列と当てはめ値の完全一致で行う。
    """

    def _spline(self, lam: float | None = SPLINE_LAM) -> MethodSpec:
        options = {} if lam is None else {"lam": lam}
        return MethodSpec(
            name="spl", kind="smoother", smoother=SmootherKind.SPLINE, options=options
        )

    def test_同一設定の再実行でサマリ表がバイト一致する(self, tmp_path: Path) -> None:
        x, y = gcv_drifter()
        data = write_csv(tmp_path / "data.csv", x, y)
        summaries = []
        for index in range(2):
            output = tmp_path / f"out{index}"
            output.mkdir()
            report = run_batch(make_config(output, [str(data)], [self._spline()]))
            assert isinstance(report, BatchReport), report
            summaries.append((output / SUMMARY_FILENAME).read_bytes())

        assert summaries[0] == summaries[1]

    def test_同一設定の再実行で当てはめ値が完全一致する(self, tmp_path: Path) -> None:
        """丸める前の値で見る。丸めは必要条件であって十分条件ではない。"""
        x, y = gcv_drifter()
        series = read_arrays(x, y, source_id="memory", method_name="spl")
        assert isinstance(series, DataSeries)

        first = fit_series(series, self._spline())
        second = fit_series(series, self._spline())

        assert isinstance(first, FitSuccess) and isinstance(second, FitSuccess)
        assert np.array_equal(first.curve.y_fit, second.curve.y_fit)
        assert first.goodness.rmse == second.goodness.rmse

    def test_平滑化パラメータの無いスプラインは実行前に拒否される(
        self, tmp_path: Path
    ) -> None:
        """要件 5.5: 未指定は処理を開始せず報告する。"""
        x, y = gcv_drifter()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()

        result = run_batch(make_config(output, [str(data)], [self._spline(lam=None)]))

        assert isinstance(result, PreflightResult)
        assert [v.kind for v in result.violations] == [
            ViolationKind.SMOOTHER_OPTION_INVALID
        ]
        assert list(output.iterdir()) == []

    def test_単一系列の経路でも未指定は拒否される(self) -> None:
        x, y = gcv_drifter()
        series = read_arrays(x, y, source_id="memory", method_name="spl")
        assert isinstance(series, DataSeries)

        with pytest.raises(PreflightAborted) as caught:
            fit_series(series, self._spline(lam=None))

        assert [v.kind for v in caught.value.result.violations] == [
            ViolationKind.SMOOTHER_OPTION_INVALID
        ]


# --- 実行前ゲート（要件 8.5、9.1）--------------------------------------------------


class Test実行前ゲート:
    """設計の中心的な判断: ゲートを通過するまで処理単位を 1 件も実行しない。"""

    def test_違反のある実行条件では何も実行されない(self, tmp_path: Path) -> None:
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()
        unknown = MethodSpec(name="bad", kind="builtin", builtin="存在しないモデル")

        result = run_batch(make_config(output, [str(data)], [LINEAR, unknown]))

        assert isinstance(result, PreflightResult)
        assert result.ok is False
        assert list(output.iterdir()) == []

    def test_違反は一括で返る(self, tmp_path: Path) -> None:
        """要件 8.5: 1 件ずつ直して再実行する往復を強いない。"""
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()
        first = MethodSpec(name="a", kind="builtin", builtin="存在しないモデル")
        second = MethodSpec(name="b", kind="expression", expression="a * x + b")

        result = run_batch(make_config(output, [str(data)], [first, second]))

        assert isinstance(result, PreflightResult)
        kinds = {violation.kind for violation in result.violations}
        assert ViolationKind.MODEL_UNRESOLVED in kinds
        assert ViolationKind.INITIAL_REQUIRED in kinds


# --- 設定ファイルからの実行（要件 8.1、9.1）----------------------------------------


class Test設定ファイルからの実行:
    """要件 9.1: 読み込みから結果取得までを 1 回の呼び出しで通せること。"""

    def test_一連の処理を通して実行できる(self, tmp_path: Path) -> None:
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        config_path = write_config(tmp_path / "run.toml", data, output, write_plot=True)

        report = run_from_config(config_path)

        assert isinstance(report, BatchReport)
        assert report.n_success == 1
        assert report.n_failure == 0
        assert report.aborted is False
        assert estimates(report.outcomes[0])["slope"] == pytest.approx(SLOPE, abs=0.05)
        assert (output / SUMMARY_FILENAME).is_file()
        assert (output / RUN_LOG_FILENAME).is_file()
        assert (output / EXECUTION_RECORD_FILENAME).is_file()
        assert list((output / "plots").glob("*.png"))

    def test_設定ファイルの位置が実行条件に記録される(self, tmp_path: Path) -> None:
        """要件 8.3: どの設定で走ったかを後から言えること。"""
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        config_path = write_config(tmp_path / "run.toml", data, output)

        report = run_from_config(config_path)

        assert isinstance(report, BatchReport)
        assert report.execution.config_path == str(config_path)
        assert report.execution.resolved_config

    def test_表題に使ったフォントが実行条件に残る(self, tmp_path: Path) -> None:
        """要件 7.4、8.3: 端末によって字形が変わるため、どのフォントで描いたかを残す。

        図の見た目が違うとき、設定の違いなのか環境の違いなのかを切り分けられる必要がある。
        """
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        config_path = write_config(tmp_path / "run.toml", data, output)

        report = run_from_config(config_path)

        assert isinstance(report, BatchReport)
        assert PLOT_FONT_KEY in report.execution.resolved_config
        assert report.execution.resolved_config[PLOT_FONT_KEY] == selected_japanese_font()

        # 記録は書き出されたものにも載る。値は JSON にできる型に限る（str または null）。
        written = json.loads(
            (output / EXECUTION_RECORD_FILENAME).read_text(encoding="utf-8")
        )
        assert written["resolved_config"][PLOT_FONT_KEY] == selected_japanese_font()
        assert isinstance(written["resolved_config"][PLOT_FONT_KEY], str | type(None))

    def test_実行時引数が設定ファイルに優先し記録される(self, tmp_path: Path) -> None:
        """要件 9.4: 上書きは前後の値ごと残る。"""
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        declared = tmp_path / "declared"
        actual = tmp_path / "actual"
        config_path = write_config(tmp_path / "run.toml", data, declared)

        report = run_from_config(config_path, {"output.directory": str(actual)})

        assert isinstance(report, BatchReport)
        assert (actual / SUMMARY_FILENAME).is_file()
        assert not declared.exists()
        keys = {record.key for record in report.execution.cli_overrides}
        assert keys == {"output.directory"}

    def test_ライブラリ呼び出しでは設定ファイルの位置を持たない(self, tmp_path: Path) -> None:
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()

        report = run_batch(make_config(output, [str(data)], [LINEAR]))

        assert isinstance(report, BatchReport)
        assert report.execution.config_path is None

    def test_進捗の通知先を渡せる(self, tmp_path: Path) -> None:
        """要件 6.3: 端末描画は CLI が持ち、ライブラリは通知先を受け取るのみ。"""
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        config_path = write_config(tmp_path / "run.toml", data, output)
        started: list[tuple[int, int]] = []
        finished: list[BatchReport] = []

        class Observer:
            def on_start(self, total_jobs: int, total_sources: int) -> None:
                started.append((total_jobs, total_sources))

            def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None:
                pass

            def on_finish(self, report: BatchReport) -> None:
                finished.append(report)

        run_from_config(config_path, None, Observer())

        assert started == [(1, 1)]
        assert len(finished) == 1

    def test_解釈できない設定ファイルは違反として返る(self, tmp_path: Path) -> None:
        """要件 8.5: 利用者が書いた内容に対して例外を送出しない。"""
        broken = tmp_path / "run.toml"
        broken.write_text("[input\npaths = \n", encoding="utf-8")

        result = run_from_config(broken)

        assert isinstance(result, PreflightResult)
        assert result.ok is False
        assert {violation.kind for violation in result.violations} == {
            ViolationKind.CONFIG_INVALID
        }

    def test_存在しない設定ファイルは違反として返る(self, tmp_path: Path) -> None:
        result = run_from_config(tmp_path / "missing.toml")

        assert isinstance(result, PreflightResult)
        assert result.ok is False

    def test_違反のある設定では出力先に何も生成されない(self, tmp_path: Path) -> None:
        x, y = linear_arrays()
        data = write_csv(tmp_path / "data.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()
        config_path = tmp_path / "run.toml"
        config_path.write_text(
            CONFIG_TEMPLATE.format(
                paths=repr(str(data)), directory=repr(str(output)), write_plot="false"
            ).replace('builtin = "linear"', 'builtin = "存在しないモデル"'),
            encoding="utf-8",
        )

        result = run_from_config(config_path)

        assert isinstance(result, PreflightResult)
        assert result.ok is False
        assert list(output.iterdir()) == []


# --- 公開面（要件 9.1）-------------------------------------------------------------


PUBLIC_FACADE = ("fit_series", "run_batch", "run_from_config")
PUBLIC_INPUT = ("ColumnSpec", "read_arrays", "read_delimited", "read_frame")

TYPE_ALIAS_MARKERS = ("TypeAlias", typing.TypeAlias)
"""``X: TypeAlias = ...`` の注釈が取りうる表現。

``curvefit.types`` は ``from __future__ import annotations`` を持つため、モジュールの
``__annotations__`` には評価前の **文字列** が入る。将来これを外しても拾えるよう、
注釈オブジェクトそのものも並べる。
"""


def _types_module_public_names() -> frozenset[str]:
    """``curvefit.types`` が定義している公開名を、モジュールの実物から導く。

    **列挙で持たない。** 列挙式にすると、``types`` に結果型を足しても検査は緑のまま
    通る。:class:`~curvefit.types.OutlierPoint`（タスク 10.1）が
    ``curvefit.__all__`` と :data:`curvefit.api.__all__` の双方から漏れたまま気付かれ
    なかったのはこの形が原因である。実物から導けば、次に型が増えたとき再エクスポート
    を忘れた側で検査が落ちる。

    採る規則は 2 つで、いずれも「``curvefit.types`` が **定義した** 公開名」を表す。

    1. ``__module__`` が ``curvefit.types`` である名前 — 凍結データクラス
       （:class:`~curvefit.types.FitSuccess` など）が該当する。``type X = ...`` 形式の
       別名を将来書いた場合もここで拾える
    2. モジュール直下の ``X: TypeAlias = ...`` 宣言 — :data:`~curvefit.types.FitOutcome`
       と :data:`~curvefit.types.FloatArray`。実体は共用体・NumPy の総称型であり
       ``__module__`` は定義元を指さないため、規則 1 だけでは落ちる

    除外は 2 つあり、**いずれも意図したものである**。

    - ``_`` で始まる名前 — 実装の補助であって型ではない（``_require_float_array``）
    - **取り込んだだけの名前** — :class:`~curvefit.errors.FailureReason` は
      ``curvefit.types`` の名前空間に現れるが、所有者は ``curvefit.errors`` である。
      公開面を保つ責任は定義した側にあり、この型は
      :meth:`Test公開面.test_実行条件と結果の型が再エクスポートされている` が見ている。
      規則 1 の ``__module__`` 判定がこの区別をそのまま表している

    導出が空振りしていないことは
    :meth:`Test公開面.test_公開面の導出が実物に結び付いている` が固定する。
    """
    module = curvefit.types
    defined = {
        name
        for name, value in vars(module).items()
        if not name.startswith("_")
        and getattr(value, "__module__", None) == module.__name__
    }
    aliases = {
        name
        for name, annotation in getattr(module, "__annotations__", {}).items()
        if not name.startswith("_") and annotation in TYPE_ALIAS_MARKERS
    }
    return frozenset(defined | aliases)


PUBLIC_TYPES = tuple(sorted(_types_module_public_names()))
"""``curvefit.types`` が定義する公開型。実物から導く（:func:`_types_module_public_names`）。"""

KNOWN_PUBLIC_TYPES = (
    "CurveData",
    "DataSeries",
    "FitFailure",
    "FitOutcome",
    "FitSuccess",
    "GoodnessOfFit",
    "ParameterEstimate",
    "PreprocessReport",
)
"""導出が覆うべき下限。**この列挙は導出の代わりではなく、導出の見張りである。**

導出に切り替える前はこの 8 名を手で並べていた。導出そのものが縮退しても、規則ごとに
1 名ずつ指す検査だけでは気づけない（実測: 規則 1 の条件を狭めて 7 名を脱落させても
全件が緑のまま通った）。既に公開されていた型が導出から消えたら落ちる形にする。

新しい型が増えたときにここへ足す必要はない。増えた型を捕まえるのは導出の側であり、
ここは減ったことだけを見る。
"""

INTERNAL_NAMES = (
    "run_job",
    "expand_jobs",
    "resolve",
    "PreparedModel",
    "PreparedSmoother",
    "select_engine",
    "write_summary",
    "render_fit_plot",
    "load_config",
    "validate",
)


class Test公開面:
    """要件 9.1: 対話環境や解析スクリプトから素直に取り込めること。"""

    def test_ファサードと型が再エクスポートされている(self) -> None:
        for name in PUBLIC_FACADE + PUBLIC_INPUT + PUBLIC_TYPES:
            assert name in curvefit.__all__, name
            assert getattr(curvefit, name) is not None, name

    def test_型は_api_の公開面にも載る(self) -> None:
        """公開面の並びは 2 か所にある。片方だけを直すと、もう片方が取り残される。

        ``curvefit.__init__`` は型を ``curvefit.types`` から取り込むため、``api`` 側の
        ``__all__`` に載せ忘れても ``import curvefit`` は通ってしまう。
        :class:`~curvefit.types.OutlierPoint` は実際に両方から漏れていた。
        """
        for name in PUBLIC_TYPES:
            assert name in curvefit.api.__all__, name

    def test_公開面の導出が実物に結び付いている(self) -> None:
        """:func:`_types_module_public_names` の 2 規則と 2 除外が実際に働いていること。

        導出が空集合に潰れても、上の 2 つは総当たりであるため緑のまま通る。規則ごとに
        1 つずつ実物を指して、空振りと規則の脱落を捕まえる。
        """
        # 規則 1（``__module__`` が ``curvefit.types``）。タスク 10.1 で漏れた型。
        assert "OutlierPoint" in PUBLIC_TYPES
        # 規則 2（``X: TypeAlias = ...`` 宣言）。データクラスではないため規則 1 では落ちる。
        assert "FitOutcome" in PUBLIC_TYPES
        # 除外 1: 取り込んだだけの名前。所有者は ``curvefit.errors`` である。
        assert "FailureReason" not in PUBLIC_TYPES
        # 除外 2: 実装の補助。
        assert [name for name in PUBLIC_TYPES if name.startswith("_")] == []

    def test_導出は既に公開されていた型を取りこぼさない(self) -> None:
        """導出の縮退を捕まえる（:data:`KNOWN_PUBLIC_TYPES`）。

        規則ごとに 1 名ずつ指す上の検査は、規則の**全廃**は捕まえるが**部分的な縮退**は
        捕まえない。実測で、規則 1 の条件を狭めて 10 名中 7 名を脱落させても全件が
        緑のまま通った。手で並べていた頃の 8 名を下限として押さえる。
        """
        missing = set(KNOWN_PUBLIC_TYPES) - set(PUBLIC_TYPES)

        assert not missing, f"導出から公開型が消えている: {sorted(missing)}"

    def test_実行条件と結果の型が再エクスポートされている(self) -> None:
        for name in (
            "RunConfig",
            "InputSpec",
            "OutputSpec",
            "MethodSpec",
            "PreprocessSpec",
            "OutlierSpec",
            "SmootherKind",
            "FailurePolicy",
            "BatchReport",
            "PreflightResult",
            "ProgressObserver",
            "ConfigViolation",
            "ViolationKind",
            "FailureReason",
            "ExecutionRecord",
            "OverrideRecord",
            "PreflightAborted",
        ):
            assert name in curvefit.__all__, name

    def test_内部の名前を再エクスポートしない(self) -> None:
        for name in INTERNAL_NAMES:
            assert name not in curvefit.__all__, name

    def test_公開名がすべて解決できる(self) -> None:
        for name in curvefit.__all__:
            assert hasattr(curvefit, name), name

    def test_再エクスポートの出所を_api_と_types_に限る(self) -> None:
        """設計の File Structure Plan: 公開 API の再エクスポートは api と types のみ。"""
        allowed = {"curvefit.api", "curvefit.types"}

        assert _imported_modules("__init__.py") <= allowed


def _imported_modules(filename: str) -> set[str]:
    """対象ファイルが実際に import している最上位モジュール名を構文木から集める。

    docstring がライブラリ名に言及するだけで誤検出しないよう、文字列ではなく構文木で
    判定する（``tests/integration/test_preflight.py`` と同じ規約）。
    """
    tree = ast.parse((SRC / filename).read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names - {"__future__"}


class Test依存の露出:
    """設計の Allowed Dependencies: ``api`` は上流のみを取り込み ``cli`` を取り込まない。"""

    def test_cli_を_import_しない(self) -> None:
        assert "curvefit.cli" not in _imported_modules("api.py")

    def test_基盤ライブラリを直接_import_しない(self) -> None:
        """数値配列の共通表現である NumPy を除き、基盤ライブラリに触れない。"""
        for imported in _imported_modules("api.py"):
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval"}, (
                f"api.py が {imported} を import している"
            )

    def test_上流の実行経路を取り込む(self) -> None:
        assert {"curvefit.pipeline", "curvefit.preflight"} <= _imported_modules("api.py")


def _referenced_types(annotation: object) -> Iterator[type]:
    """注釈が参照している型を再帰的に取り出す。"""
    if isinstance(annotation, type):
        yield annotation
    for argument in typing.get_args(annotation):
        yield from _referenced_types(argument)


def _public_annotations() -> Iterator[tuple[str, str, object]]:
    """公開名の注釈を ``(名前, 位置, 注釈)`` として列挙する。"""
    for name in curvefit.__all__:
        target = getattr(curvefit, name)
        if inspect.isfunction(target):
            signature = inspect.signature(target, eval_str=True)
            for parameter in signature.parameters.values():
                yield name, parameter.name, parameter.annotation
            yield name, "return", signature.return_annotation
        elif inspect.isclass(target):
            for field_name, annotation in typing.get_type_hints(target).items():
                yield name, field_name, annotation


FORBIDDEN_ROOTS = frozenset({"lmfit", "scipy", "matplotlib", "asteval"})


class Test公開シグネチャ:
    """設計の Invariants: 公開シグネチャに基盤ライブラリ固有の型を含めない。"""

    def test_基盤ライブラリの型が現れない(self) -> None:
        for name, where, annotation in _public_annotations():
            for referenced in _referenced_types(annotation):
                root = referenced.__module__.split(".")[0]
                assert root not in FORBIDDEN_ROOTS, f"{name}.{where} が {referenced} を露出している"

    def test_表形式の型は入力の受け口にのみ現れる(self) -> None:
        """要件 1.2 が求める DataFrame 入力は受け口に限る。返り値には現れない。"""
        for name, where, annotation in _public_annotations():
            if where != "return":
                continue
            for referenced in _referenced_types(annotation):
                assert referenced.__module__.split(".")[0] != "pandas", f"{name} の返り値"

    def test_ファサードの署名が設計どおり(self) -> None:
        assert list(inspect.signature(curvefit.fit_series).parameters) == [
            "series",
            "method",
            "preprocess",
        ]
        assert list(inspect.signature(curvefit.run_batch).parameters) == ["config", "observer"]
        assert list(inspect.signature(curvefit.run_from_config).parameters) == [
            "path",
            "overrides",
            "observer",
        ]


BACKEND_PROBE = textwrap.dedent(
    """
    import matplotlib

    matplotlib.use("pdf")
    before = matplotlib.get_backend()
    import curvefit

    import sys

    print(before, matplotlib.get_backend(), "matplotlib.figure" in sys.modules)
    """
)


class Test対話環境からの利用:
    """要件 9.1: 取り込むだけで利用者の環境を壊さないこと。"""

    def test_取り込みが描画バックエンドを変えない(self) -> None:
        """``from curvefit import run_batch`` が対話環境の表示を潰さないこと。

        別プロセスで確かめる。同一プロセスでは、既に取り込まれた ``curvefit`` の
        副作用を観測できない。
        """
        result = subprocess.run(
            [sys.executable, "-c", BACKEND_PROBE],
            capture_output=True,
            text=True,
            timeout=120,
        )

        assert result.returncode == 0, result.stderr
        before, after, drawing_imported = result.stdout.split()
        assert before == after == "pdf"
        assert drawing_imported == "True", "描画層を取り込まない経路では本検査が働かない"


# --- 失敗の扱い --------------------------------------------------------------------


class Test失敗の扱い:
    """要件 6.4: 個別データの失敗はバッチを止めず、値として返る。"""

    def test_読み込めない入力は個別の失敗になる(self, tmp_path: Path) -> None:
        output = tmp_path / "out"
        output.mkdir()

        report = run_batch(make_config(output, [str(tmp_path / "missing.csv")], [LINEAR]))

        assert isinstance(report, BatchReport)
        assert report.n_failure == 1
        assert isinstance(report.outcomes[0], FitFailure)

    def test_点数不足の単一系列は失敗として返る(self) -> None:
        """要件 2.4: 例外ではなく値で返ること。"""
        series = read_arrays(
            np.array([0.0]), np.array([1.0]), source_id="memory", method_name=GAUSSIAN.name
        )
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, GAUSSIAN)

        assert isinstance(outcome, FitFailure)
        assert outcome.source_id == "memory"

    @pytest.mark.parametrize(
        "error", [MemoryError("記憶領域が尽きた"), OSError("書き込みに失敗した")]
    )
    def test_資源枯渇で中断した場合も値として返る(
        self, monkeypatch, error: BaseException
    ) -> None:
        """要件 10.3: 中断は例外ではなく、中断した対象を明示した結果として返る。"""

        def exhausted(job: Job, config: RunConfig) -> JobResult:
            raise error

        monkeypatch.setattr(pipeline, "run_job", exhausted)
        x, y = linear_arrays()
        series = read_arrays(x, y, source_id="memory", method_name=LINEAR.name)
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, LINEAR)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.RESOURCE_EXHAUSTED
        assert outcome.source_id == "memory"
        assert outcome.method_name == LINEAR.name
        assert outcome.method_name == LINEAR.name


# --- 数式モデルと利用者定義関数（要件 3.2、3.3、4.3、9.1、9.2）----------------------


DECAY_TRUE: tuple[float, float, float] = (2.5, 0.75, 0.5)
"""当てはめで復元されるべき真の値。順に 振幅・減衰率・定数項。

``y = a·exp(-k·x) + c`` の形は組込モデルのどれとも一致しない。組込の指数モデルは
定数項を持たないため、解決済みモデルが組込に差し替わればパラメータ名も推定値も揃わない。
"""

DECAY_START: tuple[float, float, float] = (1.0, 0.25, 0.0)
"""明示指定する初期値（要件 4.3）。

**真値と一致させてはならない。** 一致させると、当てはめが初期値から一歩も動かなくても
真値が「復元」され、結線が壊れたことに気づけない。各成分を真値から離してあることは
:func:`assert_decay_recovered` の前提として検査する。
"""

DECAY_TOLERANCE = 1.0e-8
"""推定値と真値の許容差。

**データは式そのものから生成しており、測定誤差を含まない。** したがって真値は残差平方和の
厳密な最小点（残差 0）であり、許容差が覆うべきものは解法の収束判定だけである。実測の
食い違いは倍精度の丸め水準（4e-16）であり、本値はそれに対して 7 桁の余裕を持つ。
統計的な散らばりを織り込む必要がないため、「成功したこと」ではなく **値そのもの** を
主張できる。
"""

EXPRESSION = "a * exp(-k * x) + c"
"""数式文字列によるモデル指定（要件 3.2）。"""

EXPRESSION_NAMES: tuple[str, ...] = ("a", "k", "c")
"""数式モデルのパラメータ名。**式中の出現順** である（``models.expression`` の規約）。

要件 3.5 により、この名前と並びがそのまま結果出力の識別子になる。
"""

CALLABLE_NAMES: tuple[str, ...] = ("amp", "rate", "offset")
"""利用者定義関数のパラメータ名。**関数の引数の並び順** である（独立変数 ``x`` を除く）。"""


def decay_arrays(n_points: int = 81) -> tuple[np.ndarray, np.ndarray]:
    """``y = a·exp(-k·x) + c`` に厳密に乗る合成データを作る。

    区間は減衰が 1 桁分進むだけの幅を取る。減衰率と定数項が分離できるだけの信号が
    無ければ、結線が正しくても真値を復元できず、許容差を緩める以外に手がなくなる。
    """
    x = np.linspace(0.0, 4.0, n_points)
    amplitude, rate, offset = DECAY_TRUE
    y = amplitude * np.exp(-rate * x) + offset
    return x, y


def named(names: Sequence[str], values: Sequence[float]) -> dict[str, float]:
    """パラメータ名と値を対応付ける。名前だけが経路ごとに違い、値は共通である。"""
    return dict(zip(names, values, strict=True))


def expression_method(*, initial: bool = True) -> MethodSpec:
    """数式文字列による手法指定（要件 3.2）。"""
    return MethodSpec(
        name="expr",
        kind="expression",
        expression=EXPRESSION,
        initial=named(EXPRESSION_NAMES, DECAY_START) if initial else {},
    )


def assert_decay_recovered(
    outcome: FitOutcome, names: Sequence[str], *, n_points: int = 81
) -> dict[str, float]:
    """既知の真値が、名前・並び・値のすべてにおいて復元されたことを確かめる。

    **「成功した」ことは主張しない。** 結線が壊れても当てはめ自体は成功しうる（別の
    モデルに差し替われば、そのモデルなりの最良解が返る）。捕まえられるのは値と識別子の
    比較だけである。
    """
    assert all(
        start != true for start, true in zip(DECAY_START, DECAY_TRUE, strict=True)
    ), "初期値が真値と一致していると、当てはめが動かなくても検査が通ってしまう"

    values = estimates(outcome)
    assert list(values) == list(names), "結果の識別子が解決済みモデルのものと違う"
    for name, true in zip(names, DECAY_TRUE, strict=True):
        assert values[name] == pytest.approx(true, abs=DECAY_TOLERANCE), name

    assert isinstance(outcome, FitSuccess)
    assert outcome.goodness.n_points == n_points
    assert outcome.goodness.n_varied_params == len(names)
    assert outcome.goodness.r_squared == pytest.approx(1.0, abs=1.0e-12)
    assert outcome.goodness.rmse < DECAY_TOLERANCE
    return values


class Test数式モデルの当てはめ:
    """要件 3.2: 数式文字列で指定したモデルが、公開経路で実際に当てはまること。

    解決だけを見る検査（``tests/unit/test_models_resolver.py``）や当てはめエンジンを
    直に呼ぶ検査は、``api`` → ``pipeline`` → ``resolver`` → ``engine`` の結線が
    切れても赤くならない。本クラスは公開ファサードだけを入口として、**既知の真値が
    復元されること** を主張する。
    """

    def test_既知のパラメータを復元する(self) -> None:
        x, y = decay_arrays()
        series = read_arrays(x, y, source_id="memory", method_name="expr")
        assert isinstance(series, DataSeries)

        outcome = fit_series(series, expression_method())

        assert_decay_recovered(outcome, EXPRESSION_NAMES)
        assert isinstance(outcome, FitSuccess)
        assert outcome.curve is not None
        assert outcome.curve.y_fit == pytest.approx(y, abs=DECAY_TOLERANCE)

    def test_一括処理の経路でも同じ推定値を返す(self, tmp_path: Path) -> None:
        """要件 3.2、9.3: 数式モデルは CLI も通る経路であり、単一系列に限らない。

        比較は厳密一致で行う。同一の数値データを与えた 2 経路は、当てはめに渡る系列が
        同一である以上、最終ビットまで一致する。
        """
        x, y = decay_arrays()
        data = write_csv(tmp_path / "decay.csv", x, y)
        _assert_csv_roundtrip_is_exact(data, x, y)
        output = tmp_path / "out"
        output.mkdir()
        series = read_arrays(x, y, source_id="memory", method_name="expr")
        assert isinstance(series, DataSeries)

        batch = only_outcome(
            run_batch(make_config(output, [str(data)], [expression_method()]))
        )

        assert_decay_recovered(batch, EXPRESSION_NAMES)
        assert estimates(batch) == estimates(fit_series(series, expression_method()))

    def test_初期値がなければ実行前に拒否される(self) -> None:
        """要件 4.3: 自動推定の手段を持たない経路では初期値の明示が必須である。

        この拒否が働くからこそ、上の 2 つが初期値を渡すことに意味がある。
        """
        x, y = decay_arrays()
        series = read_arrays(x, y, source_id="memory", method_name="expr")
        assert isinstance(series, DataSeries)

        with pytest.raises(PreflightAborted) as caught:
            fit_series(series, expression_method(initial=False))

        assert ViolationKind.INITIAL_REQUIRED in {
            violation.kind for violation in caught.value.violations
        }


class Test利用者定義関数の当てはめ:
    """要件 3.3: 利用者が渡した Python 関数が、公開経路で実際にモデルとして使われること。

    既存の検査はいずれも **意図的に壊した関数** を ``run_job`` に直接渡すもので、
    成功する当てはめが公開ファサードを通ることを確かめていない。本経路は設定ファイルに
    書けないため（要件 9.2）、ライブラリからしか到達できない。
    """

    def test_既知のパラメータを復元する(self) -> None:
        x, y = decay_arrays()
        series = read_arrays(x, y, source_id="memory", method_name="user")
        assert isinstance(series, DataSeries)
        widths: list[int] = []

        def 減衰(x: np.ndarray, amp: float, rate: float, offset: float) -> np.ndarray:
            widths.append(np.size(x))
            return amp * np.exp(-rate * x) + offset

        method = MethodSpec(
            name="user",
            kind="callable",
            function=減衰,
            initial=named(CALLABLE_NAMES, DECAY_START),
        )

        outcome = fit_series(series, method)

        assert_decay_recovered(outcome, CALLABLE_NAMES)
        # 利用者の関数そのものが評価されたこと。差し替えられた場合、値が合わないより先に
        # ここが空になる（どの層で切れたかを分けて読める）。
        assert widths, "利用者定義関数が一度も評価されていない"
        assert set(widths) == {x.size}, widths
        assert isinstance(outcome, FitSuccess)
        assert outcome.curve is not None
        assert outcome.curve.y_fit == pytest.approx(y, abs=DECAY_TOLERANCE)

    def test_初期値がなければ実行前に拒否される(self) -> None:
        """要件 4.3: 利用者定義関数も自動推定の手段を持たない。"""
        x, y = decay_arrays()
        series = read_arrays(x, y, source_id="memory", method_name="user")
        assert isinstance(series, DataSeries)

        def 減衰(x: np.ndarray, amp: float, rate: float, offset: float) -> np.ndarray:
            return amp * np.exp(-rate * x) + offset

        with pytest.raises(PreflightAborted) as caught:
            fit_series(series, MethodSpec(name="user", kind="callable", function=減衰))

        assert ViolationKind.INITIAL_REQUIRED in {
            violation.kind for violation in caught.value.violations
        }


CALLABLE_CONFIG_TEMPLATE = """\
[input]
paths = [{paths}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "user"
{selector} = "tests.integration.test_api:減衰"

[output]
directory = {directory}
write_plot = false
"""


class Test利用者定義関数は設定ファイルに書けない:
    """要件 9.2: 利用者定義関数（要件 3.3）は設定ファイルの記述対象外である。

    **黙って無視されないことを固定する。** 関数を指す綴りが受け付けられて捨てられると、
    利用者は自分のモデルで当てはめたつもりのまま別のモデルの結果を受け取る。書けない
    という宣言は、書こうとした指定が **実行前に** 違反として返ることでしか裏づけられない。

    CLI ではなく :func:`~curvefit.api.run_from_config` で確かめる。CLI は設定ファイルを
    読まず（``load_config`` を呼ばない）、記述可能な項目を決めているのは ``config`` の
    1 か所だけである。
    """

    @pytest.mark.parametrize("selector", ["function", "callable"])
    def test_関数を指す指定は違反として返る(self, tmp_path: Path, selector: str) -> None:
        x, y = decay_arrays()
        data = write_csv(tmp_path / "decay.csv", x, y)
        output = tmp_path / "out"
        output.mkdir()
        config_path = tmp_path / "run.toml"
        config_path.write_text(
            CALLABLE_CONFIG_TEMPLATE.format(
                paths=repr(str(data)), selector=selector, directory=repr(str(output))
            ),
            encoding="utf-8",
        )

        result = run_from_config(config_path)

        assert isinstance(result, PreflightResult), result
        assert result.ok is False
        assert ViolationKind.CONFIG_INVALID in {
            violation.kind for violation in result.violations
        }
        assert list(output.iterdir()) == []
