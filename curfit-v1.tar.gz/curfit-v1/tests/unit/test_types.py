"""共有データ型と失敗分類の契約を検証する。

対応要件: 1.2（3 経路が同一構造の結果を返す土台）、5.3（パラメータなしの手法も同一形式）、
7.1（推定値と標準誤差）、7.2（適合度指標）
"""

from __future__ import annotations

import ast
import dataclasses
from pathlib import Path

import numpy as np
import pytest

from curvefit.errors import ConfigViolation, FailureReason, ViolationKind
from curvefit.types import (
    CurveData,
    DataSeries,
    FitFailure,
    FitSuccess,
    GoodnessOfFit,
    OutlierPoint,
    ParameterEstimate,
    PreprocessReport,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


def _series(n: int = 5, *, weights: bool = False) -> DataSeries:
    x = np.arange(n, dtype=np.float64)
    return DataSeries(
        source_id="sample.csv",
        x=x,
        y=x * 2.0,
        weights=np.ones(n, dtype=np.float64) if weights else None,
    )


class Test入力データ系列:
    def test_同一長の配列で構成できる(self) -> None:
        s = _series()
        assert s.source_id == "sample.csv"
        assert s.weights is None
        assert len(s.x) == len(s.y) == 5

    def test_重み列を保持できる(self) -> None:
        assert _series(weights=True).weights is not None

    def test_生成後に再代入できない(self) -> None:
        with pytest.raises(dataclasses.FrozenInstanceError):
            _series().source_id = "other.csv"  # type: ignore[misc]

    def test_x_と_y_の長さが異なると拒否する(self) -> None:
        with pytest.raises(ValueError, match="長さ"):
            DataSeries(
                source_id="s",
                x=np.zeros(3, dtype=np.float64),
                y=np.zeros(4, dtype=np.float64),
            )

    def test_重みの長さが異なると拒否する(self) -> None:
        with pytest.raises(ValueError, match="長さ"):
            DataSeries(
                source_id="s",
                x=np.zeros(3, dtype=np.float64),
                y=np.zeros(3, dtype=np.float64),
                weights=np.zeros(2, dtype=np.float64),
            )

    def test_一次元でない配列を拒否する(self) -> None:
        with pytest.raises(ValueError, match="一次元"):
            DataSeries(
                source_id="s",
                x=np.zeros((2, 2), dtype=np.float64),
                y=np.zeros((2, 2), dtype=np.float64),
            )

    def test_浮動小数点でない配列を拒否する(self) -> None:
        with pytest.raises(ValueError, match="float64"):
            DataSeries(source_id="s", x=np.arange(3), y=np.arange(3))


class Testパラメータ推定値:
    def test_推定値と標準誤差を保持する(self) -> None:
        p = ParameterEstimate(name="amplitude", value=1.5, stderr=0.02, fixed=False)
        assert (p.name, p.value, p.stderr, p.fixed) == ("amplitude", 1.5, 0.02, False)

    def test_標準誤差が算出できない場合は空を許容する(self) -> None:
        """要件 7.1: ヤコビアン不足では標準誤差が得られない。失敗にはしない。"""
        assert ParameterEstimate(name="a", value=1.0, stderr=None, fixed=False).stderr is None

    def test_固定パラメータは標準誤差を持たない(self) -> None:
        assert ParameterEstimate(name="a", value=1.0, stderr=None, fixed=True).stderr is None

    def test_固定パラメータに標準誤差があると拒否する(self) -> None:
        with pytest.raises(ValueError, match="固定"):
            ParameterEstimate(name="a", value=1.0, stderr=0.1, fixed=True)


class Test適合度指標:
    def test_決定係数と_rmse_を保持する(self) -> None:
        g = GoodnessOfFit(r_squared=0.99, rmse=0.01, n_points=10, n_varied_params=3)
        assert (g.r_squared, g.rmse, g.n_points, g.n_varied_params) == (0.99, 0.01, 10, 3)

    def test_点数が負なら拒否する(self) -> None:
        with pytest.raises(ValueError, match="点数"):
            GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=-1, n_varied_params=0)


class Test曲線データ:
    def test_四配列が同一長なら構成できる(self) -> None:
        c = _curve(4)
        assert len(c.x) == len(c.y_observed) == len(c.y_fit) == len(c.residual) == 4

    def test_配列長が揃わないと拒否する(self) -> None:
        with pytest.raises(ValueError, match="長さ"):
            CurveData(
                x=np.zeros(3, dtype=np.float64),
                y_observed=np.zeros(3, dtype=np.float64),
                y_fit=np.zeros(2, dtype=np.float64),
                residual=np.zeros(3, dtype=np.float64),
            )


def _curve(n: int) -> CurveData:
    z = np.zeros(n, dtype=np.float64)
    return CurveData(x=z, y_observed=z, y_fit=z, residual=z)


def _report(n: int = 5) -> PreprocessReport:
    return PreprocessReport(
        n_input=n,
        n_dropped_invalid=0,
        n_dropped_out_of_range=0,
        n_dropped_outlier=0,
        outlier_points=(),
    )


class Test前処理レポート:
    """要件 2.2、2.3、2.5: 除去件数と、外れ値として除外した点の記録。"""

    def test_除外した点の_x_と実測値と反復回数を保持する(self) -> None:
        """要件 2.5: 件数だけでは、どの点がどの判定で外れたのかが利用者に届かない。"""
        report = PreprocessReport(
            n_input=5,
            n_dropped_invalid=0,
            n_dropped_out_of_range=0,
            n_dropped_outlier=2,
            outlier_points=(
                OutlierPoint(x=1.5, y=20.0, iteration=1),
                OutlierPoint(x=0.5, y=-3.0, iteration=2),
            ),
        )
        assert [(p.x, p.y, p.iteration) for p in report.outlier_points] == [
            (1.5, 20.0, 1),
            (0.5, -3.0, 2),
        ]
        assert report.n_used == 3

    def test_除外した点の記録が件数と一致しないと拒否する(self) -> None:
        """要件 2.3 の件数と要件 2.5 の記録が食い違えば、どちらを信じるかが決まらない。"""
        with pytest.raises(ValueError, match="件数"):
            PreprocessReport(
                n_input=5,
                n_dropped_invalid=0,
                n_dropped_out_of_range=0,
                n_dropped_outlier=2,
                outlier_points=(OutlierPoint(x=1.5, y=20.0, iteration=1),),
            )

    def test_除外が_0_件なら記録も空でなければならない(self) -> None:
        with pytest.raises(ValueError, match="件数"):
            PreprocessReport(
                n_input=5,
                n_dropped_invalid=0,
                n_dropped_out_of_range=0,
                n_dropped_outlier=0,
                outlier_points=(OutlierPoint(x=1.5, y=20.0, iteration=1),),
            )

    def test_件数が負なら拒否する(self) -> None:
        with pytest.raises(ValueError, match="負"):
            PreprocessReport(
                n_input=5,
                n_dropped_invalid=-1,
                n_dropped_out_of_range=0,
                n_dropped_outlier=0,
                outlier_points=(),
            )


class Test除外した点:
    """要件 2.5: 除外した点 1 個の記録。"""

    def test_生成後に再代入できない(self) -> None:
        point = OutlierPoint(x=1.0, y=2.0, iteration=1)
        with pytest.raises(dataclasses.FrozenInstanceError):
            point.x = 9.0  # type: ignore[misc]

    def test_反復回数は_1_起点である(self) -> None:
        """0 起点だと「1 回目の判定で除外した」を 0 と読ませることになる。"""
        with pytest.raises(ValueError, match="反復"):
            OutlierPoint(x=1.0, y=2.0, iteration=0)


class Test当てはめ結果:
    def test_成功結果を構成できる(self) -> None:
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(ParameterEstimate(name="a", value=1.0, stderr=0.1, fixed=False),),
            goodness=GoodnessOfFit(r_squared=0.99, rmse=0.01, n_points=4, n_varied_params=1),
            curve=_curve(4),
            preprocess=_report(),
        )
        assert s.method_name == "gaussian"

    def test_パラメータを持たない手法も成功結果になる(self) -> None:
        """要件 5.3: 移動平均などパラメータのない手法でも適合度は必ず算出される。"""
        s = FitSuccess(
            source_id="a.csv",
            method_name="moving_average",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=0.8, rmse=0.2, n_points=4, n_varied_params=0),
            curve=_curve(4),
            preprocess=_report(),
        )
        assert s.parameters == ()
        assert s.goodness.rmse == 0.2

    def test_適合度の点数が曲線長と食い違うと拒否する(self) -> None:
        with pytest.raises(ValueError, match="点数"):
            FitSuccess(
                source_id="a.csv",
                method_name="gaussian",
                parameters=(),
                goodness=GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=99, n_varied_params=0),
                curve=_curve(4),
                preprocess=_report(),
            )

    def test_曲線データを解放した成功結果を構成できる(self) -> None:
        """要件 10.4: バッチが曲線を手放した後の状態を、型として表せること。

        点数は適合度に残る。曲線を落としたことが「点が 1 つも無かった」と混ざらない。
        """
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=4, n_varied_params=0),
            curve=None,
            preprocess=_report(),
        )
        assert s.curve is None
        assert s.goodness.n_points == 4

    def test_解放すると曲線だけが外れる(self) -> None:
        """要件 10.4: ``without_curve`` は推定値・適合度・前処理記録に触れない。"""
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(ParameterEstimate(name="a", value=1.0, stderr=0.1, fixed=False),),
            goodness=GoodnessOfFit(r_squared=0.99, rmse=0.01, n_points=4, n_varied_params=1),
            curve=_curve(4),
            preprocess=_report(),
        )

        released = s.without_curve()

        assert released.curve is None
        assert s.curve is not None, "元の結果が書き換えられている"
        assert (released.source_id, released.method_name) == (s.source_id, s.method_name)
        assert released.parameters == s.parameters
        assert released.goodness == s.goodness
        assert released.preprocess == s.preprocess

    def test_解放済みの結果を再度解放しても同じ結果になる(self) -> None:
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=4, n_varied_params=0),
            curve=_curve(4),
            preprocess=_report(),
        ).without_curve()

        assert s.without_curve() == s

    def test_失敗結果は理由と説明を持つ(self) -> None:
        f = FitFailure(
            source_id="a.csv",
            method_name="gaussian",
            reason=FailureReason.NOT_CONVERGED,
            message="収束しなかった",
            preprocess=_report(),
        )
        assert f.reason is FailureReason.NOT_CONVERGED

    def test_前処理到達前の失敗では前処理レポートを持たない(self) -> None:
        f = FitFailure(
            source_id="a.csv",
            method_name="gaussian",
            reason=FailureReason.COLUMN_NOT_FOUND,
            message="列 x が無い",
            preprocess=None,
        )
        assert f.preprocess is None


class Test失敗分類:
    def test_実行中失敗と実行前違反が別の分類である(self) -> None:
        """統合すると「止めるべきか継続すべきか」の判断が呼び出し側に漏れる。"""
        assert FailureReason is not ViolationKind
        assert set(FailureReason) & set(ViolationKind) == set()

    def test_実行中失敗の理由が要件に対応している(self) -> None:
        assert {r.value for r in FailureReason} == {
            "column_not_found",
            "no_valid_data",
            "insufficient_points",
            "not_converged",
            "header_ambiguous",
            "input_unreadable",
            "resource_exhausted",
        }

    def test_実行前違反の種別が要件に対応している(self) -> None:
        assert {v.value for v in ViolationKind} == {
            "config_invalid",
            "model_unresolved",
            "initial_required",
            "initial_out_of_bounds",
            "output_not_writable",
            "smoother_option_invalid",
        }

    def test_設定違反は箇所と説明を持つ(self) -> None:
        v = ConfigViolation(
            kind=ViolationKind.MODEL_UNRESOLVED,
            location="methods[0].builtin",
            message="未知のモデル名: gausian",
        )
        assert v.location == "methods[0].builtin"


def _imported_modules(filename: str) -> set[str]:
    """モジュールが実際に import している最上位モジュール名を AST から収集する。

    docstring や注釈中の文字列に反応しないよう、文字列検索ではなく構文木で判定する。
    """
    tree = ast.parse((SRC / filename).read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class Test依存の露出:
    def test_基盤ライブラリを_import_しない(self) -> None:
        """設計の Allowed Dependencies: lmfit / SciPy / matplotlib / pandas を外へ漏らさない。"""
        for name in ("types.py", "errors.py"):
            for imported in _imported_modules(name):
                root = imported.split(".")[0]
                assert root not in {"lmfit", "scipy", "matplotlib", "pandas"}, (
                    f"{name} が {imported} を import している"
                )

    def test_失敗分類は自パッケージの他モジュールに依存しない(self) -> None:
        own = {m for m in _imported_modules("errors.py") if m.split(".")[0] == "curvefit"}
        assert own == set(), f"想定外の依存: {own}"

    def test_共有型は失敗分類以外の自パッケージモジュールに依存しない(self) -> None:
        own = {m for m in _imported_modules("types.py") if m.split(".")[0] == "curvefit"}
        assert own <= {"curvefit.errors"}, f"想定外の依存: {own - {'curvefit.errors'}}"
