"""回帰・平滑化エンジンの契約を検証する。

対応要件: 1.3（重みは残差の最小化に効く。線形回帰・多項式回帰は最小二乗そのものであり、
平滑化スプラインは残差の重み付き二乗和と曲率の和を最小化する）、
5.1（線形回帰・多項式回帰・スプライン・移動平均の 4 手法）、
5.3（パラメータを持つ手法はモデル関数フィットと同一の形式で出力し、適合度は必ず算出する）、
5.4（手法固有設定が未指定なら既定値を適用し、適用した値を記録する）。

設計の engines.base / engines.least_squares / engines.smoothing ブロックが定める
Invariants（パラメータを持たない手法では ``parameters`` が空タプルで、適合度は必ず
算出される）、Implementation Notes（既定値は本モジュールが単独で所有する、スプラインは
``make_smoothing_spline`` を使い legacy API を使わない）、Validation（非有限な当てはめ値は
エンジンが :class:`EngineFailure` として返す）、および Allowed Dependencies（SciPy /
NumPy の型を外へ出さない）を対象とする。

「最小二乗と同一の形式」（要件 5.3）は、型の形が揃っていることだけでは確かめられない。
同一データに対する組込 linear モデルの最小二乗結果と突き合わせ、パラメータ名・推定値・
標準誤差が一致することまで見る。形だけ揃えて中身の意味が違えば、サマリ CSV に並んだ
2 手法の値を利用者が比較できない。

エンジンは入出力を持たないため、検証はすべて合成データによる（steering `tech.md`）。
浮動小数点の完全一致比較を行うのは、既定値の適用と再現性（要件 8.2）の確認に限る。
"""

from __future__ import annotations

import ast
import hashlib
import inspect
import math
import warnings
from collections.abc import Mapping
from pathlib import Path

import numpy as np
import pytest

from curvefit.engines import smoothing
from curvefit.engines.base import (
    EngineFailure,
    EngineSuccess,
    FitEngine,
    compute_goodness,
)
from curvefit.engines.least_squares import LeastSquaresEngine
from curvefit.engines.smoothing import (
    DEFAULT_MOVING_AVERAGE_POLYORDER,
    DEFAULT_MOVING_AVERAGE_WINDOW,
    DEFAULT_POLYNOMIAL_DEGREE,
    MIN_SPLINE_POINTS,
    MOVING_AVERAGE_POLYORDER_OPTION,
    MOVING_AVERAGE_WINDOW_OPTION,
    POLYNOMIAL_DEGREE_OPTION,
    SMOOTHER_EMITS_PARAMETERS,
    SMOOTHER_OPTION_DEFAULTS,
    SMOOTHER_OPTION_NAMES,
    SMOOTHER_USES_WEIGHTS,
    SPLINE_LAMBDA_OPTION,
    SmoothingEngine,
)
from curvefit.errors import FailureReason
from curvefit.models import resolver
from curvefit.models.resolver import MethodSpec, PreparedSmoother, SmootherKind, resolve
from curvefit.types import DataSeries, FloatArray

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

# 選択肢名は本番の定数をそのまま用いる。別名は読みやすさのためだけの局所束縛である。
DEGREE = POLYNOMIAL_DEGREE_OPTION
WINDOW = MOVING_AVERAGE_WINDOW_OPTION
POLYORDER = MOVING_AVERAGE_POLYORDER_OPTION
LAM = SPLINE_LAMBDA_OPTION

TRUE_SLOPE = 2.5
TRUE_INTERCEPT = -1.5


def _array(values: list[float]) -> FloatArray:
    return np.array(values, dtype=np.float64)


def _series(x: FloatArray, y: FloatArray, source_id: str = "smooth.csv") -> DataSeries:
    return DataSeries(source_id=source_id, x=x, y=y)


def _line_series(n: int = 21) -> DataSeries:
    x = np.linspace(0.0, 10.0, n)
    return _series(x, TRUE_SLOPE * x + TRUE_INTERCEPT, "line.csv")


def _noisy_line_series() -> DataSeries:
    """既知の直線に決定的なずれを加えた系列。

    乱数を用いないのは、標準誤差の検証が実行ごとに揺れると要件 8.2 の再現性を
    テスト自身が満たさなくなるためである。
    """
    x = np.linspace(0.0, 10.0, 11)
    wobble = _array([0.3, -0.2, 0.1, 0.4, -0.3, 0.2, -0.1, 0.3, -0.4, 0.1, 0.2])
    return _series(x, TRUE_SLOPE * x + TRUE_INTERCEPT + wobble, "noisy_line.csv")


def _weighted_line_series() -> DataSeries:
    """測定誤差の大きさが点ごとに 100 倍異なる直線の系列（要件 1.3）。

    11 点のうち 3 点（両端と中央）だけが σ = 5.0 で、残る 8 点は σ = 0.05 である。
    重みを効かせるかどうかで推定値が桁違いに変わる配置にしてある。誤差の大きい点を
    端に置くのは、重みを無視した当てはめが傾きごと引きずられるようにするためである。
    差が小さい配置では、重みを落とす退行を許容誤差が吸収してしまう。

    ずれは決定的に与える。乱数を用いると標準誤差の突き合わせが実行ごとに揺れ、
    テスト自身が要件 8.2 の再現性を満たさなくなる。
    """
    x = np.linspace(0.0, 10.0, 11)
    unit = _array([-0.9, -0.2, 0.1, 0.4, -0.3, 0.5, -0.1, 0.3, -0.4, 0.1, 0.8])
    sigma = np.full(11, 0.05)
    sigma[[0, 5, 10]] = 5.0
    y = TRUE_SLOPE * x + TRUE_INTERCEPT + sigma * unit
    return DataSeries(
        source_id="weighted_line.csv", x=x, y=y, weights=1.0 / sigma
    )


def _weighted_quadratic_series() -> DataSeries:
    """測定誤差の大きさが点ごとに異なる二次曲線の系列（要件 1.3）。"""
    x = np.linspace(-3.0, 3.0, 11)
    unit = _array([-0.9, -0.2, 0.1, 0.4, -0.3, 0.5, -0.1, 0.3, -0.4, 0.1, 0.8])
    sigma = np.full(11, 0.05)
    sigma[[0, 5, 10]] = 5.0
    y = 1.5 * x**2 - 2.0 * x + 0.5 + sigma * unit
    return DataSeries(
        source_id="weighted_quadratic.csv", x=x, y=y, weights=1.0 / sigma
    )


def _without_weights(series: DataSeries) -> DataSeries:
    """同じ観測から重みだけを落とした系列。"""
    return DataSeries(source_id=series.source_id, x=series.x, y=series.y)


DISPLACED_INDEX = 10
""":func:`_displaced_point_series` でずらす点の位置。系列の中央に置く。"""


def _displaced_point_series() -> tuple[DataSeries, FloatArray]:
    """1 点だけを大きくずらし、その点にだけ大きな測定誤差を与えた直線の系列。

    戻り値の第 2 要素はずれを加える前の真の直線である。重みが効いていれば、当てはめは
    ずれた観測ではなく真の直線に近づく。ずれは決定的に与える（要件 8.2）。

    誤差の与え方を「大きくずれた 1 点だけ σ が大きい」形にするのは、重みの向きを
    判定できるようにするためである。重みを無視した当てはめはこの 1 点に引きずられ、
    他のすべての点から離れる。
    """
    x = np.linspace(0.0, 10.0, 21)
    truth = 2.0 * x + 1.0
    y = truth.copy()
    y[DISPLACED_INDEX] += 6.0
    sigma = np.full(21, 0.1)
    sigma[DISPLACED_INDEX] = 30.0
    return (
        DataSeries(source_id="displaced.csv", x=x, y=y, weights=1.0 / sigma),
        np.asarray(truth, dtype=np.float64),
    )


DEGENERATE_LAM = 1e6
"""スプラインを直線に退化させる平滑化パラメータ。

曲率の罰則を極端に強めると、当てはめは「曲率 0 の関数のうち残差を最小にするもの」、
すなわち直線に収束する。この極限では重み付き直線回帰という厳密な参照が使えるため、
重みの効き方を数値で突き合わせられる。

これ以上大きくすると連立系の条件数が壊れ、当てはめが直線ではなく 0 へ潰れる
（実測: ``lam = 1e14`` で参照直線から 6.96 ずれた）。1e6 は退化が十分進み、かつ
数値が健全な域である（実測: 参照直線との差 2.0e-05）。
"""


def _weighted_line_of(
    x: FloatArray, y: FloatArray, weight_on_squared_residual: FloatArray
) -> FloatArray:
    """``Σ w (y - (a + b x))²`` を最小にする直線の当てはめ値。

    本番実装を一切経由しない独立な参照である。正規方程式を直接解くのは、「重みが
    二乗前の残差に掛かるのか、二乗後の残差に掛かるのか」という 2 つの解釈を、
    テスト側で書き分けられるようにするためである。
    """
    design = np.vander(x, 2, increasing=True)
    weighted = design * weight_on_squared_residual[:, np.newaxis]
    coefficients = np.linalg.solve(design.T @ weighted, weighted.T @ y)
    return np.asarray(design @ coefficients, dtype=np.float64)


def _quadratic_series(n: int = 21) -> DataSeries:
    x = np.linspace(-3.0, 3.0, n)
    return _series(x, 1.5 * x**2 - 2.0 * x + 0.5, "quadratic.csv")


def _wave_series(n: int = 41) -> DataSeries:
    """滑らかな曲線に細かい振動を重ねた、平滑化の対象となる系列。"""
    x = np.linspace(0.0, 10.0, n)
    return _series(x, np.sin(x) + 0.05 * np.cos(9.0 * x), "wave.csv")


def _gcv_drifter_series() -> DataSeries:
    """GCV による平滑化パラメータの自動選択が揺れることを実測で確認した系列。

    種を固定した乱数から作る。この配置では、平滑化パラメータを指定しない当てはめが
    呼び出しごとに 2 つの状態のいずれかに倒れ、同一設定・同一入力の 12 回実行で
    ``summary.csv`` が 2 種類になった（要件 8.2 が成立しない）。要件 5.5 が平滑化
    パラメータを必須にした根拠そのものであり、退行を捕まえる場所として用いる。
    """
    generator = np.random.default_rng(3)
    x = np.sort(generator.uniform(0.0, 10.0, 36))
    y = np.sin(x) + generator.normal(0.0, 0.05, 36)
    return _series(np.asarray(x, dtype=np.float64), np.asarray(y, dtype=np.float64), "drift.csv")


TEST_LAM = 1e-2
"""検証で用いる平滑化パラメータ。

スプラインは平滑化パラメータの指定を必須とする（要件 5.5）。実行前ゲートが未指定を
拒否するため、エンジンに届く解決済み手法は必ずこの選択肢を持つ。手法を跨いだ
パラメータ化テストで毎回書き足さずに済むよう、:func:`_prepared` が補う。
"""


def _prepared(
    kind: SmootherKind, options: Mapping[str, float | int] | None = None
) -> PreparedSmoother:
    """解決済みの手法を組み立てる。

    スプラインで選択肢を明示しなかった場合は :data:`TEST_LAM` を補う。実行前ゲートを
    通った設定だけがエンジンに届くという前提を、テストの入力側でも保つためである。
    未指定そのものを対象とする検証は :class:`Test平滑化パラメータの必須性` が
    :class:`PreparedSmoother` を直接組み立てて行う。
    """
    resolved = dict(options or {})
    if kind is SmootherKind.SPLINE and SPLINE_LAMBDA_OPTION not in resolved:
        resolved[SPLINE_LAMBDA_OPTION] = TEST_LAM
    return PreparedSmoother(display_name=kind.value, kind=kind, options=resolved)


def _outcome(series: DataSeries, prepared: PreparedSmoother) -> EngineSuccess | EngineFailure:
    return SmoothingEngine().fit(series, prepared)


def _succeeded(series: DataSeries, prepared: PreparedSmoother) -> EngineSuccess:
    outcome = _outcome(series, prepared)
    assert isinstance(outcome, EngineSuccess), f"当てはめに失敗した: {outcome}"
    return outcome


def _failed(series: DataSeries, prepared: PreparedSmoother) -> EngineFailure:
    outcome = _outcome(series, prepared)
    assert isinstance(outcome, EngineFailure), f"失敗するはずが成功した: {outcome}"
    return outcome


def _values(success: EngineSuccess) -> dict[str, float]:
    return {estimate.name: estimate.value for estimate in success.parameters}


def _suitable_series(kind: SmootherKind) -> DataSeries:
    """手法ごとに、当てはめが成立する代表的な系列。"""
    if kind is SmootherKind.LINEAR:
        return _line_series()
    if kind is SmootherKind.POLYNOMIAL:
        return _quadratic_series()
    return _wave_series()


class Test四手法の実行:
    """要件 5.1: 4 手法がいずれも当てはめ結果を返す。"""

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_各手法が当てはめ結果を返す(self, kind: SmootherKind) -> None:
        series = _suitable_series(kind)
        success = _succeeded(series, _prepared(kind))
        assert len(success.y_fit) == len(series)

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_当てはめ値は一次元の倍精度配列である(self, kind: SmootherKind) -> None:
        success = _succeeded(_suitable_series(kind), _prepared(kind))
        assert success.y_fit.ndim == 1
        assert success.y_fit.dtype == np.float64

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_選択できる手法をすべて実装している(self, kind: SmootherKind) -> None:
        """列挙に手法を足して実装を忘れると、実行時まで気付けない。"""
        assert kind in SMOOTHER_OPTION_NAMES
        assert kind in SMOOTHER_OPTION_DEFAULTS

    def test_当てはめ契約を満たす(self) -> None:
        """要件 5.2: 最小二乗と同一の契約の実装として並置される。"""
        assert isinstance(SmoothingEngine(), FitEngine)

    def test_線形回帰が既知の直線を復元する(self) -> None:
        values = _values(_succeeded(_line_series(), _prepared(SmootherKind.LINEAR)))
        assert values["slope"] == pytest.approx(TRUE_SLOPE, rel=1e-9)
        assert values["intercept"] == pytest.approx(TRUE_INTERCEPT, rel=1e-9)

    def test_多項式回帰が既知の二次式を復元する(self) -> None:
        values = _values(_succeeded(_quadratic_series(), _prepared(SmootherKind.POLYNOMIAL)))
        assert values["c0"] == pytest.approx(0.5, abs=1e-9)
        assert values["c1"] == pytest.approx(-2.0, rel=1e-9)
        assert values["c2"] == pytest.approx(1.5, rel=1e-9)

    def test_スプラインが振動を均した曲線を返す(self) -> None:
        series = _wave_series()
        success = _succeeded(series, _prepared(SmootherKind.SPLINE))
        smoothed_deviation = float(np.sum(np.abs(np.diff(success.y_fit, n=2))))
        raw_deviation = float(np.sum(np.abs(np.diff(series.y, n=2))))
        assert smoothed_deviation < raw_deviation

    def test_移動平均が振動を均した系列を返す(self) -> None:
        series = _wave_series()
        success = _succeeded(series, _prepared(SmootherKind.MOVING_AVERAGE))
        smoothed_deviation = float(np.sum(np.abs(np.diff(success.y_fit, n=2))))
        raw_deviation = float(np.sum(np.abs(np.diff(series.y, n=2))))
        assert smoothed_deviation < raw_deviation

    def test_スプラインは平滑化の強さを指定できる(self) -> None:
        """平滑化パラメータを大きくすれば、より滑らかな曲線になる。"""
        series = _wave_series()
        weak = _succeeded(series, _prepared(SmootherKind.SPLINE, {LAM: 1e-4}))
        strong = _succeeded(series, _prepared(SmootherKind.SPLINE, {LAM: 1e3}))
        assert float(np.sum(np.abs(np.diff(strong.y_fit, n=2)))) < float(
            np.sum(np.abs(np.diff(weak.y_fit, n=2)))
        )

    def test_移動平均は次数を上げると形状を保つ(self) -> None:
        """要件 5.1 の移動平均は多項式次数 0 の場合であり、次数は選択肢として開いている。"""
        series = _wave_series()
        flat = _succeeded(series, _prepared(SmootherKind.MOVING_AVERAGE))
        shaped = _succeeded(
            series, _prepared(SmootherKind.MOVING_AVERAGE, {POLYORDER: 2})
        )
        assert not np.array_equal(flat.y_fit, shaped.y_fit)
        assert float(np.sum(np.square(series.y - shaped.y_fit))) < float(
            np.sum(np.square(series.y - flat.y_fit))
        )


class Test最小二乗と同一の出力形式:
    """要件 5.3: 推定パラメータを持つ手法は最小二乗と同一の形式で出力する。"""

    def _least_squares(self, series: DataSeries) -> EngineSuccess:
        prepared = resolve(MethodSpec(name="linear", kind="builtin", builtin="linear"), series)
        outcome = LeastSquaresEngine().fit(series, prepared)  # type: ignore[arg-type]
        assert isinstance(outcome, EngineSuccess)
        return outcome

    def test_線形回帰のパラメータ名が最小二乗と一致する(self) -> None:
        series = _noisy_line_series()
        regression = _succeeded(series, _prepared(SmootherKind.LINEAR))
        least_squares = self._least_squares(series)

        assert tuple(e.name for e in regression.parameters) == tuple(
            e.name for e in least_squares.parameters
        )

    def test_線形回帰の推定値が最小二乗と一致する(self) -> None:
        series = _noisy_line_series()
        regression = _values(_succeeded(series, _prepared(SmootherKind.LINEAR)))
        least_squares = _values(self._least_squares(series))

        for name, value in least_squares.items():
            assert regression[name] == pytest.approx(value, rel=1e-6)

    def test_線形回帰の標準誤差が最小二乗と一致する(self) -> None:
        """同じ名前の量が別の意味を持たないことまで見る。"""
        series = _noisy_line_series()
        fitted = _succeeded(series, _prepared(SmootherKind.LINEAR))
        regression = {e.name: e.stderr for e in fitted.parameters}
        least_squares = {e.name: e.stderr for e in self._least_squares(series).parameters}

        for name, stderr in least_squares.items():
            assert stderr is not None
            assert regression[name] is not None
            assert regression[name] == pytest.approx(stderr, rel=1e-6)

    def test_多項式回帰は次数に応じた係数を返す(self) -> None:
        success = _succeeded(
            _quadratic_series(), _prepared(SmootherKind.POLYNOMIAL, {DEGREE: 3})
        )
        assert tuple(e.name for e in success.parameters) == ("c0", "c1", "c2", "c3")

    def test_推定したパラメータは固定扱いにしない(self) -> None:
        """要件 4.5 の固定は指定に基づく。回帰の係数はすべて推定対象である。"""
        for kind in (SmootherKind.LINEAR, SmootherKind.POLYNOMIAL):
            success = _succeeded(_suitable_series(kind), _prepared(kind))
            assert success.parameters
            assert all(not estimate.fixed for estimate in success.parameters)

    def test_標準誤差は有限の非負値になる(self) -> None:
        success = _succeeded(_noisy_line_series(), _prepared(SmootherKind.LINEAR))
        for estimate in success.parameters:
            assert estimate.stderr is not None
            assert math.isfinite(estimate.stderr)
            assert estimate.stderr >= 0.0

    def test_残差の自由度がなければ標準誤差は空になる(self) -> None:
        """要件 7.1 の標準誤差が算出できない場合、失敗にはせず空として扱う。"""
        series = _series(_array([0.0, 1.0]), _array([1.0, 3.0]))
        success = _succeeded(series, _prepared(SmootherKind.LINEAR))
        assert _values(success)["slope"] == pytest.approx(2.0)
        assert all(estimate.stderr is None for estimate in success.parameters)

    @pytest.mark.parametrize(
        "kind", [SmootherKind.SPLINE, SmootherKind.MOVING_AVERAGE], ids=lambda k: k.value
    )
    def test_パラメータを持たない手法は空のタプルを返す(self, kind: SmootherKind) -> None:
        success = _succeeded(_wave_series(), _prepared(kind))
        assert success.parameters == ()

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_適合度はどの手法でも算出できる(self, kind: SmootherKind) -> None:
        """パラメータの有無にかかわらず適合度は必ず算出される（設計の Invariants）。"""
        series = _suitable_series(kind)
        success = _succeeded(series, _prepared(kind))
        goodness = compute_goodness(series.y, success.y_fit, len(success.parameters))

        assert math.isfinite(goodness.r_squared)
        assert math.isfinite(goodness.rmse)
        assert goodness.n_points == len(series)
        assert goodness.n_varied_params == len(success.parameters)

    def test_線形回帰の適合度は誤差のない直線で_1_になる(self) -> None:
        series = _line_series()
        success = _succeeded(series, _prepared(SmootherKind.LINEAR))
        goodness = compute_goodness(series.y, success.y_fit, len(success.parameters))
        assert goodness.r_squared == pytest.approx(1.0, abs=1e-12)
        assert goodness.rmse == pytest.approx(0.0, abs=1e-9)


def _builtin(series: DataSeries, name: str, **options: float | int) -> EngineSuccess:
    """同じ系列を組込モデルの最小二乗で当てはめる。"""
    prepared = resolve(
        MethodSpec(name=name, kind="builtin", builtin=name, options=options), series
    )
    outcome = LeastSquaresEngine().fit(series, prepared)  # type: ignore[arg-type]
    assert isinstance(outcome, EngineSuccess), f"最小二乗に失敗した: {outcome}"
    return outcome


def _stderrs(success: EngineSuccess) -> dict[str, float | None]:
    return {estimate.name: estimate.stderr for estimate in success.parameters}


class Test重みの反映:
    """要件 1.3: 重みは最小二乗の残差最小化に効く。

    線形回帰と多項式回帰はいずれも最小二乗であり、`engines.least_squares` と同じ解を
    与えなければならない。要件 6.2 のサマリ CSV は両者を同じ ``slope`` / ``intercept``
    という名前で 1 枚に並べる。名前が同じで値が違えば、利用者にはその差の理由が読めない。

    平滑化スプラインも重みを用いるが、規約の変換を伴うため
    :class:`Test平滑化スプラインへの重みの反映` が別に扱う。移動平均だけが重みを
    持ち込む場所を持たない（設計の engines.smoothing / Integration）。
    """

    def test_線形回帰は重み付き最小二乗と同じ推定値を返す(self) -> None:
        """重みを落とすとこの突き合わせが崩れる。退行を捕らえるのはこの検証である。"""
        series = _weighted_line_series()
        regression = _values(_succeeded(series, _prepared(SmootherKind.LINEAR)))
        least_squares = _values(_builtin(series, "linear"))

        for name, value in least_squares.items():
            assert regression[name] == pytest.approx(value, rel=1e-9)

    def test_線形回帰の標準誤差も重みを反映する(self) -> None:
        """当てはめだけに重みを効かせて標準誤差を素の残差から出す実装を排除する。

        推定値が一致しても標準誤差が重み付きでなければ、どの最小二乗問題にも
        対応しない組が出力される。
        """
        series = _weighted_line_series()
        regression = _stderrs(_succeeded(series, _prepared(SmootherKind.LINEAR)))
        least_squares = _stderrs(_builtin(series, "linear"))

        for name, stderr in least_squares.items():
            assert stderr is not None
            assert regression[name] is not None
            assert regression[name] == pytest.approx(stderr, rel=1e-6)

    def test_重みを落とすと推定値が明確に変わる(self) -> None:
        """この系列では重みの有無が許容誤差では吸収されない差を生む。

        重みが効いていることを、一致の検証とは独立に確かめる。両手法が同時に重みを
        落としても一致だけは保たれるため、一致の検証だけでは重みの有無を判定できない。
        """
        series = _weighted_line_series()
        weighted = _values(_succeeded(series, _prepared(SmootherKind.LINEAR)))
        unweighted = _values(
            _succeeded(_without_weights(series), _prepared(SmootherKind.LINEAR))
        )

        assert abs(weighted["slope"] - unweighted["slope"]) > 0.1
        assert abs(weighted["intercept"] - unweighted["intercept"]) > 1.0

    def test_線形回帰の当てはめ値も重み付き最小二乗と一致する(self) -> None:
        """適合度は当てはめ値から算出されるため、ここが揃わなければ指標も揃わない。"""
        series = _weighted_line_series()
        regression = _succeeded(series, _prepared(SmootherKind.LINEAR))
        least_squares = _builtin(series, "linear")

        assert regression.y_fit == pytest.approx(least_squares.y_fit, rel=1e-9)

    def test_多項式回帰は重み付き最小二乗と同じ推定値を返す(self) -> None:
        series = _weighted_quadratic_series()
        regression = _values(_succeeded(series, _prepared(SmootherKind.POLYNOMIAL)))
        least_squares = _values(_builtin(series, "polynomial", degree=2))

        for name, value in least_squares.items():
            assert regression[name] == pytest.approx(value, rel=1e-6, abs=1e-9)

    def test_多項式回帰の標準誤差も重みを反映する(self) -> None:
        series = _weighted_quadratic_series()
        regression = _stderrs(_succeeded(series, _prepared(SmootherKind.POLYNOMIAL)))
        least_squares = _stderrs(_builtin(series, "polynomial", degree=2))

        for name, stderr in least_squares.items():
            assert stderr is not None
            assert regression[name] is not None
            assert regression[name] == pytest.approx(stderr, rel=1e-6)

    def test_多項式回帰も重みを落とすと推定値が変わる(self) -> None:
        series = _weighted_quadratic_series()
        weighted = _values(_succeeded(series, _prepared(SmootherKind.POLYNOMIAL)))
        unweighted = _values(
            _succeeded(_without_weights(series), _prepared(SmootherKind.POLYNOMIAL))
        )

        assert abs(weighted["c0"] - unweighted["c0"]) > 0.1

    def test_一様な重みは重みなしと同じ結果になる(self) -> None:
        """重みの規約が残差に掛かる乗数であることの確認（要件 1.3）。

        1 を並べた重みが結果を変えるなら、重みは乗数ではない別の量として
        解釈されている。
        """
        plain = _noisy_line_series()
        uniform = DataSeries(
            source_id=plain.source_id,
            x=plain.x,
            y=plain.y,
            weights=np.ones(len(plain), dtype=np.float64),
        )
        for kind in (SmootherKind.LINEAR, SmootherKind.POLYNOMIAL):
            without = _succeeded(plain, _prepared(kind))
            with_ones = _succeeded(uniform, _prepared(kind))
            assert [e.value for e in with_ones.parameters] == pytest.approx(
                [e.value for e in without.parameters], rel=1e-12
            )
            assert [e.stderr for e in with_ones.parameters] == pytest.approx(
                [e.stderr for e in without.parameters], rel=1e-12
            )

    def test_移動平均は重みに影響されない(self) -> None:
        """移動平均は重みを持ち込む場所を持たない。

        窓内の畳み込み係数は窓長と多項式次数だけで決まり、残差を最小化する過程が
        ない。スプラインは残差の重み付き二乗和を最小化するため対象外であり、
        :class:`Test平滑化スプラインへの重みの反映` が別に扱う。
        """
        plain = _wave_series()
        weights = 1.0 / np.linspace(0.05, 5.0, len(plain))
        weighted = DataSeries(
            source_id=plain.source_id, x=plain.x, y=plain.y, weights=weights
        )

        without = _succeeded(plain, _prepared(SmootherKind.MOVING_AVERAGE))
        with_weights = _succeeded(weighted, _prepared(SmootherKind.MOVING_AVERAGE))

        assert np.array_equal(with_weights.y_fit, without.y_fit)
        assert with_weights.parameters == ()


WEIGHTLESS_SPLINE_DIGEST = (
    "c80290ff65500d3ac20357ab5b5b8ed2ecfcb3915caf01fa48c1d054b4f3faa9"
)
"""誤差列を持たない :func:`_wave_series` に ``lam = 1e-2`` を当てはめた値の SHA-256。

重みを渡す経路を足す前の実装から採った値である。誤差列を持たない実行の結果が
1 ビットも変わらないことを、近似ではなくバイト列の一致で固定する（要件 8.2）。
"""


class Test平滑化スプラインへの重みの反映:
    """要件 1.3: 誤差列の逆数は平滑化スプラインでも点ごとの重みとして効く。

    平滑化スプラインが最小化するのは残差の**重み付き**二乗和と曲率の和であり、
    基盤ライブラリの当てはめは点ごとの重みを受け取る。したがって要件 1.3 は
    この手法でも成立しなければならない。

    確かめるのは 3 点である。(a) 重みが効く向き — 誤差の大きい点の寄与が小さくなる、
    (b) 効き方の強さ — 最小二乗と同一の統計的重み付けになる、(c) 誤差列を持たない
    実行が変わらないこと。

    (b) には注意が要る。本プロジェクトの ``weights`` は残差に掛かる ``1/σ`` であり
    （lmfit の規約、``Σ (w r)²`` を最小化）、基盤ライブラリのスプラインの ``w`` は
    残差の**二乗**に掛かる（``Σ w r² + λ∫f''²``）。同一の統計的重み付けを得るには
    ``weights ** 2`` を渡す必要がある。同じ配列をそのまま渡すと、手法によって測定誤差の
    効き方が変わり、要件 6.2 のサマリ CSV に意味の違う値が並ぶ。
    """

    def test_誤差の大きい点に引きずられず他の点に近づく(self) -> None:
        """要件 1.3 の向き: 誤差の大きい点ほど推定への寄与が小さくなること。

        重みの有無で「差が出る」だけでは足りない。差の向きまで見なければ、重みを
        逆数の取り違えで渡した実装も通ってしまう。
        """
        series, truth = _displaced_point_series()
        options = {LAM: 1e-2}
        weighted = _succeeded(series, _prepared(SmootherKind.SPLINE, options)).y_fit
        plain = _succeeded(
            _without_weights(series), _prepared(SmootherKind.SPLINE, options)
        ).y_fit

        others = [index for index in range(len(series)) if index != DISPLACED_INDEX]
        weighted_rms = float(np.sqrt(np.mean(np.square(weighted[others] - truth[others]))))
        plain_rms = float(np.sqrt(np.mean(np.square(plain[others] - truth[others]))))

        # 誤差の大きい 1 点を軽くした当てはめは、残るすべての点に近づく
        assert weighted_rms < plain_rms / 100.0, (
            f"重み付き RMS={weighted_rms:.6f} 重みなし RMS={plain_rms:.6f}"
        )
        # ずらした点そのものでも、当てはめは観測ではなく真の値の側にある
        assert abs(weighted[DISPLACED_INDEX] - truth[DISPLACED_INDEX]) < 0.05
        assert abs(plain[DISPLACED_INDEX] - truth[DISPLACED_INDEX]) > 1.0
        assert abs(weighted[DISPLACED_INDEX] - series.y[DISPLACED_INDEX]) > 5.0

    def test_平滑化を極大にすると重み付き最小二乗の直線に一致する(self) -> None:
        """要件 6.2: 同一データ・同一の重みなら、手法を跨いでも同じ量が並ぶこと。

        曲率の罰則を極大にしたスプラインは直線に退化する。その直線は重み付き最小二乗の
        解でなければならない。``smoother linear`` と ``builtin linear`` の突き合わせと
        同じ役割を、スプラインについて果たす。
        """
        series = _weighted_line_series()
        spline = _succeeded(
            series, _prepared(SmootherKind.SPLINE, {LAM: DEGENERATE_LAM})
        ).y_fit
        least_squares = _builtin(series, "linear").y_fit
        unweighted = _builtin(_without_weights(series), "linear").y_fit

        # 空振り防止: 重みの有無で参照直線が大きく離れている系列であること
        assert float(np.max(np.abs(least_squares - unweighted))) > 1.0

        assert spline == pytest.approx(least_squares, abs=1e-3)

    def test_重みは二乗前の残差に掛かる乗数として解釈される(self) -> None:
        """``weights`` をそのまま基盤ライブラリへ渡す実装を排除する。

        2 つの解釈それぞれに対応する厳密な参照直線を独立に組み立て、当てはめが
        どちらの側にあるかを見る。一致の許容誤差ではなく 2 つの参照の隔たりを尺度に
        するのは、系列を変えても判定の意味が保たれるようにするためである。
        """
        series = _weighted_line_series()
        weights = series.weights
        assert weights is not None
        spline = _succeeded(
            series, _prepared(SmootherKind.SPLINE, {LAM: DEGENERATE_LAM})
        ).y_fit

        # 本プロジェクトの規約 Σ (weights·r)² = Σ weights²·r² に対応する参照
        correct = _weighted_line_of(series.x, series.y, np.square(weights))
        # weights をそのまま基盤ライブラリの w に渡した場合に現れる別の直線
        alternative = _weighted_line_of(series.x, series.y, weights)

        separation = float(np.max(np.abs(correct - alternative)))
        assert separation > 1e-2, "2 つの解釈を判別できない系列では検証にならない"

        to_correct = float(np.max(np.abs(spline - correct)))
        to_alternative = float(np.max(np.abs(spline - alternative)))
        assert to_correct < separation / 100.0, (
            f"二乗前の残差に掛かる解釈から離れている（差 {to_correct:.3e}、"
            f"2 解釈の隔たり {separation:.3e}）"
        )
        assert to_alternative > separation / 2.0

    def test_一様な重みは重みなしと同じ当てはめ値になる(self) -> None:
        """重みが乗数であることの確認。1 を並べた重みが結果を変えてはならない。"""
        plain = _wave_series()
        uniform = DataSeries(
            source_id=plain.source_id,
            x=plain.x,
            y=plain.y,
            weights=np.ones(len(plain), dtype=np.float64),
        )
        options = {LAM: 1e-2}
        without = _succeeded(plain, _prepared(SmootherKind.SPLINE, options))
        with_ones = _succeeded(uniform, _prepared(SmootherKind.SPLINE, options))

        assert np.array_equal(with_ones.y_fit, without.y_fit)

    def test_誤差列を一様に定数倍すると滑らかさが変わる(self) -> None:
        """スプラインでは重みの**絶対倍率**が曲線を変える（要件 1.3、6.2）。

        目的関数が ``Σ w·r² + λ∫f''²`` であるため、重みの倍率は平滑化パラメータ λ と
        結び付く。相対的な重みしか意味を持たない最小二乗（``Σ (w·r)²`` を最小化し、
        w の定数倍は解を変えない）とは異なる。

        **利用者から見て意外な挙動であり、固定しておく。** 誤差列の単位を mm から m へ
        変えただけでスプラインの滑らかさが変わる。相対的な重みの比較可能性（要件 6.2）は
        別途 :meth:`test_平滑化を極大にすると重み付き最小二乗の直線に一致する` が守る。
        """
        plain = _wave_series()
        options = {LAM: 1e-2}

        def fitted(sigma: float) -> np.ndarray:
            series = DataSeries(
                source_id=plain.source_id,
                x=plain.x,
                y=plain.y,
                weights=np.full(len(plain), 1.0 / sigma, dtype=np.float64),
            )
            return _succeeded(series, _prepared(SmootherKind.SPLINE, options)).y_fit

        # σ=1 は重み 1 であり、重みなしと一致する（上の検査が固定する）。
        tighter = np.abs(fitted(0.1) - fitted(1.0)).max()
        looser = np.abs(fitted(2.0) - fitted(1.0)).max()

        assert tighter > 1e-3, f"σ を小さくしても曲線が変わらない（差 {tighter:.3e}）"
        assert looser > 1e-3, f"σ を大きくしても曲線が変わらない（差 {looser:.3e}）"

        # 対照: 最小二乗にあたる線形回帰では倍率が結果を変えない。
        def linear_fitted(sigma: float) -> np.ndarray:
            series = DataSeries(
                source_id=plain.source_id,
                x=plain.x,
                y=plain.y,
                weights=np.full(len(plain), 1.0 / sigma, dtype=np.float64),
            )
            return _succeeded(series, _prepared(SmootherKind.LINEAR, {})).y_fit

        assert np.abs(linear_fitted(0.1) - linear_fitted(1.0)).max() < 1e-12

    def test_誤差列を持たない当てはめ値は_1_ビットも変わらない(self) -> None:
        """要件 8.2: 重みを渡す経路の追加が、重みのない実行に触れていないこと。

        比較対象は重みを渡す前の実装から採ったバイト列である
        （:data:`WEIGHTLESS_SPLINE_DIGEST`）。許容誤差を置くと、既定で重みを
        1 以外の値に補うような変更を見逃す。
        """
        success = _succeeded(_wave_series(), _prepared(SmootherKind.SPLINE, {LAM: 1e-2}))
        digest = hashlib.sha256(success.y_fit.tobytes()).hexdigest()

        assert digest == WEIGHTLESS_SPLINE_DIGEST

    def test_重み付きでも同一の入力から同一の結果が得られる(self) -> None:
        """要件 8.2: 重みを与えた当てはめも呼び出しごとに揺れないこと。"""
        series, _ = _displaced_point_series()
        prepared = _prepared(SmootherKind.SPLINE, {LAM: 1e-2})
        first = _succeeded(series, prepared)
        second = _succeeded(series, prepared)

        assert np.array_equal(first.y_fit, second.y_fit)
        assert first.parameters == () == second.parameters

    def test_重みの並べ替えが当てはめに追随する(self) -> None:
        """x の昇順化で重みだけ置き去りになる実装を排除する。

        スプラインは内部で x の昇順に並べ替えてから当てはめる。重みを並べ替えずに
        渡すと、各点に他の点の重みが割り当たる。入力順を入れ替えた同じ観測が
        同じ曲線を返すことで、この取り違えを捕まえる。
        """
        series, _ = _displaced_point_series()
        order = np.array([*range(len(series))], dtype=np.int64)
        shuffled_order = np.concatenate([order[1::2], order[::2]])
        shuffled = DataSeries(
            source_id=series.source_id,
            x=series.x[shuffled_order],
            y=series.y[shuffled_order],
            weights=None if series.weights is None else series.weights[shuffled_order],
        )
        options = {LAM: 1e-2}

        ordered_fit = _succeeded(series, _prepared(SmootherKind.SPLINE, options)).y_fit
        shuffled_fit = _succeeded(shuffled, _prepared(SmootherKind.SPLINE, options)).y_fit

        assert shuffled_fit == pytest.approx(ordered_fit[shuffled_order], abs=1e-12)


class Test既定値の適用と記録:
    """要件 5.4: 手法固有の設定が未指定なら既定値を適用し、適用した値を記録する。"""

    def test_次数の未指定時に既定値が適用され記録される(self) -> None:
        success = _succeeded(_quadratic_series(), _prepared(SmootherKind.POLYNOMIAL))
        assert dict(success.applied_defaults) == {
            DEGREE: DEFAULT_POLYNOMIAL_DEGREE
        }

    def test_既定値の適用は明示指定と同じ結果になる(self) -> None:
        series = _quadratic_series()
        implicit = _succeeded(series, _prepared(SmootherKind.POLYNOMIAL))
        explicit = _succeeded(
            series,
            _prepared(SmootherKind.POLYNOMIAL, {DEGREE: DEFAULT_POLYNOMIAL_DEGREE}),
        )
        assert np.array_equal(implicit.y_fit, explicit.y_fit)

    def test_明示指定した値は記録されない(self) -> None:
        """記録するのは「利用者が書いていないのに効いた値」に限る。"""
        success = _succeeded(
            _quadratic_series(), _prepared(SmootherKind.POLYNOMIAL, {DEGREE: 3})
        )
        assert dict(success.applied_defaults) == {}

    def test_窓長の未指定時に既定値が適用され記録される(self) -> None:
        success = _succeeded(_wave_series(), _prepared(SmootherKind.MOVING_AVERAGE))
        assert dict(success.applied_defaults) == {
            WINDOW: DEFAULT_MOVING_AVERAGE_WINDOW,
            POLYORDER: DEFAULT_MOVING_AVERAGE_POLYORDER,
        }

    def test_一部だけ指定した場合は補った項目のみ記録される(self) -> None:
        success = _succeeded(
            _wave_series(), _prepared(SmootherKind.MOVING_AVERAGE, {WINDOW: 7})
        )
        assert dict(success.applied_defaults) == {
            POLYORDER: DEFAULT_MOVING_AVERAGE_POLYORDER
        }

    def test_既定値を持たない手法は何も記録しない(self) -> None:
        for kind in (SmootherKind.LINEAR, SmootherKind.SPLINE):
            success = _succeeded(_suitable_series(kind), _prepared(kind))
            assert dict(success.applied_defaults) == {}

    def test_記録は書き換えられない(self) -> None:
        success = _succeeded(_quadratic_series(), _prepared(SmootherKind.POLYNOMIAL))
        with pytest.raises(TypeError):
            success.applied_defaults[POLYNOMIAL_DEGREE_OPTION] = 5  # type: ignore[index]

    def test_解決層は既定値を補わない(self) -> None:
        """既定値の所有者は本エンジンのみである（設計の Implementation Notes）。"""
        prepared = resolve(
            MethodSpec(name="poly", kind="smoother", smoother=SmootherKind.POLYNOMIAL), None
        )
        assert isinstance(prepared, PreparedSmoother)
        assert dict(prepared.options) == {}

        success = _succeeded(_quadratic_series(), prepared)
        assert dict(success.applied_defaults) == {
            DEGREE: DEFAULT_POLYNOMIAL_DEGREE
        }


class Test既定値の定数:
    """設計の Implementation Notes: 実行前ゲートは本モジュールの定数を参照する。"""

    def test_既定値は素の整数である(self) -> None:
        """実行前ゲートは基盤ライブラリの値を扱えない。"""
        for defaults in SMOOTHER_OPTION_DEFAULTS.values():
            for value in defaults.values():
                assert type(value) is int

    def test_既定値は選択肢名の一部である(self) -> None:
        for kind, defaults in SMOOTHER_OPTION_DEFAULTS.items():
            assert set(defaults) <= set(SMOOTHER_OPTION_NAMES[kind])

    def test_移動平均の既定値は制約を満たす(self) -> None:
        """窓長は奇数かつ多項式次数より大きい（research.md の savgol_filter の制約）。"""
        assert DEFAULT_MOVING_AVERAGE_WINDOW % 2 == 1
        assert DEFAULT_MOVING_AVERAGE_WINDOW > DEFAULT_MOVING_AVERAGE_POLYORDER
        assert DEFAULT_MOVING_AVERAGE_POLYORDER >= 0

    def test_既定次数は当てはめ可能な値である(self) -> None:
        assert DEFAULT_POLYNOMIAL_DEGREE >= 1

    def test_選択肢名は手法ごとに確定している(self) -> None:
        assert SMOOTHER_OPTION_NAMES[SmootherKind.LINEAR] == ()
        assert SMOOTHER_OPTION_NAMES[SmootherKind.POLYNOMIAL] == (POLYNOMIAL_DEGREE_OPTION,)
        assert SMOOTHER_OPTION_NAMES[SmootherKind.SPLINE] == (SPLINE_LAMBDA_OPTION,)
        assert set(SMOOTHER_OPTION_NAMES[SmootherKind.MOVING_AVERAGE]) == {
            MOVING_AVERAGE_WINDOW_OPTION,
            MOVING_AVERAGE_POLYORDER_OPTION,
        }

    def test_定数は書き換えられない(self) -> None:
        with pytest.raises(TypeError):
            SMOOTHER_OPTION_DEFAULTS[SmootherKind.LINEAR] = {}  # type: ignore[index]


class Test点数と_x_の並びの境界:
    """当てはめが成立しない入力は、例外ではなく失敗として値で返す。"""

    def test_点数が次数に満たなければ失敗を返す(self) -> None:
        series = _series(_array([0.0, 1.0, 2.0]), _array([0.0, 1.0, 4.0]))
        failure = _failed(series, _prepared(SmootherKind.POLYNOMIAL, {DEGREE: 5}))
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS
        assert failure.message

    def test_点数がちょうど次数_プラス_1_なら成功する(self) -> None:
        series = _series(_array([0.0, 1.0, 2.0]), _array([0.0, 1.0, 4.0]))
        success = _succeeded(series, _prepared(SmootherKind.POLYNOMIAL))
        assert success.y_fit == pytest.approx(series.y, abs=1e-9)

    def test_x_が重複して自由度を失う指定は失敗を返す(self) -> None:
        """点数が足りていても、異なる x が次数に満たなければ係数は定まらない。"""
        series = _series(_array([1.0, 1.0, 1.0, 2.0]), _array([1.0, 1.1, 0.9, 2.0]))
        failure = _failed(series, _prepared(SmootherKind.POLYNOMIAL, {DEGREE: 3}))
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS

    def test_スプラインは点数が下限に満たなければ失敗を返す(self) -> None:
        n = MIN_SPLINE_POINTS - 1
        x = np.linspace(0.0, 1.0, n)
        failure = _failed(_series(x, x * 2.0), _prepared(SmootherKind.SPLINE))
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS
        assert str(MIN_SPLINE_POINTS) in failure.message

    def test_スプラインは下限ちょうどの点数なら成功する(self) -> None:
        x = np.linspace(0.0, 1.0, MIN_SPLINE_POINTS)
        success = _succeeded(_series(x, x * 2.0), _prepared(SmootherKind.SPLINE))
        assert len(success.y_fit) == MIN_SPLINE_POINTS

    def test_スプラインは_x_の重複を失敗として返す(self) -> None:
        """平滑化スプラインは狭義単調増加の x を要求する。

        報告は基盤ライブラリの例外の転記ではいけない。並べ替えは本エンジンが済ませて
        いるため、「x が昇順でない」という基盤ライブラリの言い分は利用者にとって
        原因を指していない。重複であることと、次に取るべき手が分かる説明を返す。
        """
        x = _array([0.0, 1.0, 1.0, 2.0, 3.0, 4.0])
        failure = _failed(_series(x, x * 2.0), _prepared(SmootherKind.SPLINE))
        assert failure.reason is FailureReason.NOT_CONVERGED
        assert "重複" in failure.message
        assert "ValueError" not in failure.message

    def test_移動平均は窓長より短い系列を失敗として返す(self) -> None:
        x = np.linspace(0.0, 2.0, 3)
        failure = _failed(_series(x, x), _prepared(SmootherKind.MOVING_AVERAGE))
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS
        assert str(DEFAULT_MOVING_AVERAGE_WINDOW) in failure.message

    def test_移動平均は窓長ちょうどの系列で成功する(self) -> None:
        x = np.linspace(0.0, 4.0, DEFAULT_MOVING_AVERAGE_WINDOW)
        success = _succeeded(_series(x, x), _prepared(SmootherKind.MOVING_AVERAGE))
        assert len(success.y_fit) == DEFAULT_MOVING_AVERAGE_WINDOW

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_空の系列でも例外を送出しない(self, kind: SmootherKind) -> None:
        empty = _series(_array([]), _array([]))
        failure = _failed(empty, _prepared(kind))
        assert failure.message

    def test_失敗には初期値が伴わない(self) -> None:
        """回帰・平滑化は反復の出発点を持たない（要件 4.7 は最小二乗の要件）。"""
        x = np.linspace(0.0, 2.0, 3)
        failure = _failed(_series(x, x), _prepared(SmootherKind.MOVING_AVERAGE))
        assert dict(failure.initial_values) == {}


class Test_x_の並びに依存しない当てはめ:
    """入力の並び順は当てはめの意味を変えない。当てはめ値は入力の並びで返す。"""

    def _shuffled(self, series: DataSeries) -> DataSeries:
        order = _array([3.0, 0.0, 4.0, 1.0, 5.0, 2.0]).astype(int)
        return _series(series.x[order], series.y[order], series.source_id)

    def _sorted_source(self) -> DataSeries:
        x = np.linspace(0.0, 5.0, 6)
        return _series(x, TRUE_SLOPE * x + TRUE_INTERCEPT)

    def test_線形回帰は並び順に依らない(self) -> None:
        ordered = self._sorted_source()
        shuffled = self._shuffled(ordered)
        assert _values(_succeeded(shuffled, _prepared(SmootherKind.LINEAR)))[
            "slope"
        ] == pytest.approx(_values(_succeeded(ordered, _prepared(SmootherKind.LINEAR)))["slope"])

    def test_スプラインは並び替えた入力でも当てはめ値を入力順で返す(self) -> None:
        ordered = self._sorted_source()
        shuffled = self._shuffled(ordered)
        ordered_fit = _succeeded(ordered, _prepared(SmootherKind.SPLINE)).y_fit
        shuffled_fit = _succeeded(shuffled, _prepared(SmootherKind.SPLINE)).y_fit

        order = _array([3.0, 0.0, 4.0, 1.0, 5.0, 2.0]).astype(int)
        assert shuffled_fit == pytest.approx(ordered_fit[order])

    def test_移動平均は_x_の昇順で平均を取る(self) -> None:
        ordered = self._sorted_source()
        shuffled = self._shuffled(ordered)
        prepared = _prepared(SmootherKind.MOVING_AVERAGE)
        ordered_fit = _succeeded(ordered, prepared).y_fit
        shuffled_fit = _succeeded(shuffled, prepared).y_fit

        order = _array([3.0, 0.0, 4.0, 1.0, 5.0, 2.0]).astype(int)
        assert shuffled_fit == pytest.approx(ordered_fit[order])


class Test非有限な当てはめ値:
    """設計の Validation: 非有限な当てはめ値はエンジンが失敗として返す。

    適合度の算出は非有限な値をそのまま通すため、ここで止めなければ NaN や無限大が
    サマリ CSV に流入する。前処理が非有限な点を除去するため実運用では到達しないが、
    仕様が要求する分岐であるため直接の入力で検証する。
    """

    def _diverging_series(self) -> DataSeries:
        x = np.linspace(0.0, 5.0, 6)
        y = _array([0.0, 1.0, float("inf"), 3.0, 4.0, 5.0])
        return _series(x, y)

    def test_推定値が非有限なら失敗を返す(self) -> None:
        failure = _failed(self._diverging_series(), _prepared(SmootherKind.LINEAR))
        assert failure.reason is FailureReason.NOT_CONVERGED
        assert failure.message

    def test_当てはめ値が有限でも推定値が非有限なら失敗を返す(self) -> None:
        """当てはめ値の検査だけでは、係数の桁溢れを止められない。

        当てはめは独立変数を ``[-1, 1]`` に写して行うため、原点から遠い x に大きな y が
        並ぶと、当てはめ値は有限のまま標準基底の係数だけが桁溢れする。この値を
        サマリ CSV に出すと、当てはまり自体は成立しているのに推定値の列が無限大になる。

        基盤ライブラリはこの過程で :class:`RuntimeWarning` を送出する。エンジンは警告を
        抑止しないため、テスト側で表示のみを抑える。
        """
        x = 1000.0 + np.linspace(0.0, 10.0, 11)
        y = 1e300 * _array([0.0, 1.0, 0.5, 1.5, 0.2, 1.2, 0.8, 1.8, 0.4, 1.4, 0.6])
        series = _series(x, y)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            failure = _failed(series, _prepared(SmootherKind.POLYNOMIAL, {DEGREE: 4}))

        assert failure.reason is FailureReason.NOT_CONVERGED
        assert "c0" in failure.message

    def test_パラメータを持たない手法でも非有限な当てはめ値は失敗になる(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """推定値の検査だけでは、パラメータを持たない手法の発散を止められない。

        基盤ライブラリは非有限な入力を先に拒否するため、非有限な当てはめ値を実データで
        作ることはできない。差し替えなければこの分岐が未検証のまま残る。
        """
        series = _wave_series()

        def _diverging(y: FloatArray, window: int, polyorder: int) -> FloatArray:
            broken = np.array(y, dtype=np.float64)
            broken[0] = np.inf
            return broken

        monkeypatch.setattr(smoothing, "savgol_filter", _diverging)
        failure = _failed(series, _prepared(SmootherKind.MOVING_AVERAGE))

        assert failure.reason is FailureReason.NOT_CONVERGED
        assert failure.message

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_非有限な入力でも例外を漏らさない(self, kind: SmootherKind) -> None:
        failure = _failed(self._diverging_series(), _prepared(kind))
        assert failure.message


class Test入力の不変性と再現性:
    """設計: エンジンは純粋計算であり、入力を書き換えない（要件 8.2）。"""

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_入力系列を書き換えない(self, kind: SmootherKind) -> None:
        series = _suitable_series(kind)
        x, y = series.x.copy(), series.y.copy()

        _succeeded(series, _prepared(kind))

        assert np.array_equal(series.x, x)
        assert np.array_equal(series.y, y)

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_解決済み手法の選択肢を書き換えない(self, kind: SmootherKind) -> None:
        prepared = _prepared(kind)
        before = dict(prepared.options)

        _succeeded(_suitable_series(kind), prepared)

        assert dict(prepared.options) == before

    @pytest.mark.parametrize("kind", list(SmootherKind), ids=lambda k: k.value)
    def test_同一の入力からは同一の結果が得られる(self, kind: SmootherKind) -> None:
        series = _suitable_series(kind)
        first = _succeeded(series, _prepared(kind))
        second = _succeeded(series, _prepared(kind))

        assert [e.value for e in first.parameters] == [e.value for e in second.parameters]
        assert np.array_equal(first.y_fit, second.y_fit)
        assert dict(first.applied_defaults) == dict(second.applied_defaults)

    def test_揺れる系列でもスプラインは完全に一致する(self) -> None:
        """要件 5.5、8.2: 平滑化パラメータを与えた当てはめは直接解法であり、揺れない。

        用いるのは、平滑化パラメータを指定しない当てはめが実測で 2 つの状態に倒れた
        系列である（:func:`_gcv_drifter_series`）。近似ではなく完全一致で見るのは、
        サマリ CSV の丸めが揺れを吸収しきれないことが実測で分かっているためであり、
        許容誤差を置くと元の欠陥をそのまま通してしまう。
        """
        series = _gcv_drifter_series()
        prepared = _prepared(SmootherKind.SPLINE, {LAM: 1e-2})
        first = _succeeded(series, prepared)
        second = _succeeded(series, prepared)

        assert np.array_equal(first.y_fit, second.y_fit)


class Test平滑化パラメータの必須性:
    """要件 5.5: 平滑化パラメータを指定しないスプラインは当てはめを行わない。

    通常の経路では実行前ゲートが先に拒否する。ここで見るのは、ゲートを経ずに
    エンジンへ直接届いた場合でも GCV 探索へ落ちないことである。基盤ライブラリの
    自動選択は呼び出しごとに 2 つの状態のいずれかに倒れ、要件 8.2 が成立しない。
    """

    def _bare(self) -> PreparedSmoother:
        """平滑化パラメータを持たない解決済み手法（``_prepared`` の補完を経ない）。"""
        return PreparedSmoother(
            display_name="spline", kind=SmootherKind.SPLINE, options={}
        )

    def test_未指定なら当てはめずに失敗を返す(self) -> None:
        failure = _failed(_gcv_drifter_series(), self._bare())

        assert SPLINE_LAMBDA_OPTION in failure.message
        assert "必須" in failure.message

    def test_未指定でも例外を漏らさない(self) -> None:
        """1 件の不備でバッチ全体を止めない（要件 6.4）。"""
        assert isinstance(_outcome(_wave_series(), self._bare()), EngineFailure)

    def test_自動選択の呼び出しが残っていない(self) -> None:
        """``lam=None`` で基盤ライブラリを呼ぶ経路が消えていること。

        文字列ではなく構文木で見る。docstring の言及に反応する検査では、経路が
        残ったままでも通ってしまう。
        """
        tree = ast.parse((SRC / "engines" / "smoothing.py").read_text(encoding="utf-8"))
        calls = [
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "make_smoothing_spline"
        ]
        assert calls, "平滑化スプラインの呼び出しが見つからない"
        for call in calls:
            for keyword in call.keywords:
                if keyword.arg == SPLINE_LAMBDA_OPTION:
                    assert not (
                        isinstance(keyword.value, ast.Constant)
                        and keyword.value.value is None
                    )
                    assert "None" not in ast.unparse(keyword.value)


class Test契約外の呼び出し:
    def test_モデル関数フィットを渡すと例外を送出する(self) -> None:
        """手法から実装への振り分けは本モジュールの責務ではない。"""
        series = _line_series()
        prepared = resolve(MethodSpec(name="linear", kind="builtin", builtin="linear"), series)
        with pytest.raises(TypeError):
            SmoothingEngine().fit(series, prepared)  # type: ignore[arg-type]


def _module_tree() -> ast.Module:
    return ast.parse((SRC / "engines" / "smoothing.py").read_text(encoding="utf-8"))


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。"""
    names: set[str] = set()
    for node in ast.walk(_module_tree()):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


def _imported_names() -> set[str]:
    names: set[str] = set()
    for node in ast.walk(_module_tree()):
        if isinstance(node, ast.ImportFrom):
            names.update(alias.name for alias in node.names)
    return names


class Test依存の露出:
    def test_公開署名に基盤ライブラリの型が現れない(self) -> None:
        rendered = str(inspect.signature(SmoothingEngine.fit))
        for library in ("scipy", "BSpline", "Polynomial", "ndarray", "DataFrame"):
            assert library not in rendered

    def test_自パッケージでは左側の層だけに依存する(self) -> None:
        allowed = {
            "curvefit.types",
            "curvefit.errors",
            "curvefit.engines.base",
            "curvefit.models.resolver",
        }
        own = {m for m in _imported_modules() if m.split(".")[0] == "curvefit"}
        assert own <= allowed, f"想定外の依存: {own - allowed}"

    def test_入出力を行わない(self) -> None:
        forbidden = {"pathlib", "os", "sys", "logging", "io", "open", "subprocess"}
        for imported in _imported_modules():
            assert imported.split(".")[0] not in forbidden, (
                f"engines/smoothing.py が入出力に関わる {imported} を import している"
            )

    def test_手法の列挙は解決層のものを用いる(self) -> None:
        """依存方向は models → engines であり、列挙を engines 側に複製しない。"""
        from curvefit.engines import smoothing

        assert smoothing.SmootherKind is resolver.SmootherKind

    def test_平滑化スプラインに非推奨の旧_API_を使わない(self) -> None:
        """`UnivariateSpline` は legacy であり、新規コードでは使用しない。"""
        assert "make_smoothing_spline" in _imported_names()
        assert not any("UnivariateSpline" in name for name in _imported_names())

class Testパラメータを返すかの宣言:
    """`SMOOTHER_EMITS_PARAMETERS` が実際の当てはめ結果と一致すること（要件 5.3）。

    この宣言は実行前ゲートが利用者への説明を選ぶために読む。実物とずれると、
    パラメータを返す手法に「持たない」と言い、返さない手法に「結果として得られる」と
    言うことになる。どちらも利用者を存在しない出力の捜索に向かわせる。
    """

    @pytest.mark.parametrize("kind", list(SmootherKind))
    def test_宣言は実際に返すパラメータの有無と一致する(self, kind: SmootherKind) -> None:
        """4 手法すべてを実際に当てはめ、宣言と突き合わせる。"""
        x = np.linspace(0.0, 10.0, 21)
        y = 2.0 * x + 1.0 + np.sin(x) * 0.1
        series = _series(x, y, "declared.csv")
        options = _minimal_options(kind)
        prepared = PreparedSmoother(
            display_name=kind.value, kind=kind, options=options
        )
        outcome = SmoothingEngine().fit(series, prepared)

        assert isinstance(outcome, EngineSuccess), outcome
        emits = bool(outcome.parameters)
        assert emits == SMOOTHER_EMITS_PARAMETERS[kind], (
            f"{kind.value} は宣言と食い違う。"
            f"実際に返したパラメータ: {[p.name for p in outcome.parameters]}、"
            f"宣言: {SMOOTHER_EMITS_PARAMETERS[kind]}"
        )

    def test_全手法について宣言がある(self) -> None:
        """手法が増えたときに宣言の追加を忘れないこと。"""
        assert set(SMOOTHER_EMITS_PARAMETERS) == set(SmootherKind)


MIN_WEIGHT_EFFECT = 1.0
"""重みが効いていると言うために必要な当てはめ値の最小の変化量。

:func:`_weighted_line_series` は σ が点ごとに 100 倍異なる配置であり、重みを用いる
手法では実測で 1.7〜2.3 の差が出る（重みを用いない手法では厳密に 0）。この隔たりが
あるため、判定は浮動小数の丸めに左右されない。
"""


class Test重みを扱うかの宣言:
    """`SMOOTHER_USES_WEIGHTS` が実際の当てはめの挙動と一致すること（要件 1.3、1.10）。

    この宣言は実行前ゲートが読み、誤差列と組み合わせられない手法を拒否する（要件 1.10）。
    実物とずれると 2 方向に壊れる。重みを扱える手法を「扱えない」と宣言すれば、
    正しい設定が実行前に拒否される。扱えない手法を「扱える」と宣言すれば、測定誤差が
    反映されない結果を利用者が重み付きの結果として読む。要件 1.10 が塞ごうとしている
    のは後者そのものである。

    宣言が空約束にならないよう、**4 手法すべてを重みあり・重みなしの双方で実際に
    当てはめ**、結果が変わるかどうかを宣言が言い当てることを確かめる。
    """

    @pytest.mark.parametrize("kind", list(SmootherKind))
    def test_宣言は重みが当てはめを変えるかと一致する(self, kind: SmootherKind) -> None:
        """同じ観測に重みを付けた場合と付けない場合を突き合わせる。"""
        weighted_series = _weighted_line_series()
        prepared = PreparedSmoother(
            display_name=kind.value, kind=kind, options=_minimal_options(kind)
        )
        with_weights = SmoothingEngine().fit(weighted_series, prepared)
        without_weights = SmoothingEngine().fit(
            _without_weights(weighted_series), prepared
        )

        assert isinstance(with_weights, EngineSuccess), with_weights
        assert isinstance(without_weights, EngineSuccess), without_weights
        difference = float(np.max(np.abs(with_weights.y_fit - without_weights.y_fit)))
        uses_weights = difference > 0.0
        assert uses_weights == SMOOTHER_USES_WEIGHTS[kind], (
            f"{kind.value} は宣言と食い違う。"
            f"重みの有無による当てはめ値の最大差: {difference!r}、"
            f"宣言: {SMOOTHER_USES_WEIGHTS[kind]}"
        )
        if uses_weights:
            # 「変わった」が丸め誤差ではないことを示す。σ が 100 倍異なる配置に
            # 対して、重みが本当に効いていればこの水準の差になる。
            assert difference > MIN_WEIGHT_EFFECT

    def test_重みを扱わない手法は重みを与えても厳密に同じ値を返す(self) -> None:
        """宣言が偽である側を、近似ではなくビット一致で固定する。

        移動平均の畳み込み係数は窓長と多項式次数だけで決まる。重みを受け取る場所が
        できれば、この一致は真っ先に崩れる。
        """
        weightless = [kind for kind in SmootherKind if not SMOOTHER_USES_WEIGHTS[kind]]
        assert weightless, "重みを扱わない手法が 1 つも無ければ要件 1.10 の拒否は不要になる"
        for kind in weightless:
            series = _weighted_line_series()
            prepared = PreparedSmoother(
                display_name=kind.value, kind=kind, options=_minimal_options(kind)
            )
            with_weights = _succeeded(series, prepared)
            without_weights = _succeeded(_without_weights(series), prepared)
            assert np.array_equal(with_weights.y_fit, without_weights.y_fit), kind.value

    def test_全手法について宣言がある(self) -> None:
        """手法が増えたときに宣言の追加を忘れないこと。"""
        assert set(SMOOTHER_USES_WEIGHTS) == set(SmootherKind)


def _minimal_options(kind: SmootherKind) -> dict[str, float | int]:
    """その手法を実行できる最小限の選択肢。必須のものだけを与える。"""
    if kind is SmootherKind.SPLINE:
        return {SPLINE_LAMBDA_OPTION: 0.01}
    return {}

