"""解決済み手法から当てはめエンジンへの振り分けを検証する。

対応要件: 5.2（回帰・スムージングをモデル関数フィットと同一の手順で実行する）。

設計の engines ブロックの Service Interface が定める
``select_engine(method: PreparedMethod) -> FitEngine``、File Structure Plan
（振り分けは ``engines/__init__.py`` が所有する）、および Architecture の依存方向を
対象とする。

振り分けの確認を「返ってきた実体の型名」で済ませない。型が合っていても、その実体が
当該手法を当てはめられなければ要件 5.2 は成立しないため、実際に当てはめて
:class:`~curvefit.engines.base.EngineSuccess` が返ることまで見る。

**実行時可変状態を持たないこと**を明示的に検証する。振り分けを登録簿で行うと、同一
設定・同一データでも import の状態によって別のエンジンが選ばれうる。要件 8.2 の
再現性は「同じ入力に同じ出力」であり、実行時に差し替え可能な対応表はこれを直接
損なう。したがって本テストは、公開された登録手段が存在しないこと、モジュールに
書き換え可能な状態がないこと、import の順序を変えても振り分けが変わらないことを
検証対象に含める。
"""

from __future__ import annotations

import ast
import inspect
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pytest

import curvefit.engines as engines
from curvefit.engines import select_engine
from curvefit.engines.base import EngineSuccess, FitEngine
from curvefit.engines.least_squares import LeastSquaresEngine
from curvefit.engines.smoothing import SmoothingEngine
from curvefit.models.resolver import (
    MethodSpec,
    PreparedMethod,
    PreparedModel,
    PreparedSmoother,
    SmootherKind,
    resolve,
)
from curvefit.types import DataSeries

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

N_POINTS = 9
"""検証に用いる点数。

平滑化スプラインの最小点数（5）と移動平均の既定窓長（5）をいずれも満たし、既定次数 2 の
多項式回帰に足りる異なる x を持つ。4 手法すべてを同一の系列で通せることが、要件 5.2 の
「同一の手順」を 1 つのループで示すための前提になる。
"""


def _series() -> DataSeries:
    """4 手法とモデル関数フィットのいずれも当てはめられる系列。"""
    x = np.linspace(0.0, 8.0, N_POINTS)
    return DataSeries(source_id="dispatch.csv", x=x, y=2.5 * x - 1.5)


def _prepared_model() -> PreparedModel:
    prepared = resolve(MethodSpec(name="linear", kind="builtin", builtin="linear"), _series())
    assert isinstance(prepared, PreparedModel), f"解決に失敗した: {prepared}"
    return prepared


def _prepared_smoother(kind: SmootherKind) -> PreparedSmoother:
    """解決済みの平滑化手法。

    スプラインには平滑化パラメータを与える。要件 5.5 により必須であり、実行前ゲートを
    通った設定だけがエンジンに届く。振り分けの検証はその前提の上で行う。
    """
    options = {"lam": 1e-2} if kind is SmootherKind.SPLINE else {}
    prepared = resolve(
        MethodSpec(name=kind.value, kind="smoother", smoother=kind, options=options), None
    )
    assert isinstance(prepared, PreparedSmoother), f"解決に失敗した: {prepared}"
    return prepared


@dataclass(frozen=True)
class _ForeignMethod:
    """解決済み手法のいずれでもない型。呼び出し側の誤りを表す。"""

    display_name: str = "foreign"


class Test振り分け:
    """要件 5.2: 解決済み手法の型から、それを当てはめられるエンジンが得られる。"""

    def test_解決済みモデルは当てはめられるエンジンに振り分けられる(self) -> None:
        """型名ではなく、実際に当てはめが成立することで確かめる。"""
        method = _prepared_model()
        series = _series()

        outcome = select_engine(method).fit(series, method)

        assert isinstance(outcome, EngineSuccess), f"当てはめに失敗した: {outcome}"
        assert {estimate.name for estimate in outcome.parameters} == {"slope", "intercept"}
        assert len(outcome.y_fit) == len(series)

    def test_解決済みモデルには最小二乗エンジンが対応する(self) -> None:
        assert isinstance(select_engine(_prepared_model()), LeastSquaresEngine)

    @pytest.mark.parametrize("kind", list(SmootherKind))
    def test_解決済み平滑化手法は当てはめられるエンジンに振り分けられる(
        self, kind: SmootherKind
    ) -> None:
        """4 手法すべてを対象にする。1 手法でも別の実体に向くと要件 5.1 が欠ける。"""
        method = _prepared_smoother(kind)
        series = _series()

        outcome = select_engine(method).fit(series, method)

        assert isinstance(outcome, EngineSuccess), f"{kind} の当てはめに失敗した: {outcome}"
        assert len(outcome.y_fit) == len(series)

    @pytest.mark.parametrize("kind", list(SmootherKind))
    def test_解決済み平滑化手法には平滑化エンジンが対応する(self, kind: SmootherKind) -> None:
        assert isinstance(select_engine(_prepared_smoother(kind)), SmoothingEngine)

    @pytest.mark.parametrize("kind", list(SmootherKind))
    def test_返されたエンジンは当てはめ契約を満たす(self, kind: SmootherKind) -> None:
        """設計の Service Interface: 戻り値は :class:`FitEngine` である。"""
        for method in (_prepared_model(), _prepared_smoother(kind)):
            assert isinstance(select_engine(method), FitEngine)

    def test_署名は解決済み手法だけを受け取る(self) -> None:
        assert tuple(inspect.signature(select_engine).parameters) == ("method",)


class Test対応するエンジンがない手法:
    """振り分けられない型は呼び出し側の誤りであり、値ではなく例外で知らせる。

    利用者由来のデータや設定に起因する失敗ではないため、
    :class:`~curvefit.engines.base.EngineFailure` として集約すると、プログラムの誤りが
    バッチのスキップ件数に紛れる。両エンジンが誤った解決済み型に
    :class:`TypeError` を送出するのと同じ扱いに揃える。
    """

    def test_解決済み手法でない型は例外になる(self) -> None:
        with pytest.raises(TypeError) as error:
            select_engine(_ForeignMethod())  # type: ignore[arg-type]

        assert "_ForeignMethod" in str(error.value), (
            f"例外の文言に該当の型名が現れない: {error.value}"
        )

    def test_未解決を表す値も例外になる(self) -> None:
        with pytest.raises(TypeError) as error:
            select_engine(None)  # type: ignore[arg-type]

        assert "NoneType" in str(error.value)

    def test_解決前の指定は例外になる(self) -> None:
        """:class:`MethodSpec` は解決前の表現であり、エンジンを選べない。"""
        spec = MethodSpec(name="linear", kind="builtin", builtin="linear")
        with pytest.raises(TypeError) as error:
            select_engine(spec)  # type: ignore[arg-type]

        assert "MethodSpec" in str(error.value)


class Test実行時可変状態を持たない:
    """要件 8.2: 同じ設定・同じデータなら、いつ呼んでも同じエンジンが選ばれる。"""

    def test_繰り返し呼んでも同じエンジンが選ばれる(self) -> None:
        methods: tuple[PreparedMethod, ...] = (
            _prepared_model(),
            *(_prepared_smoother(kind) for kind in SmootherKind),
        )
        for method in methods:
            selected = [type(select_engine(method)) for _ in range(3)]
            assert len(set(selected)) == 1, f"{method.display_name} の振り分けが揺れた"

    def test_返されるエンジンは呼び出しごとに独立した実体である(self) -> None:
        """共有実体を返さない。

        両エンジンは属性を持たない凍結データクラスであり、共有しても計算結果は変わらない。
        それでも実体を使い回さないのは、モジュールに保持した実体が呼び出し側から到達可能な
        書き換え対象になるためである。呼び出しごとに作れば、ある呼び出し側が受け取った
        実体に何をしても他の呼び出しに波及しない。生成費用は属性のない実体 1 個であり、
        当てはめ 1 回の計算量に対して無視できる。
        """
        method = _prepared_model()

        first, second = select_engine(method), select_engine(method)

        assert first is not second
        assert first == second

    def test_登録簿を差し替える公開手段を持たない(self) -> None:
        """登録簿があると、import の状態次第で同一設定が別の結果を生む。"""
        for module in (engines, engines.base):
            offending = [
                name
                for name in dir(module)
                if "register" in name.lower() or "registry" in name.lower()
            ]
            assert not offending, f"{module.__name__} に登録手段がある: {offending}"

    def test_振り分けは書き換え可能なモジュール状態を持たない(self) -> None:
        """``__all__`` 以外のモジュール変数を置かない。

        対応表をモジュール変数に持たせると、実行中に書き換えられる。構文木で判定するのは、
        docstring の文言では実際の代入を検出できないためである。
        """
        tree = ast.parse((SRC / "engines" / "__init__.py").read_text(encoding="utf-8"))
        assigned: list[str] = []
        for node in tree.body:
            # 注釈付き代入（``_DISPATCH: dict = {}``）も対象に含める。ast.Assign だけを
            # 見ていると、注釈を付けるだけで検査をすり抜ける登録簿を書けてしまう。
            if isinstance(node, ast.Assign):
                assigned += [t.id for t in node.targets if isinstance(t, ast.Name)]
            elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                assigned.append(node.target.id)
        assert assigned == ["__all__"], f"想定外のモジュール変数: {assigned}"
        assert not [node for node in ast.walk(tree) if isinstance(node, ast.Global)]

    @pytest.mark.parametrize(
        "order",
        [
            ("curvefit.engines", "curvefit.engines.smoothing"),
            ("curvefit.engines.smoothing", "curvefit.engines.least_squares"),
            ("curvefit.engines.least_squares", "curvefit.engines"),
        ],
    )
    def test_import_の順序によらず同じ振り分けになる(self, order: tuple[str, ...]) -> None:
        """別プロセスで import 順を変えて確かめる。

        同一プロセス内では最初の import が済んだ状態が残るため、順序の影響は
        新しいプロセスでしか観測できない。
        """
        script = (
            "import importlib\n"
            f"for name in {order!r}:\n"
            "    importlib.import_module(name)\n"
            "from curvefit.engines import select_engine\n"
            "from curvefit.models.resolver import MethodSpec, resolve\n"
            "model = resolve(MethodSpec(name='m', kind='builtin', builtin='linear'), None)\n"
            "smoother = resolve("
            "MethodSpec(name='s', kind='smoother', smoother='linear'), None)\n"
            "print(type(select_engine(model)).__name__)\n"
            "print(type(select_engine(smoother)).__name__)\n"
        )

        result = subprocess.run(
            [sys.executable, "-c", script], capture_output=True, text=True, check=True
        )

        assert result.stdout.split() == ["LeastSquaresEngine", "SmoothingEngine"]

    def test_公開名として宣言されている(self) -> None:
        assert "select_engine" in engines.__all__
        assert engines.select_engine is select_engine


class Test同一の手順:
    """要件 5.2: 回帰・スムージングをモデル関数フィットと同一の手順で実行する。"""

    def test_モデルと平滑化を同一の呼び出し列で当てはめられる(self) -> None:
        """1 つのループで両方を当てはめる。

        呼び出し側が手法の種類で分岐しないことが要件 5.2 の内容である。分岐が必要なら、
        この 1 本のループは書けない。
        """
        series = _series()
        methods: tuple[PreparedMethod, ...] = (
            _prepared_model(),
            *(_prepared_smoother(kind) for kind in SmootherKind),
        )

        outcomes = [select_engine(method).fit(series, method) for method in methods]

        assert len(outcomes) == 1 + len(SmootherKind)
        for method, outcome in zip(methods, outcomes, strict=True):
            assert isinstance(outcome, EngineSuccess), (
                f"{method.display_name} の当てはめに失敗した: {outcome}"
            )
            assert len(outcome.y_fit) == len(series)


class Test依存の向き:
    def test_振り分けは具体エンジンを静的に_import_する(self) -> None:
        """設計の File Structure Plan: 振り分けは ``engines/__init__.py`` が所有する。

        実行時に解決するのではなく、モジュールの先頭で import することが、振り分け先が
        import の状態で変わらないことの根拠になる。
        """
        tree = ast.parse((SRC / "engines" / "__init__.py").read_text(encoding="utf-8"))
        imported = {
            node.module
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module and node.level == 0
        }

        assert {"curvefit.engines.least_squares", "curvefit.engines.smoothing"} <= imported
        assert not [node for node in ast.walk(tree) if isinstance(node, ast.Import)], (
            "遅延 import や別名 import を用いず、from ... import で静的に取り込む"
        )

    def test_下流の層に依存しない(self) -> None:
        """設計の依存方向: engines は types / errors / models までしか参照しない。"""
        tree = ast.parse((SRC / "engines" / "__init__.py").read_text(encoding="utf-8"))
        own = {
            node.module
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.startswith("curvefit")
        }
        allowed = {
            "curvefit.types",
            "curvefit.errors",
            "curvefit.models.resolver",
            "curvefit.engines.base",
            "curvefit.engines.least_squares",
            "curvefit.engines.smoothing",
        }
        assert own <= allowed, f"想定外の依存: {own - allowed}"
