"""出力物の形式・命名規則・出力先検証を検証する。

対応要件: 7.3（全対象を 1 つのサマリ表として CSV 出力）、7.5（曲線・残差 CSV の
オプトイン出力）、7.6（出力名の一意性）、7.7（出力先が書けない場合の中止）、
3.5（パラメータ名を結果の識別子として使用）。

設計の writers / plotting ブロックが定める Responsibilities & Constraints
（サマリ CSV は **1 行 = (source_id, method_name, parameter_name) の long 形式**、
適合度指標は行内で繰り返す、出力名の一意性を所有する）、Batch / Job Contract
（`{output_dir}/summary.csv`、`{output_dir}/curves/{stem}.csv`、`stem` はジョブから
決定的に導出される）、サマリ CSV の列表、Implementation Notes（サマリの数値は有効数字
10 桁、曲線・残差 CSV は全精度、`build_output_stem` はパス区切りと親ディレクトリ参照を
除去する）、Error Handling（実行前違反は `ConfigViolation` として値で運ぶ）、および
Security Considerations（出力が指定ディレクトリ外に書き出されない）を対象とする。

long 形式であることは、行数を数えるだけでは確かめられない。**パラメータ数と名前の
異なる 2 モデルの結果が 1 つの表に同居し、列構成が崩れないこと** まで見る。これが
long 形式を選んだ理由（要件 7.3 と 6.2 の同時充足）そのものである。

有効数字 10 桁の丸めも、値の近さでは確かめられない。丸めが要るのは逐字比較のためで
あり（要件 8.2）、**書き出された文字列そのもの** を主張する。曲線・残差 CSV 側は
丸めてはならないため、同じ値が全精度で出ることを対にして見る。
"""

from __future__ import annotations

import ast
import csv
import os
import stat
from pathlib import Path

import numpy as np
import pytest

from curvefit.errors import ConfigViolation, FailureReason, ViolationKind
from curvefit.types import (
    CurveData,
    FitFailure,
    FitOutcome,
    FitSuccess,
    FloatArray,
    GoodnessOfFit,
    OutlierPoint,
    ParameterEstimate,
    PreprocessReport,
)
from curvefit.writers import (
    CURVE_COLUMNS,
    PREPROCESS_COLUMNS,
    SUMMARY_COLUMNS,
    build_output_stem,
    check_output_writable,
    write_curve,
    write_preprocess,
    write_summary,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
"""root は権限ビットを無視して書き込めるため、書き込み不能の検証が成立しない。"""

requires_permission_bits = pytest.mark.skipif(
    IS_ROOT, reason="root では権限ビットによる書き込み不能を再現できない"
)


def _array(values: list[float]) -> FloatArray:
    return np.array(values, dtype=np.float64)


def _curve(n: int = 3) -> CurveData:
    x = _array([float(i) for i in range(n)])
    y = _array([float(i) * 2.0 for i in range(n)])
    return CurveData(x=x, y_observed=y, y_fit=y, residual=_array([0.0] * n))


def _report(
    n_input: int = 5,
    n_dropped_invalid: int = 1,
    n_dropped_out_of_range: int = 1,
    n_dropped_outlier: int = 0,
) -> PreprocessReport:
    return PreprocessReport(
        n_input=n_input,
        n_dropped_invalid=n_dropped_invalid,
        n_dropped_out_of_range=n_dropped_out_of_range,
        n_dropped_outlier=n_dropped_outlier,
        outlier_points=tuple(
            OutlierPoint(x=float(i), y=float(i) * 2.0, iteration=1)
            for i in range(n_dropped_outlier)
        ),
    )


def _success(
    source_id: str = "sample.csv",
    method_name: str = "linear",
    parameters: tuple[ParameterEstimate, ...] = (),
    r_squared: float = 0.5,
    rmse: float = 0.25,
) -> FitSuccess:
    curve = _curve()
    return FitSuccess(
        source_id=source_id,
        method_name=method_name,
        parameters=parameters,
        goodness=GoodnessOfFit(
            r_squared=r_squared,
            rmse=rmse,
            n_points=len(curve),
            n_varied_params=len(parameters),
        ),
        curve=curve,
        preprocess=_report(),
    )


def _linear_success() -> FitSuccess:
    """パラメータ 2 個のモデル。"""
    return _success(
        source_id="a.csv",
        method_name="linear",
        parameters=(
            ParameterEstimate(name="slope", value=2.0, stderr=0.1, fixed=False),
            ParameterEstimate(name="intercept", value=1.0, stderr=0.2, fixed=False),
        ),
    )


def _gaussian_success() -> FitSuccess:
    """パラメータ 3 個のモデル。名前も個数も linear と異なる。"""
    return _success(
        source_id="a.csv",
        method_name="gaussian",
        parameters=(
            ParameterEstimate(name="amplitude", value=3.0, stderr=0.3, fixed=False),
            ParameterEstimate(name="center", value=4.0, stderr=0.4, fixed=False),
            ParameterEstimate(name="sigma", value=5.0, stderr=0.5, fixed=False),
        ),
    )


def _failure(
    source_id: str = "broken.csv",
    method_name: str = "linear",
    reason: FailureReason = FailureReason.NOT_CONVERGED,
    message: str = "当てはめが収束しなかった（初期値: slope=1.0）",
    preprocess: PreprocessReport | None = None,
) -> FitFailure:
    return FitFailure(
        source_id=source_id,
        method_name=method_name,
        reason=reason,
        message=message,
        preprocess=preprocess,
    )


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _header(path: Path) -> list[str]:
    with path.open(encoding="utf-8", newline="") as handle:
        return next(csv.reader(handle))


class Testサマリ表の列構成:
    """設計の「サマリ CSV の列」表と long 形式の要求（要件 7.3、3.5）。"""

    def test_列は設計の表どおりに並ぶ(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary([_linear_success()], path)

        assert _header(path) == list(SUMMARY_COLUMNS)
        assert SUMMARY_COLUMNS == (
            "source_id",
            "method_name",
            "status",
            "parameter_name",
            "value",
            "stderr",
            "fixed",
            "r_squared",
            "rmse",
            "n_points",
            "n_dropped_invalid",
            "n_dropped_out_of_range",
            "n_dropped_outlier",
            "failure_reason",
            "message",
        )

    def test_パラメータ名が結果の識別子になる(self, tmp_path: Path) -> None:
        """要件 3.5。モデルが定めた名前がそのまま行の識別子として出る。"""
        path = tmp_path / "summary.csv"
        write_summary([_linear_success()], path)

        rows = _rows(path)
        assert [row["parameter_name"] for row in rows] == ["slope", "intercept"]
        assert [row["value"] for row in rows] == ["2", "1"]
        assert [row["stderr"] for row in rows] == ["0.1", "0.2"]

    def test_パラメータ数の異なる2モデルが同一の表に共存する(self, tmp_path: Path) -> None:
        """要件 7.3 と 6.2 を同時に満たすのは long 形式だけである（設計 Integration）。"""
        path = tmp_path / "summary.csv"
        write_summary([_linear_success(), _gaussian_success()], path)

        rows = _rows(path)
        assert len(rows) == 5, "パラメータ 1 個につき 1 行になっていない"
        assert [(row["method_name"], row["parameter_name"]) for row in rows] == [
            ("linear", "slope"),
            ("linear", "intercept"),
            ("gaussian", "amplitude"),
            ("gaussian", "center"),
            ("gaussian", "sigma"),
        ]
        # 列は 1 種類しかない。モデルごとに列が増えれば wide 形式に退化している。
        for row in rows:
            assert set(row) == set(SUMMARY_COLUMNS)

    def test_適合度指標は行内で繰り返す(self, tmp_path: Path) -> None:
        """設計 Responsibilities:「適合度指標は行内で繰り返す」。"""
        path = tmp_path / "summary.csv"
        write_summary([_gaussian_success()], path)

        rows = _rows(path)
        assert len(rows) == 3
        assert {row["r_squared"] for row in rows} == {"0.5"}
        assert {row["rmse"] for row in rows} == {"0.25"}
        assert {row["n_points"] for row in rows} == {"3"}

    def test_パラメータを持たない手法も1行を占める(self, tmp_path: Path) -> None:
        """スプラインや移動平均は `parameters` が空。適合度は必ず出る（要件 5.3、7.2）。"""
        path = tmp_path / "summary.csv"
        write_summary([_success(source_id="s.csv", method_name="spline")], path)

        rows = _rows(path)
        assert len(rows) == 1, "パラメータなしの手法が表から消えている"
        assert rows[0]["method_name"] == "spline"
        assert rows[0]["status"] == "success"
        assert rows[0]["parameter_name"] == ""
        assert rows[0]["value"] == ""
        assert rows[0]["stderr"] == ""
        assert rows[0]["fixed"] == ""
        assert rows[0]["r_squared"] == "0.5"

    def test_前処理の除去件数が行に載る(self, tmp_path: Path) -> None:
        """要件 2.2、2.3 の除去件数はサマリから追える。"""
        path = tmp_path / "summary.csv"
        write_summary([_linear_success()], path)

        row = _rows(path)[0]
        assert row["n_dropped_invalid"] == "1"
        assert row["n_dropped_out_of_range"] == "1"
        assert row["n_dropped_outlier"] == "0"


class Test失敗の行:
    """成功と失敗の双方が同じ表に載る（要件 6.6 の成否集計の根拠）。"""

    def test_失敗も理由と説明とともに行になる(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary([_failure(preprocess=_report())], path)

        rows = _rows(path)
        assert len(rows) == 1
        row = rows[0]
        assert row["source_id"] == "broken.csv"
        assert row["method_name"] == "linear"
        assert row["status"] == "failure"
        assert row["failure_reason"] == FailureReason.NOT_CONVERGED.value
        assert "収束" in row["message"]
        assert row["parameter_name"] == ""
        assert row["value"] == ""
        assert row["r_squared"] == ""
        assert row["rmse"] == ""
        assert row["n_points"] == ""
        assert row["n_dropped_invalid"] == "1"

    def test_前処理に到達しない失敗は除去件数が空欄(self, tmp_path: Path) -> None:
        """`FitFailure.preprocess` は `None` を取りうる（読み込み段階の失敗）。"""
        path = tmp_path / "summary.csv"
        write_summary(
            [_failure(reason=FailureReason.COLUMN_NOT_FOUND, message="列 'x' がない")], path
        )

        row = _rows(path)[0]
        assert row["n_dropped_invalid"] == ""
        assert row["n_dropped_out_of_range"] == ""
        assert row["n_dropped_outlier"] == ""
        assert row["failure_reason"] == FailureReason.COLUMN_NOT_FOUND.value

    def test_成功と失敗が同じ表に並ぶ(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        outcomes: list[FitOutcome] = [_linear_success(), _failure(), _gaussian_success()]
        write_summary(outcomes, path)

        rows = _rows(path)
        assert [row["status"] for row in rows] == [
            "success",
            "success",
            "failure",
            "success",
            "success",
            "success",
        ]

    def test_改行を含む説明でも列がずれない(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary([_failure(message="1 行目\n2 行目, カンマつき")], path)

        rows = _rows(path)
        assert len(rows) == 1
        assert rows[0]["message"] == "1 行目\n2 行目, カンマつき"


class Test標準誤差の欠落:
    """`stderr` は算出不能なら空欄（設計のサマリ列表、Risks）。"""

    def test_算出できない標準誤差は空欄になる(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary(
            [
                _success(
                    parameters=(
                        ParameterEstimate(name="a", value=1.0, stderr=None, fixed=False),
                    )
                )
            ],
            path,
        )

        row = _rows(path)[0]
        assert row["stderr"] == "", "算出不能な標準誤差を nan や 0 として出している"
        assert row["value"] == "1"
        assert row["fixed"] == "False"

    def test_固定パラメータは固定として出る(self, tmp_path: Path) -> None:
        """要件 4.5。固定パラメータは標準誤差を持たない（`ParameterEstimate` の不変条件）。"""
        path = tmp_path / "summary.csv"
        write_summary(
            [
                _success(
                    parameters=(
                        ParameterEstimate(name="c", value=7.0, stderr=None, fixed=True),
                    )
                )
            ],
            path,
        )

        row = _rows(path)[0]
        assert row["fixed"] == "True"
        assert row["stderr"] == ""


class Testサマリの丸め:
    """サマリの数値は有効数字 10 桁（設計 Validation、要件 8.2）。"""

    def test_推定値と標準誤差は有効数字10桁で出る(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary(
            [
                _success(
                    parameters=(
                        ParameterEstimate(
                            name="a", value=1.0 / 3.0, stderr=2.0 / 3.0, fixed=False
                        ),
                    )
                )
            ],
            path,
        )

        row = _rows(path)[0]
        assert row["value"] == "0.3333333333"
        assert row["stderr"] == "0.6666666667"

    def test_適合度指標も有効数字10桁で出る(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary([_success(r_squared=1.0 / 3.0, rmse=1234567890123.456)], path)

        row = _rows(path)[0]
        assert row["r_squared"] == "0.3333333333"
        assert row["rmse"] == "1.23456789e+12"

    def test_10桁目より下の揺れが同じ文字列に潰れる(self, tmp_path: Path) -> None:
        """平滑化スプラインの非決定性（当てはめ値 3.0e-11、RMSE 相対 1.2e-10）を吸収する。"""
        base = 0.1234567890123
        drifted = base * (1.0 + 1.2e-10)
        assert base != drifted

        first, second = tmp_path / "a.csv", tmp_path / "b.csv"
        write_summary([_success(rmse=base)], first)
        write_summary([_success(rmse=drifted)], second)

        assert first.read_bytes() == second.read_bytes()

    def test_点数は整数のまま出る(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary([_success()], path)

        assert _rows(path)[0]["n_points"] == "3"


class Test曲線残差CSV:
    """要件 7.5。有効化された場合のみ生成する出力物。"""

    def test_列は_x_実測値_当てはめ値_残差(self, tmp_path: Path) -> None:
        path = tmp_path / "curves" / "a__linear.csv"
        write_curve(_success(), path)

        assert _header(path) == list(CURVE_COLUMNS)
        assert CURVE_COLUMNS == ("x", "y_observed", "y_fit", "residual")

    def test_解放済みの結果は書き出せない(self, tmp_path: Path) -> None:
        """要件 10.4: 曲線を手放した結果が届くのは呼び出し側の誤りである。

        書き出しはバッチが手放す **前** に行われる（``pipeline``）。空のファイルを黙って
        書くと、出力ディレクトリの内容とサマリ表の成否が食い違う。
        """
        path = tmp_path / "curve.csv"

        with pytest.raises(ValueError, match="解放済み"):
            write_curve(_success(source_id="a.csv").without_curve(), path)

        assert not path.exists(), "書けない結果に対して空のファイルが残っている"

    def test_各データ点が1行になる(self, tmp_path: Path) -> None:
        path = tmp_path / "curve.csv"
        success = _success()
        assert success.curve is not None
        write_curve(success, path)

        rows = _rows(path)
        assert len(rows) == len(success.curve)
        assert [row["x"] for row in rows] == ["0.0", "1.0", "2.0"]

    def test_曲線は丸めずに全精度で出る(self, tmp_path: Path) -> None:
        """丸めはサマリ表に限る（設計 Validation）。"""
        value = 1.0 / 3.0
        curve = CurveData(
            x=_array([value]),
            y_observed=_array([value]),
            y_fit=_array([value]),
            residual=_array([0.0]),
        )
        success = FitSuccess(
            source_id="a.csv",
            method_name="spline",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=1.0, rmse=0.0, n_points=1, n_varied_params=0),
            curve=curve,
            preprocess=_report(n_input=1, n_dropped_invalid=0, n_dropped_out_of_range=0),
        )
        path = tmp_path / "curve.csv"
        write_curve(success, path)

        row = _rows(path)[0]
        assert row["x"] == repr(value) == "0.3333333333333333"
        assert float(row["y_fit"]) == value, "往復して同じ値に戻らない"

    def test_親ディレクトリがなくても書き出せる(self, tmp_path: Path) -> None:
        """曲線 CSV の出力先は `{output_dir}/curves/`（設計 Batch / Job Contract）。"""
        path = tmp_path / "curves" / "nested" / "a.csv"
        write_curve(_success(), path)

        assert path.exists()


def _outlier_report(*points: OutlierPoint) -> PreprocessReport:
    """外れ値だけを除いた前処理レポートを作る。件数は記録と一致させる。"""
    return PreprocessReport(
        n_input=10,
        n_dropped_invalid=0,
        n_dropped_out_of_range=0,
        n_dropped_outlier=len(points),
        outlier_points=points,
    )


def _success_with(report: PreprocessReport) -> FitSuccess:
    """前処理レポートだけを指定した成功結果。"""
    curve = _curve()
    return FitSuccess(
        source_id="a.csv",
        method_name="linear",
        parameters=(),
        goodness=GoodnessOfFit(
            r_squared=0.5, rmse=0.25, n_points=len(curve), n_varied_params=0
        ),
        curve=curve,
        preprocess=report,
    )


class Test前処理CSV:
    """要件 2.5。外れ値と判定した各点の x・実測値・反復回数を出力ファイルに記録する。

    設計の「前処理 CSV の列」表と Implementation Notes（成否によらず書く、除外 0 件では
    ファイルを作らない、並びは除去順、丸めない、オプトインではない）を対象とする。

    **書くか否かの判断は本関数が単独で持つ。** 呼び出し側（``pipeline``）は条件を見ずに
    呼ぶため、除外 0 件と ``preprocess`` が ``None`` の 2 つの場合を本関数の側で確かめる。
    """

    def test_列は_x_実測値_反復回数(self, tmp_path: Path) -> None:
        path = tmp_path / "preprocess" / "a__linear__0000.csv"
        write_preprocess(
            _success_with(_outlier_report(OutlierPoint(x=1.0, y=2.0, iteration=1))), path
        )

        assert _header(path) == list(PREPROCESS_COLUMNS)
        assert PREPROCESS_COLUMNS == ("x", "y_observed", "iteration")

    def test_除外した2点が除去順に行になる(self, tmp_path: Path) -> None:
        """並びは除去順（反復順、反復内では入力の並び順）であり x の昇順ではない。"""
        path = tmp_path / "preprocess.csv"
        write_preprocess(
            _success_with(
                _outlier_report(
                    OutlierPoint(x=5.0, y=50.0, iteration=1),
                    OutlierPoint(x=1.0, y=-3.0, iteration=2),
                )
            ),
            path,
        )

        rows = _rows(path)
        assert [(row["x"], row["y_observed"], row["iteration"]) for row in rows] == [
            ("5.0", "50.0", "1"),
            ("1.0", "-3.0", "2"),
        ]

    def test_反復回数は整数のまま出る(self, tmp_path: Path) -> None:
        """1 起点の回数であり、実数として書くと「3.0 回目」と読ませることになる。"""
        path = tmp_path / "preprocess.csv"
        write_preprocess(
            _success_with(_outlier_report(OutlierPoint(x=0.5, y=9.0, iteration=3))), path
        )

        assert _rows(path)[0]["iteration"] == "3"

    def test_除外0件ではファイルを作らない(self, tmp_path: Path) -> None:
        """空のファイルが対象ごとに並ぶと、外れ値があった対象を探すのに開く必要が生じる。

        存在そのものが「この対象には除外があった」を意味する形にする（設計 Integration）。
        """
        directory = tmp_path / "preprocess"
        path = directory / "a__linear__0000.csv"
        write_preprocess(_success_with(_outlier_report()), path)

        assert not path.exists(), "除外 0 件で空のファイルが作られている"
        assert not directory.exists(), "書かない対象のために出力先が作られている"
        assert list(tmp_path.iterdir()) == [], "書かない対象が出力ディレクトリを汚している"

    def test_前処理に到達しない失敗ではファイルを作らない(self, tmp_path: Path) -> None:
        """``preprocess`` が ``None`` は除外 0 件ではなく **未計測** である。"""
        directory = tmp_path / "preprocess"
        path = directory / "broken__linear__0000.csv"
        write_preprocess(_failure(preprocess=None), path)

        assert not path.exists(), "前処理に到達していない結果でファイルが作られている"
        assert list(tmp_path.iterdir()) == [], "書かない対象が出力ディレクトリを汚している"

    def test_外れ値を除いた結果として失敗しても書かれる(self, tmp_path: Path) -> None:
        """要件 2.5 は成功を条件にしない。この場合こそ x を知りたい場面である。"""
        path = tmp_path / "preprocess.csv"
        write_preprocess(
            _failure(
                reason=FailureReason.INSUFFICIENT_POINTS,
                message="前処理後のデータ点数が不足している",
                preprocess=_outlier_report(
                    OutlierPoint(x=2.0, y=7.0, iteration=1),
                    OutlierPoint(x=3.0, y=8.0, iteration=1),
                ),
            ),
            path,
        )

        rows = _rows(path)
        assert [row["x"] for row in rows] == ["2.0", "3.0"]

    def test_丸めずに全精度で出る(self, tmp_path: Path) -> None:
        """丸めはサマリ表に限る（設計 Validation）。前処理 CSV は数値データそのもの。"""
        x = 0.1234567890123456
        y = -9.876543210987654e-07
        # サマリの有効数字 10 桁なら別の文字列になる値を選ぶ。そうでない値では
        # 丸めを入れる変異が検査をすり抜ける。
        assert f"{x:.10g}" == "0.123456789"
        assert f"{y:.10g}" == "-9.876543211e-07"

        path = tmp_path / "preprocess.csv"
        write_preprocess(
            _success_with(_outlier_report(OutlierPoint(x=x, y=y, iteration=1))), path
        )

        row = _rows(path)[0]
        assert row["x"] == repr(x) == "0.1234567890123456"
        assert float(row["x"]) == x, "往復して同じ値に戻らない"
        assert float(row["y_observed"]) == y, "往復して同じ値に戻らない"

    def test_親ディレクトリがなくても書き出せる(self, tmp_path: Path) -> None:
        """出力先は `{output_dir}/preprocess/`（設計 Batch / Job Contract）。"""
        path = tmp_path / "preprocess" / "nested" / "a.csv"
        write_preprocess(
            _success_with(_outlier_report(OutlierPoint(x=1.0, y=2.0, iteration=1))), path
        )

        assert path.exists()

    def test_2回書くとバイト単位で一致する(self, tmp_path: Path) -> None:
        """要件 8.2。並びは入力だけで決まる。"""
        outcome = _success_with(
            _outlier_report(
                OutlierPoint(x=5.0, y=50.0, iteration=1),
                OutlierPoint(x=1.0, y=-3.0, iteration=2),
            )
        )
        first, second = tmp_path / "first.csv", tmp_path / "second.csv"
        write_preprocess(outcome, first)
        write_preprocess(outcome, second)

        assert first.read_bytes() == second.read_bytes()


class Test出力名の導出:
    """要件 7.6 と設計の Security Considerations（出力パスの正規化）。"""

    @pytest.mark.parametrize(
        "source_id",
        [
            "../../etc/passwd",
            "/abs/path.csv",
            "a/b/c.csv",
            "..\\..\\windows.csv",
            "",
            "...",
            "..",
            ".",
            "/",
            "./../x.csv",
            "..hidden.csv",
        ],
    )
    def test_指定ディレクトリの外に出られない(self, tmp_path: Path, source_id: str) -> None:
        stem = build_output_stem(source_id, "linear", 0)

        assert stem, "空の名前を返している"
        assert "/" not in stem and "\\" not in stem, f"パス区切りが残っている: {stem!r}"
        assert os.sep not in stem
        assert ".." not in stem, f"親ディレクトリ参照が残っている: {stem!r}"
        assert not stem.startswith("."), f"隠しファイルになる: {stem!r}"

        target = (tmp_path / f"{stem}.csv").resolve()
        assert target.parent == tmp_path.resolve(), f"出力先の外に出た: {target}"

    def test_対象と手法を識別できる情報を含む(self) -> None:
        stem = build_output_stem("data/sample1.csv", "gaussian", 0)

        assert "sample1" in stem
        assert "gaussian" in stem

    def test_同名になりうる2入力の出力先が衝突しない(self) -> None:
        """別ディレクトリの同名ファイルは、正規化すると同じ名前になりうる（要件 7.6）。"""
        first = build_output_stem("run1/sample.csv", "linear", 0)
        second = build_output_stem("run2/sample.csv", "linear", 1)

        assert first != second

    def test_拡張子だけが違う2入力も衝突しない(self) -> None:
        first = build_output_stem("sample.csv", "linear", 0)
        second = build_output_stem("sample.tsv", "linear", 1)

        assert first != second

    def test_安全でない文字に潰れる2入力も衝突しない(self) -> None:
        """正規化で同じ文字に落ちる入力どうし（設計 Integration）。"""
        first = build_output_stem("a b.csv", "linear", 0)
        second = build_output_stem("a+b.csv", "linear", 1)

        assert first != second

    def test_同一ジョブなら常に同一の名前になる(self) -> None:
        """要件 8.2。名前にハッシュや時刻を混ぜない。"""
        assert build_output_stem("data/sample.csv", "linear", 3) == build_output_stem(
            "data/sample.csv", "linear", 3
        )

    def test_同一対象でも手法が違えば名前が違う(self) -> None:
        """要件 6.2。同一データへの複数モデル適用が互いを上書きしない。"""
        assert build_output_stem("a.csv", "linear", 0) != build_output_stem(
            "a.csv", "gaussian", 1
        )

    def test_極端に長い名前でも書き出せる(self, tmp_path: Path) -> None:
        stem = build_output_stem("x" * 500 + ".csv", "linear", 0)
        path = tmp_path / f"{stem}.csv"
        write_curve(_success(), path)

        assert path.exists()

    def test_親ディレクトリ参照は1つ前の要素を打ち消す(self) -> None:
        """``data/subdir/..`` が指すのは ``data`` であり ``subdir`` ではない。"""
        assert "data" in build_output_stem("data/subdir/..", "linear", 0)
        assert "subdir" not in build_output_stem("data/subdir/..", "linear", 0)
        assert "b" in build_output_stem("a/../b.csv", "linear", 0)

    def test_負のジョブ番号は呼び出し側の誤りとして例外になる(self) -> None:
        with pytest.raises(ValueError):
            build_output_stem("a.csv", "linear", -1)

    def test_日本語の対象名を保つ(self) -> None:
        stem = build_output_stem("測定/試料1.csv", "linear", 0)

        assert "試料1" in stem


class Test出力先の検証:
    """要件 7.7。書けない出力先は値として報告し、例外にしない。"""

    def test_書き込めるディレクトリは違反なし(self, tmp_path: Path) -> None:
        assert check_output_writable(tmp_path) == ()

    @requires_permission_bits
    def test_書き込めないディレクトリは違反になる(self, tmp_path: Path) -> None:
        directory = tmp_path / "locked"
        directory.mkdir()
        directory.chmod(stat.S_IRUSR | stat.S_IXUSR)
        try:
            violations = check_output_writable(directory)
        finally:
            directory.chmod(stat.S_IRWXU)

        assert len(violations) == 1
        violation = violations[0]
        assert isinstance(violation, ConfigViolation)
        assert violation.kind is ViolationKind.OUTPUT_NOT_WRITABLE
        assert violation.location, "どこが原因かを特定できない違反は無価値である"
        assert str(directory) in violation.message

    def test_ファイルが置かれた場所は違反になる(self, tmp_path: Path) -> None:
        path = tmp_path / "not_a_dir"
        path.write_text("x", encoding="utf-8")

        violations = check_output_writable(path)

        assert len(violations) == 1
        assert violations[0].kind is ViolationKind.OUTPUT_NOT_WRITABLE
        assert str(path) in violations[0].message

    def test_親が存在すれば未作成の出力先は違反にならない(self, tmp_path: Path) -> None:
        """1 階層の新規作成は打ち間違いと正当な新規指定を区別できないため許容する。

        出力先そのものの作成は writers が行う（`{output_dir}/curves/` も同様）。
        """
        assert check_output_writable(tmp_path / "new") == ()

    def test_親が存在しない出力先は違反になる(self, tmp_path: Path) -> None:
        """深い打ち間違いが黙って成功すると、利用者が見に行く場所に何も無い。"""
        typo = tmp_path / "a" / "very" / "deep" / "typo" / "path"

        violations = check_output_writable(typo)

        assert len(violations) == 1
        violation = violations[0]
        assert violation.kind is ViolationKind.OUTPUT_NOT_WRITABLE
        assert violation.location, "どこが原因かを特定できない違反は無価値である"
        assert str(typo) in violation.message, "どの出力先の話かが分からない"
        assert str(typo.parent) in violation.message, "何が足りないかが分からない"

    def test_親が存在しない違反は次の行動を示す(self, tmp_path: Path) -> None:
        """「存在しない」だけでは、綴りを直すのか親を作るのかを決められない。"""
        violations = check_output_writable(tmp_path / "missing" / "child")

        assert len(violations) == 1
        message = violations[0].message
        assert "綴り" in message
        assert "作成" in message

    def test_親が未作成でも一階層なら書き出しで作られる(self, tmp_path: Path) -> None:
        """検証を通した出力先は、実際に書き出せなければ意味がない。"""
        directory = tmp_path / "new"
        assert check_output_writable(directory) == ()

        write_summary([_linear_success()], directory / "summary.csv")

        assert (directory / "summary.csv").is_file()

    @requires_permission_bits
    def test_作成もできない場所は違反になる(self, tmp_path: Path) -> None:
        parent = tmp_path / "locked"
        parent.mkdir()
        parent.chmod(stat.S_IRUSR | stat.S_IXUSR)
        try:
            violations = check_output_writable(parent / "child")
        finally:
            parent.chmod(stat.S_IRWXU)

        assert len(violations) == 1
        assert violations[0].kind is ViolationKind.OUTPUT_NOT_WRITABLE

    def test_ファイルの下は違反になる(self, tmp_path: Path) -> None:
        blocker = tmp_path / "file"
        blocker.write_text("x", encoding="utf-8")

        violations = check_output_writable(blocker / "child")

        assert len(violations) == 1
        assert violations[0].kind is ViolationKind.OUTPUT_NOT_WRITABLE

    def test_検証は出力先を汚さない(self, tmp_path: Path) -> None:
        assert check_output_writable(tmp_path) == ()

        assert list(tmp_path.iterdir()) == [], "検査の痕跡が残っている"


class Test資源の失敗:
    """書き込み中の :class:`OSError` は要件 10.3 の系統であり、握り潰さない。"""

    @requires_permission_bits
    def test_書き込めない場所への出力は例外になる(self, tmp_path: Path) -> None:
        directory = tmp_path / "locked"
        directory.mkdir()
        directory.chmod(stat.S_IRUSR | stat.S_IXUSR)
        try:
            with pytest.raises(OSError):
                write_summary([_success()], directory / "summary.csv")
        finally:
            directory.chmod(stat.S_IRWXU)


class Test決定性:
    """要件 8.2。同一の結果からは逐字同一の出力物が出る。"""

    def test_同じ結果を2回書くとバイト単位で一致する(self, tmp_path: Path) -> None:
        outcomes: list[FitOutcome] = [
            _linear_success(),
            _gaussian_success(),
            _failure(preprocess=_report()),
            _success(source_id="s.csv", method_name="spline"),
        ]
        first, second = tmp_path / "first.csv", tmp_path / "second.csv"
        write_summary(outcomes, first)
        write_summary(outcomes, second)

        assert first.read_bytes() == second.read_bytes()

    def test_曲線CSVも2回書くとバイト単位で一致する(self, tmp_path: Path) -> None:
        success = _success()
        first, second = tmp_path / "first.csv", tmp_path / "second.csv"
        write_curve(success, first)
        write_curve(success, second)

        assert first.read_bytes() == second.read_bytes()

    def test_行の順序は与えられた順序に従う(self, tmp_path: Path) -> None:
        """ジョブ順序が決定的であるため、並べ替えは行わない。"""
        path = tmp_path / "summary.csv"
        write_summary([_gaussian_success(), _linear_success()], path)

        assert [row["method_name"] for row in _rows(path)][:1] == ["gaussian"]

    def test_改行コードは環境によらない(self, tmp_path: Path) -> None:
        path = tmp_path / "summary.csv"
        write_summary([_success()], path)

        assert b"\r\n" not in path.read_bytes()

    def test_再実行は同一パスを上書きする(self, tmp_path: Path) -> None:
        """設計 Idempotency & recovery。"""
        path = tmp_path / "summary.csv"
        write_summary([_linear_success(), _gaussian_success()], path)
        write_summary([_success(source_id="s.csv", method_name="spline")], path)

        assert len(_rows(path)) == 1, "追記になっている"


class Test依存の向き:
    """設計の Allowed Dependencies と依存方向の制約。"""

    def test_下流の層に依存しない(self) -> None:
        """``writers`` が参照してよいのは ``types`` / ``errors`` までである。"""
        tree = ast.parse((SRC / "writers.py").read_text(encoding="utf-8"))
        own = {
            node.module
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.startswith("curvefit")
        }
        own |= {
            alias.name
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
            if alias.name.startswith("curvefit")
        }

        assert own <= {"curvefit.types", "curvefit.errors"}, f"想定外の依存: {own}"

    def test_描画ライブラリを取り込まない(self) -> None:
        """描画は ``plotting`` に閉じる（Allowed Dependencies）。"""
        source = (SRC / "writers.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        imported = {
            alias.name.split(".")[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imported |= {
            node.module.split(".")[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        }

        assert "matplotlib" not in imported
