"""パッケージ骨格と実行環境が要件どおり整っていることを検証する。

対応要件: 8.1（設定ファイル形式を標準ライブラリで読める Python 下限）、9.2（コマンドからの実行）
"""

from __future__ import annotations

import subprocess
import sys
import tomllib
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def test_パッケージがインポートできる() -> None:
    import curvefit

    assert curvefit.__version__


def test_設定ファイル形式を標準ライブラリで読める下限が宣言されている() -> None:
    """要件 8.1 の設定ファイルは TOML。tomllib は 3.11 以降の標準ライブラリ。"""
    assert sys.version_info >= (3, 11)
    assert tomllib is not None

    manifest = tomllib.loads((PROJECT_ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert manifest["project"]["requires-python"] == ">=3.11"


def test_脆弱性修正済みの式評価ライブラリが下限として固定されている() -> None:
    """asteval 1.0.5 以下には sandbox escape がある（GHSA-vp47-9734-prjw）。"""
    manifest = tomllib.loads((PROJECT_ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    deps = manifest["project"]["dependencies"]
    asteval = next(d for d in deps if d.startswith("asteval"))
    assert asteval == "asteval>=1.0.6"


def _console_script() -> Path:
    """宣言されたコンソールスクリプトの実体を、実行中のインタプリタから解決する。

    ``python -m curvefit.cli`` ではなくこの実体を起動することで、``[project.scripts]``
    の宣言とインストールの双方を検証対象に含める。
    """
    return Path(sys.executable).parent / "curvefit"


def test_宣言したコマンド名がインストールされている() -> None:
    """要件 9.2 のコマンド実行の土台。宣言が欠けていればここで落ちる。"""
    assert _console_script().is_file(), (
        f"コンソールスクリプトが見つからない: {_console_script()}。"
        "pyproject.toml の [project.scripts] 宣言とインストール状態を確認すること。"
    )


def test_宣言したコマンド名が起動する() -> None:
    """要件 9.2: コマンド名で起動し、正常終了すること。"""
    result = subprocess.run(
        [str(_console_script()), "--help"],
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert result.returncode == 0, result.stderr
    assert "curvefit" in result.stdout


def test_コマンドが引数なしでも正常終了する() -> None:
    result = subprocess.run(
        [str(_console_script())],
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert result.returncode == 0, result.stderr


def test_テスト区分のディレクトリが存在する() -> None:
    for kind in ("unit", "integration", "e2e", "performance"):
        assert (PROJECT_ROOT / "tests" / kind).is_dir(), kind
