"""数式文字列によるモデル指定を検証する。

対応要件: 3.2（数式文字列をモデル関数として解釈し、未知記号を推定対象パラメータとして扱う）、
3.4（解釈できない式を、原因となった指定内容を含めて報告する）
"""

from __future__ import annotations

import ast
from pathlib import Path

import numpy as np
import pytest

import curvefit.models.expression as expression_module
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.expression import (
    DEFAULT_LOCATION,
    INDEPENDENT_VARIABLE,
    ExpressionModelSpec,
    build_expression_model,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


def _spec(expression: str) -> ExpressionModelSpec:
    """解釈できることを前提に仕様を取り出す。違反が返ったらその場で落とす。"""
    result = build_expression_model(expression)
    assert isinstance(result, ExpressionModelSpec), f"解釈できるはずの式が拒否された: {result}"
    return result


def _violation(expression: str, location: str = DEFAULT_LOCATION) -> ConfigViolation:
    """解釈できないことを前提に違反を取り出す。"""
    result = build_expression_model(expression, location=location)
    assert isinstance(result, ConfigViolation), f"拒否されるはずの式が通った: {result}"
    return result


class Testパラメータ名の抽出:
    """要件 3.2: 式中の未知記号を推定対象パラメータとして扱う。"""

    @pytest.mark.parametrize(
        ("expression", "expected"),
        [
            ("a*exp(-b*x)+c", ("a", "b", "c")),
            ("m*x + c", ("m", "c")),
            ("a*x**2+b*x+c", ("a", "b", "c")),
            ("a*sqrt(x)+b*log(x)+c", ("a", "b", "c")),
            ("amp*sin(freq*x+phase)", ("amp", "freq", "phase")),
        ],
    )
    def test_未知記号がパラメータとして抽出される(
        self, expression: str, expected: tuple[str, ...]
    ) -> None:
        assert _spec(expression).parameter_names == expected

    @pytest.mark.parametrize(
        "expression",
        ["a*exp(-b*x)+c", "m*x + c", "a*x**2+b*x+c", "a*sqrt(x)+b*log(x)+c"],
    )
    def test_独立変数はパラメータに含まれない(self, expression: str) -> None:
        """設計の Risks: `x` を独立変数として除外する規則を明示的に持つ。"""
        assert INDEPENDENT_VARIABLE not in _spec(expression).parameter_names

    def test_数学関数と定数はパラメータにならない(self) -> None:
        """asteval が既に知っている名前は未知記号ではない。"""
        assert _spec("amp*pi*x").parameter_names == ("amp",)
        assert _spec("tanh(x)*a").parameter_names == ("a",)

    def test_同じ記号が複数回現れても1回だけ数える(self) -> None:
        assert _spec("a*x + a*x**2 + b").parameter_names == ("a", "b")

    def test_パラメータ名の順序は呼び出しごとに変わらない(self) -> None:
        """要件 8.2 の再現性は、下流に渡る順序が安定していることに依存する。"""
        expression = "z*x + a*x**2 + q*exp(-w*x)"
        first = _spec(expression).parameter_names
        for _ in range(5):
            assert _spec(expression).parameter_names == first

    def test_パラメータ名は出現順で並ぶ(self) -> None:
        """辞書の反復順に依存しない、式の記述から決まる順序であること。"""
        assert _spec("z*x + a*x**2 + q").parameter_names == ("z", "a", "q")

    def test_抽出結果は書き換えられない列である(self) -> None:
        names = _spec("a*x+b").parameter_names
        assert isinstance(names, tuple)


class Testモデル実体の生成:
    """抽出したパラメータで実際に評価できることまでを確認する。"""

    def test_モデル実体を生成できる(self) -> None:
        model = _spec("a*x+b").create()
        assert model is not None

    def test_呼び出しごとに独立した実体を返す(self) -> None:
        """当てはめはジョブごとに解決し直される。実体の使い回しは状態を持ち込む。"""
        spec = _spec("a*x+b")
        assert spec.create() is not spec.create()

    def test_生成した実体のパラメータ名が抽出結果と一致する(self) -> None:
        spec = _spec("a*exp(-b*x)+c")
        assert tuple(spec.create().param_names) == spec.parameter_names

    def test_生成した実体が式のとおりに評価される(self) -> None:
        spec = _spec("a*exp(-b*x)+c")
        model = spec.create()
        x = np.linspace(0.0, 5.0, 41)
        actual = model.eval(model.make_params(a=3.0, b=0.5, c=1.0), x=x)
        np.testing.assert_allclose(actual, 3.0 * np.exp(-0.5 * x) + 1.0)

    def test_前後の空白は取り除いて保持される(self) -> None:
        spec = _spec("  a*x + b  ")
        assert spec.expression == "a*x + b"

    def test_独立変数の名前を保持する(self) -> None:
        assert _spec("a*x+b").independent_variable == INDEPENDENT_VARIABLE


class Test解釈できない式:
    """要件 3.4: 解釈できない式は例外ではなく違反として返す。"""

    @pytest.mark.parametrize(
        "expression",
        [
            "a*x +",  # 構文誤り
            "a*x)",  # 括弧の不整合
            "a**",  # 演算子の未完
            "@x",  # 式として成立しない
            "",  # 空
            "   ",  # 空白のみ
            "a*y+b",  # 独立変数 x を含まない
            "c",  # 定数のみで x を含まない
            "frobnicate(x)",  # 未定義の関数呼び出し
            "2*x",  # 推定対象のパラメータがない
            "x",  # 独立変数のみ
            "a*x; import os",  # 単一の式ではない
            "a = 1",  # 式ではなく文
        ],
    )
    def test_解釈できない式は違反を返す(self, expression: str) -> None:
        assert _violation(expression).kind is ViolationKind.MODEL_UNRESOLVED

    @pytest.mark.parametrize("expression", ["a*x +", "frobnicate(x)", "2*x", "a*y+b"])
    def test_違反は原因となった式を含む(self, expression: str) -> None:
        assert expression in _violation(expression).message

    def test_構文誤りの違反は理由を示す(self) -> None:
        message = _violation("a*x +").message
        assert "構文" in message

    def test_未定義の関数呼び出しは関数名を示す(self) -> None:
        """未知記号をパラメータとして扱う規則の下では、未定義関数も黙って
        パラメータになってしまう。当てはめ時の不可解な失敗を避けるため先に弾く。"""
        message = _violation("frobnicate(x)").message
        assert "frobnicate" in message

    def test_独立変数を含まない式は独立変数名を示す(self) -> None:
        assert INDEPENDENT_VARIABLE in _violation("a*y+b").message

    def test_パラメータのない式は理由を示す(self) -> None:
        assert "パラメータ" in _violation("2*x").message

    def test_違反は既定の指定箇所を持つ(self) -> None:
        assert _violation("a*x +").location == DEFAULT_LOCATION

    def test_違反は指定箇所を上書きできる(self) -> None:
        violation = _violation("a*x +", location="methods[2].expression")
        assert violation.location == "methods[2].expression"

    @pytest.mark.parametrize("expression", ["a*x +", "", "frobnicate(x)", "a*y+b", "2*x"])
    def test_基盤ライブラリの例外を外に漏らさない(self, expression: str) -> None:
        """lmfit / asteval の例外がそのまま出ると、実行前ゲートが違反を集約できない。"""
        assert isinstance(build_expression_model(expression), ConfigViolation)

    def test_基盤ライブラリの想定外の例外も違反として返す(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """構文検査を通った式でも、基盤ライブラリ側の事情で組み立てが失敗しうる。
        その場合も例外を外に出さず違反として返すこと。"""

        def _raise(*args: object, **kwargs: object) -> object:
            raise RuntimeError("組み立てに失敗した")

        monkeypatch.setattr(expression_module, "ExpressionModel", _raise)
        violation = _violation("a*x+b")
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED
        assert "組み立てに失敗した" in violation.message


def _module_source() -> str:
    return (SRC / "models" / "expression.py").read_text(encoding="utf-8")


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse(_module_source())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


def _names_bound_from(prefixes: set[str]) -> set[str]:
    """指定モジュール群から束縛された識別子（別名を含む）を集める。"""
    tree = ast.parse(_module_source())
    bound: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in prefixes:
                    bound.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            if node.module.split(".")[0] in prefixes:
                bound.update(alias.asname or alias.name for alias in node.names)
    return bound


def _public_annotations() -> list[str]:
    """公開シグネチャ（非私有の関数引数・戻り値・属性）の注釈を文字列で返す。"""
    tree = ast.parse(_module_source())
    annotations: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            if node.name.startswith("_") and node.name != "__init__":
                continue
            args = node.args
            for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs):
                if arg.annotation is not None and not arg.arg.startswith("_"):
                    annotations.append(ast.unparse(arg.annotation))
            if node.returns is not None:
                annotations.append(ast.unparse(node.returns))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if not node.target.id.startswith("_"):
                annotations.append(ast.unparse(node.annotation))
    return annotations


class Test依存の露出:
    def test_平滑化や描画のライブラリを_import_しない(self) -> None:
        """設計の Allowed Dependencies: SciPy は engines、matplotlib は plotting に閉じる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"scipy", "matplotlib", "pandas"}, (
                f"expression.py が {imported} を import している"
            )

    def test_式の評価系を直接_import_しない(self) -> None:
        """設計: asteval は lmfit 経由で使う。直接 import しない。"""
        roots = {imported.split(".")[0] for imported in _imported_modules()}
        assert "asteval" not in roots

    def test_公開シグネチャに基盤ライブラリの型が現れない(self) -> None:
        """内部で lmfit を使うことは前提。外向きの注釈に漏らさないことを検証する。"""
        leaked = _names_bound_from({"lmfit", "asteval"})
        assert leaked, "lmfit を import していない場合、この検証は無意味になる"
        for annotation in _public_annotations():
            used = {
                node.id for node in ast.walk(ast.parse(annotation)) if isinstance(node, ast.Name)
            }
            assert not (used & leaked), f"公開注釈 {annotation!r} が {used & leaked} を露出している"

    def test_自パッケージへの依存は下位レイヤに限る(self) -> None:
        own = {m for m in _imported_modules() if m.split(".")[0] == "curvefit"}
        allowed = {"curvefit.errors", "curvefit.types"}
        assert own <= allowed, f"想定外の依存: {own - allowed}"
