"""組込モデルのレジストリを検証する。

対応要件: 3.1（線形・多項式・ガウシアン・指数を名前で選択できる）、
3.4（未知の組込モデル名を、原因となった指定内容を含めて報告する）
"""

from __future__ import annotations

import ast
from pathlib import Path

import numpy as np
import pytest

from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.registry import (
    BUILTIN_MODELS,
    DEFAULT_POLYNOMIAL_DEGREE,
    POLYNOMIAL_DEGREE_OPTION,
    BuiltinModelSpec,
    resolve_builtin,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

REQUIRED_NAMES = ("linear", "polynomial", "gaussian", "exponential")
"""要件 3.1 が明示的に求める組込モデル名。"""


def _sample_for(name: str) -> tuple[np.ndarray, np.ndarray]:
    """各モデルが素直に当てはまる合成データを返す。初期値推定の実効性の確認に使う。"""
    if name == "linear":
        x = np.linspace(0.0, 10.0, 50)
        return x, 2.0 * x + 1.0
    if name == "polynomial":
        x = np.linspace(-5.0, 5.0, 60)
        return x, 1.0 + 2.0 * x + 0.5 * x**2
    if name == "gaussian":
        x = np.linspace(-5.0, 5.0, 101)
        return x, 3.0 * np.exp(-((x - 0.5) ** 2) / (2.0 * 1.2**2))
    if name == "exponential":
        x = np.linspace(0.0, 5.0, 60)
        return x, 4.0 * np.exp(-x / 1.5)
    raise AssertionError(f"合成データを用意していないモデル名: {name!r}")


class Test組込モデルの対応表:
    def test_要件が求める4種類を過不足なく提供する(self) -> None:
        assert set(BUILTIN_MODELS) == set(REQUIRED_NAMES)

    @pytest.mark.parametrize("name", REQUIRED_NAMES)
    def test_各モデル名が解決できる(self, name: str) -> None:
        spec = resolve_builtin(name)
        assert isinstance(spec, BuiltinModelSpec)
        assert spec.name == name

    @pytest.mark.parametrize("name", REQUIRED_NAMES)
    def test_解決結果は対応表の項目そのものである(self, name: str) -> None:
        assert resolve_builtin(name) is BUILTIN_MODELS[name]

    def test_対応表は書き換えられない(self) -> None:
        """実行条件の再現性は、対応表が実行中に変化しないことに依存する。"""
        with pytest.raises(TypeError):
            BUILTIN_MODELS["linear"] = BUILTIN_MODELS["gaussian"]  # type: ignore[index]

    @pytest.mark.parametrize("name", REQUIRED_NAMES)
    def test_モデル実体を生成できる(self, name: str) -> None:
        spec = BUILTIN_MODELS[name]
        model = spec.create()
        assert model is not None
        assert spec.create() is not model, "呼び出しごとに独立した実体を返すこと"


class Test初期値の自動推定可否:
    @pytest.mark.parametrize("name", REQUIRED_NAMES)
    def test_自動推定の可否を保持している(self, name: str) -> None:
        assert isinstance(BUILTIN_MODELS[name].supports_auto_initial, bool)

    @pytest.mark.parametrize("name", REQUIRED_NAMES)
    def test_保持した可否が実際の推定可否と一致する(self, name: str) -> None:
        """宣言と実体の乖離を防ぐ。宣言だけを直しても、ここで落ちる。"""
        spec = BUILTIN_MODELS[name]
        x, y = _sample_for(name)
        model = spec.create()
        try:
            params = model.guess(y, x=x)
        except NotImplementedError:
            guessed = False
        else:
            guessed = bool(len(params)) and all(
                np.isfinite(p.value) for p in params.values()
            )
        assert guessed is spec.supports_auto_initial


class Test多項式の次数:
    def test_既定の次数が対応表に記録されている(self) -> None:
        """次数はモデル生成時に必須のため、既定値をレジストリが持つ必要がある。"""
        spec = BUILTIN_MODELS["polynomial"]
        assert spec.default_options[POLYNOMIAL_DEGREE_OPTION] == DEFAULT_POLYNOMIAL_DEGREE

    def test_既定の次数でパラメータ数が決まる(self) -> None:
        model = BUILTIN_MODELS["polynomial"].create()
        assert len(model.param_names) == DEFAULT_POLYNOMIAL_DEGREE + 1

    def test_次数を指定すると反映される(self) -> None:
        model = BUILTIN_MODELS["polynomial"].create({POLYNOMIAL_DEGREE_OPTION: 3})
        assert len(model.param_names) == 4

    def test_次数を持たないモデルは選択肢を持たない(self) -> None:
        assert BUILTIN_MODELS["gaussian"].default_options == {}

    def test_未知のオプション名を拒否する(self) -> None:
        with pytest.raises(ValueError, match="degrees"):
            BUILTIN_MODELS["polynomial"].create({"degrees": 3})


class Test適用される既定値の告知:
    """要件 5.4: 既定値で補う選択肢を、記録できる形で対応表が答える。

    対応表が答えるのは、既定値の所有者がここだからである。呼び出し側が
    「指定が無ければ 2」と書き写すと、所有が 2 か所に分かれ、片方だけの変更が
    記録と実行の食い違いになる。
    """

    def test_未指定なら既定の次数を返す(self) -> None:
        applied = BUILTIN_MODELS["polynomial"].applied_defaults()
        assert dict(applied) == {POLYNOMIAL_DEGREE_OPTION: DEFAULT_POLYNOMIAL_DEGREE}

    def test_明示された選択肢は含めない(self) -> None:
        applied = BUILTIN_MODELS["polynomial"].applied_defaults(
            {POLYNOMIAL_DEGREE_OPTION: 3}
        )
        assert dict(applied) == {}

    def test_選択肢を持たないモデルでは空である(self) -> None:
        assert dict(BUILTIN_MODELS["gaussian"].applied_defaults()) == {}

    def test_返した写像は書き換えられない(self) -> None:
        applied = BUILTIN_MODELS["polynomial"].applied_defaults()
        with pytest.raises(TypeError):
            applied[POLYNOMIAL_DEGREE_OPTION] = 9  # type: ignore[index]

    def test_告知した既定値は実際に組み立てへ効いている(self) -> None:
        """告知と組み立てが食い違えば、記録は実行を説明しない（要件 8.5）。"""
        spec = BUILTIN_MODELS["polynomial"]
        applied = spec.applied_defaults()
        assert len(spec.create().param_names) == applied[POLYNOMIAL_DEGREE_OPTION] + 1


class Test未知のモデル名:
    def test_未知名で違反を返す(self) -> None:
        """例外ではなく値で返す。実行前ゲートが全違反を集めるため（要件 3.4）。"""
        violation = resolve_builtin("gausian")
        assert isinstance(violation, ConfigViolation)
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED

    def test_違反は原因となった名前を含む(self) -> None:
        violation = resolve_builtin("gausian")
        assert isinstance(violation, ConfigViolation)
        assert "gausian" in violation.message

    def test_違反は選択可能な名前を示す(self) -> None:
        violation = resolve_builtin("gausian")
        assert isinstance(violation, ConfigViolation)
        for name in REQUIRED_NAMES:
            assert name in violation.message

    def test_違反は指定箇所を保持する(self) -> None:
        violation = resolve_builtin("gausian", location="methods[1].builtin")
        assert isinstance(violation, ConfigViolation)
        assert violation.location == "methods[1].builtin"

    @pytest.mark.parametrize("name", ["", "  ", "Linear", "linear "])
    def test_完全一致しない指定は未知として扱う(self, name: str) -> None:
        """綴りの揺れを黙って受け入れると、設定ファイルと実行結果の対応が崩れる。"""
        violation = resolve_builtin(name)
        assert isinstance(violation, ConfigViolation)
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED


def _module_source() -> str:
    return (SRC / "models" / "registry.py").read_text(encoding="utf-8")


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse(_module_source())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


def _names_bound_from(prefixes: set[str]) -> set[str]:
    """指定モジュール群から束縛された識別子（別名を含む）を集める。"""
    tree = ast.parse(_module_source())
    bound: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in prefixes:
                    bound.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            if node.module.split(".")[0] in prefixes:
                bound.update(alias.asname or alias.name for alias in node.names)
    return bound


def _public_annotations() -> list[str]:
    """公開シグネチャ（非私有の関数引数・戻り値・属性）の注釈を文字列で返す。"""
    tree = ast.parse(_module_source())
    annotations: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            if node.name.startswith("_") and node.name != "__init__":
                continue
            args = node.args
            for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs):
                if arg.annotation is not None and not arg.arg.startswith("_"):
                    annotations.append(ast.unparse(arg.annotation))
            if node.returns is not None:
                annotations.append(ast.unparse(node.returns))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if not node.target.id.startswith("_"):
                annotations.append(ast.unparse(node.annotation))
    return annotations


class Test依存の露出:
    def test_平滑化や描画のライブラリを_import_しない(self) -> None:
        """設計の Allowed Dependencies: SciPy は engines、matplotlib は plotting に閉じる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"scipy", "matplotlib", "pandas"}, (
                f"registry.py が {imported} を import している"
            )

    def test_公開シグネチャに基盤ライブラリの型が現れない(self) -> None:
        """内部で lmfit を使うことは前提。外向きの注釈に漏らさないことを検証する。"""
        leaked = _names_bound_from({"lmfit", "asteval"})
        assert leaked, "lmfit を import していない場合、この検証は無意味になる"
        for annotation in _public_annotations():
            used = {
                node.id for node in ast.walk(ast.parse(annotation)) if isinstance(node, ast.Name)
            }
            assert not (used & leaked), f"公開注釈 {annotation!r} が {used & leaked} を露出している"

    def test_自パッケージへの依存は下位レイヤに限る(self) -> None:
        own = {m for m in _imported_modules() if m.split(".")[0] == "curvefit"}
        allowed = {"curvefit.errors", "curvefit.types"}
        assert own <= allowed, f"想定外の依存: {own - allowed}"
