"""フィット前のデータ整形（欠損除去・区間限定・点数不足判定）を検証する。

対応要件: 2.1（指定された x の範囲内のデータ点のみを使用）、2.2（欠損値および数値として
解釈できない行を除外し、除外件数を記録）、2.3（残差に基づく外れ値の除去と、件数および
該当する x の記録）、2.4（残点数が不足する場合はフィットを実行せず点数不足を理由として
報告）、2.5（外れ値と判定した各点の x・実測値・何回目の判定で除外したかの記録）。

設計の Invariants（欠損除去は設定で無効化できない）、Postconditions（件数の合計が
元の点数と残った点数の差に一致する）、および入出力を持たない純粋計算であることも
あわせて検証する。
"""

from __future__ import annotations

import ast
import dataclasses
import inspect
from pathlib import Path

import numpy as np
import pytest

from curvefit.errors import FailureReason
from curvefit.preprocess import OutlierSpec, PreprocessSpec, apply_preprocess
from curvefit.types import (
    DataSeries,
    FitFailure,
    FloatArray,
    OutlierPoint,
    PreprocessReport,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

METHOD = "linear"
"""呼び出し側が供給する手法の識別名。前処理層は手法の内容を知らない。"""

SLOPE = 2.0
"""合成データの傾き。外れ値の検証では厳密にこの直線を暫定当てはめとして与える。"""


def _series(
    x: list[float],
    y: list[float],
    *,
    weights: list[float] | None = None,
    source_id: str = "sample.csv",
) -> DataSeries:
    return DataSeries(
        source_id=source_id,
        x=np.array(x, dtype=np.float64),
        y=np.array(y, dtype=np.float64),
        weights=None if weights is None else np.array(weights, dtype=np.float64),
    )


def _exact_line(series: DataSeries) -> FloatArray:
    """厳密に ``y = 2x`` を返す暫定当てはめ。

    実在のエンジンではなく既知の直線を返すことで、残差が意図的に混入した外れ値だけに
    現れる状態を作る。判定閾値の検算が手計算で行えるため、期待値を実装から逆算せずに
    書ける。
    """
    return SLOPE * series.x


X_ORIGIN = 10.0
"""合成データの x の始点。

0 から始めると x の値と配列上の位置が一致してしまい、「除外した x」ではなく「除外した
位置」を記録する実装を見逃す。
"""


def _spiked_x(n: int) -> list[float]:
    return [X_ORIGIN + float(i) for i in range(n)]


def _line_with_spikes(n: int, spikes: dict[int, float]) -> DataSeries:
    """``y = 2x`` の合成データに、指定した位置だけ既知の量だけずれた点を混入する。"""
    x = _spiked_x(n)
    y = [SLOPE * value for value in x]
    for index, offset in spikes.items():
        y[index] += offset
    return _series(x, y)


def _ok(result: object) -> tuple[DataSeries, PreprocessReport]:
    """前処理が成功したことを確かめ、その結果を返す。"""
    assert not isinstance(result, FitFailure), (
        f"成功するはずが失敗した: {getattr(result, 'message', result)}"
    )
    assert isinstance(result, tuple)
    series, report = result
    assert isinstance(series, DataSeries)
    assert isinstance(report, PreprocessReport)
    return series, report


def _failure(result: object) -> FitFailure:
    """前処理が失敗したことを確かめ、その失敗を返す。"""
    assert isinstance(result, FitFailure), f"失敗が返るはずが {type(result).__name__} だった"
    return result


def _outlier_xs(report: PreprocessReport) -> tuple[float, ...]:
    """除外した点の x だけを、記録された並び（除去順）のまま取り出す。

    x 以外の欄（実測値・反復回数）は :class:`Test除外した点の記録` が固定する。
    """
    return tuple(point.x for point in report.outlier_points)


class Test欠損と不正値の除去:
    """要件 2.2: 欠損値を含む行および数値として解釈できない行を除外し件数を記録する。"""

    def test_欠損値を含む点を除外し件数を記録する(self) -> None:
        result = apply_preprocess(
            _series([0.0, 1.0, 2.0, 3.0], [1.0, np.nan, 3.0, 4.0]),
            PreprocessSpec(),
            min_points=1,
            method_name=METHOD,
        )
        series, report = _ok(result)
        assert report.n_dropped_invalid == 1
        assert len(series) == 3
        assert np.array_equal(series.x, np.array([0.0, 2.0, 3.0]))
        assert np.array_equal(series.y, np.array([1.0, 3.0, 4.0]))

    def test_x_側の欠損も除外する(self) -> None:
        series, report = _ok(
            apply_preprocess(
                _series([0.0, np.nan, 2.0], [1.0, 2.0, 3.0]),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_invalid == 1
        assert np.array_equal(series.x, np.array([0.0, 2.0]))

    @pytest.mark.parametrize("bad", [np.inf, -np.inf])
    def test_数値として扱えない無限大を除外する(self, bad: float) -> None:
        """無限大は浮動小数点値ではあるが、残差を評価できないため除外対象とする。"""
        series, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [1.0, bad, 3.0]),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_invalid == 1
        assert np.array_equal(series.y, np.array([1.0, 3.0]))

    def test_重みの欠損も行ごと除外する(self) -> None:
        """重みが欠損した点は当てはめに寄与できない。x/y だけ残すと長さが食い違う。"""
        series, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [1.0, 2.0, 3.0], weights=[1.0, np.nan, 1.0]),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_invalid == 1
        assert series.weights is not None
        assert np.array_equal(series.x, np.array([0.0, 2.0]))
        assert np.array_equal(series.weights, np.array([1.0, 1.0]))

    def test_重みを持つ入力では重みも同じ長さで返る(self) -> None:
        series, _ = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [1.0, np.nan, 3.0], weights=[1.0, 2.0, 3.0]),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert series.weights is not None
        assert len(series.weights) == len(series)
        assert np.array_equal(series.weights, np.array([1.0, 3.0]))

    def test_欠損のない入力では件数が_0_になる(self) -> None:
        _, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0], [1.0, 2.0]),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_invalid == 0

    def test_欠損除去は設定で無効化できない(self) -> None:
        """設計の Invariants: 要件 2.2 は無条件の shall である。

        指定できる設定項目に欠損除去の可否が現れないことを構造として確かめる。
        """
        names = {field.name for field in dataclasses.fields(PreprocessSpec)}
        assert names == {"x_min", "x_max", "outlier"}, f"想定外の設定項目: {names}"


class Test区間限定:
    """要件 2.1: 指定された x の範囲内にあるデータ点のみを使用する。"""

    def test_下限より小さい点を除外し件数を記録する(self) -> None:
        series, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0, 3.0], [0.0, 1.0, 2.0, 3.0]),
                PreprocessSpec(x_min=2.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_out_of_range == 2
        assert np.array_equal(series.x, np.array([2.0, 3.0]))

    def test_上限より大きい点を除外し件数を記録する(self) -> None:
        series, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0, 3.0], [0.0, 1.0, 2.0, 3.0]),
                PreprocessSpec(x_max=1.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_out_of_range == 2
        assert np.array_equal(series.x, np.array([0.0, 1.0]))

    def test_上下限を同時に指定できる(self) -> None:
        series, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0, 3.0, 4.0], [0.0, 1.0, 2.0, 3.0, 4.0]),
                PreprocessSpec(x_min=1.0, x_max=3.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_out_of_range == 2
        assert np.array_equal(series.x, np.array([1.0, 2.0, 3.0]))

    def test_境界上の点は範囲内として残す(self) -> None:
        """「範囲内」に端点を含める。端点を落とすと利用者が指定した区間より狭くなる。"""
        series, report = _ok(
            apply_preprocess(
                _series([1.0, 2.0, 3.0], [1.0, 2.0, 3.0]),
                PreprocessSpec(x_min=1.0, x_max=3.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_out_of_range == 0
        assert len(series) == 3

    def test_区間の指定がなければ全点を残す(self) -> None:
        series, report = _ok(
            apply_preprocess(
                _series([0.0, 5.0, 10.0], [0.0, 1.0, 2.0]),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_out_of_range == 0
        assert len(series) == 3

    def test_上下限が逆転した指定では点が残らず点数不足になる(self) -> None:
        """設定の妥当性検証は実行前ゲートの担当。ここで例外を送出するとバッチが落ちる。"""
        failure = _failure(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [0.0, 1.0, 2.0]),
                PreprocessSpec(x_min=2.0, x_max=1.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS


class Test適用順序:
    """設計の Responsibilities: 欠損除去 → 区間限定 の順序は固定であり設定で変えられない。"""

    def test_区間外かつ欠損の点は欠損として数える(self) -> None:
        """順序が逆なら区間外として数えられる。件数の内訳が順序を一意に示す。"""
        _, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 100.0], [0.0, 1.0, np.nan]),
                PreprocessSpec(x_max=10.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_invalid == 1
        assert report.n_dropped_out_of_range == 0

    def test_x_が欠損した点は区間外ではなく欠損として数える(self) -> None:
        """欠損した x は範囲比較が常に偽になるため、順序が逆だと区間外に化ける。"""
        _, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, np.nan], [0.0, 1.0, 2.0]),
                PreprocessSpec(x_min=0.0, x_max=10.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_invalid == 1
        assert report.n_dropped_out_of_range == 0

    def test_順序を変更する設定項目を持たない(self) -> None:
        parameters = inspect.signature(apply_preprocess).parameters
        assert "order" not in parameters
        assert not any("order" in field.name for field in dataclasses.fields(PreprocessSpec))


class Test点数不足:
    """要件 2.4: 残点数が最小点数を下回る場合、フィットを実行せず点数不足を報告する。"""

    def test_残点数が最小点数を下回ると失敗結果を返す(self) -> None:
        failure = _failure(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [0.0, np.nan, np.nan]),
                PreprocessSpec(),
                min_points=3,
                method_name=METHOD,
            )
        )
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS

    def test_例外ではなく値として失敗を返す(self) -> None:
        """設計の Error Strategy: 想定内の失敗は値として運ぶ。"""
        result = apply_preprocess(
            _series([0.0], [0.0]),
            PreprocessSpec(),
            min_points=5,
            method_name=METHOD,
        )
        assert isinstance(result, FitFailure)

    def test_失敗結果が対象と手法を含む(self) -> None:
        """設計の Error Categories: 個別データの失敗は source_id と method_name を必ず含む。"""
        failure = _failure(
            apply_preprocess(
                _series([0.0], [0.0], source_id="run/a.csv"),
                PreprocessSpec(),
                min_points=2,
                method_name="gaussian",
            )
        )
        assert failure.source_id == "run/a.csv"
        assert failure.method_name == "gaussian"

    def test_失敗結果が前処理の記録を保持する(self) -> None:
        """何点がなぜ落ちたのかが分からなければ、利用者は次の行動を選べない。"""
        failure = _failure(
            apply_preprocess(
                _series([0.0, 1.0, 50.0, 60.0], [0.0, np.nan, 2.0, 3.0]),
                PreprocessSpec(x_max=10.0),
                min_points=3,
                method_name=METHOD,
            )
        )
        assert failure.preprocess is not None
        assert failure.preprocess.n_input == 4
        assert failure.preprocess.n_dropped_invalid == 1
        assert failure.preprocess.n_dropped_out_of_range == 2
        assert failure.preprocess.n_used == 1

    def test_失敗の説明に残点数と必要点数が現れる(self) -> None:
        failure = _failure(
            apply_preprocess(
                _series([0.0, 1.0], [0.0, 1.0]),
                PreprocessSpec(),
                min_points=7,
                method_name=METHOD,
            )
        )
        assert "2" in failure.message
        assert "7" in failure.message

    def test_最小点数と等しい場合は成功する(self) -> None:
        series, _ = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [0.0, 1.0, 2.0]),
                PreprocessSpec(),
                min_points=3,
                method_name=METHOD,
            )
        )
        assert len(series) == 3

    def test_最小点数が_0_なら空系列でも成功する(self) -> None:
        """点数の下限は呼び出し側が決める。前処理層は手法を知らない。"""
        series, report = _ok(
            apply_preprocess(
                _series([np.nan], [np.nan]),
                PreprocessSpec(),
                min_points=0,
                method_name=METHOD,
            )
        )
        assert len(series) == 0
        assert report.n_used == 0


class Test除去件数の整合:
    """設計の Postconditions: 件数の合計は元の点数と残った点数の差に一致する。"""

    def test_入力点数と各件数の差が残点数に一致する(self) -> None:
        series, report = _ok(
            apply_preprocess(
                _series(
                    [0.0, 1.0, np.nan, 3.0, 40.0, 50.0],
                    [0.0, np.inf, 2.0, 3.0, 4.0, 5.0],
                ),
                PreprocessSpec(x_min=0.0, x_max=10.0),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_input == 6
        assert report.n_dropped_invalid == 2
        assert report.n_dropped_out_of_range == 2
        assert report.n_used == len(series) == 2

    def test_全点が有効なら入力点数と残点数が等しい(self) -> None:
        series, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [0.0, 1.0, 2.0]),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_input == len(series) == 3
        assert report.n_used == 3


class Test外れ値除去の契約:
    """要件 2.3 の設定項目そのもの（既定値・凍結・コールバック受け渡し）を確かめる。"""

    def test_外れ値除去を行わない場合は件数が_0_で位置の記録が空になる(self) -> None:
        _, report = _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [0.0, 1.0, 2.0]),
                PreprocessSpec(outlier=None),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert report.outlier_points == ()

    def test_外れ値除去の設定を既定では持たない(self) -> None:
        assert PreprocessSpec().outlier is None

    def test_外れ値除去の閾値と反復上限が既定値を持つ(self) -> None:
        """要件 8.2 の決定性: 閾値と反復上限を固定しなければ再実行で結果が揺れる。"""
        spec = OutlierSpec()
        assert spec.sigma == 3.0
        assert spec.max_iterations == 3

    def test_暫定当てはめをコールバックとして受け取る(self) -> None:
        """設計の Service Interface: エンジンはコールバックで渡され、前処理層は engines に依存しない。"""
        parameter = inspect.signature(apply_preprocess).parameters["provisional_fit"]
        assert parameter.default is None

    def test_設定と暫定当てはめを与えても呼び出せる(self) -> None:
        result = apply_preprocess(
            _series([0.0, 1.0, 2.0], [0.0, 1.0, 2.0]),
            PreprocessSpec(outlier=OutlierSpec()),
            min_points=1,
            provisional_fit=lambda series: series.y,
            method_name=METHOD,
        )
        _ok(result)


class _RecordingFit:
    """呼び出しを記録する暫定当てはめ。何回、どの系列に対して呼ばれたかを検証する。"""

    def __init__(self) -> None:
        self.calls: list[DataSeries] = []

    def __call__(self, series: DataSeries) -> FloatArray:
        self.calls.append(series)
        return _exact_line(series)


class _FitFailingAfter:
    """指定回数だけ成功し、その後は非収束を模して例外を送出する暫定当てはめ。"""

    def __init__(self, successes: int, error: type[BaseException] = RuntimeError) -> None:
        self._successes = successes
        self._error = error
        self.calls = 0

    def __call__(self, series: DataSeries) -> FloatArray:
        self.calls += 1
        if self.calls > self._successes:
            raise self._error("暫定当てはめが収束しなかった")
        return _exact_line(series)


class Test外れ値除去:
    """要件 2.3: 残差に基づいて外れ値と判定した点を除外し、件数と x の値を記録する。"""

    def test_混入した外れ値が除外され件数と位置が記録される(self) -> None:
        """完了状態: 意図的に外れ値を混入した合成データで、該当点が除外されること。"""
        series, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 1
        assert _outlier_xs(report) == (13.0,)
        assert len(series) == 11
        assert 13.0 not in set(series.x.tolist())

    def test_外れ値でない点は残る(self) -> None:
        """混入した点以外が巻き込まれれば、当てはめに使えるデータが失われる。"""
        series, _ = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        expected = [value for index, value in enumerate(_spiked_x(12)) if index != 3]
        assert series.x.tolist() == expected
        assert series.y.tolist() == [SLOPE * value for value in expected]

    def test_外れ値のない合成データでは何も除外しない(self) -> None:
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert report.outlier_points == ()

    def test_系統的なずれだけでは外れ値にならない(self) -> None:
        """全点が同量ずれている場合、突出した点は存在しない。

        残差の中心を 0 と置いたうえで散らばりを残差自身から測るため、一律のずれは
        判定尺度も同じだけ大きくし、誰も閾値を越えない。ここで全点を落とす実装だと、
        暫定当てはめが少しずれただけでデータが消える。

        この性質の裏返し（一律のずれに乗った突出点も見えなくなる）は
        :meth:`test_一律にずれた当てはめでは突出した点も除去しない` で固定する。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=lambda series: SLOPE * series.x - 5.0,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0

    def test_閾値を大きくすると同じ点が外れ値にならない(self) -> None:
        """sigma が判定に効いていることを、同一データの結果の差で示す。"""
        data = _line_with_spikes(12, {3: 50.0})
        _, strict = _ok(
            apply_preprocess(
                data,
                PreprocessSpec(outlier=OutlierSpec(sigma=3.0)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        _, loose = _ok(
            apply_preprocess(
                data,
                PreprocessSpec(outlier=OutlierSpec(sigma=5.0)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert strict.n_dropped_outlier == 1
        assert loose.n_dropped_outlier == 0

    def test_反復により初回に埋もれた外れ値も除外される(self) -> None:
        """大きな外れ値が散らばりを押し上げ、小さな外れ値は初回では閾値内に収まる。

        記録の並びは除去した順である。x が小さい方を後から除去する配置にして、
        単に昇順へ並べただけの記録と区別する。
        """
        series, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=3)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 2
        assert _outlier_xs(report) == (19.0, 13.0)
        assert len(series) == 10

    def test_反復上限で打ち切る(self) -> None:
        """上限を固定しなければ再実行で結果が揺れる（要件 8.2）。"""
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=1)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 1
        assert _outlier_xs(report) == (19.0,)

    def test_反復上限に達するまでしか暫定当てはめを呼ばない(self) -> None:
        recorder = _RecordingFit()
        _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=1)),
                min_points=1,
                provisional_fit=recorder,
                method_name=METHOD,
            )
        )
        assert len(recorder.calls) == 1

    def test_設定が_None_なら外れ値を混入しても除外しない(self) -> None:
        """要件 2.3 は「外れ値除去が有効な場合」の条件付き shall である。"""
        recorder = _RecordingFit()
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=None),
                min_points=1,
                provisional_fit=recorder,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert recorder.calls == []

    def test_暫定当てはめが未指定なら外れ値除去を行わない(self) -> None:
        """残差を得る手段がなければ判定できない。ここで失敗にする理由はない。"""
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=None,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert report.outlier_points == ()

    def test_重みは除外後も残った点と対応し続ける(self) -> None:
        data = _line_with_spikes(12, {3: 50.0})
        weights = [float(i + 1) for i in range(12)]
        series, report = _ok(
            apply_preprocess(
                _series(data.x.tolist(), data.y.tolist(), weights=weights),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 1
        assert series.weights is not None
        assert len(series.weights) == len(series)
        assert series.weights.tolist() == [float(i + 1) for i in range(12) if i != 3]

    # 以下 6 件は判定尺度そのもの（残差の二乗平均平方根＝中心を 0 と置いた標準偏差）を
    # 固定する。中心を標本平均に置く尺度と結果が食い違う配置、および除去が原理的に
    # 起こらない配置を選んである。前者は尺度を差し替えれば落ち、後者は利用者に見える
    # 契約（有効にしても何も起きない範囲）である。

    @pytest.mark.parametrize("magnitude", [1e1, 1e6, 1e150])
    def test_点数が_9_以下なら単一の外れ値をどれほど大きくしても除去しない(
        self, magnitude: float
    ) -> None:
        """判定は残差の比だけで決まり、``|r_i| / RMS(r)`` は ``sqrt(n)`` を越えない。

        既定の ``sigma=3.0`` では ``n <= 9`` の系列で単一の外れ値が閾値に届かない。
        外れ値の大きさは判定尺度も同じだけ押し上げるためであり、桁を変えても結果は
        変わらない。除去を有効にしても何も起きない範囲であり、盲点として固定する。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(8, {3: magnitude}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert report.outlier_points == ()

    def test_点数が_10_なら同じ配置の単一の外れ値を除去する(self) -> None:
        """``n > sigma**2`` を満たす最小の点数。8 点との差が判定尺度の内容そのもの。

        中心を標本平均に置く尺度では検出できる範囲が ``n > sigma**2 + 1`` となり、
        10 点はその境界にちょうど届かず 0 件になる。この 1 点差がここで固定する差である。
        """
        series, report = _ok(
            apply_preprocess(
                _line_with_spikes(10, {3: 1e6}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 1
        assert _outlier_xs(report) == (13.0,)
        assert len(series) == 9

    def test_同程度の外れ値が_2_点ある_12_点の系列では除去しない(self) -> None:
        """同程度の外れ値が ``k >= n / sigma**2`` 点あると、互いの存在で閾値に届かない。

        12 点中の 2 点はこれに当たる。1 点なら除去される大きさ（
        :meth:`test_混入した外れ値が除外され件数と位置が記録される`）でも、2 点そろうと
        1 点も除去されない。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 1e6, 9: 1e6}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert report.outlier_points == ()

    def test_外れ値が_2_点でも_19_点あれば両方を除去する(self) -> None:
        """``n > sigma**2 * k`` を満たせば同数の外れ値でも除去される。

        12 点との差が、除去されるか否かが点数と外れ値の個数の比で決まることを示す。
        中心を標本平均に置く尺度では 19 点でも 0 件にとどまる。
        """
        series, report = _ok(
            apply_preprocess(
                _line_with_spikes(19, {3: 1e6, 9: 1e6}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 2
        assert _outlier_xs(report) == (13.0, 19.0)
        assert len(series) == 17

    def test_一律にずれた当てはめでは突出した点も除去しない(self) -> None:
        """一律のずれが判定尺度を押し上げ、その上に乗った突出点が閾値内に収まる。

        :meth:`test_混入した外れ値が除外され件数と位置が記録される` と同じ 12 点・同じ
        突出量でありながら、暫定当てはめが全点で 100 ずれているだけで 0 件になる。
        中心を標本平均に置く尺度なら一律のずれは相殺され、この点は除去される。
        一律のずれで全点が外れ値に化けないこと（
        :meth:`test_系統的なずれだけでは外れ値にならない`）と同じ性質の裏返しであり、
        盲点として固定する。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=lambda series: SLOPE * series.x - 100.0,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert report.outlier_points == ()

    @pytest.mark.parametrize("factor", [1e-9, 1.0, 1e9])
    def test_判定は残差の大きさの比だけで決まる(self, factor: float) -> None:
        """残差全体を定数倍しても除去される点は変わらない。

        尺度が残差自身から決まるため、判定は絶対量ではなく比で行われる。点数の少ない
        系列で除去が起きないという盲点は、この性質から出ている。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0 * factor}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 1
        assert _outlier_xs(report) == (13.0,)


class Test除外した点の記録:
    """要件 2.5: 除外した各点の x・実測値・何回目の判定で除外したかを記録する。

    件数（要件 2.3）だけでは「どんな点が外れ値とされたか」が利用者に届かない。実測値が
    なければ元データを引き直すことになり、反復回数がなければ 1 回目で外れた点と 3 回目で
    外れた点を同じ確かさとして扱うことになる。
    """

    def test_除外した点の_x_と実測値と反復回数を記録する(self) -> None:
        """完了状態: 除外した各点の x・実測値・反復回数が得られること。

        実測値は ``y = 2x`` から 50 ずれた点そのもの（``2 * 13 + 50``）であり、暫定
        当てはめが返した値（``2 * 13``）ではない。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.outlier_points == (OutlierPoint(x=13.0, y=76.0, iteration=1),)

    def test_記録される実測値は当てはめ値ではなく入力の実測値である(self) -> None:
        """当てはめ値を記録すると、除外の理由となったずれが記録から消える。"""
        data = _line_with_spikes(12, {3: 50.0})
        _, report = _ok(
            apply_preprocess(
                data,
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        (point,) = report.outlier_points
        index = data.x.tolist().index(point.x)
        assert point.y == data.y.tolist()[index]
        assert point.y != _exact_line(data).tolist()[index]

    @pytest.mark.parametrize("spike_index", [0, 3, 11])
    def test_どの位置の点を除外しても実測値が対応する(self, spike_index: int) -> None:
        """位置をずらして、記録される実測値が「除外した点の y」であることを固定する。

        先頭や末尾の値を機械的に拾う実装、および除外後に残った側の y を拾う実装は、
        いずれかの位置で食い違う。
        """
        data = _line_with_spikes(12, {spike_index: 1e6})
        _, report = _ok(
            apply_preprocess(
                data,
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        expected_x = _spiked_x(12)[spike_index]
        assert report.outlier_points == (
            OutlierPoint(x=expected_x, y=SLOPE * expected_x + 1e6, iteration=1),
        )

    def test_反復をまたぐと反復回数が増える(self) -> None:
        """1 回目で外れた点と 2 回目で外れた点に別の番号が付く（要件 2.5）。

        大きな外れ値が散らばりを押し上げるため、小さい方は 1 回目では閾値内に収まり、
        2 回目の判定で初めて外れる。並びは除去順であり、x の昇順ではない。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=3)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.outlier_points == (
            OutlierPoint(x=19.0, y=SLOPE * 19.0 + 50.0, iteration=1),
            OutlierPoint(x=13.0, y=SLOPE * 13.0 + 20.0, iteration=2),
        )
        assert [point.iteration for point in report.outlier_points] == [1, 2]

    def test_2_回目に外れる点が_1_回目より後ろにあっても記録が対応する(self) -> None:
        """反復をまたぐ索引のずれで、記録する x と実測値が別の点にならないこと。

        1 回目の除去で系列は縮む。2 回目に外れる点が 1 回目の除去位置より **後ろ** に
        あると、縮む前の系列を見て記録した場合に 1 つずれた点を拾う。上の
        :meth:`test_反復をまたぐと反復回数が増える` は 2 回目の点が 1 回目より前に
        あるため、この取り違えを検出できない。両方向を残す。
        """
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0, 9: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=3)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.outlier_points == (
            OutlierPoint(x=13.0, y=SLOPE * 13.0 + 50.0, iteration=1),
            OutlierPoint(x=19.0, y=SLOPE * 19.0 + 20.0, iteration=2),
        )

    def test_反復回数は_1_起点である(self) -> None:
        """0 起点だと「1 回目の判定」を 0 と読ませることになる。"""
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert [point.iteration for point in report.outlier_points] == [1]

    def test_同一の反復で除外した点は入力の並び順に並ぶ(self) -> None:
        """反復内の並びは入力だけで決まる（要件 8.2）。"""
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(19, {9: 1e6, 3: 1e6}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.outlier_points == (
            OutlierPoint(x=13.0, y=SLOPE * 13.0 + 1e6, iteration=1),
            OutlierPoint(x=19.0, y=SLOPE * 19.0 + 1e6, iteration=1),
        )

    def test_並びは除去順であり_x_の昇順ではない(self) -> None:
        """記録を並べ替えると、どちらの点が先に外れたのかが読めなくなる。"""
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=3)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        xs = [point.x for point in report.outlier_points]
        assert xs == [19.0, 13.0]
        assert xs != sorted(xs)

    def test_記録件数は除外件数と一致する(self) -> None:
        """型が課す不変条件（要件 2.3 の件数と要件 2.5 の記録の一致）を経路上で確かめる。"""
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=3)),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert len(report.outlier_points) == report.n_dropped_outlier == 2

    def test_反復途中の非収束でも確定済みの記録が残る(self) -> None:
        """先に確定した判定は、後続の反復が失敗しても無効にならない。"""
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=3)),
                min_points=1,
                provisional_fit=_FitFailingAfter(successes=1),
                method_name=METHOD,
            )
        )
        assert report.outlier_points == (
            OutlierPoint(x=19.0, y=SLOPE * 19.0 + 50.0, iteration=1),
        )


class Test外れ値除去の適用順序:
    """設計の Responsibilities: 外れ値判定は区間内の残差に基づくため、区間限定より後。"""

    def test_外れ値判定は区間限定後の点だけを対象とする(self) -> None:
        recorder = _RecordingFit()
        _ok(
            apply_preprocess(
                _series(
                    [0.0, 1.0, 2.0, 3.0, 4.0, 50.0],
                    [0.0, 2.0, 4.0, 6.0, 8.0, 100.0],
                ),
                PreprocessSpec(x_max=10.0, outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=recorder,
                method_name=METHOD,
            )
        )
        assert recorder.calls, "暫定当てはめが呼ばれていない"
        assert recorder.calls[0].x.tolist() == [0.0, 1.0, 2.0, 3.0, 4.0]

    def test_区間外の点は外れ値ではなく区間外として数える(self) -> None:
        _, report = _ok(
            apply_preprocess(
                _series(
                    [0.0, 1.0, 2.0, 3.0, 4.0, 50.0],
                    [0.0, 2.0, 4.0, 6.0, 8.0, 999.0],
                ),
                PreprocessSpec(x_max=10.0, outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_out_of_range == 1
        assert report.n_dropped_outlier == 0

    def test_欠損は外れ値判定に持ち込まれない(self) -> None:
        """残差が算出できない点が判定尺度に混じると、閾値が意味を失う。"""
        recorder = _RecordingFit()
        _ok(
            apply_preprocess(
                _series([0.0, 1.0, 2.0, 3.0], [0.0, np.nan, 4.0, 6.0]),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=recorder,
                method_name=METHOD,
            )
        )
        assert recorder.calls[0].x.tolist() == [0.0, 2.0, 3.0]


class Test暫定当てはめの非収束:
    """設計の Risks: 非収束時は外れ値除去をスキップし、除去 0 件として当てはめに進む。

    ここで失敗にすると、外れ値除去を有効にしただけで成功していたはずのジョブが落ちる。
    """

    def test_例外を送出した場合は除去せず処理を継続する(self) -> None:
        def failing(series: DataSeries) -> FloatArray:
            raise RuntimeError("収束しなかった")

        series, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=failing,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0
        assert report.outlier_points == ()
        assert len(series) == 12

    def test_None_を返した場合は除去せず処理を継続する(self) -> None:
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=lambda series: None,  # type: ignore[arg-type, return-value]
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0

    def test_非有限値を返した場合は除去せず処理を継続する(self) -> None:
        """発散した当てはめは残差を評価できない。"""
        def diverged(series: DataSeries) -> FloatArray:
            values = SLOPE * series.x
            values[0] = np.nan
            return values

        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=diverged,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0

    def test_長さの異なる配列を返した場合は除去せず処理を継続する(self) -> None:
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=lambda series: (SLOPE * series.x)[:-1],
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 0

    def test_反復途中の非収束では確定済みの除外を保持する(self) -> None:
        """初回の判定は収束した当てはめに基づく。取り消す理由がない。"""
        provisional = _FitFailingAfter(successes=1)
        _, report = _ok(
            apply_preprocess(
                _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                PreprocessSpec(outlier=OutlierSpec(max_iterations=3)),
                min_points=1,
                provisional_fit=provisional,
                method_name=METHOD,
            )
        )
        assert report.n_dropped_outlier == 1
        assert _outlier_xs(report) == (19.0,)

    @pytest.mark.parametrize("error", [MemoryError, OSError])
    def test_資源枯渇の例外は握りつぶさない(self, error: type[BaseException]) -> None:
        """設計の Error Strategy: 例外を制御フローに使うのは資源枯渇の捕捉のみ。

        非収束として黙って飲み込むと、要件 10.3 が求める中断対象の明示ができなくなる。
        """
        with pytest.raises(error):
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_FitFailingAfter(successes=0, error=error),
                method_name=METHOD,
            )


class Test外れ値除去と点数不足:
    """要件 2.4 との組み合わせ。外れ値除去は最終的な点数判定より前に完了する。"""

    def test_外れ値除去で点数が下限を下回ると点数不足として報告する(self) -> None:
        failure = _failure(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=12,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS
        assert failure.preprocess is not None
        assert failure.preprocess.n_dropped_outlier == 1
        assert failure.preprocess.n_used == 11

    def test_失敗の説明に外れ値の除外件数が現れる(self) -> None:
        failure = _failure(
            apply_preprocess(
                _line_with_spikes(12, {3: 50.0}),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=12,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert "外れ値を 1 点" in failure.message

    def test_点数がすでに不足していれば暫定当てはめを呼ばない(self) -> None:
        """当てはめられない点数の系列に暫定当てはめを試みる意味はない。

        呼べばエンジン側の例外を非収束として飲み込むだけで、報告される失敗は同じ
        点数不足になる。呼ばない方が、失敗の原因が欠損・区間指定にあることを保てる。
        """
        recorder = _RecordingFit()
        failure = _failure(
            apply_preprocess(
                _series([0.0, 1.0, 2.0], [0.0, 2.0, 4.0]),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=5,
                provisional_fit=recorder,
                method_name=METHOD,
            )
        )
        assert recorder.calls == []
        assert failure.reason is FailureReason.INSUFFICIENT_POINTS
        assert failure.preprocess is not None
        assert failure.preprocess.n_dropped_outlier == 0

    def test_空の系列でも暫定当てはめを呼ばない(self) -> None:
        recorder = _RecordingFit()
        _, report = _ok(
            apply_preprocess(
                _series([np.nan], [np.nan]),
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=0,
                provisional_fit=recorder,
                method_name=METHOD,
            )
        )
        assert recorder.calls == []
        assert report.n_dropped_outlier == 0

    def test_三段階すべての件数の合計が残点数に一致する(self) -> None:
        """設計の Postconditions: 件数の合計は元の点数と残った点数の差に一致する。"""
        x = _spiked_x(12) + [50.0, 15.5]
        y = [SLOPE * value for value in _spiked_x(12)] + [100.0, np.nan]
        y[3] += 50.0
        series, report = _ok(
            apply_preprocess(
                _series(x, y),
                PreprocessSpec(x_max=30.0, outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert report.n_input == 14
        assert report.n_dropped_invalid == 1
        assert report.n_dropped_out_of_range == 1
        assert report.n_dropped_outlier == 1
        assert report.n_used == len(series) == 11
        assert len(report.outlier_points) == report.n_dropped_outlier


class Test外れ値除去の決定性と純粋性:
    """要件 8.2: 同一設定・同一入力の再実行は同一結果でなければならない。"""

    def test_同一入力に対して同一の除外結果を返す(self) -> None:
        def run() -> tuple[DataSeries, PreprocessReport]:
            return _ok(
                apply_preprocess(
                    _line_with_spikes(12, {9: 50.0, 3: 20.0}),
                    PreprocessSpec(outlier=OutlierSpec()),
                    min_points=1,
                    provisional_fit=_exact_line,
                    method_name=METHOD,
                )
            )

        first_series, first_report = run()
        second_series, second_report = run()
        assert first_report == second_report
        assert np.array_equal(first_series.x, second_series.x)
        assert np.array_equal(first_series.y, second_series.y)

    def test_外れ値除去を経ても入力の配列を書き換えない(self) -> None:
        source = _line_with_spikes(12, {3: 50.0})
        before_x = source.x.copy()
        before_y = source.y.copy()
        _ok(
            apply_preprocess(
                source,
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        assert np.array_equal(source.x, before_x)
        assert np.array_equal(source.y, before_y)
        assert len(source) == 12

    def test_外れ値除去後の配列が入力と記憶領域を共有しない(self) -> None:
        source = _line_with_spikes(12, {3: 50.0})
        series, _ = _ok(
            apply_preprocess(
                source,
                PreprocessSpec(outlier=OutlierSpec()),
                min_points=1,
                provisional_fit=_exact_line,
                method_name=METHOD,
            )
        )
        series.y[0] = 999.0
        assert source.y[0] == SLOPE * X_ORIGIN


class Test純粋性と決定性:
    """設計: preprocess は入出力を持たない純粋計算である。要件 8.2 の再現性の土台。"""

    def test_入力の配列を書き換えない(self) -> None:
        source = _series([0.0, 1.0, 2.0], [0.0, np.nan, 2.0], weights=[1.0, 1.0, 1.0])
        before_x = source.x.copy()
        before_y = source.y.copy()
        _ok(apply_preprocess(source, PreprocessSpec(x_max=1.5), 1, method_name=METHOD))
        assert np.array_equal(source.x, before_x, equal_nan=True)
        assert np.array_equal(source.y, before_y, equal_nan=True)
        assert len(source) == 3

    def test_返した配列が入力と記憶領域を共有しない(self) -> None:
        source = _series([0.0, 1.0, 2.0], [0.0, 1.0, 2.0])
        series, _ = _ok(apply_preprocess(source, PreprocessSpec(), 1, method_name=METHOD))
        series.y[0] = 99.0
        assert source.y[0] == 0.0

    def test_同一入力に対して同一結果を返す(self) -> None:
        def run() -> tuple[DataSeries, PreprocessReport]:
            return _ok(
                apply_preprocess(
                    _series([0.0, 1.0, np.nan, 3.0, 40.0], [0.0, 1.0, 2.0, np.nan, 4.0]),
                    PreprocessSpec(x_min=0.0, x_max=10.0),
                    min_points=1,
                    method_name=METHOD,
                )
            )

        first_series, first_report = run()
        second_series, second_report = run()
        assert np.array_equal(first_series.x, second_series.x)
        assert np.array_equal(first_series.y, second_series.y)
        assert first_report == second_report

    def test_識別子を引き継ぐ(self) -> None:
        series, _ = _ok(
            apply_preprocess(
                _series([0.0, 1.0], [0.0, 1.0], source_id="data/run7.csv"),
                PreprocessSpec(),
                min_points=1,
                method_name=METHOD,
            )
        )
        assert series.source_id == "data/run7.csv"

    def test_設定が凍結されている(self) -> None:
        spec = PreprocessSpec(x_min=0.0)
        with pytest.raises(dataclasses.FrozenInstanceError):
            spec.x_min = 1.0  # type: ignore[misc]
        with pytest.raises(dataclasses.FrozenInstanceError):
            OutlierSpec().sigma = 1.0  # type: ignore[misc]


def _module_source() -> str:
    return (SRC / "preprocess.py").read_text(encoding="utf-8")


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse(_module_source())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class Test依存の露出:
    def test_他領域の基盤ライブラリを_import_しない(self) -> None:
        """設計の Allowed Dependencies: 前処理層が扱うのは NumPy 配列のみ。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas"}, (
                f"preprocess.py が {imported} を import している"
            )

    def test_自パッケージでは基盤型だけに依存する(self) -> None:
        """設計の依存方向: preprocess は types / errors までしか参照しない。

        特に engines への依存を持たないことが、暫定当てはめをコールバックで受け取る
        設計判断の目的である。
        """
        own = {m for m in _imported_modules() if m.split(".")[0] == "curvefit"}
        assert own <= {"curvefit.types", "curvefit.errors"}, (
            f"想定外の依存: {own - {'curvefit.types', 'curvefit.errors'}}"
        )

    def test_入出力を行わない(self) -> None:
        """設計: engines / preprocess はファイル・端末・ログに触れない。"""
        forbidden = {"pathlib", "os", "sys", "logging", "io", "open", "subprocess"}
        for imported in _imported_modules():
            assert imported.split(".")[0] not in forbidden, (
                f"preprocess.py が入出力に関わる {imported} を import している"
            )
