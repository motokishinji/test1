"""実行条件の記録を検証する。

対応要件: 5.4（手法固有オプションの既定値適用と記録）、8.3（実行条件・入力の識別情報・
実行日時の記録）、9.4（CLI 引数が設定ファイルに優先し、上書きした項目を記録する）。

設計の execution / logging_setup ブロック（`OverrideRecord` / `ExecutionRecord` の
フィールド構成、Implementation Notes の「`execution.json` として出力ディレクトリに
書き出す。設定は TOML で読むが記録は JSON で出す」「`library_versions` は環境差を
後から判別する手段」「`resolved_config` に絶対パスが含まれる点は運用上の注意事項」）、
Boundary Commitments の Allowed Dependencies（依存方向の制約）を対象とする。

**記録は再実行で一致しなければならない。** 要件 8.2 の再現性が拠り所とするのは
「同一環境・同一設定なら同一の出力物」であり、記録だけが実行のたびに揺れると、
差分が出たときに設定の違いなのか記録の非決定性なのかを切り分けられない。実行日時だけが
正当に変わる値であるため、時計を注入可能にし、固定した時計の下でバイト同一になることを
主張する。集合の反復順のような暗黙の非決定性もここで塞ぐ。

**上書きは前後の値が揃って初めて意味を持つ。** 「どの項目が上書きされたか」だけでは
利用者は元の設定に戻せない。要件 9.4 が求めるのは上書きの事実ではなく再現の手段であり、
`config_value` と `cli_value` の双方が記録に出ることを主張する。
"""

from __future__ import annotations

import ast
import json
import math
import subprocess
import sys
import textwrap
from dataclasses import FrozenInstanceError, dataclass, fields
from datetime import UTC, datetime, timedelta, timezone
from enum import StrEnum
from importlib.metadata import version as installed_version
from pathlib import Path

import pytest

from curvefit.execution import (
    EXECUTION_RECORD_FILENAME,
    HEADER_KEY,
    RECORDED_LIBRARIES,
    TOOL_PACKAGE,
    UNKNOWN_VERSION,
    ExecutionRecord,
    OverrideRecord,
    build_execution_record,
    collect_applied_defaults,
    collect_library_versions,
    dumps_execution_record,
    format_timestamp,
    record_to_mapping,
    write_execution_record,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

FIXED_MOMENT = datetime(2026, 8, 14, 3, 4, 5, 678901, tzinfo=UTC)
"""試験用の固定時計。実行日時は唯一「実行ごとに変わってよい」値である。"""


def _clock() -> datetime:
    return FIXED_MOMENT


def _record(**overrides: object) -> ExecutionRecord:
    """既定値の揃った記録。個々の試験は必要な項目だけを差し替える。"""
    arguments: dict[str, object] = {
        "resolved_config": {"input": {"paths": ["/data/a.csv"]}, "methods": ["linear"]},
        "config_path": "/etc/curvefit/run.toml",
        "clock": _clock,
    }
    arguments.update(overrides)
    return build_execution_record(**arguments)  # type: ignore[arg-type]


def _loaded(record: ExecutionRecord) -> dict[str, object]:
    return json.loads(dumps_execution_record(record))


def _sample_model(x: float, a: float) -> float:
    """要件 3.3 の経路で実行条件に載る利用者定義モデルの代わり。"""
    return a * x


def _other_model(x: float, a: float) -> float:
    """`_sample_model` と区別できることを確かめるための別の関数。"""
    return a + x


FUNCTION_RECORD_PROBE = textwrap.dedent(
    """
    import json

    from curvefit.execution import build_execution_record, dumps_execution_record

    def probe_model(x, a):
        return a * x

    record = build_execution_record(
        resolved_config={"function": probe_model}, config_path=None
    )
    print(json.loads(dumps_execution_record(record))["resolved_config"]["function"])
    """
)
"""別プロセスで利用者定義関数を実行条件に載せ、記録された表現だけを出力する。"""


def _run_probe() -> str:
    """`FUNCTION_RECORD_PROBE` を別プロセスで実行し、記録された関数の表現を返す。"""
    result = subprocess.run(
        [sys.executable, "-c", FUNCTION_RECORD_PROBE],
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert result.returncode == 0, result.stderr
    return result.stdout.strip()


class Test記録の構造:
    """設計の `ExecutionRecord` フィールド構成（要件 8.3）。"""

    def test_フィールドが設計どおりに並ぶ(self) -> None:
        assert [field.name for field in fields(ExecutionRecord)] == [
            "started_at",
            "tool_version",
            "library_versions",
            "config_path",
            "resolved_config",
            "cli_overrides",
            "applied_defaults",
        ]

    def test_上書き記録は_3_項目を持つ(self) -> None:
        assert [field.name for field in fields(OverrideRecord)] == [
            "key",
            "config_value",
            "cli_value",
        ]

    def test_記録は生成後に変更できない(self) -> None:
        record = _record()

        with pytest.raises(FrozenInstanceError):
            record.started_at = "2000-01-01T00:00:00Z"  # type: ignore[misc]

    def test_渡した写像を後から書き換えても記録は変わらない(self) -> None:
        resolved: dict[str, object] = {"header": True}
        record = build_execution_record(resolved_config=resolved, clock=_clock)

        resolved["header"] = False

        assert record.resolved_config["header"] is True

    def test_実行日時は_UTC_の_ISO_8601(self) -> None:
        """要件 8.3。時刻帯の分からない日時は再現の手掛かりにならない。"""
        record = _record()

        assert record.started_at == "2026-08-14T03:04:05.678901Z"
        assert datetime.fromisoformat(record.started_at).utcoffset() == timedelta(0)

    def test_時刻帯なしの日時は誤りとして拒否する(self) -> None:
        """時刻帯のない日時を UTC と見なすと、地方時が UTC として静かに記録される。"""
        with pytest.raises(ValueError):
            format_timestamp(datetime(2026, 8, 14, 3, 4, 5))

    def test_時刻帯付きの日時は_UTC_に正規化される(self) -> None:
        moment = datetime(2026, 8, 14, 12, 4, 5, tzinfo=timezone(timedelta(hours=9)))

        assert format_timestamp(moment) == "2026-08-14T03:04:05.000000Z"


class Test機械可読な書き出し:
    """設計の Implementation Notes: `execution.json` として JSON で書き出す（要件 8.3）。"""

    def test_出力ファイル名は_execution_json(self) -> None:
        assert EXECUTION_RECORD_FILENAME == "execution.json"

    def test_書き出した内容が_JSON_として読み戻せる(self, tmp_path: Path) -> None:
        record = _record()
        path = tmp_path / EXECUTION_RECORD_FILENAME

        write_execution_record(record, path)

        loaded = json.loads(path.read_text(encoding="utf-8"))
        assert loaded["started_at"] == record.started_at
        assert loaded["tool_version"] == record.tool_version
        assert loaded["config_path"] == "/etc/curvefit/run.toml"
        assert loaded["resolved_config"] == {
            "input": {"paths": ["/data/a.csv"]},
            "methods": ["linear"],
        }

    def test_親ディレクトリが無くても書き出せる(self, tmp_path: Path) -> None:
        path = tmp_path / "out" / EXECUTION_RECORD_FILENAME

        write_execution_record(_record(), path)

        assert path.exists()

    def test_設定ファイルなしの実行は_null_として記録される(self) -> None:
        """ライブラリ呼び出し（要件 9.1）には設定ファイルが無い。空文字と区別する。"""
        loaded = _loaded(_record(config_path=None))

        assert loaded["config_path"] is None

    def test_日本語をそのまま書き出す(self, tmp_path: Path) -> None:
        record = _record(resolved_config={"label": "試料 A"})
        path = tmp_path / EXECUTION_RECORD_FILENAME

        write_execution_record(record, path)

        assert "試料 A" in path.read_text(encoding="utf-8")


class Test上書きの記録:
    """要件 9.4。CLI 引数が優先されたとき、上書き前後の値を残す。"""

    def test_上書き前と上書き後の双方が記録される(self) -> None:
        record = _record(
            cli_overrides=(
                OverrideRecord(key="output.directory", config_value="out", cli_value="/tmp/run"),
            )
        )

        loaded = _loaded(record)
        assert loaded["cli_overrides"] == [
            {
                "key": "output.directory",
                "config_value": "out",
                "cli_value": "/tmp/run",
            }
        ]

    def test_上書きの順序は与えられた順序を保つ(self) -> None:
        record = _record(
            cli_overrides=(
                OverrideRecord(key="b", config_value=1, cli_value=2),
                OverrideRecord(key="a", config_value=3, cli_value=4),
            )
        )

        loaded = _loaded(record)
        assert [entry["key"] for entry in loaded["cli_overrides"]] == ["b", "a"]

    def test_上書きが無い場合は空の並びになる(self) -> None:
        assert _loaded(_record())["cli_overrides"] == []

    def test_上書き前の値が空でも項目は消えない(self) -> None:
        """`None` を欠落として落とすと、上書きされた事実そのものが記録から消える。"""
        record = _record(
            cli_overrides=(OverrideRecord(key="delimiter", config_value=None, cli_value="\t"),)
        )

        assert _loaded(record)["cli_overrides"] == [
            {"key": "delimiter", "config_value": None, "cli_value": "\t"}
        ]

    def test_項目名のない上書きは誤りとして拒否する(self) -> None:
        with pytest.raises(ValueError):
            OverrideRecord(key="", config_value=1, cli_value=2)


class Test適用された既定値の記録:
    """要件 5.4。利用者が書いていないのに効いた値を記録に残す。"""

    def test_手法固有オプションの既定値が記録に現れる(self) -> None:
        record = _record(
            applied_defaults={"moving_average": {"window": 5, "polyorder": 0}},
        )

        assert _loaded(record)["applied_defaults"] == {
            "moving_average": {"window": 5, "polyorder": 0}
        }

    def test_既定値が適用されなければ空になる(self) -> None:
        assert _loaded(_record())["applied_defaults"] == {}

    def test_手法ごとに畳み込める(self) -> None:
        """同一手法を数百対象に適用しても、記録は手法ごとに 1 件で足りる。"""
        collected = collect_applied_defaults(
            [
                ("moving_average", {"window": 5}),
                ("moving_average", {"window": 5}),
                ("polynomial", {"degree": 2}),
            ]
        )

        assert collected == {"moving_average": {"window": 5}, "polynomial": {"degree": 2}}
        assert list(collected) == ["moving_average", "polynomial"]

    def test_既定値を適用しなかった手法は畳み込みに現れない(self) -> None:
        assert collect_applied_defaults([("linear", {})]) == {}


class Test入力の識別情報:
    """要件 8.3。どの入力をどう読んだかが後から分かること。"""

    def test_入力の識別情報が実行条件として記録される(self) -> None:
        record = _record(
            resolved_config={"input": {"paths": ["/data/run1/a.csv", "/data/run2/a.csv"]}}
        )

        loaded = _loaded(record)
        assert loaded["resolved_config"]["input"]["paths"] == [
            "/data/run1/a.csv",
            "/data/run2/a.csv",
        ]

    def test_適用された見出し行の指定が記録される(self) -> None:
        """タスク 5.5 の 3 状態。`None`（未指定）が `false` と区別できること。"""
        assert HEADER_KEY == "header"

        for applied in (True, False, None):
            loaded = _loaded(_record(resolved_config={HEADER_KEY: applied}))
            assert HEADER_KEY in loaded["resolved_config"]
            assert loaded["resolved_config"][HEADER_KEY] is applied


class Testライブラリのバージョン:
    """設計の Implementation Notes: 環境差を後から判別する手段（要件 8.2 の前提）。"""

    def test_導入済みの版が記録される(self) -> None:
        versions = collect_library_versions()

        assert list(versions) == list(RECORDED_LIBRARIES)
        for name in RECORDED_LIBRARIES:
            assert versions[name] == installed_version(name)

    def test_基盤ライブラリを網羅する(self) -> None:
        assert set(RECORDED_LIBRARIES) >= {"lmfit", "scipy", "numpy", "matplotlib"}

    def test_2_回目以降は版を引き直さない(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """要件 9.1: 配布メタデータの走査が対話利用の応答性を覆い隠していた。

        導入済みの版は工程の実行中に変わらないため、一度だけ引けばよい。実測では
        単一系列の当てはめ 26.6 ミリ秒のうち 20.7 ミリ秒がこの走査だった。
        """
        import curvefit.execution as execution_module

        監視した名前: list[str] = []
        本来の版取得 = execution_module._package_version

        def 数える版取得(name: str) -> str:
            監視した名前.append(name)
            return 本来の版取得(name)

        monkeypatch.setattr(execution_module, "_package_version", 数える版取得)
        monkeypatch.setattr(execution_module, "_version_cache", {})

        初回 = collect_library_versions()
        走査件数 = len(監視した名前)
        再呼び出し = collect_library_versions()

        assert 走査件数 == len(RECORDED_LIBRARIES)
        assert len(監視した名前) == 走査件数, "2 回目で引き直している"
        assert dict(再呼び出し) == dict(初回), "記憶しても記録される内容は変わらない"

    def test_別の並びは別に引く(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """並びを鍵にする。試験が別の並びを渡したときに前の結果を返してはならない。"""
        import curvefit.execution as execution_module

        monkeypatch.setattr(execution_module, "_version_cache", {})

        既定の並び = collect_library_versions()
        絞った並び = collect_library_versions(("lmfit",))

        assert list(絞った並び) == ["lmfit"]
        assert 絞った並び["lmfit"] == 既定の並び["lmfit"]

    def test_導入されていない場合も記録は欠けない(self) -> None:
        versions = collect_library_versions(("curvefit-not-installed-probe",))

        assert versions == {"curvefit-not-installed-probe": UNKNOWN_VERSION}

    def test_ツール自身の版が記録される(self) -> None:
        record = _record()

        assert record.tool_version == installed_version(TOOL_PACKAGE)

    def test_記録された版は書き出しに現れる(self) -> None:
        loaded = _loaded(_record())

        assert loaded["library_versions"]["numpy"] == installed_version("numpy")


class Test決定性:
    """要件 8.2。同一環境・同一設定・固定した時計ならバイト同一。"""

    def test_同一入力と固定時計でバイト同一になる(self, tmp_path: Path) -> None:
        def build() -> ExecutionRecord:
            return build_execution_record(
                resolved_config={
                    "input": {"paths": ["/data/a.csv"], "columns": {"x": 0, "y": 1}},
                    "methods": ["linear", "gaussian"],
                },
                config_path="/etc/curvefit/run.toml",
                cli_overrides=(
                    OverrideRecord(key="output.directory", config_value="out", cli_value="/tmp/x"),
                ),
                applied_defaults={"moving_average": {"window": 5}},
                clock=_clock,
            )

        first = tmp_path / "first.json"
        second = tmp_path / "second.json"
        write_execution_record(build(), first)
        write_execution_record(build(), second)

        assert first.read_bytes() == second.read_bytes()

    def test_集合の反復順に依存しない(self) -> None:
        """集合の反復順はハッシュの撹拌に左右され、実行のたびに変わりうる。

        要素数を増やしてあるのは、並べ替えを外したときに「たまたま整列していた」で
        通り抜けないようにするためである。10 要素の自然な反復順が整列順と一致する
        確率は無視できる。
        """
        labels = [f"tag{index}" for index in range(10)]
        forward = _loaded(_record(resolved_config={"tags": set(labels)}))
        backward = _loaded(_record(resolved_config={"tags": set(reversed(labels))}))

        assert forward == backward
        assert forward["resolved_config"]["tags"] == sorted(labels)

    def test_書き出しは改行で終わる(self, tmp_path: Path) -> None:
        path = tmp_path / EXECUTION_RECORD_FILENAME

        write_execution_record(_record(), path)

        assert path.read_bytes().endswith(b"\n")


class Test実行条件の値の変換:
    """`resolved_config` は TOML と CLI 由来の任意の値を運ぶ。JSON に落とせること。"""

    def test_パスは文字列として記録される(self) -> None:
        loaded = _loaded(_record(resolved_config={"output": Path("/tmp/out")}))

        assert loaded["resolved_config"]["output"] == "/tmp/out"

    def test_列挙は値として記録される(self) -> None:
        class Policy(StrEnum):
            SKIP = "skip"

        loaded = _loaded(_record(resolved_config={"on_failure": Policy.SKIP}))

        assert loaded["resolved_config"]["on_failure"] == "skip"

    def test_データクラスは写像として記録される(self) -> None:
        @dataclass(frozen=True)
        class OutputSpec:
            directory: Path
            write_plot: bool

        loaded = _loaded(
            _record(resolved_config={"output": OutputSpec(Path("/tmp/out"), write_plot=True)})
        )

        assert loaded["resolved_config"]["output"] == {
            "directory": "/tmp/out",
            "write_plot": True,
        }

    def test_タプルは並びとして記録される(self) -> None:
        loaded = _loaded(_record(resolved_config={"methods": ("linear", "gaussian")}))

        assert loaded["resolved_config"]["methods"] == ["linear", "gaussian"]

    def test_非有限な数値は文字列として記録される(self) -> None:
        """`NaN` / `Infinity` は JSON の数値ではない。素通しすると読めない記録になる。"""
        loaded = _loaded(
            _record(resolved_config={"x_max": math.inf, "threshold": math.nan})
        )

        assert loaded["resolved_config"]["x_max"] == "inf"
        assert loaded["resolved_config"]["threshold"] == "nan"

    def test_記録できない値も落とさず文字列にする(self) -> None:
        """記録の欠落は「指定しなかった」と読める。読めない値でも残す方が誤解が少ない。"""
        loaded = _loaded(_record(resolved_config={"callback": object()}))

        assert isinstance(loaded["resolved_config"]["callback"], str)

    def test_利用者定義関数は所属と名前で記録される(self) -> None:
        """要件 3.3 の経路は関数そのものを実行条件に載せる。名前で書けること。"""
        loaded = _loaded(_record(resolved_config={"function": _sample_model}))

        assert loaded["resolved_config"]["function"] == f"{__name__}._sample_model"

    def test_利用者定義関数の記録にメモリ番地が現れない(self) -> None:
        """既定の `str()` は `<function model at 0x...>` を返す。番地は実行ごとに変わる。

        要件 8.2 は同一設定・同一入力の再実行が同一の出力になることを求める。番地を
        載せた記録は、当てはめ結果が同一でも実行条件の記録だけが毎回異なる。
        """
        loaded = _loaded(_record(resolved_config={"function": _sample_model}))
        recorded = loaded["resolved_config"]["function"]

        assert isinstance(recorded, str)
        assert "0x" not in recorded
        assert " at " not in recorded

    def test_同一関数の記録は別プロセスでも一致する(self) -> None:
        """番地は同一プロセス内では変わらない。再現性の検証には別プロセスが要る。

        要件 8.2 が求めるのは「同じ設定・同じ入力なら同じ出力」であり、比較の相手は
        別の日・別のプロセスで行った実行である。
        """
        runs = [_run_probe(), _run_probe()]

        assert runs[0] == runs[1]
        assert runs[0] == "__main__.probe_model"

    def test_別の関数は別の名前で記録される(self) -> None:
        """安定させるために全てを同じ文字列に潰しては、記録として意味を失う。"""
        one = _loaded(_record(resolved_config={"function": _sample_model}))
        other = _loaded(_record(resolved_config={"function": _other_model}))

        assert one["resolved_config"]["function"] != other["resolved_config"]["function"]

    def test_写像の並びは与えられた順序を保つ(self) -> None:
        record = _record(resolved_config={"z": 1, "a": 2, "m": 3})

        assert list(_loaded(record)["resolved_config"]) == ["z", "a", "m"]


def _module_source() -> str:
    return (SRC / "execution.py").read_text(encoding="utf-8")


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring がライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse(_module_source())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class Test依存の露出:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_基盤ライブラリを_import_しない(self) -> None:
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval"}, (
                f"execution.py が {imported} を import している"
            )

    def test_自パッケージからは_types_と_errors_しか_import_しない(self) -> None:
        internal = {name for name in _imported_modules() if name.split(".")[0] == "curvefit"}

        assert internal <= {"curvefit.types", "curvefit.errors"}, (
            f"execution.py が層をまたいで import している: {internal}"
        )

    def test_環境変数や利用者情報を記録に含めない(self) -> None:
        """設計の Risks は入力パスの露出だけを受け入れている。それ以上を増やさない。"""
        assert "os.environ" not in _module_source()
        assert "getpass" not in _imported_modules()
        assert "socket" not in _imported_modules()
