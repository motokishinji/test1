"""再現性の E2E テスト（要件 8.2）。

steering の ``product.md`` が本製品の中核価値に置くのは速度ではなく
「同じ設定ファイルと同じ入力なら誰がいつ実行しても同じ結果になる」ことである。
本テストはその主張を直接検査する。設計の Testing Strategy → E2E Tests の
「同一設定・同一入力で 2 回実行し、サマリ CSV がタイムスタンプ列を除いて完全一致
すること（8.2）」に対応する。

検査する非決定性の源
--------------------

``research.md`` の「再現性を破る要因の洗い出し」と、実装中に実測された事実に対応する。

1. **ファイルシステムの走査順**: ``glob`` / ``Path.iterdir`` の順序は保証されない。
   ``pipeline.expand_sources`` が絶対パスを **集合に集めてから整列する** ことで
   吸収している。集合の反復順は文字列のハッシュに依存するため、整列を外すと
   同一プロセス内でも実行ごとにジョブ順が変わる
2. **SciPy の GCV による平滑化スプライン**: 完全な再現性を持たない。呼び出しごとに
   2 つの状態のいずれかに倒れ、**同一プロセス内でもプロセスを跨いでも**当てはめ値が
   変わる。当初これを有効数字 10 桁の丸めで吸収する方針だったが、丸めは必要条件で
   あって十分条件ではなく、値が境界付近にあれば表記が変わる（実測: 同一設定・同一
   入力の 12 回実行でサマリ表が 2 種類になった）。要件 5.5 で平滑化パラメータを必須に
   し、この経路そのものを断つことで解決している
3. **``PYTHONHASHSEED``**: 集合と辞書の反復順を決める。既定では起動ごとに無作為であり、
   固定した値でも別プロセスとして実行して確かめる

比較から除くもの（これ以外は一切除かない）
------------------------------------------

- ``execution.json`` の ``started_at``: 実行開始時刻であり、要件 8.3 が変わることを
  前提に記録している唯一の項目。除いてよいことを空振りさせないため、**除いた値が
  実行ごとに実際に異なること** も併せて表明する
- ``run.log`` の行頭の時刻: 1 行ごとに付く。書式が
  :data:`LOG_TIMESTAMP_PATTERN` に一致することを確かめてから、最初の空白までを
  取り除く。行の残り（水準・対象・手法・成否）は 1 文字も落とさない
- ``run.log`` の ``status=started`` 行（**入力の並び順の検査でのみ**）: この 1 行は
  解決済み設定をそのまま書き出しており、設定ファイルの綴り（``paths`` の並びと
  ``config_path``）を含む。並び順の検査は綴りを意図的に変えるため、この行だけは
  一致し得ない。処理単位の行と集計行は完全に一致することを表明する

サマリ CSV は **一切除かずにバイト単位で** 比較する。``source_id`` は絶対パスだが、
同一の入力ディレクトリを使う以上は実行を跨いで同一であり、除く理由がない
（要件 8.2 は同一環境を前提とする。design.md の execution / Risks）。

実行時間について
----------------

コンソールスクリプトを 5 回起動する（約 18 秒）。回数はそれぞれ別の非決定性を
担当しており減らせない。グラフ出力は無効にしてある。画像の生成は本テストが見る
契約（サマリ表・実行ログ・実行条件の記録・出力名）に含まれず、1 回あたり約 1 秒を
足すためである。
"""

from __future__ import annotations

import csv
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

import pytest

# --- 利用者から見た契約（実装の定数は取り込まない）----------------------------------

SUMMARY_NAME = "summary.csv"
"""サマリ表のファイル名（要件 7.3）。"""

RUN_LOG_NAME = "run.log"
"""実行ログのファイル名（要件 8.4）。"""

EXECUTION_RECORD_NAME = "execution.json"
"""実行条件の記録のファイル名（要件 8.3）。"""

CURVES_DIRECTORY = "curves"
"""曲線・残差 CSV を収める下位ディレクトリ（要件 7.5）。"""

CURVE_COLUMNS: tuple[str, ...] = ("x", "y_observed", "y_fit", "residual")
"""曲線・残差 CSV の列（要件 7.5）。"""

RESIDUAL_COLUMN = CURVE_COLUMNS.index("residual")
"""残差の列位置。RMSE を全精度から組み直すために使う。"""

SUMMARY_SIGNIFICANT_DIGITS = 10
"""サマリ表の数値の有効数字（設計の writers / Validation）。

利用者に対する公約であり、外部ツールが読む桁数でもある。実装の定数を取り込まずに
ここへ書き写すのは、桁数の変更が利用者から見た破壊であることを検出するためである。
"""

STARTED_AT_KEY = '"started_at"'
"""``execution.json`` のうち実行ごとに変わってよい唯一の項目（要件 8.3）。"""

LOG_TIMESTAMP_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
"""実行ログの行頭に付く UTC の時刻。除く範囲をこの形に限る。"""

STARTED_AT_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$")
"""``started_at`` の書式（UTC ISO 8601）。除いた項目が時刻であることを確かめる。"""

STARTED_LOG_MARKER = "status=started"
"""解決済み設定を書き出す実行ログの 1 行目を指す語。"""

EXIT_SUCCESS = 0
"""全処理単位が成功した（要件 9.5）。"""

# --- 入力の用意 ----------------------------------------------------------------------

SERIES_LENGTHS: Mapping[str, int] = {
    "alpha": 44,
    "beta": 36,
    "delta": 40,
    "gamma": 52,
}
"""入力ごとの点数。

**点数を入力ごとに変える。** 当初は「点数によって GCV スプラインの倒れ方が決まる」
という想定で散らしていたが、その想定は誤りだった（揺れは呼び出しごとの分岐であり、
点数では決まらない）。平滑化パラメータが必須になった今、散らす理由は別にある。
点数の違う系列が混ざっていれば、行数や整列に依存する不具合が出力に現れやすい。

名前の辞書順（alpha < beta < delta < gamma）と、後述の作成順は一致させない。
"""

CREATION_ORDER: tuple[str, ...] = ("alpha", "beta", "delta", "gamma")
"""基準となる実行で入力ファイルをディスクに作る順序。"""

NOISE_AMPLITUDE = 0.15
"""測定のばらつきの振幅。

0 にしない。残差が厳密に 0 の系列は当てはめが自明になり、実際の測定データが
通る経路を検査したことにならない。
"""

X_STEP = 0.25
"""独立変数の刻み。"""


def write_series(path: Path, *, n_points: int, seed: int) -> Path:
    """曲がりのある測定データを書き出す。

    値は :func:`repr` で書き、最終ビットまで復元できる表記にする。NumPy のスカラは
    :func:`repr` が ``np.float64(...)`` を返すため、素の :class:`float` だけを扱う。

    ばらつきは :class:`random.Random` に種を与えて作る。**テストの入力自体が
    再現可能でなければ、再現性の検査に意味がない。**
    """
    generator = random.Random(seed)
    lines = ["x,y"]
    for index in range(n_points):
        x = float(index) * X_STEP
        y = float(
            2.0 * math.sin(x)
            + 0.5 * x
            + generator.uniform(-NOISE_AMPLITUDE, NOISE_AMPLITUDE)
        )
        lines.append(f"{x!r},{y!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def create_sources(data_dir: Path, order: Sequence[str]) -> None:
    """入力ファイル一式を、与えられた順序でディスク上に作り直す。

    いったん全件を消してから作る。作成順そのものがファイルシステムの走査順に影響し
    うるため、順序を変えた状況を実際に作らなければ要件 8.2 の「並び順の非決定性」を
    検査したことにならない。内容は名前ごとに一意に決まるため、順序を変えても
    出力は変わってはならない。
    """
    for name in SERIES_LENGTHS:
        path = data_dir / f"{name}.csv"
        if path.exists():
            path.unlink()
    for name in order:
        write_series(
            data_dir / f"{name}.csv",
            n_points=SERIES_LENGTHS[name],
            seed=sorted(SERIES_LENGTHS).index(name),
        )


CONFIG = """\
[input]
paths = {paths}
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "line"
builtin = "linear"

[[methods]]
name = "spl"
smoother = "spline"
options = {{ lam = 0.01 }}

[output]
directory = {output_dir}
write_plot = false
write_curve = true
"""
"""検査に使う実行条件。

手法を 2 つ置く。``spl``（平滑化スプライン）は、かつて自動選択によって揺れていた
経路である。要件 5.5 で平滑化パラメータを必須にしたため揺れは断たれており、
``options`` に ``lam`` を明示する。``line``（最小二乗）は当初から揺れない側の対照。

``write_curve`` を有効にするのは、丸める前の全精度の値を観測する手段がこれだけ
だからである（設計の writers / Validation: 丸めるのはサマリ表に限る）。
"""


def toml_string(value: Path | str) -> str:
    """TOML の文字列として安全に書ける形にする。"""
    return json.dumps(str(value), ensure_ascii=False)


def console_script() -> Path:
    """宣言されたコンソールスクリプトの実体。

    ``python -m curvefit.cli`` では ``[project.scripts]`` の宣言漏れを検出できない。
    また要件 8.2 が問うのは **別プロセスとして起動し直したときの一致** であり、
    同一プロセス内の呼び出しでは、記憶された状態が揺れを隠してしまう。
    """
    return Path(sys.executable).parent / "curvefit"


# --- 1 回の実行と、その成果物の写し ---------------------------------------------------


@dataclass(frozen=True)
class Snapshot:
    """1 回の実行が出力先に残したものの写し。

    出力先は全実行で共有し、実行のたびに写しを取る。出力先を実行ごとに分けると
    ``execution.json`` の ``resolved_config.output.directory`` と ``run.log`` の
    1 行目が必ず食い違い、比較から除く範囲が広がってしまう。
    """

    label: str
    directory: Path

    @property
    def summary_bytes(self) -> bytes:
        return (self.directory / SUMMARY_NAME).read_bytes()

    @property
    def file_names(self) -> list[str]:
        return sorted(
            path.relative_to(self.directory).as_posix()
            for path in self.directory.rglob("*")
            if path.is_file()
        )

    @property
    def summary_rows(self) -> list[dict[str, str]]:
        with (self.directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            header = tuple(next(reader))
            return [dict(zip(header, row, strict=True)) for row in reader]

    @property
    def curve_names(self) -> list[str]:
        curves = self.directory / CURVES_DIRECTORY
        return sorted(path.name for path in curves.iterdir() if path.is_file())

    def curve_bytes(self, name: str) -> bytes:
        return (self.directory / CURVES_DIRECTORY / name).read_bytes()

    def curve_rows(self, name: str) -> list[tuple[float, ...]]:
        """曲線・残差 CSV を全精度のまま読む。"""
        path = self.directory / CURVES_DIRECTORY / name
        with path.open(encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            header = tuple(next(reader))
            assert header == CURVE_COLUMNS, (name, header)
            return [tuple(float(cell) for cell in row) for row in reader]

    @property
    def log_lines(self) -> list[str]:
        """実行ログを、**行頭の時刻だけを除いて** 読む。

        除く範囲を狭く保つため、まず行頭が時刻の形であることを確かめ、最初の空白
        までを落とす。時刻の書式が変わればここで落ちる。
        """
        text = (self.directory / RUN_LOG_NAME).read_text(encoding="utf-8")
        stripped: list[str] = []
        for line in text.splitlines():
            if not line:
                continue
            assert LOG_TIMESTAMP_PATTERN.match(line), (self.label, line)
            stripped.append(line.split(" ", 1)[1])
        return stripped

    @property
    def job_log_lines(self) -> list[str]:
        """解決済み設定を書き出す 1 行目を除いた実行ログ。

        除くのは入力の並び順を変えた実行と比べるときだけである。その行は
        ``config_path`` と ``paths`` を字義どおり書き出しており、綴りを変えた以上
        一致し得ない。処理単位の行と集計行は綴りに依存しない。
        """
        return [line for line in self.log_lines if STARTED_LOG_MARKER not in line]

    @property
    def execution_record_parts(self) -> tuple[str, str]:
        """``execution.json`` を「``started_at`` の行」と「それ以外」に分ける。

        JSON として読み直さず本文のまま扱う。読み直すとキーの並びと数値の表記が
        比較から落ち、要件 8.2 が求めるバイト単位の一致より弱い検査になる。
        """
        text = (self.directory / EXECUTION_RECORD_NAME).read_text(encoding="utf-8")
        lines = text.splitlines(keepends=True)
        started = [line for line in lines if STARTED_AT_KEY in line]
        assert len(started) == 1, (self.label, started)
        rest = "".join(line for line in lines if STARTED_AT_KEY not in line)
        return rest, started[0]

    @property
    def started_at(self) -> str:
        _, line = self.execution_record_parts
        return json.loads(f"{{{line.strip().rstrip(',')}}}")["started_at"]


def run_command(config: Path, *, hash_seed: str | None) -> subprocess.CompletedProcess[str]:
    """コマンドを別プロセスとして起動する（要件 9.2）。

    :param hash_seed: ``PYTHONHASHSEED`` に与える値。``None`` は環境から取り除き、
        Python の既定である起動ごとの無作為なハッシュ種で動かすことを意味する。
    """
    environment = dict(os.environ)
    if hash_seed is None:
        environment.pop("PYTHONHASHSEED", None)
    else:
        environment["PYTHONHASHSEED"] = hash_seed
    return subprocess.run(
        [str(console_script()), str(config)],
        capture_output=True,
        text=True,
        timeout=300,
        env=environment,
    )


@dataclass(frozen=True)
class Repetitions:
    """同一の入力に対する 5 回の実行の写し。"""

    snapshots: Mapping[str, Snapshot]
    sources: tuple[Path, ...]
    hash_seeds: Mapping[str, str | None]
    """実行ごとに ``PYTHONHASHSEED`` へ実際に与えた値。``None`` は取り除いたことを表す。

    定数ではなく **起動時に使った値** を控える。検査が定数どうしを比べるだけになると、
    起動条件を変え忘れても表明が成立してしまう。
    """

    def __getitem__(self, label: str) -> Snapshot:
        return self.snapshots[label]

    @property
    def same_config(self) -> tuple[Snapshot, ...]:
        """同一の設定ファイルで起動した実行（並び順を変えた実行を除く）。"""
        return tuple(
            snapshot
            for label, snapshot in self.snapshots.items()
            if label != REORDERED
        )

    @property
    def all_snapshots(self) -> tuple[Snapshot, ...]:
        return tuple(self.snapshots.values())


BASELINE = "baseline"
"""基準となる実行。"""

REPEAT = "repeat"
"""基準と何も変えずに繰り返した実行。"""

REORDERED = "reordered"
"""入力の並び順だけを変えた実行（ディスク上の作成順と設定の記述順の双方）。"""

HASH_SEED_ZERO = "hash_seed_zero"
"""``PYTHONHASHSEED=0``（ハッシュのかく乱を止めた状態）で起動した実行。"""

HASH_SEED_MAX = "hash_seed_max"
"""``PYTHONHASHSEED`` に最大値を与えて起動した実行。"""

MAX_HASH_SEED = "4294967295"
"""``PYTHONHASHSEED`` が受け付ける最大値。"""


@pytest.fixture(scope="module")
def repetitions(tmp_path_factory: pytest.TempPathFactory) -> Repetitions:
    """同一の入力に対して 5 回起動し、それぞれの出力先の写しを返す。

    1. 基準
    2. 何も変えない繰り返し（要件 8.2 の本体）
    3. 入力の並び順を変えた実行（ディスク上の作成順を逆にし、設定にも逆順で書く）
    4. ``PYTHONHASHSEED=0``
    5. ``PYTHONHASHSEED`` 最大値

    3 が別の設定ファイルを使うのは、**走査順の非決定性を確実に作るため** である。
    ディスク上の作成順は、ファイルシステムが名前順に返す実装であれば出力順に影響を
    与えない。設定に逆順で書けば、整列が外れた瞬間に必ず順序が変わる。
    """
    base = tmp_path_factory.mktemp("reproducibility")
    data_dir = base / "data"
    data_dir.mkdir()
    output_dir = base / "out"

    create_sources(data_dir, CREATION_ORDER)
    sources = tuple(sorted(data_dir / f"{name}.csv" for name in SERIES_LENGTHS))

    directory_config = base / "run.toml"
    directory_config.write_text(
        CONFIG.format(
            paths=f"[{toml_string(data_dir)}]",
            output_dir=toml_string(output_dir),
        ),
        encoding="utf-8",
    )
    reversed_config = base / "run_reversed.toml"
    reversed_config.write_text(
        CONFIG.format(
            paths="["
            + ", ".join(toml_string(source) for source in reversed(sources))
            + "]",
            output_dir=toml_string(output_dir),
        ),
        encoding="utf-8",
    )

    plan: tuple[tuple[str, Path, str | None, tuple[str, ...]], ...] = (
        (BASELINE, directory_config, None, CREATION_ORDER),
        (REPEAT, directory_config, None, CREATION_ORDER),
        (REORDERED, reversed_config, None, tuple(reversed(CREATION_ORDER))),
        (HASH_SEED_ZERO, directory_config, "0", CREATION_ORDER),
        (HASH_SEED_MAX, directory_config, MAX_HASH_SEED, CREATION_ORDER),
    )

    snapshots: dict[str, Snapshot] = {}
    hash_seeds: dict[str, str | None] = {}
    for label, config, hash_seed, order in plan:
        create_sources(data_dir, order)
        process = run_command(config, hash_seed=hash_seed)
        assert process.returncode == EXIT_SUCCESS, (label, process.stderr)
        snapshot_dir = base / f"snapshot_{label}"
        shutil.copytree(output_dir, snapshot_dir)
        snapshots[label] = Snapshot(label=label, directory=snapshot_dir)
        hash_seeds[label] = hash_seed

    return Repetitions(snapshots=snapshots, sources=sources, hash_seeds=hash_seeds)


# --- 比較の道具 ----------------------------------------------------------------------


def spline_curve_names(snapshot: Snapshot) -> list[str]:
    """平滑化スプラインの曲線 CSV の名前（出力名の規則 ``{対象}__{手法}__{番号}``）。"""
    return [name for name in snapshot.curve_names if "__spl__" in name]


def least_squares_curve_names(snapshot: Snapshot) -> list[str]:
    """最小二乗の曲線 CSV の名前。"""
    return [name for name in snapshot.curve_names if "__line__" in name]


def rmse_from_curve(rows: Sequence[tuple[float, ...]]) -> float:
    """全精度の残差から RMSE を組み直す（要件 7.2 の定義）。

    サマリ表の ``rmse`` 列が、丸める前の値をどこまで落としているかを見るために使う。
    実装を参照せず定義から組み直すことで、比較が「同じ実装を 2 回呼んだだけ」に
    ならないようにする。
    """
    residuals = [row[RESIDUAL_COLUMN] for row in rows]
    return math.sqrt(sum(value * value for value in residuals) / len(residuals))


# --- 同一設定・同一入力での再実行 -----------------------------------------------------


class Test同一設定同一入力の再実行:
    """要件 8.2: 同じ設定ファイルと同じ入力なら、いつ実行しても同じ結果になること。"""

    def test_サマリ表がバイト単位で完全に一致する(self, repetitions: Repetitions) -> None:
        """要件 8.2、7.3: サマリ表は 1 バイトも違わない。除外は 1 つも設けない。

        サマリ表に実行日時に依存する内容は無く、``source_id`` は同一の入力を指す
        絶対パスであるため、除くべきものが存在しない。
        """
        baseline = repetitions[BASELINE]
        repeat = repetitions[REPEAT]
        assert baseline.summary_bytes == repeat.summary_bytes

    def test_比較したサマリ表が空でも自明でもない(self, repetitions: Repetitions) -> None:
        """一致の表明が空振りしないことを、比較した中身の側から確かめる。

        行が 0 件でも「一致」は成立する。何がどれだけ一致したのかを固定する。
        """
        rows = repetitions[BASELINE].summary_rows
        # 4 入力 × (直線の 2 パラメータ + スプラインの 1 行) = 12 行。
        assert len(rows) == len(SERIES_LENGTHS) * 3
        assert {row["status"] for row in rows} == {"success"}
        assert {row["method_name"] for row in rows} == {"line", "spl"}
        # 揺れる側の手法が実際に表へ載っていること。ここが空だと丸めの検査ごと空振りする。
        spline_rows = [row for row in rows if row["method_name"] == "spl"]
        assert len(spline_rows) == len(SERIES_LENGTHS)
        assert all(row["rmse"] for row in spline_rows)

    def test_出力ファイルの一覧と名前が一致する(self, repetitions: Repetitions) -> None:
        """要件 7.6: 出力名は対象と手法と処理単位番号から決まり、実行ごとに変わらない。"""
        baseline = repetitions[BASELINE]
        repeat = repetitions[REPEAT]
        assert baseline.file_names == repeat.file_names
        expected = [
            f"{CURVES_DIRECTORY}/{source.stem}__{method}__{index:04d}.csv"
            for index, (source, method) in enumerate(
                (source, method)
                for source in repetitions.sources
                for method in ("line", "spl")
            )
        ]
        assert baseline.file_names == sorted(
            [*expected, SUMMARY_NAME, RUN_LOG_NAME, EXECUTION_RECORD_NAME]
        )

    def test_実行条件の記録が実行開始時刻を除いて一致する(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.3、8.2: 変わってよいのは ``started_at`` の 1 行だけである。"""
        baseline_rest, _ = repetitions[BASELINE].execution_record_parts
        repeat_rest, _ = repetitions[REPEAT].execution_record_parts
        assert baseline_rest == repeat_rest

    def test_除外した実行開始時刻は実際に実行ごとに異なる(
        self, repetitions: Repetitions
    ) -> None:
        """除外が過剰でないことの裏取り。

        変わらない項目を除外に含めていれば、その項目の不一致を見逃す。``started_at``
        が本当に実行ごとに変わることを示して初めて、除外が最小であると言える。
        """
        baseline = repetitions[BASELINE].started_at
        repeat = repetitions[REPEAT].started_at
        assert STARTED_AT_PATTERN.match(baseline), baseline
        assert STARTED_AT_PATTERN.match(repeat), repeat
        assert baseline != repeat

    def test_実行ログが行頭の時刻を除いて一致する(self, repetitions: Repetitions) -> None:
        """要件 8.4、8.2: 記録の順序と内容が実行ごとに変わらない。

        除くのは各行の先頭に付く時刻だけである（:attr:`Snapshot.log_lines`）。
        """
        baseline = repetitions[BASELINE].log_lines
        repeat = repetitions[REPEAT].log_lines
        assert baseline == repeat
        # 除外後に残っているのが空でないこと。1 行目の設定と、処理単位ごとの行と集計行。
        assert len(baseline) == len(SERIES_LENGTHS) * 2 + 2
        assert any("n_success=8" in line and "n_failure=0" in line for line in baseline)


# --- 入力の並び順に対する不変性 -------------------------------------------------------


class Test入力の並び順に依存しないこと:
    """要件 8.2、6.1: 走査順や記述順が変わっても、結果は 1 バイトも変わらないこと。

    ``pipeline.expand_sources`` は入力の指定を **集合** に集めてから整列する。
    整列を外すと、集合の反復順（文字列のハッシュ依存）がそのままジョブ順になり、
    サマリ表の行順・処理単位番号・ログの記録順のすべてが実行ごとに変わる。
    """

    def test_並び順を変えてもサマリ表がバイト単位で一致する(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.2: 行順を含めて完全に一致する。"""
        baseline = repetitions[BASELINE]
        reordered = repetitions[REORDERED]
        assert baseline.summary_bytes == reordered.summary_bytes

    def test_並び順を変えても出力ファイル名が一致する(
        self, repetitions: Repetitions
    ) -> None:
        """要件 7.6: 出力名に含まれる処理単位番号は、整列後の順序で振られる。

        番号が並び順に依存すると、同じ対象の出力が実行ごとに別のファイルへ移る。
        """
        baseline = repetitions[BASELINE]
        reordered = repetitions[REORDERED]
        assert baseline.file_names == reordered.file_names
        # 番号は入力の絶対パスを整列した順に振られる。設定の記述順（逆順）ではない。
        assert baseline.curve_names[0].startswith(f"{repetitions.sources[0].stem}__")

    def test_並び順を変えても処理単位の記録順が一致する(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.4、8.2: ログの記録順も整列後の順序に従う。

        1 行目（``status=started``）だけは、設定ファイルの綴りをそのまま書き出す
        ため一致し得ない。除くのはその 1 行に限り、処理単位の行と集計行は完全に
        一致することを表明する。
        """
        baseline = repetitions[BASELINE]
        reordered = repetitions[REORDERED]
        assert baseline.job_log_lines == reordered.job_log_lines
        assert len(baseline.job_log_lines) == len(baseline.log_lines) - 1

    def test_並び順を変えた実行が実際に別の綴りで起動している(
        self, repetitions: Repetitions
    ) -> None:
        """並び順を変えた状況が本当に作られていることの裏取り。

        設定の綴りが同じなら、上の 3 つは「同じものを 2 回実行しただけ」になる。
        """
        baseline_started = next(
            line for line in repetitions[BASELINE].log_lines if STARTED_LOG_MARKER in line
        )
        reordered_started = next(
            line for line in repetitions[REORDERED].log_lines if STARTED_LOG_MARKER in line
        )
        assert baseline_started != reordered_started
        # 逆順に書いた最初の入力が、整列後の最後の対象であること。
        assert str(repetitions.sources[-1]) in reordered_started


# --- ハッシュ種に対する不変性 ---------------------------------------------------------


class Test環境のハッシュ種に依存しないこと:
    """要件 8.2: ``PYTHONHASHSEED`` は集合と辞書の反復順を決める。

    実行順の決定を集合の反復順に委ねている箇所が残っていれば、種を変えた別プロセスの
    実行で結果が変わる。既定の無作為な種による 3 回の実行に、固定した 2 つの種を
    加えて確かめる。
    """

    def test_どのハッシュ種でもサマリ表が一致する(self, repetitions: Repetitions) -> None:
        """要件 8.2: 4 つの実行のサマリ表がすべて同一のバイト列になる。"""
        distinct = {snapshot.summary_bytes for snapshot in repetitions.same_config}
        assert len(distinct) == 1, [
            snapshot.label for snapshot in repetitions.same_config
        ]

    def test_どのハッシュ種でも実行条件の記録が開始時刻を除いて一致する(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.3、8.2: 記録の内容もキーの並びも種に依存しない。"""
        distinct = {
            snapshot.execution_record_parts[0] for snapshot in repetitions.same_config
        }
        assert len(distinct) == 1

    def test_どのハッシュ種でも実行ログが行頭の時刻を除いて一致する(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.4、8.2: 記録の順序も種に依存しない。"""
        distinct = {tuple(snapshot.log_lines) for snapshot in repetitions.same_config}
        assert len(distinct) == 1

    def test_比較した実行が実際に別の種の別プロセスである(
        self, repetitions: Repetitions
    ) -> None:
        """一致の表明が空振りしないことの裏取り。

        同じ条件で 4 回起動していたなら、上の 3 つは何も検査していない。起動時に
        与えた種が実際に食い違っていること、5 回が別プロセスであること（開始時刻が
        すべて異なる）を示す。
        """
        seeds = repetitions.hash_seeds
        assert seeds[HASH_SEED_ZERO] != seeds[HASH_SEED_MAX]
        assert {seeds[HASH_SEED_ZERO], seeds[HASH_SEED_MAX]} == {"0", MAX_HASH_SEED}
        # 既定の実行はハッシュ種を環境から取り除いてある（起動ごとに無作為）。
        assert seeds[BASELINE] is None and seeds[REPEAT] is None
        assert len({snapshot.started_at for snapshot in repetitions.all_snapshots}) == 5


# --- 有効数字 10 桁の丸めが担っている役割 ---------------------------------------------


class Test有効数字_10_桁の丸めが担っている役割:
    """設計の writers / Validation: サマリ表を有効数字 10 桁で書く決定の検証。

    丸めは **報告物の桁を揃えるため** であり、再現性の担保ではない。丸めは必要条件で
    あって十分条件ではなく、値が丸めの境界付近にあれば最終桁の刻みより小さい揺れでも
    表記は変わる。要件 8.2 の再現性は、揺れを生む経路（平滑化パラメータの自動選択）を
    要件 5.5 で断つことによって成立させている。

    かつてここには「全精度の出力が実行ごとに揺れる」という表明があった。平滑化
    パラメータが必須になり自動選択が到達不能になったため、その揺れはもはや存在しない。
    本クラスが残して検証するのは、サマリ表の数値が全精度の出力と同じ量の丸めであること
    と、その結果として実行を跨いで同一の文字列になることである。
    """

    def test_最小二乗の全精度の出力は揺れない(self, repetitions: Repetitions) -> None:
        """最小二乗の全精度出力がプロセスを跨いで一致すること。"""
        snapshots = repetitions.all_snapshots
        for name in least_squares_curve_names(snapshots[0]):
            distinct = {snapshot.curve_bytes(name) for snapshot in snapshots}
            assert len(distinct) == 1, name

    def test_サマリの_RMSE_は全精度の曲線を_10_桁に丸めた値である(
        self, repetitions: Repetitions
    ) -> None:
        """サマリ表の数値が、全精度の出力と同じ量の丸めであることを結び付ける。

        これが無いと「揺れる出力」と「一致するサマリ」が別々の量を指している可能性が
        残り、丸めが効いているという結論にならない。
        """
        for snapshot in repetitions.all_snapshots:
            rows = {
                (Path(row["source_id"]).stem, row["method_name"]): row["rmse"]
                for row in snapshot.summary_rows
            }
            for name in snapshot.curve_names:
                source, method, _ = name.removesuffix(".csv").split("__")
                rebuilt = rmse_from_curve(snapshot.curve_rows(name))
                assert f"{rebuilt:.{SUMMARY_SIGNIFICANT_DIGITS}g}" == rows[(source, method)], (
                    snapshot.label,
                    name,
                )

    def test_平滑化スプラインの全精度の出力は揺れない(
        self, repetitions: Repetitions
    ) -> None:
        """スプラインの全精度出力が実行を跨いで完全に一致すること。

        かつてここには「揺れが最終桁 1 つ分に収まる」という表明があった。それは誤った
        検査だった。丸めは必要条件であって十分条件ではなく、値が丸めの境界付近にあれば
        最終桁の刻みより小さい揺れでも表記は変わる（実測: 462 件中 5 件が境界をまたぎ、
        同一設定・同一入力の 12 回実行でサマリ表が 2 種類になった）。

        平滑化パラメータを必須にして自動選択を断ったため（要件 5.5）、揺れそのものが
        存在しない。丸めに頼らず全精度で一致することを直接確かめる。
        """
        snapshots = repetitions.all_snapshots
        for name in spline_curve_names(snapshots[0]):
            distinct = {snapshot.curve_bytes(name) for snapshot in snapshots}
            assert len(distinct) == 1, (name, len(distinct))

    def test_丸めた結果としてサマリの平滑化スプラインの行が一致する(
        self, repetitions: Repetitions
    ) -> None:
        """結論。揺れる量を含む行が、実行を跨いで同一の文字列になる。"""
        spline_cells = [
            tuple(
                (row["source_id"], row["r_squared"], row["rmse"])
                for row in snapshot.summary_rows
                if row["method_name"] == "spl"
            )
            for snapshot in repetitions.all_snapshots
        ]
        assert len(set(spline_cells)) == 1
        assert len(spline_cells[0]) == len(SERIES_LENGTHS)
