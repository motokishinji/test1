"""通し実行の E2E テスト（要件 6.6、8.3、8.4、8.5、9.2、9.5）。

設計の Testing Strategy が E2E に置く 3 シナリオを、**導入済みのコンソールスクリプトを
別プロセスとして起動して** 検証する。

- **1 ディレクトリ分の処理**（要件 9.2、8.3、8.4、9.5）: 設定ファイルの指定だけで
  サマリ表・グラフ画像・実行ログ・実行条件の記録が揃い、終了コードが 0 になること
- **失敗を含むバッチ**（要件 6.6、8.4、9.5）: 実行ログに対象識別子と失敗理由が残り、
  成功した対象の出力はそのまま残り、終了コードが成功時と区別されること
- **設定ファイルの誤り**（要件 8.5、9.5）: 出力先に何も生成されないまま、実行前検証の
  終了コードで停止し、全違反が位置とともに示されること

``tests/integration/test_cli.py`` との違い
------------------------------------------

統合テストは :func:`curvefit.cli.main` を同一プロセス内で呼び、結線と引数の受け渡しを
見る。本テストは **利用者が実際に打つコマンド** を起動し、``[project.scripts]`` の宣言・
実プロセスの終了コード・標準出力と標準エラーの分離・実ファイルシステム上の成果物という、
同一プロセス内の呼び出しでは観測できない層を見る。

そのため **本テストは :mod:`curvefit` を一切 import しない**。ファイル名・列構成・ログの
語彙・終了コードはいずれも利用者と外部ツールが依存する契約であり、実装の定数を取り込んで
照合すると、定数の改名が利用者から見た破壊であっても検出できない。

各シナリオの起動は 1 回で足りる。モジュール有効期間の fixture で結果を共有し、1 回の
実行に対して複数の観点を確かめる。規模の検証は本テストの担当ではない
（``tests/performance/``）。
"""

from __future__ import annotations

import csv
import json
import subprocess
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

import pytest

# --- 利用者から見た契約（実装の定数は取り込まない）----------------------------------

SUMMARY_NAME = "summary.csv"
"""サマリ表のファイル名（要件 7.3）。"""

RUN_LOG_NAME = "run.log"
"""実行ログのファイル名（要件 8.4）。"""

EXECUTION_RECORD_NAME = "execution.json"
"""実行条件の記録のファイル名（要件 8.3）。"""

PLOTS_DIRECTORY = "plots"
"""グラフ画像を収める下位ディレクトリ（要件 7.4）。"""

SUMMARY_HEADER: tuple[str, ...] = (
    "source_id",
    "method_name",
    "status",
    "parameter_name",
    "value",
    "stderr",
    "fixed",
    "r_squared",
    "rmse",
    "n_points",
    "n_dropped_invalid",
    "n_dropped_out_of_range",
    "n_dropped_outlier",
    "failure_reason",
    "message",
)
"""サマリ表の列（要件 7.1、7.2、7.3）。外部ツールが読む形であり、順序を含めて契約である。"""

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
"""PNG の識別子。拡張子だけでは中身が画像であることを示せない。"""

EXIT_SUCCESS = 0
"""全処理単位が成功した（要件 9.5）。"""

EXIT_PARTIAL_FAILURE = 1
"""1 件以上が失敗した（要件 9.5）。"""

EXIT_CONFIG_ERROR = 2
"""実行前検証で停止した（要件 8.5、9.5）。"""

MOVING_AVERAGE_DEFAULTS: Mapping[str, int] = {"window": 5, "polyorder": 0}
"""移動平均の既定値（要件 5.4）。設定に書いていないのに効いた値が記録に残ることを見る。"""

N_POINTS = 24
"""1 入力あたりの点数。移動平均の既定窓長より十分多く、実行は 1 秒台で終わる。"""


# --- 入力と設定の用意 ----------------------------------------------------------------


def write_series(path: Path, *, slope: float, intercept: float) -> Path:
    """既知の直線に微小なばらつきを載せた測定データを書き出す。

    値は :func:`repr` で書き、最終ビットまで復元できる表記にする。NumPy のスカラは
    :func:`repr` が ``np.float64(...)`` を返すため、素の :class:`float` だけを扱う。

    ばらつきを 0 にしない。残差が厳密に 0 の系列は標準誤差が算出できず、要件 7.1 の
    「推定値と標準誤差の双方」を確かめられなくなる。
    """
    lines = ["x,y"]
    for index in range(N_POINTS):
        x = float(index) * 0.5
        y = float(slope * x + intercept + (0.01 if index % 2 == 0 else -0.01))
        lines.append(f"{x!r},{y!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_config(path: Path, body: str) -> Path:
    path.write_text(body, encoding="utf-8")
    return path


def toml_string(value: Path | str) -> str:
    """TOML の文字列として安全に書ける形にする。"""
    return json.dumps(str(value), ensure_ascii=False)


def console_script() -> Path:
    """宣言されたコンソールスクリプトの実体（``tests/unit/test_package_scaffold.py``）。

    ``python -m curvefit.cli`` では ``[project.scripts]`` の宣言漏れを検出できない。
    利用者が打つのはコマンド名であり、起動すべきはその実体である。
    """
    return Path(sys.executable).parent / "curvefit"


def run_command(config: Path) -> subprocess.CompletedProcess[str]:
    """コマンドを別プロセスとして起動する（要件 9.2）。"""
    return subprocess.run(
        [str(console_script()), str(config)],
        capture_output=True,
        text=True,
        timeout=300,
    )


# --- 成果物の読み取り ----------------------------------------------------------------


@dataclass(frozen=True)
class Execution:
    """1 回のコマンド実行と、その出力先。"""

    process: subprocess.CompletedProcess[str]
    output_dir: Path
    sources: tuple[Path, ...]
    missing: Path | None = None

    @property
    def stdout(self) -> str:
        return self.process.stdout

    @property
    def stderr(self) -> str:
        return self.process.stderr

    @property
    def returncode(self) -> int:
        return self.process.returncode


def output_files(directory: Path) -> list[str]:
    """出力先に実際に生成されたファイルを、位置の分かる相対表記で並べる。"""
    if not directory.is_dir():
        return []
    return sorted(
        str(item.relative_to(directory)) for item in directory.rglob("*") if item.is_file()
    )


def summary_table(directory: Path) -> tuple[tuple[str, ...], list[dict[str, str]]]:
    """サマリ表を見出しと行に分けて読む。"""
    with (directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = tuple(next(reader))
        rows = [dict(zip(header, row, strict=True)) for row in reader]
    return header, rows


def log_lines(directory: Path) -> list[str]:
    text = (directory / RUN_LOG_NAME).read_text(encoding="utf-8")
    return [line for line in text.splitlines() if line]


def execution_record(directory: Path) -> Mapping[str, object]:
    with (directory / EXECUTION_RECORD_NAME).open(encoding="utf-8") as handle:
        record: Mapping[str, object] = json.load(handle)
    return record


def plot_names(directory: Path) -> list[str]:
    plots = directory / PLOTS_DIRECTORY
    if not plots.is_dir():
        return []
    return sorted(item.name for item in plots.iterdir() if item.is_file())


def job_line(source: Path, method: str) -> str:
    """実行ログ 1 行のうち、対象と手法を指す部分（``logging_setup`` の書式）。"""
    return f"source_id={str(source)!r} method={method!r}"


# --- シナリオ 1: 1 ディレクトリ分の通し実行 ------------------------------------------

SLOPES: Mapping[str, float] = {"alpha": 2.5, "beta": -1.25, "gamma": 0.75}
"""入力ごとの真の傾き。名前は辞書順に並ぶよう選び、処理単位の並びを一意に決める。"""

INTERCEPT = 1.5
"""入力に共通の真の切片。"""

DIRECTORY_CONFIG = """\
[input]
paths = [{data_dir}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "line"
builtin = "linear"

[[methods]]
name = "ma"
smoother = "moving_average"

[output]
directory = {output_dir}
write_plot = true
"""


@pytest.fixture(scope="module")
def directory_run(tmp_path_factory: pytest.TempPathFactory) -> Execution:
    """1 ディレクトリ分（3 入力）× 2 手法を、コマンド 1 回で処理する。"""
    base = tmp_path_factory.mktemp("directory_run")
    data_dir = base / "data"
    data_dir.mkdir()
    sources = tuple(
        write_series(data_dir / f"{name}.csv", slope=slope, intercept=INTERCEPT)
        for name, slope in SLOPES.items()
    )
    output_dir = base / "out"
    config = write_config(
        base / "run.toml",
        DIRECTORY_CONFIG.format(
            data_dir=toml_string(data_dir), output_dir=toml_string(output_dir)
        ),
    )
    return Execution(
        process=run_command(config), output_dir=output_dir, sources=tuple(sorted(sources))
    )


class Test1ディレクトリ分の通し実行:
    """要件 9.2、8.3、8.4、9.5: 設定ファイルの指定だけで出力一式が揃うこと。"""

    def test_終了コードが_0_で標準出力を汚さない(self, directory_run: Execution) -> None:
        """要件 9.5: 全件成功は 0。人が読む出力はすべて標準エラーへ出す。"""
        assert directory_run.returncode == EXIT_SUCCESS, directory_run.stderr
        assert directory_run.stdout == ""
        # 「空でない」だけでは、何を書いたかを問わないため進捗が消えても通ってしまう。
        # 要件 6.3 が求める 2 つの件数と、集計が出ることまで見る。
        assert "処理単位" in directory_run.stderr
        assert "入力" in directory_run.stderr
        assert "成功 6 件" in directory_run.stderr

    def test_出力一式が生成される(self, directory_run: Execution) -> None:
        """要件 7.3、7.4、8.3、8.4: サマリ表・グラフ・実行ログ・実行条件が揃う。"""
        generated = output_files(directory_run.output_dir)
        assert SUMMARY_NAME in generated
        assert RUN_LOG_NAME in generated
        assert EXECUTION_RECORD_NAME in generated
        assert len([name for name in generated if name.startswith(f"{PLOTS_DIRECTORY}/")]) == 6
        # 曲線 CSV は既定で生成しない（要件 7.5）。
        assert not any(name.startswith("curves/") for name in generated), generated

    def test_サマリ表に対象と手法とパラメータの組ごとの行が並ぶ(
        self, directory_run: Execution
    ) -> None:
        """要件 7.3、6.2、5.3: パラメータ数の異なる 2 手法が同一の表に共存する。"""
        header, rows = summary_table(directory_run.output_dir)
        assert header == SUMMARY_HEADER

        expected = {
            (str(source), "line", parameter)
            for source in directory_run.sources
            for parameter in ("slope", "intercept")
        } | {
            # 移動平均は推定パラメータを持たない。行は 1 つ、パラメータ名は空。
            (str(source), "ma", "")
            for source in directory_run.sources
        }
        actual = [
            (row["source_id"], row["method_name"], row["parameter_name"]) for row in rows
        ]
        assert len(actual) == len(expected)
        assert set(actual) == expected
        assert {row["status"] for row in rows} == {"success"}
        assert {row["failure_reason"] for row in rows} == {""}

    def test_サマリ表の推定値が既知の直線を復元する(self, directory_run: Execution) -> None:
        """要件 7.1、7.2: 推定値・標準誤差・適合度が実際の数値として並ぶ。"""
        _, rows = summary_table(directory_run.output_dir)
        for source in directory_run.sources:
            slope_row = next(
                row
                for row in rows
                if row["source_id"] == str(source)
                and row["method_name"] == "line"
                and row["parameter_name"] == "slope"
            )
            intercept_row = next(
                row
                for row in rows
                if row["source_id"] == str(source)
                and row["method_name"] == "line"
                and row["parameter_name"] == "intercept"
            )
            expected_slope = SLOPES[source.stem]
            assert float(slope_row["value"]) == pytest.approx(expected_slope, abs=0.01)
            assert float(intercept_row["value"]) == pytest.approx(INTERCEPT, abs=0.01)
            assert 0.0 < float(slope_row["stderr"]) < 0.01
            assert slope_row["fixed"] == "False"
            assert float(slope_row["r_squared"]) > 0.99
            assert 0.0 < float(slope_row["rmse"]) < 0.05
            assert slope_row["n_points"] == str(N_POINTS)
            assert (
                slope_row["n_dropped_invalid"],
                slope_row["n_dropped_out_of_range"],
                slope_row["n_dropped_outlier"],
            ) == ("0", "0", "0")

    def test_処理単位ごとに_PNG_のグラフ画像が生成される(
        self, directory_run: Execution
    ) -> None:
        """要件 7.4、7.6: 対象を識別できる名前で、互いを上書きしない画像が 1 枚ずつ出る。"""
        expected = [
            f"{source.stem}__{method}__{index:04d}.png"
            for index, (source, method) in enumerate(
                (source, method)
                for source in directory_run.sources
                for method in ("line", "ma")
            )
        ]
        assert plot_names(directory_run.output_dir) == sorted(expected)

        for name in expected:
            content = (directory_run.output_dir / PLOTS_DIRECTORY / name).read_bytes()
            assert content.startswith(PNG_MAGIC), name
            assert len(content) > 1000, name

    def test_実行ログに処理単位ごとの成否と集計が残る(self, directory_run: Execution) -> None:
        """要件 8.4、6.6: 処理した対象とその成否、および件数の集計が行として残る。"""
        lines = log_lines(directory_run.output_dir)
        for source in directory_run.sources:
            for method in ("line", "ma"):
                matched = [line for line in lines if job_line(source, method) in line]
                assert len(matched) == 1, (source, method, lines)
                assert "status=success" in matched[0]
        assert any("status=started" in line for line in lines)
        assert any(
            "status=finished" in line and "n_success=6" in line and "n_failure=0" in line
            for line in lines
        ), lines
        assert not any("status=failure" in line for line in lines)

    def test_実行条件の記録に版と解決済み設定と適用既定値が残る(
        self, directory_run: Execution
    ) -> None:
        """要件 8.3、5.4: 後から実行条件を再構成できる内容が機械可読な形で残る。"""
        record = execution_record(directory_run.output_dir)

        versions = record["library_versions"]
        assert isinstance(versions, dict)
        assert {"lmfit", "scipy", "numpy", "matplotlib"} <= set(versions)
        assert all(isinstance(value, str) and value for value in versions.values())

        resolved = record["resolved_config"]
        assert isinstance(resolved, dict)
        assert resolved["paths"] == [str(directory_run.sources[0].parent)]
        assert resolved["columns"] == {"x": "x", "y": "y", "weight": None}
        assert resolved["header"] is True
        assert [method["name"] for method in resolved["methods"]] == ["line", "ma"]
        assert resolved["output"]["directory"] == str(directory_run.output_dir)
        assert resolved["output"]["write_plot"] is True

        # 設定に書いていない移動平均の窓長・次数が、適用値として残る（要件 5.4）。
        assert record["applied_defaults"] == {"ma": dict(MOVING_AVERAGE_DEFAULTS)}

        assert record["cli_overrides"] == []
        assert isinstance(record["started_at"], str) and record["started_at"]


# --- シナリオ 2: 失敗を含むバッチ ----------------------------------------------------

PARTIAL_FAILURE_CONFIG = """\
[input]
paths = [{good}, {missing}, {other}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "line"
builtin = "linear"

[output]
directory = {output_dir}
write_plot = true
"""


@pytest.fixture(scope="module")
def partial_failure_run(tmp_path_factory: pytest.TempPathFactory) -> Execution:
    """読めない入力を 1 件混ぜたバッチを実行する。

    存在しないファイルを **名指しで** 指定する。ワイルドカードやディレクトリの指定が
    0 件に解決されるのは警告であって失敗ではなく、要件 1.8 の個別失敗にならない。
    """
    base = tmp_path_factory.mktemp("partial_failure_run")
    data_dir = base / "data"
    data_dir.mkdir()
    good = write_series(data_dir / "alpha.csv", slope=2.5, intercept=INTERCEPT)
    other = write_series(data_dir / "beta.csv", slope=-1.25, intercept=INTERCEPT)
    missing = data_dir / "nowhere.csv"
    output_dir = base / "out"
    config = write_config(
        base / "run.toml",
        PARTIAL_FAILURE_CONFIG.format(
            good=toml_string(good),
            missing=toml_string(missing),
            other=toml_string(other),
            output_dir=toml_string(output_dir),
        ),
    )
    return Execution(
        process=run_command(config),
        output_dir=output_dir,
        sources=(good, other),
        missing=missing,
    )


class Test失敗を含むバッチ:
    """要件 6.6、8.4、9.5: 1 件の失敗が残りを止めず、後から原因を追えること。"""

    def test_終了コードが_1_で標準出力を汚さない(
        self, partial_failure_run: Execution
    ) -> None:
        """要件 9.5: 失敗を含む実行は、全件成功と区別できる終了コードで終わる。"""
        assert partial_failure_run.returncode == EXIT_PARTIAL_FAILURE, (
            partial_failure_run.stderr
        )
        assert partial_failure_run.stdout == ""

    def test_実行ログに失敗した対象識別子と理由が残る(
        self, partial_failure_run: Execution
    ) -> None:
        """要件 8.4、6.4: どの対象がなぜ失敗したかを、対象 1 件 1 行で読み取れる。"""
        assert partial_failure_run.missing is not None
        lines = log_lines(partial_failure_run.output_dir)
        matched = [
            line
            for line in lines
            if job_line(partial_failure_run.missing, "line") in line
        ]
        assert len(matched) == 1, lines
        assert "status=failure" in matched[0]
        assert "reason=input_unreadable" in matched[0]
        assert str(partial_failure_run.missing) in matched[0]

    def test_成功した対象の出力はそのまま残る(self, partial_failure_run: Execution) -> None:
        """要件 6.4: 失敗はスキップされ、残りの処理単位の成果物は失われない。"""
        lines = log_lines(partial_failure_run.output_dir)
        for source in partial_failure_run.sources:
            matched = [line for line in lines if job_line(source, "line") in line]
            assert len(matched) == 1, lines
            assert "status=success" in matched[0]

        # 処理単位の番号は入力の絶対パスを並べ替えた順で振られる（設定の記述順でも
        # 読めたかどうかでもない）。alpha < beta < nowhere の順になるため、読めなかった
        # nowhere.csv が末尾の番号を占め、成功した 2 件は 0000 と 0001 に落ち着く。
        # 欠損させる対象の名前を変えるとこの期待値は変わる。
        assert plot_names(partial_failure_run.output_dir) == [
            "alpha__line__0000.png",
            "beta__line__0001.png",
        ]
        assert any(
            "status=finished" in line and "n_success=2" in line and "n_failure=1" in line
            for line in lines
        ), lines

    def test_サマリ表に成功と失敗が同じ表として並ぶ(
        self, partial_failure_run: Execution
    ) -> None:
        """要件 6.6、7.3: 成否の件数をサマリ表と突き合わせられる。"""
        assert partial_failure_run.missing is not None
        header, rows = summary_table(partial_failure_run.output_dir)
        assert header == SUMMARY_HEADER

        failures = [row for row in rows if row["status"] == "failure"]
        assert len(failures) == 1
        failure = failures[0]
        assert failure["source_id"] == str(partial_failure_run.missing)
        assert failure["method_name"] == "line"
        assert failure["failure_reason"] == "input_unreadable"
        assert failure["message"] != ""
        assert (failure["value"], failure["stderr"], failure["r_squared"]) == ("", "", "")

        successes = {
            row["source_id"] for row in rows if row["status"] == "success"
        }
        assert successes == {str(source) for source in partial_failure_run.sources}


# --- シナリオ 3: 設定ファイルに誤りがある実行 ----------------------------------------

INVALID_CONFIG = """\
[input]
paths = [{data_dir}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "line"
builtin = "存在しないモデル"

[[methods]]
name = "ma"
smoother = "moving_average"
options = {{ window = 4 }}

[preprocess]
x_min = 10.0
x_max = 1.0

[preprocess.outlier]
sigma = 0.0

[output]
directory = {output_dir}
"""

EXPECTED_VIOLATIONS: tuple[tuple[str, str], ...] = (
    ("model_unresolved", "method[line].builtin"),
    ("smoother_option_invalid", "method[ma].options"),
    ("config_invalid", "preprocess.x_min"),
    ("config_invalid", "preprocess.outlier.sigma"),
)
"""意図的に仕込んだ違反の分類と位置。1 件ずつ直す往復を強いないため全件が出る。"""


@pytest.fixture(scope="module")
def config_violation_run(tmp_path_factory: pytest.TempPathFactory) -> Execution:
    """実行可能な入力を用意したうえで、設定ファイルに 4 件の誤りを仕込んで実行する。

    出力先はあらかじめ作っておく。書き込める出力先が空のままであることが、
    「処理単位を 1 件も実行していない」ことの観測可能な形である。
    """
    base = tmp_path_factory.mktemp("config_violation_run")
    data_dir = base / "data"
    data_dir.mkdir()
    source = write_series(data_dir / "alpha.csv", slope=2.5, intercept=INTERCEPT)
    output_dir = base / "out"
    output_dir.mkdir()
    config = write_config(
        base / "run.toml",
        INVALID_CONFIG.format(
            data_dir=toml_string(data_dir), output_dir=toml_string(output_dir)
        ),
    )
    return Execution(
        process=run_command(config), output_dir=output_dir, sources=(source,)
    )


class Test設定ファイルの誤り:
    """要件 8.5、9.5: 実行前に停止し、出力先に何も残さないこと。"""

    def test_終了コードが_2_で標準出力を汚さない(
        self, config_violation_run: Execution
    ) -> None:
        """要件 8.5、9.5: 実行前検証での停止は、失敗を含む実行とも区別される。"""
        assert config_violation_run.returncode == EXIT_CONFIG_ERROR, (
            config_violation_run.stderr
        )
        assert config_violation_run.stdout == ""

    def test_出力先に何も生成されない(self, config_violation_run: Execution) -> None:
        """要件 8.5: 処理単位を 1 件も実行していない以上、成果物もログも残らない。"""
        assert config_violation_run.output_dir.is_dir()
        assert list(config_violation_run.output_dir.iterdir()) == []
        assert output_files(config_violation_run.output_dir) == []

    def test_標準エラーに全違反が位置とともに示される(
        self, config_violation_run: Execution
    ) -> None:
        """要件 8.5: 該当箇所を示す。先頭 1 件で打ち切らない。"""
        stderr = config_violation_run.stderr
        for kind, location in EXPECTED_VIOLATIONS:
            assert f"[{kind}] {location}:" in stderr, stderr
        assert str(len(EXPECTED_VIOLATIONS)) in stderr.splitlines()[0]

    def test_違反の提示に対象ごとの説明が付く(
        self, config_violation_run: Execution
    ) -> None:
        """設計の Error Handling: 位置だけでなく、直し方が分かる説明を添える。"""
        lines = [
            line for line in config_violation_run.stderr.splitlines() if line.startswith("  [")
        ]
        assert len(lines) == len(EXPECTED_VIOLATIONS)
        for line, (_, location) in zip(lines, EXPECTED_VIOLATIONS, strict=True):
            assert line.split(f"{location}:", 1)[1].strip() != ""


# --- 3 シナリオの突き合わせ ----------------------------------------------------------


class Test終了状態の区別:
    def test_3_つの実行がそれぞれ異なる終了コードで終わる(
        self,
        directory_run: Execution,
        partial_failure_run: Execution,
        config_violation_run: Execution,
    ) -> None:
        """要件 9.5: 呼び出し元の自動化が、次に見る場所を終了コードだけで決められる。"""
        codes = (
            directory_run.returncode,
            partial_failure_run.returncode,
            config_violation_run.returncode,
        )
        assert codes == (EXIT_SUCCESS, EXIT_PARTIAL_FAILURE, EXIT_CONFIG_ERROR)
        assert len(set(codes)) == 3

    def test_どの実行でも標準出力は空に保たれる(
        self,
        directory_run: Execution,
        partial_failure_run: Execution,
        config_violation_run: Execution,
    ) -> None:
        """設計の cli ブロック: 成果は出力先のファイルと終了コードであり、標準出力ではない。"""
        outputs: Sequence[str] = (
            directory_run.stdout,
            partial_failure_run.stdout,
            config_violation_run.stdout,
        )
        assert outputs == ("", "", "")
