"""利用形態間の一致検証の E2E テスト（要件 1.2、9.1、9.3）。

要件 9.3 は「同一の入力データと同一の実行条件を与えたとき、コマンド経由の結果は
ライブラリを直接使用した場合と同一である」ことを求める。要件 1.2 は「配列・
DataFrame をファイル入力と同一の手順で扱い、同一構造の結果を返す」ことを求める。
本テストはこの 2 つを **実際の数値** の水準で突き合わせる。

比較する 3 つの入口と 3 つの読み込み経路
----------------------------------------

- **コマンド経由**（要件 9.2）— 導入済みのコンソールスクリプトを別プロセスとして起動し、
  出力先に残るサマリ表と曲線・残差 CSV を読む
- **設定ファイルからのライブラリ呼び出し**（:func:`~curvefit.api.run_from_config`）—
  コマンドが内部で通るのと同じ入口を、同じ設定ファイルに対して直接呼ぶ
- **実行条件を組み立てたライブラリ呼び出し**（:func:`~curvefit.api.run_batch`）—
  設定ファイルを読まず、同じ内容の実行条件を Python で組み立てて渡す
- **単一系列の当てはめ**（:func:`~curvefit.api.fit_series`）を、要件 1.2 の 3 経路
  （:func:`~curvefit.readers.read_delimited` / :func:`~curvefit.readers.read_frame` /
  :func:`~curvefit.readers.read_arrays`）それぞれで得た系列に対して呼ぶ

``tests/integration/test_api.py`` との違い
------------------------------------------

統合テストは同一プロセス内でライブラリの経路どうしを比べ、``pipeline`` への到達を
差し替えで観測する。**コマンドとライブラリの比較はそこには無い。** 本テストは実際に
別プロセスとしてコマンドを起動し、その結果ファイルの数値と、同一プロセスで得た
ライブラリの返り値（``float`` そのもの）を突き合わせる。要件 9.3 が問うのは、
利用者が打つコマンドと利用者が書くスクリプトの一致であり、それは実プロセスを
起動しなければ観測できない。

**本テストは 8.1 / 8.2 の E2E と違い :mod:`curvefit` を import する。** 比較の一方が
ライブラリ API そのものだからである。ただし取り込むのは公開ファサード
（:mod:`curvefit.api` が再エクスポートする名前）だけに限り、ファイル名・列構成・
サマリ表の丸め桁・終了コードといった **利用者に見える契約は実装の定数を取り込まず**
本モジュールに書き写す。契約の変更が利用者から見た破壊であることを検出するためである。

一致をどの水準で主張するか
--------------------------

**許容誤差を置かない。** 両者は同一プロセス族で同一のコードを実行しており、
浮動小数点の値が食い違う理由が無い（設計の Key decisions: 要件 9.3 は比較ではなく
:func:`~curvefit.api._execute` という単一経路の構造によって保証される）。比較は
出力の水準ごとに次のとおり厳密に行う。

1. **サマリ表** — バイト単位で一致すること。数値は有効数字
   :data:`SUMMARY_SIGNIFICANT_DIGITS` 桁に丸めて書かれる（``writers`` の Validation）。
   丸めた表記の一致は、丸める前の値の一致の必要条件にすぎない
2. **曲線・残差 CSV** — バイト単位で一致すること。こちらは丸めずに全精度
   （``repr``）で書かれるため、当てはめ値・残差が **最終ビットまで** 一致することを
   意味する。1 だけでは弱い比較になるため、この水準を必ず併せて見る
3. **ライブラリの返り値とコマンドの出力ファイル** — ライブラリが返す ``float`` を
   契約どおりの桁に整形した文字列が、コマンドが書いたサマリ表の欄と一文字も違わない
   こと。および、返り値の当てはめ値の配列が、コマンドが書いた曲線 CSV を読み戻した
   値と ``==`` で一致すること。ファイルどうしの比較だけでは「同じ書き出しを 2 回
   通しただけ」になりうるため、メモリ上の推定値そのものを突き合わせる

3 の後半（全精度の当てはめ値）を担う入口について
------------------------------------------------

一括処理の返り値は **曲線データを保持しない**（要件 10.4、``pipeline`` の
:class:`~curvefit.pipeline.BatchReport`）。全件分を抱えると常駐メモリが処理件数に比例して
増えるためであり、曲線は ``curves/*.csv`` として既にディスクにある。

そこで全精度の突き合わせは **単一系列の入口**（:func:`~curvefit.api.fit_series`）が返す
配列で行う。この入口は曲線を保持したまま返す唯一の経路であり（``api`` の「曲線データの
保持について」）、比較の性質は変わらない。**メモリ上の ``float`` と、別プロセスのコマンドが
書いたファイルとを、丸めを介さずに突き合わせる** という水準そのものが要件 9.3 の主張であり、
それを担う入口が一括処理から単一系列に移っただけである。一括処理の返り値については、
サマリ表の欄との突き合わせ（有効数字 10 桁）と、書き出した曲線 CSV のバイト一致が引き続き
その経路を覆う。

実行時間について
----------------

コンソールスクリプトの起動は **1 回だけ** である。残りの入口は同一プロセス内の
ライブラリ呼び出しであり、実プロセスの起動を伴わない。グラフ出力は無効にしてある
（本テストが見る契約に画像は含まれない）。
"""

from __future__ import annotations

import csv
import json
import subprocess
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from curvefit.api import (
    BatchReport,
    ColumnSpec,
    DataSeries,
    FailurePolicy,
    FitSuccess,
    InputSpec,
    MethodSpec,
    OutputSpec,
    PreprocessSpec,
    RunConfig,
    fit_series,
    read_arrays,
    read_delimited,
    read_frame,
    run_batch,
    run_from_config,
)

# --- 利用者から見た契約（実装の定数は取り込まない）----------------------------------

SUMMARY_NAME = "summary.csv"
"""サマリ表のファイル名（要件 7.3）。"""

CURVES_DIRECTORY = "curves"
"""曲線・残差 CSV を収める下位ディレクトリ（要件 7.5）。"""

CURVE_COLUMNS: tuple[str, ...] = ("x", "y_observed", "y_fit", "residual")
"""曲線・残差 CSV の列（要件 7.5）。"""

SUMMARY_SIGNIFICANT_DIGITS = 10
"""サマリ表の数値の有効数字（``writers`` の Validation）。

利用者への公約であり外部ツールが読む桁数でもある。実装の定数を取り込まずここへ書き
写すのは、桁数の変更が利用者から見た破壊であることを検出するためである。
"""

EXIT_SUCCESS = 0
"""全処理単位が成功した（要件 9.5）。"""

WEIGHT_COLUMN = "sigma"
"""測定誤差 σ の列名（要件 1.3）。

**設定ファイルには書かず、実行時に上書きとして与える。** コマンドは
``--weight-column``、ライブラリは ``overrides`` の ``input.columns.weight`` で渡す
（要件 9.4）。重みは最小二乗の推定値を実際に動かすため、2 つの利用形態が同じ項目を
同じ値として届けているかが推定値の水準で問われる。片方が届け損ねればサマリ表の
数値が食い違う。
"""


# --- 入力の用意 ----------------------------------------------------------------------


@dataclass(frozen=True)
class Source:
    """1 つの入力ファイルと、それを書き出す元になった配列。

    配列を控えておくのは、要件 1.2 の配列経路にファイルを読み直さずに渡すためである。
    読み直して渡すと、比べているのは「同じファイルを 2 回読んだ結果」になり、経路の
    違いを検査したことにならない。
    """

    path: Path
    x: np.ndarray
    y: np.ndarray
    sigma: np.ndarray

    @property
    def stem(self) -> str:
        return self.path.stem


def write_source(
    path: Path, *, seed: int, n_points: int, amplitude: float, center: float
) -> Source:
    """ガウス形の測定データを、誤差列つきの CSV として書き出す。

    値は :func:`repr` で書く。**二進で厳密に表せる値だけを使わない。** 短い十進表記を
    持つ値は、読み込みの丸めが正しくなくてもたまたま元に戻るため、経路の食い違いに
    対して構造的に盲目になる（``tests/integration/test_api.py`` の同旨）。

    ばらつきを 0 にしない。残差が厳密に 0 の系列は標準誤差が算出できず、推定値が重みにも
    点の取捨にも反応しないため、経路が食い違っていても一致してしまう。
    """
    generator = np.random.default_rng(seed)
    x = np.sort(generator.uniform(-4.0, 4.0, n_points))
    y = amplitude * np.exp(-((x - center) ** 2) / (2.0 * 1.2**2)) + generator.normal(
        0.0, 0.02, n_points
    )
    sigma = generator.uniform(0.05, 0.5, n_points)

    lines = [",".join(("x", "y", WEIGHT_COLUMN))]
    for values in zip(x.tolist(), y.tolist(), sigma.tolist(), strict=True):
        lines.append(",".join(repr(float(value)) for value in values))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return Source(path=path, x=x, y=y, sigma=sigma)


SOURCE_PLAN: tuple[tuple[str, int, int, float, float], ...] = (
    ("alpha", 20260817, 41, 3.0, 0.5),
    ("beta", 20260818, 37, 2.0, -0.75),
)
"""入力ごとの（名前・乱数種・点数・振幅・中心）。

2 件用意し、点数も形も変える。1 件だけでは、対象を取り違える食い違い（どの入力の
結果をどの行に書いたか）が一致の比較から漏れる。
"""


# --- 比較に用いる手法 ----------------------------------------------------------------

GAUSSIAN = MethodSpec(name="gauss", kind="builtin", builtin="gaussian")
"""非線形最小二乗（要件 4.1）。初期値を **データから自動推定** する経路であり、
入力が 1 点でも違えば初期値が動き、推定値もずれる。"""

POLYNOMIAL = MethodSpec(
    name="poly", kind="builtin", builtin="polynomial", options={"degree": 3}
)
"""条件の悪い最小二乗。設計行列が強く相関し、入力の最終ビットの差が係数の上位桁に届く。"""

SPLINE = MethodSpec(
    name="spl", kind="smoother", smoother="spline", options={"lam": 0.01}
)
"""平滑化スプライン（要件 5.1）。

``lam`` を明示する。要件 5.5 により平滑化パラメータは必須であり、未指定の設定は実行前
検証で拒否される（自動選択が呼び出しごとに揺れ、要件 8.2 が成立しないため）。
"""

METHODS: tuple[MethodSpec, ...] = (GAUSSIAN, POLYNOMIAL, SPLINE)
"""最小二乗 2 種と平滑化 1 種。エンジンが違えば一致の成立の仕方も違う。"""

PARAMETER_NAMES: Mapping[str, tuple[str, ...]] = {
    "gauss": ("amplitude", "center", "sigma"),
    "poly": ("c0", "c1", "c2", "c3"),
    "spl": (),
}
"""手法ごとのパラメータ名（要件 3.5）。

比較が空振りしていないことを、**何がいくつ並ぶか** の側から固定する。平滑化スプライン
は推定パラメータを持たず、サマリ表には 1 行だけが載る（要件 5.3）。
"""

CONFIG = """\
[input]
paths = [{data_dir}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "gauss"
builtin = "gaussian"

[[methods]]
name = "poly"
builtin = "polynomial"
options = {{ degree = 3 }}

[[methods]]
name = "spl"
smoother = "spline"
options = {{ lam = 0.01 }}

[output]
directory = {output_dir}
write_plot = false
write_curve = true
"""
"""比較に用いる実行条件。

``write_curve`` を有効にするのは、**丸める前の当てはめ値を観測する手段がこれだけ**
だからである（``writers`` の Validation: 丸めるのはサマリ表に限る）。``write_plot`` は
切る。画像は本テストが見る契約に含まれず、1 対象あたり約 1 秒を足す。

誤差列（``input.columns.weight``）は **書かない**。両方の利用形態が実行時の上書きとして
与える（:data:`WEIGHT_COLUMN`）。
"""


def toml_string(value: Path | str) -> str:
    """TOML の文字列として安全に書ける形にする。"""
    return json.dumps(str(value), ensure_ascii=False)


def console_script() -> Path:
    """宣言されたコンソールスクリプトの実体。

    ``python -m curvefit.cli`` では ``[project.scripts]`` の宣言漏れを検出できない。
    利用者が打つのはコマンド名であり、起動すべきはその実体である。
    """
    return Path(sys.executable).parent / "curvefit"


# --- 成果物の読み取り ----------------------------------------------------------------


def summary_bytes(directory: Path) -> bytes:
    return (directory / SUMMARY_NAME).read_bytes()


def summary_rows(directory: Path) -> list[dict[str, str]]:
    with (directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = tuple(next(reader))
        return [dict(zip(header, row, strict=True)) for row in reader]


def curve_names(directory: Path) -> list[str]:
    return sorted(path.name for path in (directory / CURVES_DIRECTORY).iterdir())


def curve_bytes(directory: Path, name: str) -> bytes:
    return (directory / CURVES_DIRECTORY / name).read_bytes()


def curve_column(directory: Path, name: str, column: str) -> list[float]:
    """曲線・残差 CSV の 1 列を、全精度のまま読む。

    値は ``repr`` で書かれているため、:func:`float` で読み戻せば最終ビットまで元の値に
    戻る。丸めを介さずにメモリ上の配列と ``==`` で比べられるのはこのためである。
    """
    path = directory / CURVES_DIRECTORY / name
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = tuple(next(reader))
        assert header == CURVE_COLUMNS, (name, header)
        index = header.index(column)
        return [float(row[index]) for row in reader]


def curve_name_for(directory: Path, source: Source, method: str) -> str:
    """対象と手法に対応する曲線 CSV の名前（出力名の規則 ``{対象}__{手法}__{番号}``）。"""
    matched = [
        name
        for name in curve_names(directory)
        if name.startswith(f"{source.stem}__") and f"__{method}__" in name
    ]
    assert len(matched) == 1, (source.stem, method, matched)
    return matched[0]


def summary_cell(
    rows: Sequence[Mapping[str, str]],
    source: Source,
    method: str,
    parameter: str,
    column: str,
) -> str:
    """サマリ表から、対象・手法・パラメータで 1 つの欄を引く。"""
    matched = [
        row
        for row in rows
        if row["source_id"] == str(source.path)
        and row["method_name"] == method
        and row["parameter_name"] == parameter
    ]
    assert len(matched) == 1, (source.stem, method, parameter, len(matched))
    return matched[0][column]


def as_summary_text(value: float | None) -> str:
    """ライブラリが返す実数を、サマリ表の書式に整形する（``writers`` の公約）。

    実装の整形関数を取り込まない。取り込むと「同じ関数を 2 回呼んだ」比較になり、
    利用者が読む桁数が変わっても気付けない。
    """
    if value is None:
        return ""
    return f"{value:.{SUMMARY_SIGNIFICANT_DIGITS}g}"


def estimates(outcome: object) -> dict[str, tuple[float, float | None]]:
    """成功した当てはめの推定値と標準誤差を、名前で引ける形にする。"""
    assert isinstance(outcome, FitSuccess), outcome
    return {
        parameter.name: (parameter.value, parameter.stderr)
        for parameter in outcome.parameters
    }


# --- 3 つの入口の実行 ----------------------------------------------------------------


@dataclass(frozen=True)
class Parity:
    """同一の入力・同一の実行条件に対する 3 つの入口の実行結果。"""

    sources: tuple[Source, ...]
    cli_output: Path
    library_output: Path
    batch_output: Path
    process: subprocess.CompletedProcess[str]
    library_report: BatchReport
    batch_report: BatchReport

    def outcome(self, source: Source, method: str) -> FitSuccess:
        """ライブラリ（設定ファイル経由）の返り値から、1 処理単位の結果を取り出す。"""
        matched = [
            outcome
            for outcome in self.library_report.outcomes
            if outcome.source_id == str(source.path) and outcome.method_name == method
        ]
        assert len(matched) == 1, (source.stem, method, matched)
        assert isinstance(matched[0], FitSuccess), matched[0]
        return matched[0]


@pytest.fixture(scope="module")
def parity(tmp_path_factory: pytest.TempPathFactory) -> Parity:
    """同一の入力と同一の実行条件を、3 つの入口で実行する。

    出力先だけは入口ごとに分ける。同じ場所に書けば後の実行が前の実行を上書きし、
    比較する対象が残らない。出力先はサマリ表にも曲線 CSV にも現れないため、分けても
    比較から除くものは増えない。

    **出力先の指定の与え方を 3 つの入口で揃える。** コマンドは ``-o``、設定ファイル
    経由のライブラリ呼び出しは ``overrides``、実行条件を組み立てる呼び出しは
    :class:`~curvefit.config.OutputSpec` である。誤差列も同様に、前 2 者は実行時の
    上書きとして与える（要件 9.4）。
    """
    base = tmp_path_factory.mktemp("interface_parity")
    data_dir = base / "data"
    data_dir.mkdir()
    sources = tuple(
        write_source(
            data_dir / f"{name}.csv",
            seed=seed,
            n_points=n_points,
            amplitude=amplitude,
            center=center,
        )
        for name, seed, n_points, amplitude, center in SOURCE_PLAN
    )

    library_output = base / "out_library"
    config = base / "run.toml"
    config.write_text(
        CONFIG.format(data_dir=toml_string(data_dir), output_dir=toml_string(library_output)),
        encoding="utf-8",
    )

    cli_output = base / "out_cli"
    process = subprocess.run(
        [
            str(console_script()),
            str(config),
            "-o",
            str(cli_output),
            "--weight-column",
            WEIGHT_COLUMN,
        ],
        capture_output=True,
        text=True,
        timeout=300,
    )

    library_report = run_from_config(
        config,
        {"output.directory": str(library_output), "input.columns.weight": WEIGHT_COLUMN},
    )
    assert isinstance(library_report, BatchReport), library_report

    batch_output = base / "out_batch"
    batch_report = run_batch(
        RunConfig(
            inputs=InputSpec(
                paths=(str(data_dir),),
                columns=ColumnSpec(x="x", y="y", weight=WEIGHT_COLUMN),
                header=True,
            ),
            methods=METHODS,
            preprocess=PreprocessSpec(),
            output=OutputSpec(
                directory=batch_output,
                write_summary=True,
                write_plot=False,
                write_curve=True,
            ),
            failure_policy=FailurePolicy.SKIP,
        )
    )
    assert isinstance(batch_report, BatchReport), batch_report

    return Parity(
        sources=sources,
        cli_output=cli_output,
        library_output=library_output,
        batch_output=batch_output,
        process=process,
        library_report=library_report,
        batch_report=batch_report,
    )


@pytest.fixture(scope="module")
def single_series(parity: Parity) -> Mapping[tuple[str, str], FitSuccess]:
    """各対象・各手法を、単一系列の入口（:func:`~curvefit.api.fit_series`）でも当てはめる。

    **全精度の当てはめ値を返り値として受け取れる唯一の入口である**（要件 10.4: 一括処理の
    返り値は曲線データを保持しない）。読み込みはコマンドと同じ
    :func:`~curvefit.api.read_delimited` で行い、**誤差列も同じ列名で与える**。系列が
    違えば当てはめ値も違うため、ここを揃えなければ比較は別のデータどうしの比較になる。

    前処理は既定のまま渡す（``preprocess=None``）。比較に使う設定ファイルも
    ``[preprocess]`` を持たないため、両者は同一の前処理を通る。
    """
    columns = ColumnSpec(x="x", y="y", weight=WEIGHT_COLUMN)
    outcomes: dict[tuple[str, str], FitSuccess] = {}
    for source in parity.sources:
        series = read_delimited(source.path, columns, header=True, method_name="single")
        assert isinstance(series, DataSeries), (source.stem, series)
        for method in METHODS:
            outcome = fit_series(series, method)
            assert isinstance(outcome, FitSuccess), (source.stem, method.name, outcome)
            outcomes[(source.stem, method.name)] = outcome
    return outcomes


# --- 比較の前提が成立していること -----------------------------------------------------


class Test比較の前提:
    """一致の主張が空振りしないことを、比較した中身の側から固定する。

    「両方とも成功した」「どちらも 3 件出た」だけの比較では、実際の食い違いが通り抜ける。
    何がいくつ、どんな値として並んだのかをここで確定させる。
    """

    def test_コマンドが実体として起動し全件成功している(self, parity: Parity) -> None:
        """要件 9.2、9.5: 比較の一方が、利用者が打つコマンドの実行結果であること。"""
        assert parity.process.returncode == EXIT_SUCCESS, parity.process.stderr
        assert parity.process.stdout == ""
        assert "成功 6 件" in parity.process.stderr

    def test_3_つの入口がいずれも_6_件を成功させている(self, parity: Parity) -> None:
        """2 入力 × 3 手法。処理単位が 0 件なら、以降の一致はすべて自明に成立する。"""
        expected = len(SOURCE_PLAN) * len(METHODS)
        for report in (parity.library_report, parity.batch_report):
            assert (report.n_success, report.n_failure, report.aborted) == (expected, 0, False)
        # サマリ表はパラメータを行方向に展開する（``writers``）。パラメータを持たない
        # 手法は 1 行を占める。2 入力 × (3 + 4 + 1) = 16 行。
        rows_per_source = sum(len(PARAMETER_NAMES[method.name]) or 1 for method in METHODS)
        assert len(summary_rows(parity.cli_output)) == rows_per_source * len(SOURCE_PLAN)

    def test_サマリ表に手法ごとのパラメータが実際の数値として並ぶ(self, parity: Parity) -> None:
        """要件 7.1、7.2、5.3: 比較しているのが空欄ではなく数値であること。"""
        rows = summary_rows(parity.cli_output)
        assert {row["status"] for row in rows} == {"success"}
        for source in parity.sources:
            for method in METHODS:
                names = PARAMETER_NAMES[method.name]
                for parameter in names or ("",):
                    value = summary_cell(rows, source, method.name, parameter, "value")
                    stderr = summary_cell(rows, source, method.name, parameter, "stderr")
                    r_squared = summary_cell(rows, source, method.name, parameter, "r_squared")
                    if names:
                        assert float(value) != 0.0, (source.stem, method.name, parameter)
                        assert float(stderr) > 0.0, (source.stem, method.name, parameter)
                    else:
                        # 平滑化スプラインは推定パラメータを持たない（要件 5.3）。
                        assert (value, stderr) == ("", "")
                    # 当てはめが退化していないこと。3 次多項式はガウス形の裾を追い切れ
                    # ないため 0.8 台に留まるが、値が意味を持つことは示せる。
                    assert float(r_squared) > 0.5, (source.stem, method.name)

    def test_対象と手法ごとに異なる値が並ぶ(self, parity: Parity) -> None:
        """一致が「どこも同じ定数だった」ことによる自明な成立でないことを示す。

        対象を取り違える食い違い（別の入力の結果を同じ行に書く）は、値が対象ごとに
        異なって初めて検出できる。
        """
        rows = summary_rows(parity.cli_output)
        for method in METHODS:
            per_source = [
                summary_cell(rows, source, method.name, "", "rmse")
                if not PARAMETER_NAMES[method.name]
                else summary_cell(
                    rows, source, method.name, PARAMETER_NAMES[method.name][0], "value"
                )
                for source in parity.sources
            ]
            assert len(set(per_source)) == len(parity.sources), (method.name, per_source)


# --- コマンド経由とライブラリ呼び出しの一致（要件 9.3）-------------------------------


class Testコマンドとライブラリの一致:
    """要件 9.3: 同一の入力・同一の実行条件なら、コマンドとライブラリの結果は同一である。

    比較は 3 つの水準で行い、許容誤差を一切置かない。両者は同一のコードを同一の入力に
    対して実行しており（設計の Key decisions: 公開する 3 つの入口はいずれも
    ``api._execute`` を通る）、値が食い違う根拠が無い。
    """

    def test_サマリ表がバイト単位で一致する(self, parity: Parity) -> None:
        """要件 9.3、7.3: 行の並び・欄・丸めた表記まで含めて 1 バイトも違わない。

        ``source_id`` は入力の絶対パスであり、同一の入力を指す以上は入口を跨いで
        同一である。出力先は表に現れないため、除くべきものが存在しない。
        """
        assert summary_bytes(parity.cli_output) == summary_bytes(parity.library_output)

    def test_全精度の当てはめ値がバイト単位で一致する(self, parity: Parity) -> None:
        """要件 9.3、7.5: 丸める前の値が最終ビットまで一致する。

        サマリ表の一致は有効数字 10 桁での一致にすぎず、それより細かい食い違いを
        通す。曲線・残差 CSV は丸めずに書かれるため、この比較が一致の主張を
        表記の水準から値の水準へ引き上げる。
        """
        names = curve_names(parity.cli_output)
        assert names == curve_names(parity.library_output)
        assert len(names) == len(SOURCE_PLAN) * len(METHODS)
        for name in names:
            assert curve_bytes(parity.cli_output, name) == curve_bytes(
                parity.library_output, name
            ), name

    def test_ライブラリの返り値の推定値がコマンドのサマリ表と一致する(
        self, parity: Parity
    ) -> None:
        """要件 9.3、7.1、7.2: メモリ上の ``float`` と、コマンドが書いた欄を突き合わせる。

        ファイルどうしの比較だけでは「同じ書き出しを 2 回通した」ことしか言えない。
        利用者がスクリプトで受け取るのは返り値であり、そこに載る数値がコマンドの
        出力と同じであることを直接示す。整形は契約どおりの桁でこちらが行う。
        """
        rows = summary_rows(parity.cli_output)
        for source in parity.sources:
            for method in METHODS:
                outcome = parity.outcome(source, method.name)
                assert tuple(estimates(outcome)) == PARAMETER_NAMES[method.name]
                for name, (value, stderr) in estimates(outcome).items():
                    assert as_summary_text(value) == summary_cell(
                        rows, source, method.name, name, "value"
                    ), (source.stem, method.name, name)
                    assert as_summary_text(stderr) == summary_cell(
                        rows, source, method.name, name, "stderr"
                    ), (source.stem, method.name, name)

                parameter = PARAMETER_NAMES[method.name][0] if PARAMETER_NAMES[method.name] else ""
                assert as_summary_text(outcome.goodness.r_squared) == summary_cell(
                    rows, source, method.name, parameter, "r_squared"
                ), (source.stem, method.name)
                assert as_summary_text(outcome.goodness.rmse) == summary_cell(
                    rows, source, method.name, parameter, "rmse"
                ), (source.stem, method.name)
                assert str(outcome.goodness.n_points) == summary_cell(
                    rows, source, method.name, parameter, "n_points"
                ), (source.stem, method.name)

    def test_一括処理の返り値は曲線データを保持しない(self, parity: Parity) -> None:
        """要件 10.4: 全精度の比較を単一系列の入口で行う理由を、事実として固定する。

        この検査が失われると、下の比較が「なぜ一括処理の返り値ではなく
        :func:`~curvefit.api.fit_series` を見ているのか」を説明できなくなる。曲線を
        保持する形に戻れば、ここが赤くなって比較の立て方を見直す機会になる。
        """
        for report in (parity.library_report, parity.batch_report):
            successes = [o for o in report.outcomes if isinstance(o, FitSuccess)]
            assert len(successes) == len(SOURCE_PLAN) * len(METHODS)
            assert all(outcome.curve is None for outcome in successes)
            # 点数は残る。曲線を落としたことが「何も処理していない」と区別できること。
            assert all(outcome.goodness.n_points > 0 for outcome in successes)

    def test_単一系列の返り値の当てはめ値がコマンドの曲線_CSV_と一致する(
        self, parity: Parity, single_series: Mapping[tuple[str, str], FitSuccess]
    ) -> None:
        """要件 9.3、7.5: 返り値の当てはめ値の配列が、コマンドの出力と最終ビットまで同じ。

        丸めを介さない比較である。曲線 CSV は ``repr`` で書かれるため、読み戻した値は
        元の ``float`` に厳密に戻る。

        **メモリ上の配列と、別プロセスのコマンドが書いたファイルとの突き合わせである。**
        ファイルどうしの比較（:meth:`test_全精度の当てはめ値がバイト単位で一致する`）だけ
        では「同じ書き出しを 2 回通した」ことしか言えない。曲線を保持したまま返すのは
        単一系列の入口だけであるため（要件 10.4）、比較の一方はそこから取る。誤差列も
        同じ値で与えており、当てはめに渡る系列はコマンドが読むものと同一である。
        """
        for source in parity.sources:
            for method in METHODS:
                name = curve_name_for(parity.cli_output, source, method.name)
                outcome = single_series[(source.stem, method.name)]
                curve = outcome.curve
                assert curve is not None, (source.stem, method.name)
                for column, values in (
                    ("y_fit", curve.y_fit),
                    ("residual", curve.residual),
                ):
                    from_cli = curve_column(parity.cli_output, name, column)
                    # 空の列どうしでも == は成立する。点数を先に固定する。
                    assert len(from_cli) == outcome.goodness.n_points > 1, (
                        source.stem,
                        method.name,
                        column,
                    )
                    assert from_cli == values.tolist(), (source.stem, method.name, column)


# --- 一括処理の 2 つの入口の一致（要件 9.1）------------------------------------------


class Test設定ファイル経由と実行条件の組み立ての一致:
    """要件 9.1: 設定ファイルから実行しても、実行条件を組み立てて渡しても結果は同一。

    :func:`~curvefit.api.run_from_config` は設定ファイルを読んで実行条件を作り、
    :func:`~curvefit.api.run_batch` は呼び出し元が作った実行条件を受け取る。両者が
    食い違えば、設定ファイルの読み取り（``config``）が実行条件を別物に写している。
    """

    def test_サマリ表がバイト単位で一致する(self, parity: Parity) -> None:
        assert summary_bytes(parity.batch_output) == summary_bytes(parity.library_output)

    def test_全精度の当てはめ値がバイト単位で一致する(self, parity: Parity) -> None:
        names = curve_names(parity.batch_output)
        assert names == curve_names(parity.library_output)
        for name in names:
            assert curve_bytes(parity.batch_output, name) == curve_bytes(
                parity.library_output, name
            ), name

    def test_返り値の推定値が完全に一致する(self, parity: Parity) -> None:
        """返り値どうしを直接比べる。丸めもテキストへの往復も挟まない。"""
        by_key = {
            (outcome.source_id, outcome.method_name): outcome
            for outcome in parity.batch_report.outcomes
        }
        assert len(by_key) == len(parity.library_report.outcomes)
        for source in parity.sources:
            for method in METHODS:
                expected = parity.outcome(source, method.name)
                actual = by_key[(str(source.path), method.name)]
                assert estimates(actual) == estimates(expected), (source.stem, method.name)
                assert actual.goodness == expected.goodness, (source.stem, method.name)


class Test3_つの入口が同一の結果に収束すること:
    """要件 9.1、9.3: 結論。3 つの入口が書いたサマリ表は 1 種類しかない。"""

    def test_サマリ表が_1_種類に収束する(self, parity: Parity) -> None:
        distinct = {
            summary_bytes(directory)
            for directory in (parity.cli_output, parity.library_output, parity.batch_output)
        }
        assert len(distinct) == 1
        # 空のサマリ表 3 つでも「1 種類」は成立する。中身があることまで固定する。
        assert len(summary_rows(parity.cli_output)) > 0


# --- 入力 3 経路の一致（要件 1.2）----------------------------------------------------


@dataclass(frozen=True)
class Routes:
    """同一のデータを 3 経路で読み込んだ系列と、それぞれに対する当てはめ結果。"""

    source: Source
    series: Mapping[str, DataSeries]
    outcomes: Mapping[tuple[str, str], FitSuccess]
    """（読み込み経路、手法名）→ 当てはめ結果。"""


FILE_ROUTE = "read_delimited"
FRAME_ROUTE = "read_frame"
ARRAY_ROUTE = "read_arrays"
ROUTE_NAMES: tuple[str, ...] = (FILE_ROUTE, FRAME_ROUTE, ARRAY_ROUTE)
"""要件 1.2 の 3 経路。名前はライブラリの読み込み関数に対応する。"""


@pytest.fixture(scope="module")
def routes(parity: Parity) -> Routes:
    """同一のデータを 3 経路で読み込み、それぞれ :func:`~curvefit.api.fit_series` に渡す。

    配列経路には **ファイルを読み直さずに** 書き出し元の配列をそのまま渡す。読み直して
    渡すと、比べているのは同じファイルを 2 回読んだ結果になり、経路の違いを検査した
    ことにならない。

    表形式の経路は :mod:`pandas` で読む。``float_precision="round_trip"`` を指定するのは
    利用者に案内している読み方であり（CLI のヘルプ）、既定の解釈器は値の約 46% の
    最下位ビットを変えてしまう。
    """
    source = parity.sources[0]
    columns = ColumnSpec(x="x", y="y", weight=WEIGHT_COLUMN)

    frame = pd.read_csv(source.path, float_precision="round_trip")
    series: dict[str, DataSeries] = {}
    for name, read in (
        (
            FILE_ROUTE,
            lambda: read_delimited(source.path, columns, header=True, method_name="route"),
        ),
        (
            FRAME_ROUTE,
            lambda: read_frame(frame, columns, source_id=FRAME_ROUTE, method_name="route"),
        ),
        (
            ARRAY_ROUTE,
            lambda: read_arrays(
                source.x, source.y, source_id=ARRAY_ROUTE, sigma=source.sigma, method_name="route"
            ),
        ),
    ):
        read_series = read()
        assert isinstance(read_series, DataSeries), (name, read_series)
        series[name] = read_series

    outcomes: dict[tuple[str, str], FitSuccess] = {}
    for name, read_series in series.items():
        for method in METHODS:
            outcome = fit_series(read_series, method)
            assert isinstance(outcome, FitSuccess), (name, method.name, outcome)
            outcomes[(name, method.name)] = outcome

    return Routes(source=source, series=series, outcomes=outcomes)


class Test入力_3_経路の一致:
    """要件 1.2: ファイル・配列・表形式のどれで渡しても、同一の手順で同一の結果になる。

    ``tests/integration/test_api.py`` は 3 経路の推定値どうしを同一プロセス内で比べる。
    本テストはそこに **コマンド経由の結果** を突き合わせる。要件 1.2 の「ファイル入力の
    場合と同一の手順」の「ファイル入力の場合」は、利用者にとってはコマンドの出力である。
    """

    def test_3_経路が読み込んだ系列が最終ビットまで同一である(self, routes: Routes) -> None:
        """比較の前提。ここが崩れていれば、以降の一致は別のデータどうしの比較になる。

        重み（``1/σ``）まで見る。σ から重みへの変換は ``readers`` の 1 か所だけが行う
        （要件 1.3）ため、経路ごとに変換が二重に掛かればここで露見する。
        """
        reference = routes.series[FILE_ROUTE]
        for name in ROUTE_NAMES:
            series = routes.series[name]
            assert np.array_equal(series.x, reference.x), name
            assert np.array_equal(series.y, reference.y), name
            assert series.weights is not None, name
            assert reference.weights is not None
            assert np.array_equal(series.weights, reference.weights), name
        # 重みが実際に効く値であること（すべて 1 なら重みの食い違いが結果に出ない）。
        assert len(set(reference.weights.tolist())) > 1

    def test_3_経路の推定値と当てはめ値が完全に一致する(self, routes: Routes) -> None:
        """要件 1.2: 推定値・標準誤差・適合度・当てはめ値のいずれも厳密に一致する。"""
        for method in METHODS:
            reference = routes.outcomes[(FILE_ROUTE, method.name)]
            for name in ROUTE_NAMES:
                outcome = routes.outcomes[(name, method.name)]
                assert estimates(outcome) == estimates(reference), (name, method.name)
                assert outcome.goodness == reference.goodness, (name, method.name)
                assert outcome.curve.y_fit.tolist() == reference.curve.y_fit.tolist(), (
                    name,
                    method.name,
                )

    def test_3_経路の結果がコマンド経由の推定値と一致する(
        self, routes: Routes, parity: Parity
    ) -> None:
        """要件 1.2、9.3: 単一系列の経路 3 通りが、コマンドが書いた数値と同じになる。

        ここで初めて「配列で渡した当てはめ」と「コマンドでファイルを処理した当てはめ」が
        同じ数値であることが示される。整形は契約どおりの桁でこちらが行う。
        """
        rows = summary_rows(parity.cli_output)
        for name in ROUTE_NAMES:
            for method in METHODS:
                outcome = routes.outcomes[(name, method.name)]
                for parameter, (value, stderr) in estimates(outcome).items():
                    assert as_summary_text(value) == summary_cell(
                        rows, routes.source, method.name, parameter, "value"
                    ), (name, method.name, parameter)
                    assert as_summary_text(stderr) == summary_cell(
                        rows, routes.source, method.name, parameter, "stderr"
                    ), (name, method.name, parameter)

    def test_3_経路の当てはめ値がコマンドの曲線_CSV_と最終ビットまで一致する(
        self, routes: Routes, parity: Parity
    ) -> None:
        """要件 1.2、9.3: 丸めを介さない水準でも 3 経路とコマンドが一致する。"""
        for method in METHODS:
            name = curve_name_for(parity.cli_output, routes.source, method.name)
            from_cli = curve_column(parity.cli_output, name, "y_fit")
            for route in ROUTE_NAMES:
                outcome = routes.outcomes[(route, method.name)]
                assert outcome.curve.y_fit.tolist() == from_cli, (route, method.name)

    def test_3_経路の結果が同一の構造を持つ(self, routes: Routes) -> None:
        """要件 1.2: 「同一構造の結果」であること。欄立てと点数が経路で変わらない。"""
        reference = routes.outcomes[(FILE_ROUTE, GAUSSIAN.name)]
        for name in ROUTE_NAMES:
            outcome = routes.outcomes[(name, GAUSSIAN.name)]
            assert type(outcome) is type(reference), name
            assert [p.name for p in outcome.parameters] == [p.name for p in reference.parameters]
            assert outcome.goodness.n_points == reference.goodness.n_points == len(routes.source.x)
            assert outcome.preprocess == reference.preprocess, name
