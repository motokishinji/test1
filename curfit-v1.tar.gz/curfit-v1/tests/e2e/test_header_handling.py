"""見出し行の指定が経路全体で効いていることの E2E 検査（要件 1.6、1.7）。

要件 1.6 は「見出し行の有無が指定されている場合、その指定に従って先頭行を解釈する」
ことを求める。要件 1.7 は「指定が無く、位置による列指定が与えられ、位置で指定された列の
先頭行の値がすべて数値として解釈できる」入力を、推測せずに失敗として報告することを求める。
指定は **3 状態** である（明示あり / 明示なし / 未指定）。

なぜ E2E で固定するか
---------------------

``tests/unit/test_readers.py`` は 3 状態を :func:`~curvefit.readers.read_delimited` の
引数として直接与えて確かめている。**そこには設定ファイルから読み込みまでの受け渡しが
無い。** 実際、``pipeline`` が読み込みに渡す見出し指定を ``None`` に置き換えても
（＝設定に書いた ``header`` を捨てても）読み込み層の単体検査は全件通る。要件 1.6 の
実装が正しくても、それを読み込みまで届ける配管が切れた瞬間に、見出しのない入力から
**先頭の測定点が黙って失われる**。この欠落こそが要件 1.6 / 1.7 を追加した元の不具合で
あり、無言で再発しうる状態にある。

本テストは 3 状態を **設定ファイル → コマンド / ライブラリ → 読み込み → 当てはめ →
出力** の全体で固定する。観測するのは配管そのものではなく、配管が切れたときに変わる
利用者から見える値である。

- **点数** — サマリ表の ``n_points``。先頭行をデータとして読めば 24、見出しとして
  消費すれば 23
- **推定値** — 先頭の測定点だけを既知の量（:data:`FIRST_POINT_OFFSET`）だけずらして
  ある。その点が当てはめに参加すれば切片は真値から離れ、参加しなければ真値に戻る。
  点数だけを見る検査は「読めた行数」しか見ないが、要件が守ろうとしているのは
  **推定結果** である
- **曲線 CSV の先頭行** — 先頭の測定点が実際に残っているか（要件 7.5）
- **失敗の報告** — 未指定かつ判断できない入力が ``header_ambiguous`` として記録され、
  バッチの残りが継続すること（要件 6.4 の既定、要件 1.8 と同じ扱い）

``tests/unit/test_readers.py`` / ``tests/integration/test_config.py`` との違い
------------------------------------------------------------------------------

単体は読み込み層の引数として、統合は設定ファイルの読み取り結果としてそれぞれ 3 状態を
見る。**両者を繋ぐ区間はどちらの担当でもない。** 本テストはその区間を含む全体を、
利用者が打つコマンドと利用者が書くスクリプトの双方で通す。

``tests/e2e/test_interface_parity.py`` と同じく、比較の一方がライブラリ API そのもので
あるため :mod:`curvefit` を import する。ただし取り込むのは公開ファサード
（:mod:`curvefit.api`）だけであり、ファイル名・列構成・終了コード・失敗理由の綴りといった
**利用者に見える契約は実装の定数を取り込まず** 本モジュールに書き写す。契約の変更が
利用者から見た破壊であることを検出するためである。

実行時間について
----------------

コンソールスクリプトの起動は **3 回** である（明示あり / 明示なしの上書き / 未指定）。
残りは同一プロセス内のライブラリ呼び出しであり、グラフ出力は全経路で無効にしてある。
"""

from __future__ import annotations

import csv
import json
import subprocess
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

import pytest

from curvefit.api import (
    BatchReport,
    ColumnSpec,
    FailurePolicy,
    FailureReason,
    FitFailure,
    FitSuccess,
    InputSpec,
    MethodSpec,
    OutputSpec,
    PreprocessSpec,
    RunConfig,
    run_batch,
    run_from_config,
)

# --- 利用者から見た契約（実装の定数は取り込まない）----------------------------------

SUMMARY_NAME = "summary.csv"
"""サマリ表のファイル名（要件 7.3）。"""

RUN_LOG_NAME = "run.log"
"""実行ログのファイル名（要件 8.4）。"""

EXECUTION_RECORD_NAME = "execution.json"
"""実行条件の記録のファイル名（要件 8.3）。"""

CURVES_DIRECTORY = "curves"
"""曲線・残差 CSV を収める下位ディレクトリ（要件 7.5）。"""

CURVE_COLUMNS: tuple[str, ...] = ("x", "y_observed", "y_fit", "residual")
"""曲線・残差 CSV の列（要件 7.5）。"""

HEADER_KEY = "header"
"""実行条件の記録に載る見出し行の項目名（要件 8.3）。3 状態のどれで読んだかが残る。"""

HEADER_AMBIGUOUS_REASON = "header_ambiguous"
"""見出し行の有無を判断できなかった失敗の理由（要件 1.7）。

サマリ表と実行ログに現れる綴りであり、外部ツールが失敗を分類する手掛かりである。
"""

EXIT_SUCCESS = 0
"""全処理単位が成功した（要件 9.5）。"""

EXIT_PARTIAL_FAILURE = 1
"""1 件以上が失敗した（要件 9.5）。"""


# --- 入力データ ----------------------------------------------------------------------

N_POINTS = 24
"""測定点の数。見出し行を含めるかどうかで 24 と 23 に分かれる。"""

SLOPE = 2.5
"""真の傾き。"""

INTERCEPT = 1.5
"""真の切片。"""

FIRST_POINT_OFFSET = 1.0
"""先頭の測定点にだけ載せるずれ。

**点数の一致だけでは要件を守れない。** 要件 1.6 / 1.7 が守ろうとしているのは読めた
行数ではなく推定結果であり、先頭の 1 点が失われたことは推定値に現れて初めて利用者の
被害になる。先頭点だけを既知の量だけずらしておくと、その点が当てはめに参加した場合と
しなかった場合で切片が判別可能なだけ食い違う（参加すれば約 1.66、しなければ約 1.50）。

残りの点には ±0.01 の微小なばらつきだけを載せる。残差が厳密に 0 の系列では標準誤差が
算出できず、成功の中身を確かめられなくなるためである。ずれは外れ値除去の既定
（無効）では除外されない。
"""

INTERCEPT_TOLERANCE = 0.01
"""先頭点を含まない当てはめが真の切片を復元する許容差。"""

INTERCEPT_SHIFT_FLOOR = 0.1
"""先頭点を含む当てはめが真の切片から離れる最小量。

:data:`FIRST_POINT_OFFSET` から定まる実際のずれ（約 0.158）より小さく、ばらつきが
生む揺れ（0.01 水準）より十分大きい値を選ぶ。定義式を書き写すと恒真になるため、
両側から挟める定数として置く。
"""


def data_rows() -> list[str]:
    """見出しを持たない測定データの行を返す。

    値は :func:`repr` で書き、最終ビットまで復元できる表記にする（``readers`` が
    ``float_precision="round_trip"`` で読むことと対になる）。
    """
    rows: list[str] = []
    for index in range(N_POINTS):
        x = float(index) * 0.5
        y = float(SLOPE * x + INTERCEPT + (0.01 if index % 2 == 0 else -0.01))
        if index == 0:
            y = float(y + FIRST_POINT_OFFSET)
        rows.append(f"{x!r},{y!r}")
    return rows


FIRST_X = 0.0
"""先頭の測定点の x。見出し行として消費されると曲線 CSV から消える。"""

SECOND_X = 0.5
"""2 番目の測定点の x。先頭行が消費された場合に曲線 CSV の先頭に来る。"""

FIRST_Y = float(SLOPE * FIRST_X + INTERCEPT + 0.01 + FIRST_POINT_OFFSET)
"""先頭の測定点の y。"""


def write_headerless(path: Path) -> Path:
    """見出し行を持たない入力（装置からの素の 2 列出力）。"""
    path.write_text("\n".join(data_rows()) + "\n", encoding="utf-8")
    return path


def write_labelled(path: Path) -> Path:
    """見出し行を持つ入力。測定点は :func:`write_headerless` と同一である。

    同一の測定点を持たせるのは、見出し行の扱いが異なる 2 つの入力から **同じ推定値**
    が出ることを突き合わせられるようにするためである。``header = false`` の入力から
    出た推定値が、見出しを持つ入力の推定値と一致していれば、先頭行がデータとして
    読まれたことを点数以外の側からも確かめられる。
    """
    path.write_text("x,y\n" + "\n".join(data_rows()) + "\n", encoding="utf-8")
    return path


def toml_string(value: Path | str) -> str:
    """TOML の文字列として安全に書ける形にする。"""
    return json.dumps(str(value), ensure_ascii=False)


# --- 設定 ----------------------------------------------------------------------------

POSITIONAL_CONFIG = """\
[input]
paths = [{paths}]
{header_line}
[input.columns]
x = 0
y = 1

[[methods]]
name = "line"
builtin = "linear"

[output]
directory = {output_dir}
write_plot = false
write_curve = true
"""
"""位置による列指定の設定。

**列は位置で指定する。** 要件 1.7 の検査が作動する条件であり、``header = false`` を
指定した入力は見出しを持たないため名前では指定できない（見出しの無い入力に名前指定を
与えると要件 1.4 の失敗になる）。

``write_curve`` を有効にするのは、**先頭の測定点が残っているかを直接観測する手段が
これだけ** だからである。``write_plot`` は切る（画像は本テストが見る契約に含まれない）。
"""


def write_config(
    path: Path, *, paths: Sequence[Path], header: bool | None, output_dir: Path
) -> Path:
    """3 状態のいずれかを書いた設定ファイルを用意する。

    ``header`` が ``None`` の場合は **行そのものを書かない**。``header`` の欄に何かを
    書けば未指定にはならず、未指定という 3 番目の状態を作れない。
    """
    header_line = "" if header is None else f"header = {'true' if header else 'false'}\n"
    body = POSITIONAL_CONFIG.format(
        paths=", ".join(toml_string(item) for item in paths),
        header_line=header_line,
        output_dir=toml_string(output_dir),
    )
    path.write_text(body, encoding="utf-8")
    return path


def console_script() -> Path:
    """宣言されたコンソールスクリプトの実体。

    ``python -m curvefit.cli`` では ``[project.scripts]`` の宣言漏れを検出できない。
    利用者が打つのはコマンド名であり、起動すべきはその実体である。
    """
    return Path(sys.executable).parent / "curvefit"


def run_command(config: Path, *arguments: str) -> subprocess.CompletedProcess[str]:
    """コマンドを別プロセスとして起動する（要件 9.2）。"""
    return subprocess.run(
        [str(console_script()), str(config), *arguments],
        capture_output=True,
        text=True,
        timeout=300,
    )


# --- 成果物の読み取り ----------------------------------------------------------------


@dataclass(frozen=True)
class Execution:
    """1 回のコマンド実行と、その出力先。"""

    process: subprocess.CompletedProcess[str]
    output_dir: Path
    source: Path

    @property
    def returncode(self) -> int:
        return self.process.returncode

    @property
    def stderr(self) -> str:
        return self.process.stderr


def summary_rows(directory: Path) -> list[dict[str, str]]:
    with (directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = tuple(next(reader))
        return [dict(zip(header, row, strict=True)) for row in reader]


def parameter_row(directory: Path, source: Path, parameter: str) -> dict[str, str]:
    matched = [
        row
        for row in summary_rows(directory)
        if row["source_id"] == str(source) and row["parameter_name"] == parameter
    ]
    assert len(matched) == 1, (source, parameter, matched)
    return matched[0]


def curve_rows(directory: Path, source: Path) -> list[tuple[float, ...]]:
    """対象に対応する曲線・残差 CSV を、全精度のまま読む（要件 7.5）。"""
    matched = [
        path
        for path in (directory / CURVES_DIRECTORY).iterdir()
        if path.name.startswith(f"{source.stem}__")
    ]
    assert len(matched) == 1, (source.stem, matched)
    with matched[0].open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        assert tuple(next(reader)) == CURVE_COLUMNS
        return [tuple(float(value) for value in row) for row in reader]


def log_lines(directory: Path) -> list[str]:
    text = (directory / RUN_LOG_NAME).read_text(encoding="utf-8")
    return [line for line in text.splitlines() if line]


def execution_record(directory: Path) -> Mapping[str, object]:
    with (directory / EXECUTION_RECORD_NAME).open(encoding="utf-8") as handle:
        record: Mapping[str, object] = json.load(handle)
    return record


def resolved_header(directory: Path) -> object:
    resolved = execution_record(directory)["resolved_config"]
    assert isinstance(resolved, dict)
    return resolved[HEADER_KEY]


# --- 明示指定（要件 1.6）------------------------------------------------------------


@dataclass(frozen=True)
class ExplicitWorkspace:
    """``header = true`` を書いた設定と、見出しを持たない入力 1 件。"""

    config: Path
    source: Path
    labelled: Path
    base: Path


@pytest.fixture(scope="module")
def explicit_workspace(tmp_path_factory: pytest.TempPathFactory) -> ExplicitWorkspace:
    """設定に ``header = true`` を書き、見出しを持たない入力を与える。

    **設定と入力が食い違っている状態を意図して作る。** 指定に従えば先頭の測定点は
    見出しとして消費され、点数は 23 になる。この食い違いこそが「指定が実際に効いた
    かどうか」を観測できる形であり、指定と入力が一致していると、指定を無視しても
    同じ結果になるため検査にならない。

    同じ設定ファイルを ``--no-header`` で起動し直すことで、上書き（要件 9.4）を含む
    もう一方の明示状態も同じ入力に対して観測する。
    """
    base = tmp_path_factory.mktemp("explicit_state")
    data_dir = base / "data"
    data_dir.mkdir()
    source = write_headerless(data_dir / "raw.csv")
    labelled = write_labelled(data_dir / "labelled.csv")
    config = write_config(
        base / "run.toml", paths=[source], header=True, output_dir=base / "out_true"
    )
    return ExplicitWorkspace(config=config, source=source, labelled=labelled, base=base)


@pytest.fixture(scope="module")
def header_true_run(explicit_workspace: ExplicitWorkspace) -> Execution:
    """``header = true``: 先頭行を見出しとして解釈する。"""
    return Execution(
        process=run_command(explicit_workspace.config),
        output_dir=explicit_workspace.base / "out_true",
        source=explicit_workspace.source,
    )


@pytest.fixture(scope="module")
def header_false_run(explicit_workspace: ExplicitWorkspace) -> Execution:
    """``--no-header``: 同じ設定ファイルを上書きして、先頭行をデータとして解釈する。"""
    output_dir = explicit_workspace.base / "out_false"
    return Execution(
        process=run_command(
            explicit_workspace.config, "--no-header", "--output", str(output_dir)
        ),
        output_dir=output_dir,
        source=explicit_workspace.source,
    )


class Test見出しありを明示した場合:
    """要件 1.6: ``header = true`` は先頭行を見出しとして解釈させる。

    数値に見える先頭行を持つ入力であっても、明示指定は要件 1.7 の推測に優先する
    （``readers`` の Postconditions）。誤検出された入力の逃げ道でもある。
    """

    def test_終了コードが_0_で先頭行が見出しとして消費される(
        self, header_true_run: Execution
    ) -> None:
        """明示指定があるため要件 1.7 の検査は作動せず、点数は 1 つ減る。"""
        assert header_true_run.returncode == EXIT_SUCCESS, header_true_run.stderr
        row = parameter_row(header_true_run.output_dir, header_true_run.source, "slope")
        assert row["status"] == "success"
        assert row["n_points"] == str(N_POINTS - 1)

    def test_先頭の測定点が当てはめに参加しない(self, header_true_run: Execution) -> None:
        """要件 7.5: 曲線 CSV に先頭の測定点が現れない（見出しとして消費された）。"""
        rows = curve_rows(header_true_run.output_dir, header_true_run.source)
        assert len(rows) == N_POINTS - 1
        assert rows[0][0] == SECOND_X

    def test_先頭点を除いた推定値になる(self, header_true_run: Execution) -> None:
        """ずらした先頭点が参加していないため、切片は真値に戻る。"""
        intercept = float(
            parameter_row(header_true_run.output_dir, header_true_run.source, "intercept")[
                "value"
            ]
        )
        assert intercept == pytest.approx(INTERCEPT, abs=INTERCEPT_TOLERANCE)

    def test_実行条件の記録に見出しありが残る(self, header_true_run: Execution) -> None:
        """要件 8.3: 3 状態のどれで読んだかを後から判別できる。"""
        assert resolved_header(header_true_run.output_dir) is True


class Test見出しなしを明示した場合:
    """要件 1.6、9.4: ``--no-header`` は先頭行をデータとして解釈させる。

    **これが黙って壊れていた状態である。** 見出しを持たない入力の先頭行が見出しとして
    消費されると、失敗にも警告にもならないまま最初の測定点が失われる。
    """

    def test_終了コードが_0_で先頭行がデータとして読まれる(
        self, header_false_run: Execution
    ) -> None:
        assert header_false_run.returncode == EXIT_SUCCESS, header_false_run.stderr
        row = parameter_row(header_false_run.output_dir, header_false_run.source, "slope")
        assert row["status"] == "success"
        assert row["n_points"] == str(N_POINTS)

    def test_先頭の測定点が曲線に残る(self, header_false_run: Execution) -> None:
        """要件 7.5: 先頭行の x・実測値がそのまま 1 点目として並ぶ。"""
        rows = curve_rows(header_false_run.output_dir, header_false_run.source)
        assert len(rows) == N_POINTS
        assert rows[0][0] == FIRST_X
        assert rows[0][1] == FIRST_Y

    def test_先頭点が推定値に効く(self, header_false_run: Execution) -> None:
        """点数だけでなく **推定結果** が先頭点の参加を反映する。"""
        intercept = float(
            parameter_row(
                header_false_run.output_dir, header_false_run.source, "intercept"
            )["value"]
        )
        assert abs(intercept - INTERCEPT) > INTERCEPT_SHIFT_FLOOR

    def test_見出しを持つ同一データと同じ推定値になる(
        self,
        header_false_run: Execution,
        explicit_workspace: ExplicitWorkspace,
        tmp_path: Path,
    ) -> None:
        """先頭行がデータとして読まれた証拠を、点数以外の側からも取る。

        測定点が同一で見出し行だけを持つ入力を ``header = true`` で読むと、同じ 24 点に
        なる。両者の推定値・標準誤差・適合度がサマリ表の表記として一文字も違わなければ、
        ``header = false`` の経路は先頭行を確かに測定点として読んでいる。
        """
        output_dir = tmp_path / "out_labelled"
        config = write_config(
            tmp_path / "labelled.toml",
            paths=[explicit_workspace.labelled],
            header=True,
            output_dir=output_dir,
        )
        report = run_from_config(config)
        assert isinstance(report, BatchReport), report

        compared = ("value", "stderr", "r_squared", "rmse", "n_points")
        for parameter in ("slope", "intercept"):
            from_headerless = parameter_row(
                header_false_run.output_dir, header_false_run.source, parameter
            )
            from_labelled = parameter_row(
                output_dir, explicit_workspace.labelled, parameter
            )
            assert [from_headerless[key] for key in compared] == [
                from_labelled[key] for key in compared
            ], parameter

    def test_実行条件の記録に見出しなしと上書きが残る(
        self, header_false_run: Execution
    ) -> None:
        """要件 8.3、9.4: 適用した値と、設定ファイルの値の双方が残る。"""
        assert resolved_header(header_false_run.output_dir) is False
        record = execution_record(header_false_run.output_dir)
        overrides = record["cli_overrides"]
        assert isinstance(overrides, list)
        assert {
            "key": "input.header",
            "config_value": True,
            "cli_value": False,
        } in overrides


# --- 未指定（要件 1.7）--------------------------------------------------------------


@dataclass(frozen=True)
class UnspecifiedRun:
    """見出し指定を書かない設定での 1 回のバッチ実行。"""

    process: subprocess.CompletedProcess[str]
    output_dir: Path
    headerless: Path
    labelled: Path

    @property
    def returncode(self) -> int:
        return self.process.returncode

    @property
    def stderr(self) -> str:
        return self.process.stderr


@pytest.fixture(scope="module")
def unspecified_run(tmp_path_factory: pytest.TempPathFactory) -> UnspecifiedRun:
    """見出し指定を書かない設定で、判断できる入力と判断できない入力を並べる。

    2 件を 1 回のバッチで処理するのは、未指定の 2 つの分岐（先頭行が数値と解釈できる /
    できない）を同じ実行条件の下で対比させ、併せて要件 6.4 の既定（失敗をスキップして
    継続する）が働くことを見るためである。
    """
    base = tmp_path_factory.mktemp("unspecified_state")
    data_dir = base / "data"
    data_dir.mkdir()
    # 処理単位の番号は入力の絶対パスを並べ替えた順で振られる。名前は本テストの表明に
    # 影響しない（対象は source_id で選ぶ）が、並びを一意にしておく。
    labelled = write_labelled(data_dir / "labelled.csv")
    headerless = write_headerless(data_dir / "raw.csv")
    output_dir = base / "out"
    config = write_config(
        base / "run.toml",
        paths=[headerless, labelled],
        header=None,
        output_dir=output_dir,
    )
    return UnspecifiedRun(
        process=run_command(config),
        output_dir=output_dir,
        headerless=headerless,
        labelled=labelled,
    )


class Test見出し指定が無い場合:
    """要件 1.7: 未指定は 3 番目の状態であり、``false`` と同じではない。

    位置による列指定で先頭行の値がすべて数値として解釈できる入力は、推測せずに失敗と
    して報告する。先頭行が数値として解釈できない入力は見出しとして読む（誤検出しない）。
    """

    def test_終了コードが_1_で片方だけが失敗する(
        self, unspecified_run: UnspecifiedRun
    ) -> None:
        """要件 6.4、9.5: 失敗は当該対象に閉じ、残りは処理される。"""
        assert unspecified_run.returncode == EXIT_PARTIAL_FAILURE, unspecified_run.stderr
        statuses = {
            row["source_id"]: row["status"] for row in summary_rows(unspecified_run.output_dir)
        }
        assert statuses[str(unspecified_run.headerless)] == "failure"
        assert statuses[str(unspecified_run.labelled)] == "success"

    def test_判断できない入力が失敗理由とともに記録される(
        self, unspecified_run: UnspecifiedRun
    ) -> None:
        """要件 1.7、7.3: どの対象がなぜ失敗したかがサマリ表に残る。"""
        rows = [
            row
            for row in summary_rows(unspecified_run.output_dir)
            if row["source_id"] == str(unspecified_run.headerless)
        ]
        assert len(rows) == 1
        failure = rows[0]
        assert failure["failure_reason"] == HEADER_AMBIGUOUS_REASON
        assert failure["n_points"] == ""
        # 次の行動（どちらを書けばよいか）が示されること。パスにも現れうる "header"
        # 単体ではなく、指定の形そのものを見る。
        assert "header=False" in failure["message"]
        assert "header=True" in failure["message"]

    def test_実行ログにも同じ理由が残る(self, unspecified_run: UnspecifiedRun) -> None:
        """要件 8.4: 実行ログ 1 行から対象と理由を読み取れる。"""
        matched = [
            line
            for line in log_lines(unspecified_run.output_dir)
            if f"source_id='{unspecified_run.headerless}'" in line
        ]
        assert len(matched) == 1, matched
        assert "status=failure" in matched[0]
        assert f"reason={HEADER_AMBIGUOUS_REASON}" in matched[0]

    def test_判断できる入力は全点が読まれる(self, unspecified_run: UnspecifiedRun) -> None:
        """先頭行が数値として解釈できない入力では検査は作動せず、測定点は失われない。"""
        row = parameter_row(unspecified_run.output_dir, unspecified_run.labelled, "slope")
        assert row["status"] == "success"
        assert row["n_points"] == str(N_POINTS)
        rows = curve_rows(unspecified_run.output_dir, unspecified_run.labelled)
        assert len(rows) == N_POINTS
        assert rows[0][0] == FIRST_X

    def test_失敗した対象の出力は書かれない(self, unspecified_run: UnspecifiedRun) -> None:
        """要件 6.4: 成功した対象の成果物だけが残る。"""
        names = sorted(
            path.name for path in (unspecified_run.output_dir / CURVES_DIRECTORY).iterdir()
        )
        assert len(names) == 1, names
        assert names[0].startswith(f"{unspecified_run.labelled.stem}__")

    def test_実行条件の記録に未指定が残る(self, unspecified_run: UnspecifiedRun) -> None:
        """要件 8.3: 未指定は ``null`` として残り、``false`` と区別できる。"""
        assert resolved_header(unspecified_run.output_dir) is None


# --- ライブラリ経由（要件 9.1、9.3）--------------------------------------------------

METHODS: tuple[MethodSpec, ...] = (
    MethodSpec(name="line", kind="builtin", builtin="linear"),
)
"""ライブラリ経由の実行で用いる手法。コマンド経由の設定と同一である。"""


def build_config(
    *, source: Path, columns: ColumnSpec, header: bool | None, output_dir: Path
) -> RunConfig:
    """設定ファイルを読まずに実行条件を組み立てる（要件 9.1）。"""
    return RunConfig(
        inputs=InputSpec(paths=(str(source),), columns=columns, header=header),
        methods=METHODS,
        preprocess=PreprocessSpec(),
        output=OutputSpec(
            directory=output_dir, write_summary=True, write_plot=False, write_curve=False
        ),
        failure_policy=FailurePolicy.SKIP,
    )


def single_outcome(report: object) -> FitSuccess | FitFailure:
    assert isinstance(report, BatchReport), report
    assert len(report.outcomes) == 1, report.outcomes
    return report.outcomes[0]


class Testライブラリ経由の見出し行指定:
    """要件 9.1、9.3: 3 状態はライブラリ呼び出しでも同じように効く。

    コマンド経由と同じ経路（``api._execute``）を通るが、**同じ経路を通ることは検査の
    代わりにならない**。要件 1.6 の指定を運ぶのは呼び出し側が組み立てた実行条件であり、
    その受け渡しが切れれば利用形態を問わず結果が変わる。
    """

    def test_見出しなしを明示すると先頭行がデータになる(self, tmp_path: Path) -> None:
        """要件 1.6: ``header=False`` で全 24 点が読まれる。"""
        source = write_headerless(tmp_path / "raw.csv")
        report = run_batch(
            build_config(
                source=source,
                columns=ColumnSpec(x=0, y=1),
                header=False,
                output_dir=tmp_path / "out_false",
            )
        )
        outcome = single_outcome(report)
        assert isinstance(outcome, FitSuccess), outcome
        assert outcome.goodness.n_points == N_POINTS
        assert outcome.preprocess.n_input == N_POINTS

    def test_見出しありを明示すると先頭行が消費される(self, tmp_path: Path) -> None:
        """要件 1.6: 同一の入力が ``header=True`` では 23 点になる。"""
        source = write_headerless(tmp_path / "raw.csv")
        report = run_batch(
            build_config(
                source=source,
                columns=ColumnSpec(x=0, y=1),
                header=True,
                output_dir=tmp_path / "out_true",
            )
        )
        outcome = single_outcome(report)
        assert isinstance(outcome, FitSuccess), outcome
        assert outcome.goodness.n_points == N_POINTS - 1

    def test_見出しありを明示すれば名前で列を指定できる(self, tmp_path: Path) -> None:
        """要件 1.6、1.1: 見出しを持つ入力では、消費した先頭行が列名として使える。

        位置指定の側だけを見ると、見出し行を「捨てる行」としてしか扱っていない実装でも
        通ってしまう。名前で解決できることが、先頭行が **見出しとして** 解釈された
        ことの裏づけになる。
        """
        source = write_labelled(tmp_path / "labelled.csv")
        report = run_batch(
            build_config(
                source=source,
                columns=ColumnSpec(x="x", y="y"),
                header=True,
                output_dir=tmp_path / "out_named_true",
            )
        )
        outcome = single_outcome(report)
        assert isinstance(outcome, FitSuccess), outcome
        assert outcome.goodness.n_points == N_POINTS

    def test_未指定かつ位置指定では失敗として返る(self, tmp_path: Path) -> None:
        """要件 1.7: 判断できない入力は例外ではなく失敗として返り、バッチは続く。"""
        source = write_headerless(tmp_path / "raw.csv")
        report = run_batch(
            build_config(
                source=source,
                columns=ColumnSpec(x=0, y=1),
                header=None,
                output_dir=tmp_path / "out_unset",
            )
        )
        outcome = single_outcome(report)
        assert isinstance(outcome, FitFailure), outcome
        assert outcome.reason is FailureReason.HEADER_AMBIGUOUS
        assert outcome.source_id == str(source)
        assert "header=False" in outcome.message

    def test_未指定でも名前指定なら検査は作動しない(self, tmp_path: Path) -> None:
        """要件 1.7: 検査の条件は位置による列指定である。

        名前指定では先頭行が見出しとして解釈されなければ列が解決できず、測定点が
        黙って失われる形にならない。
        """
        source = write_labelled(tmp_path / "labelled.csv")
        report = run_batch(
            build_config(
                source=source,
                columns=ColumnSpec(x="x", y="y"),
                header=None,
                output_dir=tmp_path / "out_named",
            )
        )
        outcome = single_outcome(report)
        assert isinstance(outcome, FitSuccess), outcome
        assert outcome.goodness.n_points == N_POINTS

    def test_3_状態が実行条件の記録に区別して残る(self, tmp_path: Path) -> None:
        """要件 8.3: ``None`` と ``False`` を同じ値に潰さない。"""
        source = write_headerless(tmp_path / "raw.csv")
        recorded: list[object] = []
        for index, header in enumerate((True, False, None)):
            report = run_batch(
                build_config(
                    source=source,
                    columns=ColumnSpec(x=0, y=1),
                    header=header,
                    output_dir=tmp_path / f"out_{index}",
                )
            )
            assert isinstance(report, BatchReport), report
            recorded.append(report.execution.resolved_config[HEADER_KEY])
        assert recorded == [True, False, None]

    def test_設定ファイル経由の指定と実行時の上書きが届く(self, tmp_path: Path) -> None:
        """要件 8.1、9.4: 設定ファイルに書いた ``header = false`` と、その上書き。"""
        source = write_headerless(tmp_path / "raw.csv")
        config = write_config(
            tmp_path / "run.toml",
            paths=[source],
            header=False,
            output_dir=tmp_path / "out_from_config",
        )

        from_file = run_from_config(config)
        outcome = single_outcome(from_file)
        assert isinstance(outcome, FitSuccess), outcome
        assert outcome.goodness.n_points == N_POINTS

        overridden = run_from_config(
            config,
            {"input.header": True, "output.directory": str(tmp_path / "out_overridden")},
        )
        outcome = single_outcome(overridden)
        assert isinstance(outcome, FitSuccess), outcome
        assert outcome.goodness.n_points == N_POINTS - 1
