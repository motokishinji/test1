# curvefit

入力データに対するフィッティングを一括かつ再現可能に実行するライブラリと CLI。

**同じ設定ファイルと同じ入力なら、誰がいつ実行しても同じ結果になる**ことを中核の価値とする。

## 開発

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## コマンドからの実行

```bash
curvefit run.toml                      # 設定ファイルだけで一括実行する
curvefit run.toml -i data/ -o out/     # 入力指定と出力先を実行時に差し替える
curvefit --help                        # 指定できる項目と終了コードの一覧
```

同じ項目が設定ファイルと実行時引数の双方で指定された場合は実行時引数を優先し、上書きした項目は
出力先の `execution.json` に上書き前後の値とともに残る。

終了コードは 3 状態を区別する。

| コード | 意味 |
|--------|------|
| 0 | 全処理単位が成功した |
| 1 | 1 件以上が失敗した、または中断した |
| 2 | 実行前検証で停止した（処理単位を 1 件も実行していない） |

進捗・集計・違反はすべて標準エラー出力に書く。実行中の標準出力はどの状態でも空であり、
`curvefit run.toml > result.txt` のような取り回しを壊さない。`--help` と `--version`、
および引数なしで実行した場合のヘルプだけは、利用者が明示的に要求した内容として
標準出力に出る。

設定ファイルは **BOM 無しの UTF-8** で保存する。Windows のメモ帳の既定保存は BOM を付けるため、
TOML としては 1 行目から構文誤りになる（この場合は BOM を名指しで案内する）。

## 自分で読み込んだデータを渡す場合

本ライブラリは CSV を `float_precision="round_trip"` で読み、値を最終ビットまで保つ。

`pandas.read_csv` を自分で呼んだ結果を `read_frame` に渡す場合は、**同じ指定を行うこと。**

```python
frame = pd.read_csv(path, float_precision="round_trip")
```

既定の解釈器は正確な丸めを行わず、実測で値の約 46% の最下位ビットが変わる。渡された時点で
劣化した値はライブラリ側では回復できず、条件の悪い当てはめでは推定値が上位桁で動く。

## 仕様と設計の記録

この機能がどう決まったかは `.kiro/specs/data-curve-fitting/` に残してある。

| ファイル | 何が書いてあるか | 開くとよいとき |
|---|---|---|
| [`requirements.md`](.kiro/specs/data-curve-fitting/requirements.md) | 要件 10 件・受け入れ基準 60 件（EARS 形式） | 「この挙動は意図されたものか」を確かめたいとき |
| [`design.md`](.kiro/specs/data-curve-fitting/design.md) | 境界・依存方向・各層の契約・試験戦略 | コードを変える前に、触ってよい範囲を知りたいとき |
| [`tasks.md`](.kiro/specs/data-curve-fitting/tasks.md) | 実装タスク 45 件と、実装中に得た申し送り | 同じ失敗を繰り返したくないとき（末尾の Implementation Notes） |
| [`research.md`](.kiro/specs/data-curve-fitting/research.md) | 依存ライブラリの調査と、設計判断に至った経緯 | 「なぜこのライブラリなのか」を知りたいとき |

プロジェクト横断の前提は [`.kiro/steering/`](.kiro/steering/) にある
（`product.md` = 何を作っているか、`tech.md` = 技術選択と開発規約、
`structure.md` = モジュールの並びと依存方向）。

進捗と現況は `/kiro-spec-status data-curve-fitting` で確認できる。

## セキュリティ上の注意

設定ファイルに記述する数式文字列は評価される。**第三者から受け取った設定ファイルをそのまま実行しないこと。**
任意の Python コードを実行することと同等のリスクがある。
