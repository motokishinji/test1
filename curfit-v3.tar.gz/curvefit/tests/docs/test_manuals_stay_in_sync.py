"""ユーザーマニュアルが実装から取り残されないことを検査する。

ドキュメントは実装より静かに古くなる。誰も落ちないからである。ここでは 2 方向を
固定し、古くなった時点で検査を落とす。

1. `docs/manual_facts.py` の宣言と、実装が持つ値が一致すること
2. 宣言に現れるすべての名前が、生成スクリプトの本文に語として現れること

1 だけでは「宣言を直したがドキュメント本文を直していない」状態を通してしまい、
2 だけでは「実装に項目が増えたが宣言にもドキュメントにも無い」状態を通してしまう。
両方あって初めて、実装の変更がドキュメントの更新を強制する。

生成物（.pptx / .docx）そのものは検査しない。ZIP の内部に生成時刻が入るため、
中身が同じでもバイト列が毎回変わり、比較が意味を持たないためである。代わりに
「生成スクリプトが最新の事実を含み、かつ実行できること」を検査する。
"""
from __future__ import annotations

import importlib.util
import re
import subprocess
import sys
from pathlib import Path
from types import ModuleType

import pytest

from curvefit import config, errors, writers
from curvefit.engines import smoothing
from curvefit.execution import ExecutionRecord
from curvefit.models import expression, registry

DOCS = Path(__file__).resolve().parents[2] / "docs"
"""生成スクリプトと宣言の置き場所。"""

_WORD_CHARACTER = re.compile(r"[A-Za-z0-9_]")
r"""名前の一部として続きうる文字。

Unicode の `\w` ではなく ASCII に限る。マニュアルの本文は日本語であり、`列 x を` の
ように名前が日本語に直付けで書かれる。Unicode の `\w` は日本語の文字も語の一部と
見なすため、その書き方を「語として現れていない」と判定してしまう。
"""


def appears_as_a_word(name: str, source: str) -> bool:
    r"""`name` が `source` に語として現れるか。

    部分文字列一致では短い名前の宣言が空振りする。`pi` は本文中の `pip install` に
    一致してしまい、宣言を足しても検査が何も要求しなくなる（実測: 4 つの生成
    スクリプトと README.md のすべてで真）。ここでは名前の両端が別の名前の途中に
    埋まっていないことを要求する。

    境界は名前の端の文字で決める。`\b` を機械的に前後に付けると、記号で終わる名前
    （`methods[]` のような形）で「後ろに語の文字が続くこと」を要求してしまい、
    意図と逆になる。端が語の文字のときだけ、その側に境界を課す。
    """
    pattern = re.escape(name)
    if _WORD_CHARACTER.match(name[0]):
        pattern = r"(?<![A-Za-z0-9_])" + pattern
    if _WORD_CHARACTER.match(name[-1]):
        pattern = pattern + r"(?![A-Za-z0-9_])"
    return re.search(pattern, source) is not None


def _load_manual_facts() -> ModuleType:
    """docs/manual_facts.py を読み込む。

    docs はパッケージではないため、通常の import 経路には乗らない。位置を指定して
    読み込むことで、リポジトリのどこから pytest を起動しても同じものを指す。
    """
    path = DOCS / "manual_facts.py"
    spec = importlib.util.spec_from_file_location("manual_facts", path)
    assert spec is not None and spec.loader is not None, f"読み込めない: {path}"
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


facts = _load_manual_facts()


class TestTheDeclaredFactsMatchTheImplementation:
    """宣言と実装の一致。実装に項目を足す・消す・綴りを変えると落ちる。"""

    @pytest.mark.parametrize(
        ("declared", "actual", "where"),
        [
            (facts.TOP_LEVEL_KEYS, config.TOP_LEVEL_KEYS, "config.TOP_LEVEL_KEYS"),
            (facts.INPUT_KEYS, config.INPUT_KEYS, "config.INPUT_KEYS"),
            (facts.COLUMNS_KEYS, config.COLUMNS_KEYS, "config.COLUMNS_KEYS"),
            (facts.METHOD_KEYS, config.METHOD_KEYS, "config.METHOD_KEYS"),
            (facts.BOUND_KEYS, config.BOUND_KEYS, "config.BOUND_KEYS"),
            (facts.PREPROCESS_KEYS, config.PREPROCESS_KEYS, "config.PREPROCESS_KEYS"),
            (facts.OUTLIER_KEYS, config.OUTLIER_KEYS, "config.OUTLIER_KEYS"),
            (facts.OUTPUT_KEYS, config.OUTPUT_KEYS, "config.OUTPUT_KEYS"),
            (facts.OVERRIDABLE_KEYS, config.OVERRIDABLE_KEYS, "config.OVERRIDABLE_KEYS"),
            (facts.SUMMARY_COLUMNS, writers.SUMMARY_COLUMNS, "writers.SUMMARY_COLUMNS"),
            (facts.CURVE_COLUMNS, writers.CURVE_COLUMNS, "writers.CURVE_COLUMNS"),
            (
                facts.PREPROCESS_COLUMNS,
                writers.PREPROCESS_COLUMNS,
                "writers.PREPROCESS_COLUMNS",
            ),
        ],
    )
    def test_key_and_column_lists_agree(
        self, declared: tuple[str, ...], actual: tuple[str, ...], where: str
    ) -> None:
        assert tuple(declared) == tuple(actual), (
            f"{where} が docs/manual_facts.py の宣言と食い違う。"
            f"実装を変えたなら、宣言と 4 つの生成スクリプトの本文も直すこと"
        )

    def test_the_number_of_significant_digits_agrees(self) -> None:
        assert facts.SUMMARY_SIGNIFICANT_DIGITS == writers.SUMMARY_SIGNIFICANT_DIGITS

    def test_the_violation_kinds_agree(self) -> None:
        assert tuple(facts.VIOLATION_KINDS) == tuple(kind.value for kind in errors.ViolationKind)

    def test_the_failure_reasons_agree(self) -> None:
        assert tuple(facts.FAILURE_REASONS) == tuple(
            reason.value for reason in errors.FailureReason
        )

    def test_the_expression_value_constants_agree(self) -> None:
        # 実装側（expression.VALUE_CONSTANTS）は frozenset であり順序を持たない。
        # 列に直して比べると、要素が 2 つ以上になった時点で反復順がハッシュ種に依存し、
        # 同じコードが実行ごとに緑と赤を行き来する。集合同士で比べる。
        assert set(facts.EXPRESSION_VALUE_CONSTANTS) == set(expression.VALUE_CONSTANTS), (
            "expression.VALUE_CONSTANTS が docs/manual_facts.py の宣言と食い違う。"
            "値として参照できる予約名を変えたなら、宣言と詳細版 2 本の本文も直すこと"
        )

    def test_the_builtin_model_names_agree(self) -> None:
        assert tuple(facts.BUILTIN_MODELS) == tuple(registry.BUILTIN_MODELS)

    def test_the_smoothers_and_their_options_agree(self) -> None:
        actual = {
            kind.value: tuple(options)
            for kind, options in smoothing.SMOOTHER_OPTION_NAMES.items()
        }
        assert {name: tuple(opts) for name, opts in facts.SMOOTHERS.items()} == actual

    def test_the_execution_record_keys_agree(self) -> None:
        # 実行記録は dataclass であり、書き出される JSON の鍵は場の名前に一致する。
        actual = tuple(ExecutionRecord.__dataclass_fields__)
        assert tuple(facts.EXECUTION_RECORD_KEYS) == actual


class TestTheMatchRuleRequiresAWholeWord:
    """一致規則そのものの検査。

    部分文字列一致に戻すと、短い名前の宣言が本文に無くても緑になる。宣言側
    （docs/manual_facts.py）を触らずに、規則の縮退をここで押さえる。
    """

    def test_a_name_buried_in_a_longer_word_does_not_count(self) -> None:
        # 実測された空振りの形。`pip install` は 4 つの生成スクリプトと README.md の
        # すべてに現れるため、部分文字列一致では `pi` の宣言が何も要求しない。
        assert not appears_as_a_word("pi", "pip3 install python-pptx で入れる")
        assert not appears_as_a_word("min", "x_min より小さい値は落とす")
        assert not appears_as_a_word("name", "method_name 列に手法名が入る")

    def test_a_name_standing_on_its_own_counts(self) -> None:
        assert appears_as_a_word("pi", "予約名 `pi` は値として参照できる")
        assert appears_as_a_word("pi", "円周率は np.pi と同じ値である")
        assert appears_as_a_word("min", "bounds の min と max を書く")

    def test_a_name_written_against_japanese_counts(self) -> None:
        # 本文は日本語であり、名前が助詞に直付けで書かれる。Unicode の \w を境界に
        # 使うとこの書き方が「語として現れない」ことになる。
        assert appears_as_a_word("x", "列xを横軸に使う")
        assert appears_as_a_word("spline", "手法splineは重みを使う")

    def test_a_name_containing_symbols_keeps_matching(self) -> None:
        # 記号を含む宣言（`input.columns.weight` など）が規則の変更で落ちないこと。
        assert appears_as_a_word(
            "input.columns.weight", "`input.columns.weight` を上書きできる"
        )
        assert appears_as_a_word("x_max", "前処理は x_max で範囲を絞る")
        # `.` は境界として扱う。`np.pi` の `pi` を語として認めるための選択であり、
        # その裏返しとして `input.columns` は `input.columns.weight` に一致する。
        # 宣言側は区切りを含む完全な経路（`input.columns.weight`）を並べるため、
        # これで空振りする名前は無い（全宣言で実測済み）。
        assert appears_as_a_word("input.columns", "input.columns.weight を上書きできる")

    def test_a_name_ending_in_a_symbol_does_not_require_a_letter_after_it(self) -> None:
        # `\b` を機械的に後ろに付けた実装では、記号で終わる名前が「後ろに語の文字が
        # 続くこと」を要求して落ちる。端が語の文字のときだけ境界を課す。
        assert appears_as_a_word("methods[]", "methods[] の各要素に手法を書く")
        assert appears_as_a_word("plots/*.png", "図は plots/*.png に出る")


class TestEveryDeclaredNameAppearsInTheManuals:
    """宣言だけ直してドキュメント本文を直し忘れた状態を落とす。"""

    @staticmethod
    def _source(script: str) -> str:
        path = DOCS / script
        assert path.exists(), f"生成スクリプトが無い: {path}"
        return path.read_text(encoding="utf-8")

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_generator_exists_and_names_its_output(self, script: str) -> None:
        source = self._source(script)
        assert facts.GENERATORS[script] in source, (
            f"{script} が {facts.GENERATORS[script]} を書き出していない"
        )

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_names_common_to_every_manual_appear(self, script: str) -> None:
        """スライドと詳細版の双方が触れる事実。"""
        source = self._source(script)
        common = (
            *facts.TOP_LEVEL_KEYS,
            *facts.INPUT_KEYS,
            *facts.COLUMNS_KEYS,
            *facts.PREPROCESS_KEYS,
            *facts.OUTPUT_KEYS,
            *facts.SMOOTHERS,
        )
        missing = sorted({name for name in common if not appears_as_a_word(name, source)})
        assert not missing, f"{script} に現れない名前がある: {missing}"

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_reserved_name_caution_appears_in_every_manual(self, script: str) -> None:
        """予約名の注意が 4 本すべてに載っていること。

        `EXPRESSION_VALUE_CONSTANTS` は `DETAILED_ONLY` にあり、詳細版 2 本にしか
        課されない。スライド 2 本の注意 1 行はそれだけではどの検査にも守られず、
        丸ごと削っても緑のままになる。言語に依らない綴りを 1 つ選んで 4 本に課す。
        """
        source = self._source(script)
        assert appears_as_a_word(facts.RESERVED_NAME_CUE, source), (
            f"{script} に予約名の注意が無い: {facts.RESERVED_NAME_CUE!r} が現れない"
        )

    @pytest.mark.parametrize(
        "script", sorted(s for s in facts.GENERATORS if "docx" in s)
    )
    def test_the_names_only_the_detailed_manual_carries_appear(self, script: str) -> None:
        """詳細版（Word）だけが列挙する事実。スライドには課さない。"""
        source = self._source(script)
        detailed: list[str] = []
        for group in facts.DETAILED_ONLY:
            detailed.extend(getattr(facts, group))
        missing = sorted(
            {name for name in detailed if not appears_as_a_word(name, source)}
        )
        assert not missing, f"{script} に現れない名前がある: {missing}"


class TestTheGeneratorsStillRun:
    """本文を直したつもりでスクリプトを壊した状態を落とす。"""

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_generator_compiles(self, script: str) -> None:
        # 実行には python-pptx / python-docx が要る。開発依存に含めていないため、
        # ここでは構文と名前解決の手前までを見る。生成そのものは docs/README.md の
        # 手順で人が回す。
        source = (DOCS / script).read_text(encoding="utf-8")
        compile(source, str(DOCS / script), "exec")

    def test_the_generators_are_the_only_python_files_under_docs(self) -> None:
        # 置き忘れた実験用スクリプトが「マニュアルの一部」に見えないようにする。
        found = {path.name for path in DOCS.glob("*.py")}
        expected = set(facts.GENERATORS) | {"manual_facts.py"}
        assert found == expected, f"docs/ の Python ファイルが想定と違う: {found ^ expected}"


class TestTheGeneratedDocumentsArePresent:
    """生成物そのものが版管理から落ちていないことを見る。"""

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_document_exists(self, script: str) -> None:
        document = DOCS / facts.GENERATORS[script]
        assert document.exists(), (
            f"{document.name} が無い。docs/README.md の手順で生成すること"
        )
        assert document.stat().st_size > 10_000, f"{document.name} が小さすぎる"


def test_the_repository_has_no_stray_manual_outside_docs() -> None:
    """マニュアルの置き場所を docs/ の 1 か所に保つ。"""
    root = DOCS.parent
    stray = sorted(
        path.name
        for pattern in ("*.pptx", "*.docx")
        for path in root.glob(pattern)
    )
    assert not stray, f"docs/ の外にマニュアルがある: {stray}"


def test_the_python_used_to_run_pytest_can_import_the_facts() -> None:
    # 読み込み経路そのものの検査。ここが壊れると上の検査すべてが空振りする。
    result = subprocess.run(
        [sys.executable, "-c", "import importlib.util, sys; sys.exit(0)"],
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0
    assert facts.GENERATORS, "宣言が空になっている"
