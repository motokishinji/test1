"""予約名の扱いについて、改訂前からの性質が保たれていることを検証する。

対応要件: 3.2（式中の記号のうち独立変数でも予約名でもないものをパラメータとして扱う）、
3.6（値として参照できる予約名を円周率 `pi` に限る）、
3.8（予約名の関数呼び出しを受け入れ、パラメータにしない）

改訂 14 は「予約名を **値として** 参照した式」を実行前の違反にした。塞ぐべき経路の隣に、
**塞いではならない経路が 2 つ** ある。予約名を **関数として** 呼び出す式と、円周率 `pi` を
値として使う式である。

なぜ件数で数えないのか
----------------------

この 2 つの経路は検査一式の随所で使われており、特定のファイルに集まっていない。
「7 件が緑であること」のように件数で書くと、**書いた数だけを見て終わる** ことになり、
数え漏らした地点の退行を見逃す。そこで本モジュールは件数を書かず、**性質** として述べる。

- 検査一式の Python 原文から、モデル式として書かれた文字列を機械的に集める
- そのうち **予約名を関数として呼び出しているもの全て** が解釈でき、呼び出した名前が
  パラメータに **ならない** こと（要件 3.8）
- そのうち **円周率を値として参照しているもの全て** が解釈でき、`pi` がパラメータに
  **ならない** こと（要件 3.6）

集める対象は tests/ 以下の全ファイルである。境界（単体・統合・性能）は本モジュールを
**置く** 場所の話であり、読み取る対象を狭める理由にはならない。退行はどの区分の検査の
式にも等しく現れる。

空振りへの備え
--------------

収集結果をそのまま :func:`pytest.mark.parametrize` に渡すため、**収集が 0 件になると
検査そのものが消えて全緑になる**。収集規則が実装から独立していること（下記）と併せて、
収集が実際に複数のファイル・複数の予約名に渡っていることを別の検査で主張する。

収集規則が実装に依存しないこと
------------------------------

選別は :mod:`curvefit.models.expression` を呼ばずに :mod:`ast` だけで行う。実装に
「解釈できたもの」を選ばせると、一律に拒否する実装でも収集が 0 件になって全緑になる。
選別は原文の形だけで決め、**解釈できることは主張の側に置く**。
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

from curvefit.models.expression import (
    INDEPENDENT_VARIABLE,
    VALUE_CONSTANTS,
    ExpressionModelSpec,
    build_expression_model,
)

TESTS_ROOT = Path(__file__).resolve().parents[1]

RESERVED_FUNCTIONS: frozenset[str] = frozenset(
    {"exp", "log", "log10", "sqrt", "sin", "cos", "tan", "tanh"}
)
"""関数として呼び出せる予約名のうち、本モジュールが探針として使うもの。

**この集合は主張の対象でもある。** 各要素が実際に予約名の関数として通ることを
:class:`TestProbeNamesAreReallyReserved` が確かめる。確かめずに使うと、評価器が
当該の名前を失ったときに収集の側から静かに消え、退行ではなく検査の縮小として現れる。

網羅は要求しない。ここに無い予約名を呼ぶ式は収集されないだけであり、収集されたものへの
主張が弱まることはない。
"""

TOML_EXPRESSION = re.compile(
    r"""expression\s*=\s*(?P<quote>["'])(?P<expression>[^"'\n]*)(?P=quote)"""
)
"""検査が文字列の中に書いた設定ファイル本文から数式欄を取り出す規則。

:mod:`ast` は Python の文字列リテラルまでしか見ない。統合検査と E2E 検査は設定ファイルを
三重引用符の中に TOML として書くため、その中の ``expression = "..."`` は 1 つの長い
文字列リテラルの一部でしかなく、式として取り出せない。
"""


def _string_literals(path: Path) -> list[str]:
    """1 ファイルから、式の候補になりうる 1 行の文字列を集める。"""
    source = path.read_text(encoding="utf-8")
    found: list[str] = [
        node.value
        for node in ast.walk(ast.parse(source))
        if isinstance(node, ast.Constant) and isinstance(node.value, str)
    ]
    found += [match.group("expression") for match in TOML_EXPRESSION.finditer(source)]
    return [text.strip() for text in found if text.strip() and "\n" not in text]


def _tree(text: str) -> ast.Expression | None:
    """1 つの式として解析できたら構文木を返す。できなければ候補から外す。"""
    try:
        return ast.parse(text, mode="eval")
    except SyntaxError:
        return None


def _called_names(tree: ast.Expression) -> set[str]:
    """関数として呼び出されている記号名。"""
    return {
        node.func.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }


def _value_names(tree: ast.Expression) -> set[str]:
    """値として参照されている記号名。

    呼び出し位置にある ``ast.Name`` を除く。差集合で求めると ``exp + a*exp(x)`` の
    ``exp`` が消え、値参照を含む式を「関数呼び出しだけの式」として収集してしまう。
    """
    called_positions = {
        id(node.func)
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }
    return {
        node.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Name) and id(node) not in called_positions
    }


def _model_expressions() -> dict[str, set[str]]:
    """検査一式に書かれたモデル式を、式ごとに出現ファイルの集合として集める。

    モデル式とみなす条件は、1 つの式として解析でき、かつ独立変数を参照していることの
    2 点だけである。式として成立しない文字列（誤りを与える検査の入力）や、独立変数を
    含まない文字列（見出し名・パス・メッセージ）はここで落ちる。
    """
    found: dict[str, set[str]] = {}
    for path in sorted(TESTS_ROOT.rglob("*.py")):
        for text in _string_literals(path):
            tree = _tree(text)
            if tree is None:
                continue
            if INDEPENDENT_VARIABLE not in {
                node.id for node in ast.walk(tree) if isinstance(node, ast.Name)
            }:
                continue
            found.setdefault(text, set()).add(str(path.relative_to(TESTS_ROOT)))
    return found


def _calls_reserved_functions_only(text: str) -> bool:
    """予約名を関数として呼び出しており、値としては参照していない式か。

    値として予約名を参照している式（``exp + a*exp(x)``）は改訂が **拒むべき** 側であり、
    ここで除く。探針の集合に無い名前を呼ぶ式（``frobnicate(x)``）も、未定義の関数を
    拒む従来からの規則の側であるため除く。
    """
    tree = _tree(text)
    assert tree is not None
    called = _called_names(tree)
    if not called or not called <= RESERVED_FUNCTIONS:
        return False
    return not _value_names(tree) & RESERVED_FUNCTIONS


def _references_pi_as_a_value(text: str) -> bool:
    """円周率を値として参照している式か。"""
    tree = _tree(text)
    assert tree is not None
    return bool(_value_names(tree) & set(VALUE_CONSTANTS))


MODEL_EXPRESSIONS = _model_expressions()

FUNCTION_CALL_EXPRESSIONS = sorted(
    text for text in MODEL_EXPRESSIONS if _calls_reserved_functions_only(text)
)
"""検査一式に現れる「予約名を関数として呼び出す」式のすべて。"""

PI_VALUE_EXPRESSIONS = sorted(
    text for text in MODEL_EXPRESSIONS if _references_pi_as_a_value(text)
)
"""検査一式に現れる「円周率を値として使う」式のすべて。"""


def _files_of(expressions: list[str]) -> set[str]:
    """与えた式が現れるファイルの集合。"""
    return {path for text in expressions for path in MODEL_EXPRESSIONS[text]}


class TestProbeNamesAreReallyReserved:
    """探針として使う名前が、予約名の関数であり続けること。

    要件 3.8 の前提である。評価器が当該の名前を失うと、それは静かにパラメータに変わり、
    収集の側からも消える。退行が「検査が減った」という形で隠れるのを防ぐ。
    """

    @pytest.mark.parametrize("name", sorted(RESERVED_FUNCTIONS))
    def test_each_probe_name_is_callable_and_is_not_a_parameter(self, name: str) -> None:
        """探針の各名前が関数として通り、パラメータにならない。"""
        result = build_expression_model(f"a*{name}(x)")
        assert isinstance(result, ExpressionModelSpec), f"{name} が関数として通らない: {result}"
        assert result.parameter_names == ("a",)


class TestTheScanIsNotVacuous:
    """収集が空振りしていないこと。

    収集結果は :func:`pytest.mark.parametrize` に渡る。0 件になると主張が消えて全緑に
    なるため、件数ではなく **散らばり** を性質として主張する。
    """

    def test_function_call_expressions_span_more_than_one_test_file(self) -> None:
        """予約名の関数呼び出しは、1 つのファイルに閉じていない。"""
        files = _files_of(FUNCTION_CALL_EXPRESSIONS)
        assert len(files) > 1, f"収集が 1 ファイルに閉じている: {sorted(files)}"

    def test_function_call_expressions_span_more_than_one_test_layer(self) -> None:
        """予約名の関数呼び出しは、検査の区分をまたいで使われている。"""
        layers = {path.split("/")[0] for path in _files_of(FUNCTION_CALL_EXPRESSIONS)}
        assert len(layers) > 1, f"収集が 1 区分に閉じている: {sorted(layers)}"

    def test_function_call_expressions_cover_more_than_one_reserved_name(self) -> None:
        """1 つの予約名だけを見ているのではない。"""
        covered = {
            name
            for text in FUNCTION_CALL_EXPRESSIONS
            for name in _called_names(_tree(text))  # type: ignore[arg-type]
        }
        assert len(covered) > 1, f"収集が 1 つの予約名に閉じている: {sorted(covered)}"

    def test_pi_value_expressions_are_collected(self) -> None:
        """円周率を値として使う式が収集されている。"""
        assert PI_VALUE_EXPRESSIONS

    def test_a_call_to_a_name_outside_the_probe_set_is_not_collected(self) -> None:
        """未定義の関数を呼ぶ式は「通るべき側」ではない。選別で外れる。

        収集規則が緩むと、拒まれるべき式に「解釈できること」を主張してしまい、
        検査が実装ではなく自分自身と矛盾する。
        """
        assert not _calls_reserved_functions_only("frobnicate(x)")

    def test_a_reserved_name_used_as_a_value_is_not_collected(self) -> None:
        """同じ名前を値と関数の双方で使う式も「通るべき側」ではない。"""
        assert not _calls_reserved_functions_only("exp + a*exp(x)")
        assert "exp + a*exp(x)" in MODEL_EXPRESSIONS, (
            "選別の対象になっていない。除外できたことの証明にならない"
        )


class TestReservedNamesStillWorkAsFunctions:
    """要件 3.8: 検査一式に現れる予約名の関数呼び出しが、すべて従来どおり通ること。"""

    @pytest.mark.parametrize("expression", FUNCTION_CALL_EXPRESSIONS)
    def test_the_expression_is_still_resolved(self, expression: str) -> None:
        """式が解釈できる。"""
        result = build_expression_model(expression)
        assert isinstance(result, ExpressionModelSpec), (
            f"従来通っていた式が拒否された（{sorted(MODEL_EXPRESSIONS[expression])}）: {result}"
        )

    @pytest.mark.parametrize("expression", FUNCTION_CALL_EXPRESSIONS)
    def test_the_called_reserved_names_are_not_parameters(self, expression: str) -> None:
        """呼び出した予約名が推定対象パラメータに混ざらない。

        混ざると、既存の式が推定するパラメータを黙って 1 つ増やす。当てはめは成功する
        ため、警告も終了コードも変わらない。
        """
        result = build_expression_model(expression)
        assert isinstance(result, ExpressionModelSpec)
        called = _called_names(_tree(expression))  # type: ignore[arg-type]
        assert called.isdisjoint(result.parameter_names), (
            f"呼び出した予約名がパラメータになった: {sorted(called)} / {result.parameter_names}"
        )


class TestPiStillWorksAsAValue:
    """要件 3.6: 検査一式に現れる円周率の値参照が、すべて従来どおり通ること。"""

    @pytest.mark.parametrize("expression", PI_VALUE_EXPRESSIONS)
    def test_the_expression_is_still_resolved(self, expression: str) -> None:
        """式が解釈できる。"""
        result = build_expression_model(expression)
        assert isinstance(result, ExpressionModelSpec), (
            f"従来通っていた式が拒否された（{sorted(MODEL_EXPRESSIONS[expression])}）: {result}"
        )

    @pytest.mark.parametrize("expression", PI_VALUE_EXPRESSIONS)
    def test_pi_does_not_become_a_parameter(self, expression: str) -> None:
        """円周率がパラメータにならない。"""
        result = build_expression_model(expression)
        assert isinstance(result, ExpressionModelSpec)
        assert set(VALUE_CONSTANTS).isdisjoint(result.parameter_names)
