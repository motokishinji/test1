"""数式文字列によるモデル指定を検証する。

対応要件: 3.2（数式文字列をモデル関数として解釈し、未知記号を推定対象パラメータとして扱う）、
3.4（解釈できない式を、原因となった指定内容を含めて報告する）、
3.6（値として参照できる予約名を円周率 `pi` に限る）、
3.7（値として参照された予約名を記号名・予約名である旨・対処とともに報告する）、
3.8（予約名の関数呼び出しは受け入れ、パラメータにしない）
"""

from __future__ import annotations

import ast
from pathlib import Path

import numpy as np
import pytest

import curvefit.models.expression as expression_module
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.expression import (
    DEFAULT_LOCATION,
    INDEPENDENT_VARIABLE,
    ExpressionModelSpec,
    build_expression_model,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


def _spec(expression: str) -> ExpressionModelSpec:
    """解釈できることを前提に仕様を取り出す。違反が返ったらその場で落とす。"""
    result = build_expression_model(expression)
    assert isinstance(result, ExpressionModelSpec), f"解釈できるはずの式が拒否された: {result}"
    return result


def _violation(expression: str, location: str = DEFAULT_LOCATION) -> ConfigViolation:
    """解釈できないことを前提に違反を取り出す。"""
    result = build_expression_model(expression, location=location)
    assert isinstance(result, ConfigViolation), f"拒否されるはずの式が通った: {result}"
    return result


class TestParameterNameExtraction:
    """要件 3.2: 式中の未知記号を推定対象パラメータとして扱う。"""

    @pytest.mark.parametrize(
        ("expression", "expected"),
        [
            ("a*exp(-b*x)+c", ("a", "b", "c")),
            ("m*x + c", ("m", "c")),
            ("a*x**2+b*x+c", ("a", "b", "c")),
            ("a*sqrt(x)+b*log(x)+c", ("a", "b", "c")),
            ("amp*sin(freq*x+phase)", ("amp", "freq", "phase")),
        ],
    )
    def test_unknown_symbols_are_extracted_as_parameters(
        self, expression: str, expected: tuple[str, ...]
    ) -> None:
        """未知記号がパラメータとして抽出される。"""
        assert _spec(expression).parameter_names == expected

    @pytest.mark.parametrize(
        "expression",
        ["a*exp(-b*x)+c", "m*x + c", "a*x**2+b*x+c", "a*sqrt(x)+b*log(x)+c"],
    )
    def test_independent_variable_is_not_a_parameter(self, expression: str) -> None:
        """設計の Risks: `x` を独立変数として除外する規則を明示的に持つ。"""
        assert INDEPENDENT_VARIABLE not in _spec(expression).parameter_names

    def test_math_functions_and_constants_are_not_parameters(self) -> None:
        """asteval が既に知っている名前は未知記号ではない。"""
        assert _spec("amp*pi*x").parameter_names == ("amp",)
        assert _spec("tanh(x)*a").parameter_names == ("a",)

    def test_repeated_symbol_is_counted_once(self) -> None:
        """同じ記号が複数回現れても1回だけ数える。"""
        assert _spec("a*x + a*x**2 + b").parameter_names == ("a", "b")

    def test_parameter_name_order_is_stable_across_calls(self) -> None:
        """要件 8.2 の再現性は、下流に渡る順序が安定していることに依存する。"""
        expression = "z*x + a*x**2 + q*exp(-w*x)"
        first = _spec(expression).parameter_names
        for _ in range(5):
            assert _spec(expression).parameter_names == first

    def test_parameter_names_follow_order_of_appearance(self) -> None:
        """辞書の反復順に依存しない、式の記述から決まる順序であること。"""
        assert _spec("z*x + a*x**2 + q").parameter_names == ("z", "a", "q")

    def test_extraction_result_is_an_immutable_sequence(self) -> None:
        """抽出結果は書き換えられない列である。"""
        names = _spec("a*x+b").parameter_names
        assert isinstance(names, tuple)


class TestModelInstanceCreation:
    """抽出したパラメータで実際に評価できることまでを確認する。"""

    def test_creates_a_model_instance(self) -> None:
        """モデル実体を生成できる。"""
        model = _spec("a*x+b").create()
        assert model is not None

    def test_returns_an_independent_instance_per_call(self) -> None:
        """当てはめはジョブごとに解決し直される。実体の使い回しは状態を持ち込む。"""
        spec = _spec("a*x+b")
        assert spec.create() is not spec.create()

    def test_instance_parameter_names_match_the_extraction(self) -> None:
        """生成した実体のパラメータ名が抽出結果と一致する。"""
        spec = _spec("a*exp(-b*x)+c")
        assert tuple(spec.create().param_names) == spec.parameter_names

    def test_instance_evaluates_as_the_expression_says(self) -> None:
        """生成した実体が式のとおりに評価される。"""
        spec = _spec("a*exp(-b*x)+c")
        model = spec.create()
        x = np.linspace(0.0, 5.0, 41)
        actual = model.eval(model.make_params(a=3.0, b=0.5, c=1.0), x=x)
        np.testing.assert_allclose(actual, 3.0 * np.exp(-0.5 * x) + 1.0)

    def test_surrounding_whitespace_is_stripped_and_kept(self) -> None:
        """前後の空白は取り除いて保持される。"""
        spec = _spec("  a*x + b  ")
        assert spec.expression == "a*x + b"

    def test_keeps_the_independent_variable_name(self) -> None:
        """独立変数の名前を保持する。"""
        assert _spec("a*x+b").independent_variable == INDEPENDENT_VARIABLE


class TestUninterpretableExpression:
    """要件 3.4: 解釈できない式は例外ではなく違反として返す。"""

    @pytest.mark.parametrize(
        "expression",
        [
            "a*x +",  # 構文誤り
            "a*x)",  # 括弧の不整合
            "a**",  # 演算子の未完
            "@x",  # 式として成立しない
            "",  # 空
            "   ",  # 空白のみ
            "a*y+b",  # 独立変数 x を含まない
            "c",  # 定数のみで x を含まない
            "frobnicate(x)",  # 未定義の関数呼び出し
            "2*x",  # 推定対象のパラメータがない
            "x",  # 独立変数のみ
            "a*x; import os",  # 単一の式ではない
            "a = 1",  # 式ではなく文
        ],
    )
    def test_uninterpretable_expression_returns_a_violation(self, expression: str) -> None:
        """解釈できない式は違反を返す。"""
        assert _violation(expression).kind is ViolationKind.MODEL_UNRESOLVED

    @pytest.mark.parametrize("expression", ["a*x +", "frobnicate(x)", "2*x", "a*y+b"])
    def test_violation_includes_the_offending_expression(self, expression: str) -> None:
        """違反は原因となった式を含む。"""
        assert expression in _violation(expression).message

    def test_syntax_error_violation_states_the_reason(self) -> None:
        """構文誤りの違反は理由を示す。"""
        message = _violation("a*x +").message
        assert "構文" in message

    def test_undefined_function_call_names_the_function(self) -> None:
        """未知記号をパラメータとして扱う規則の下では、未定義関数も黙って
        パラメータになってしまう。当てはめ時の不可解な失敗を避けるため先に弾く。"""
        message = _violation("frobnicate(x)").message
        assert "frobnicate" in message

    def test_expression_without_the_independent_variable_names_it(self) -> None:
        """独立変数を含まない式は独立変数名を示す。"""
        assert INDEPENDENT_VARIABLE in _violation("a*y+b").message

    def test_expression_without_parameters_states_the_reason(self) -> None:
        """パラメータのない式は理由を示す。"""
        assert "パラメータ" in _violation("2*x").message

    def test_violation_has_a_default_location(self) -> None:
        """違反は既定の指定箇所を持つ。"""
        assert _violation("a*x +").location == DEFAULT_LOCATION

    def test_violation_location_can_be_overridden(self) -> None:
        """違反は指定箇所を上書きできる。"""
        violation = _violation("a*x +", location="methods[2].expression")
        assert violation.location == "methods[2].expression"

    @pytest.mark.parametrize("expression", ["a*x +", "", "frobnicate(x)", "a*y+b", "2*x"])
    def test_underlying_library_exceptions_do_not_escape(self, expression: str) -> None:
        """lmfit / asteval の例外がそのまま出ると、実行前ゲートが違反を集約できない。"""
        assert isinstance(build_expression_model(expression), ConfigViolation)

    def test_unexpected_library_exceptions_are_returned_as_violations(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """構文検査を通った式でも、基盤ライブラリ側の事情で組み立てが失敗しうる。
        その場合も例外を外に出さず違反として返すこと。"""

        def _raise(*args: object, **kwargs: object) -> object:
            raise RuntimeError("組み立てに失敗した")

        monkeypatch.setattr(expression_module, "ExpressionModel", _raise)
        violation = _violation("a*x+b")
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED
        assert "組み立てに失敗した" in violation.message


def _module_source() -> str:
    return (SRC / "models" / "expression.py").read_text(encoding="utf-8")


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse(_module_source())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


def _names_bound_from(prefixes: set[str]) -> set[str]:
    """指定モジュール群から束縛された識別子（別名を含む）を集める。"""
    tree = ast.parse(_module_source())
    bound: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in prefixes:
                    bound.add(alias.asname or alias.name.split(".")[0])
        elif (
            isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.split(".")[0] in prefixes
        ):
            bound.update(alias.asname or alias.name for alias in node.names)
    return bound


def _public_annotations() -> list[str]:
    """公開シグネチャ（非私有の関数引数・戻り値・属性）の注釈を文字列で返す。"""
    tree = ast.parse(_module_source())
    annotations: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            if node.name.startswith("_") and node.name != "__init__":
                continue
            args = node.args
            for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs):
                if arg.annotation is not None and not arg.arg.startswith("_"):
                    annotations.append(ast.unparse(arg.annotation))
            if node.returns is not None:
                annotations.append(ast.unparse(node.returns))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if not node.target.id.startswith("_"):
                annotations.append(ast.unparse(node.annotation))
    return annotations


class TestDependencyExposure:
    """依存の露出。"""

    def test_does_not_import_smoothing_or_plotting_libraries(self) -> None:
        """設計の Allowed Dependencies: SciPy は engines、matplotlib は plotting に閉じる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"scipy", "matplotlib", "pandas"}, (
                f"expression.py が {imported} を import している"
            )

    def test_does_not_import_the_expression_evaluator_directly(self) -> None:
        """設計: asteval は lmfit 経由で使う。直接 import しない。"""
        roots = {imported.split(".")[0] for imported in _imported_modules()}
        assert "asteval" not in roots

    def test_public_signatures_expose_no_underlying_library_types(self) -> None:
        """内部で lmfit を使うことは前提。外向きの注釈に漏らさないことを検証する。"""
        leaked = _names_bound_from({"lmfit", "asteval"})
        assert leaked, "lmfit を import していない場合、この検証は無意味になる"
        for annotation in _public_annotations():
            used = {
                node.id for node in ast.walk(ast.parse(annotation)) if isinstance(node, ast.Name)
            }
            assert not (used & leaked), f"公開注釈 {annotation!r} が {used & leaked} を露出している"

    def test_own_package_dependencies_stay_in_lower_layers(self) -> None:
        """自パッケージへの依存は下位レイヤに限る。"""
        own = {m for m in _imported_modules() if m.split(".")[0] == "curvefit"}
        allowed = {"curvefit.errors", "curvefit.types"}
        assert own <= allowed, f"想定外の依存: {own - allowed}"


class TestReservedNameReferencedAsValue:
    """要件 3.6〜3.8: 値として参照できる予約名は円周率 `pi` のみである。"""

    QUARTIC_WITH_E = "a*x**4 + b*x**3 + c*x**2 + d*x + e"

    def test_reserved_name_as_value_is_rejected_before_running(self) -> None:
        """要件 3.7: 4 次多項式の `e` は定数に解決されず、実行前の違反になる。

        改訂前は定数 2.718281828459045 に黙って解決され、終了コード 0 のまま
        利用者が意図したモデルとは異なるモデルが当てはめられていた。
        """
        violation = _violation(self.QUARTIC_WITH_E)
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED

    def test_reserved_name_as_value_is_reported_once(self) -> None:
        """要件 3.7: 違反は 1 件であり、箇所は手法の数式欄を指す。"""
        result = build_expression_model(self.QUARTIC_WITH_E)
        assert isinstance(result, ConfigViolation)
        assert result.location == DEFAULT_LOCATION

    def test_report_names_the_symbol_and_calls_it_reserved(self) -> None:
        """要件 3.7: 報告は記号名と、それが予約名であることを含む。"""
        message = _violation(self.QUARTIC_WITH_E).message
        assert "'e'" in message
        assert "予約名" in message

    def test_value_only_reference_is_told_to_rename(self) -> None:
        """設計の案内 2 分岐: 値としてしか現れない名前はパラメータの意図である。"""
        message = _violation("a*x + exp").message
        assert "'exp'" in message
        assert "別の名前" in message

    def test_name_also_called_as_a_function_is_told_about_the_parentheses(self) -> None:
        """設計の案内 2 分岐: 関数としても呼ばれている名前は括弧の抜けである。"""
        message = _violation("exp + a*exp(x)").message
        assert "'exp'" in message
        assert "括弧" in message
        assert "別の名前" not in message

    def test_value_reference_is_found_even_when_the_name_is_also_called(self) -> None:
        """要件 3.8 / 設計: 差集合で分類すると `exp` が消えて検出漏れになる。"""
        assert _violation("exp + a*exp(x)").kind is ViolationKind.MODEL_UNRESOLVED

    def test_reserved_name_is_reported_instead_of_having_no_parameters(self) -> None:
        """設計の判定順序: `e * x` は双方が成立する。利用者に近い原因を報告する。"""
        message = _violation("e * x").message
        assert "予約名" in message
        assert "パラメータが 1 つもない" not in message

    @pytest.mark.parametrize("expression", ["a*x + True", "a*x + False", "a*x*True + b"])
    def test_boolean_literals_are_not_violations(self, expression: str) -> None:
        """要件 3.6: `True` は `ast.Constant` であり予約名の衝突ではない。"""
        assert _spec(expression).parameter_names[0] == "a"

    @pytest.mark.parametrize(
        ("expression", "expected"),
        [
            ("a*exp(-b*x)+c", ("a", "b", "c")),
            ("a*sin(x)+b*cos(x)", ("a", "b")),
            ("amp*sin(2*pi*x/period)", ("amp", "period")),
            ("amp*pi*x", ("amp",)),
        ],
    )
    def test_calling_a_reserved_name_and_using_pi_still_succeed(
        self, expression: str, expected: tuple[str, ...]
    ) -> None:
        """要件 3.8 と 3.6: 関数呼び出しと円周率の値参照は従来どおり通る。"""
        assert _spec(expression).parameter_names == expected

    def test_allowed_value_constants_are_not_empty(self) -> None:
        """許可集合が空になると、下の各要素の検査が無内容に通ってしまう。"""
        assert expression_module.VALUE_CONSTANTS

    @pytest.mark.parametrize("name", sorted(expression_module.VALUE_CONSTANTS))
    def test_each_allowed_constant_really_is_a_reserved_name(self, name: str) -> None:
        """設計: 許可した定数が予約名であり続けることを固定する。

        評価器が当該の名前を持たなくなると、それが静かにパラメータに変わり、
        既存の式が推定対象を 1 つ増やす。警告は出ない。
        """
        assert _spec(f"a*{name}*x").parameter_names == ("a",)

    def test_only_the_circle_constant_may_be_referenced_as_a_value(self) -> None:
        """要件 3.6: 値として参照できる予約名は円周率 `pi` に限る。

        集合に別の予約名を足すと、その名前を値として書いた式が再び黙って定数に
        解決される。**その事故を捕まえるのが要件 3.6 である。**

        この主張を要件の側に置く理由。許可集合に `e` を足した場合は、`e` を使う
        拒否の検査（本クラスの他の検査）が落ちて気づける。しかし `sum` のように
        既存の検査が使っていない予約名を足した場合、落ちるのはドキュメント同期
        検査の 1 件だけになる（実測）。同期検査は文書が実装から取り残されることを
        見張るもので、要件 3.6 を守る場所ではない。
        """
        assert frozenset({"pi"}) == expression_module.VALUE_CONSTANTS
