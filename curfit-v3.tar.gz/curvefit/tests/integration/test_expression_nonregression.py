"""予約名を含まない数式の推定値が、改訂前と同じであることを検証する。

対応要件: 3.2（式中の記号のうち独立変数でも予約名でもないものを推定対象パラメータとして
扱う）、10.1・10.2（処理規模と応答性。本モジュールは非退行の値の側だけを扱い、時間と
メモリは ``tests/performance/`` が測る）

改訂 14 は :mod:`curvefit.models.expression` に判定を 1 つ足した。足した判定は「予約名を
値として参照している」ことを条件にするため、**予約名を 1 つも含まない式は通過するだけ** で
なければならない。通過するだけであることは「成功したこと」では示せない。式が別のモデルに
差し替わっても当てはめは成功し、そのモデルなりの最良解が返るためである（要件 8.2 の
再現性検査と同じ判断）。したがって主張するのは **値そのもの** である。

値の出どころ
------------

改訂の直前（仕様のみを更新し実装を含まないコミット ``23cc2da``）の ``src`` を
``git worktree`` で取り出し、同一の仮想環境から ``PYTHONPATH`` を差し替えて本モジュールと
同じ条件で実測した。改訂後の値と **全桁で一致** したため、その実測値を下記の
:data:`QUARTIC_ESTIMATES` / :data:`QUADRATIC_ESTIMATES` にリテラルとして固定してある。
tasks.md の Implementation Notes が同じ手順を記録している。

**``e`` を ``f`` に改名した 4 次多項式を選んである。** 改訂の引き金になった式そのもの
（``a*x**4 + ... + e``）は、記号を 1 つ改名するだけで予約名を含まない式になる。足した
判定のすぐ隣を通る条件であり、判定が式を通り越して値を変えたなら真っ先にここに出る。

入力について
------------

二進で厳密に表せる値だけでは、経路の食い違いに対して盲目になる（``test_api.py`` の
方針）。種を固定した :func:`numpy.random.default_rng` の全桁の値を雑音として加える。
雑音を加えるのは残差 0 を避けるためでもある。残差が 0 の当てはめは真値が厳密な最小点に
なり、解法の違いを吸収してしまう。
"""

from __future__ import annotations

from collections.abc import Callable
from typing import ClassVar

import numpy as np
import pytest

from curvefit.api import fit_series
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.expression import build_expression_model
from curvefit.models.resolver import MethodSpec
from curvefit.readers import read_arrays
from curvefit.types import DataSeries, FitSuccess

SEED = 20260911
"""雑音の種。改訂前の実測と本モジュールで同じ値を使う。"""

N_POINTS = 61

X_START = -1.5
X_STOP = 2.5

NOISE_SIGMA = 0.05

QUARTIC_EXPRESSION = "a*x**4 + b*x**3 + c*x**2 + d*x + f"
"""改訂の引き金になった 4 次多項式の、定数項を ``e`` から ``f`` に改名したもの。

予約名を 1 つも含まない。``e`` のままだと要件 3.7 により実行前に拒まれる（14.1）。
"""

QUARTIC_INITIAL = {"a": 1.0, "b": 1.0, "c": 1.0, "d": 1.0, "f": 1.0}

QUARTIC_ESTIMATES = {
    "a": 0.703435545256266,
    "b": -1.306804084339697,
    "c": 0.3882570581113195,
    "d": 2.1246092899622875,
    "f": -0.5911540643164204,
}
"""``23cc2da``（改訂前）で実測した推定値。改訂後と全桁一致した。"""

QUARTIC_GOODNESS = {
    "r_squared": 0.9998510672712246,
    "rmse": 0.04404223395065524,
}

QUADRATIC_EXPRESSION = "c * x**2 + b * x + a"
"""関数呼び出しも予約名も含まない式。記述順がパラメータの並びになる（要件 3.5）。"""

QUADRATIC_INITIAL = {"a": 0.0, "b": 0.0, "c": 0.0}

QUADRATIC_ESTIMATES = {
    "a": 3.256576589207723,
    "b": -0.7357178159154412,
    "c": 2.495364988884555,
}
"""``23cc2da``（改訂前）で実測した推定値。改訂後と全桁一致した。"""

QUADRATIC_GOODNESS = {
    "r_squared": 0.9998571379881754,
    "rmse": 0.04426719393631394,
}


def _noise() -> np.ndarray:
    """種を固定した雑音。改訂前の実測と同じ並びで引く。"""
    return np.random.default_rng(SEED).normal(0.0, NOISE_SIGMA, N_POINTS)


def _series(source_id: str, truth: np.ndarray) -> DataSeries:
    """真の曲線に雑音を加えた系列を組む。"""
    x = np.linspace(X_START, X_STOP, N_POINTS)
    series = read_arrays(x, truth + _noise(), source_id=source_id, method_name=source_id)
    assert isinstance(series, DataSeries), series
    return series


def _quartic_series() -> DataSeries:
    x = np.linspace(X_START, X_STOP, N_POINTS)
    return _series("quartic", 0.7 * x**4 - 1.3 * x**3 + 0.4 * x**2 + 2.1 * x - 0.6)


def _quadratic_series() -> DataSeries:
    x = np.linspace(X_START, X_STOP, N_POINTS)
    return _series("quadratic", 2.5 * x**2 - 0.75 * x + 3.25)


def _sine_series() -> DataSeries:
    """円周率を含む真の曲線。周期が `x` の全長のちょうど 2 倍になるよう選ぶ。"""
    x = np.linspace(X_START, X_STOP, N_POINTS)
    return _series("sine", 1.8 * np.sin(np.pi * x / 3.0) + 0.45)


def _fit(series: DataSeries, expression: str, initial: dict[str, float]) -> FitSuccess:
    """数式モデルを 1 系列に当てはめる。一括処理と同じ経路を通る（要件 9.3）。"""
    outcome = fit_series(
        series,
        MethodSpec(
            name=series.source_id, kind="expression", expression=expression, initial=initial
        ),
    )
    assert isinstance(outcome, FitSuccess), outcome
    return outcome


def _estimates(outcome: FitSuccess) -> dict[str, float]:
    return {parameter.name: parameter.value for parameter in outcome.parameters}


class TestExpressionWithoutReservedNamesIsUnchanged:
    """要件 3.2: 予約名を含まない式の推定値が、改訂前と全桁で一致すること。

    許容差を置かない。改訂前の実測と改訂後が **同じ浮動小数点値** であることを確かめて
    あり、許容差を置くと「足した判定が値を動かした」ことが幅の中に隠れる。
    """

    @pytest.mark.parametrize(
        ("expression", "initial", "expected", "series"),
        [
            pytest.param(
                QUARTIC_EXPRESSION,
                QUARTIC_INITIAL,
                QUARTIC_ESTIMATES,
                _quartic_series,
                id="quartic-with-renamed-constant",
            ),
            pytest.param(
                QUADRATIC_EXPRESSION,
                QUADRATIC_INITIAL,
                QUADRATIC_ESTIMATES,
                _quadratic_series,
                id="quadratic",
            ),
        ],
    )
    def test_estimates_match_the_values_measured_before_the_revision(
        self,
        expression: str,
        initial: dict[str, float],
        expected: dict[str, float],
        series: Callable[[], DataSeries],
    ) -> None:
        """推定値が改訂前の実測と一致する。"""
        outcome = _fit(series(), expression, initial)
        assert _estimates(outcome) == expected

    def test_the_initial_values_are_not_the_answer(self) -> None:
        """初期値が答えと一致していると、当てはめが動かなくても検査が通ってしまう。"""
        for initial, expected in (
            (QUARTIC_INITIAL, QUARTIC_ESTIMATES),
            (QUADRATIC_INITIAL, QUADRATIC_ESTIMATES),
        ):
            assert all(initial[name] != value for name, value in expected.items())

    def test_parameter_order_follows_the_expression(self) -> None:
        """要件 3.5: 結果の識別子と並びが式の記述順のまま保たれる。"""
        outcome = _fit(_quadratic_series(), QUADRATIC_EXPRESSION, QUADRATIC_INITIAL)
        assert tuple(parameter.name for parameter in outcome.parameters) == ("c", "b", "a")

    @pytest.mark.parametrize(
        ("expression", "initial", "expected", "series"),
        [
            pytest.param(
                QUARTIC_EXPRESSION,
                QUARTIC_INITIAL,
                QUARTIC_GOODNESS,
                _quartic_series,
                id="quartic-with-renamed-constant",
            ),
            pytest.param(
                QUADRATIC_EXPRESSION,
                QUADRATIC_INITIAL,
                QUADRATIC_GOODNESS,
                _quadratic_series,
                id="quadratic",
            ),
        ],
    )
    def test_goodness_matches_the_values_measured_before_the_revision(
        self,
        expression: str,
        initial: dict[str, float],
        expected: dict[str, float],
        series: Callable[[], DataSeries],
    ) -> None:
        """要件 7.2 の指標も改訂前の実測と一致する。

        推定値だけを見ると、雑音の引き方が変わった場合に「別のデータに対する別の最良解」
        として通り抜けうる。残差側の指標も併せて固定する。
        """
        outcome = _fit(series(), expression, initial)
        assert outcome.goodness.r_squared == expected["r_squared"]
        assert outcome.goodness.rmse == expected["rmse"]
        assert outcome.goodness.n_points == N_POINTS

    def test_the_same_expression_with_a_reserved_name_is_rejected(self) -> None:
        """拒否を固定する検査には通る対を置く（tasks.md の Implementation Notes）。

        改名前の ``e`` を戻すと同じ 4 次式が実行前に拒まれる。改名した式が通ることと
        併せて主張することで、「4 次式を一律に通す／拒む」実装のいずれでも落ちる。
        """
        violation = build_expression_model(QUARTIC_EXPRESSION.replace("d*x + f", "d*x + e"))
        assert isinstance(violation, ConfigViolation)
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED


class TestPiKeepsWorkingAsTheCircleConstant:
    """要件 3.6: 円周率の値参照は、当てはめまで通して従来どおり効く。

    単体の検査は `build_expression_model` が `pi` をパラメータにしないことを見る。
    それは「解釈の段階で除外される」ことの主張であり、**`pi` が円周率 3.14159… として
    当てはめに効いている**ことまでは言わない。値が別の数に化けても、モデルは
    そのモデルなりの最良解を返して成功する。

    ここでは真の曲線を `1.8 * sin(pi * x / 3.0) + 0.45` で作り、同じ式を当てはめて
    真値が戻ることを見る。`pi` が円周率でなければ周期が合わず、振幅も切片も戻らない。
    """

    TRUTH: ClassVar[dict[str, float]] = {"amp": 1.8, "period": 3.0, "offset": 0.45}
    """真値。式 `amp*sin(pi*x/period) + offset` の各パラメータ。"""

    EXPRESSION = "amp*sin(pi*x/period) + offset"
    """円周率を**値として**参照し、`sin` を**関数として**呼ぶ式（要件 3.6、3.8）。"""

    def test_the_true_values_come_back(self) -> None:
        success = _fit(
            _sine_series(),
            self.EXPRESSION,
            {"amp": 1.0, "period": 2.5, "offset": 0.0},
        )
        estimates = {estimate.name: estimate.value for estimate in success.parameters}

        for name, truth in self.TRUTH.items():
            assert estimates[name] == pytest.approx(truth, abs=0.05), estimates

    def test_pi_is_not_among_the_estimated_parameters(self) -> None:
        """`pi` は推定対象にならない。3 つのパラメータだけが返る。"""
        success = _fit(
            _sine_series(),
            self.EXPRESSION,
            {"amp": 1.0, "period": 2.5, "offset": 0.0},
        )

        assert sorted(estimate.name for estimate in success.parameters) == [
            "amp",
            "offset",
            "period",
        ]

    def test_replacing_pi_with_a_parameter_does_not_recover_the_truth(self) -> None:
        """空振り防止: `pi` を推定対象の記号に替えると真値は戻らない。

        これが無いと、上の 2 件は「`pi` が何であっても通る」主張になりうる。
        円周率でない値では周期が合わず、当てはめは真値から外れる。
        """
        success = _fit(
            _sine_series(),
            "amp*sin(q*x/period) + offset",
            {"amp": 1.0, "q": 1.0, "period": 2.5, "offset": 0.0},
        )
        estimates = {estimate.name: estimate.value for estimate in success.parameters}

        assert "q" in estimates, estimates
        assert estimates["q"] != pytest.approx(np.pi, abs=1e-6), estimates
