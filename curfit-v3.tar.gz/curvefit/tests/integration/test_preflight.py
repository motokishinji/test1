"""実行前の一括検証ゲートの統合テスト（要件 3.4、3.7、4.3、4.6、5.4、7.7、8.5、2.1）。

本テストは `curvefit.preflight` が次を満たすことを検証する。

- 「処理を開始せず報告する」種類の検査がすべてこのゲートに集約されていること。
  モデル解決（3.4）、数式中で値として参照された予約名（3.7）、組込以外のモデルにおける
  初期値の必須性（4.3）、初期値と上下限の整合（4.6）、平滑化オプションの制約（5.4）、
  出力先の書き込み可否（7.7）、設定構造の妥当性（8.5、2.1）
- **最初の違反で打ち切らない**。全項目を検査してから違反を一括で返すこと
- 違反の並びが実行のたびに変わらないこと（要件 8.2 の決定性）
- 平滑化オプションの制約検証が `engines.smoothing` の所有する定数のみを出所とすること
- モデル解決をデータなし（`sample=None`）で試み、データに依存しない違反だけを
  検出すること
- **入力パスの存在確認を行わない**こと。ファイルが 0 件なら処理対象 0 件として正常に
  終わり、存在しないファイルの直接指定は要件 1.4/1.5 の個別失敗として扱う

設計の Testing Strategy が `config` + `preflight` を統合テストに置いているため、
単体ではなく `tests/integration/` に置く。
"""

from __future__ import annotations

import ast
import os
import stat
import subprocess
import sys
from collections import Counter
from dataclasses import FrozenInstanceError
from pathlib import Path

import pytest

from curvefit import preflight as preflight_module
from curvefit.config import InputSpec, OutputSpec, RunConfig, load_config
from curvefit.engines import smoothing
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.preflight import PreflightResult, validate
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src" / "curvefit"

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
"""root は権限ビットを無視して書き込めるため、書き込み不能の検証が成立しない。"""

requires_permission_bits = pytest.mark.skipif(
    IS_ROOT, reason="root では権限ビットによる書き込み不能を再現できない"
)

GAUSSIAN = MethodSpec(name="gauss", kind="builtin", builtin="gaussian")
"""正常な手法指定。組込モデルは初期値を与えなくてもよい（要件 4.1）。"""

_QUARTIC_INITIALS = {"a": 1.0, "b": 1.0, "c": 1.0, "d": 1.0, "e": 1.0}
"""4 次多項式の全記号に初期値を与えた指定。

利用者が実際に報告した形である。`e` にも初期値を書いてあるため、初期値必須
（要件 4.3）は成立せず、残る違反は数式欄のものだけになる。
"""

ORDER_SCRIPT = '''
import sys
from pathlib import Path

from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.preflight import validate
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec

base = Path(sys.argv[1])
config = RunConfig(
    inputs=InputSpec(paths=("data/a.csv",), columns=(ColumnSpec(x="time", y="signal"),)),
    methods=(
        MethodSpec(name="u", kind="builtin", builtin="nope"),
        MethodSpec(name="expr", kind="expression", expression="a * x + b"),
        MethodSpec(
            name="mav",
            kind="smoother",
            smoother=SmootherKind.MOVING_AVERAGE,
            options={"window": 4, "polyorder": -1, "zeta": 1, "alpha": 2},
        ),
        MethodSpec(name="gauss", kind="builtin", builtin="gaussian", initial={"sigma": -1.0}),
    ),
    preprocess=PreprocessSpec(
        x_min=10.0, x_max=0.0, outlier=OutlierSpec(sigma=0.0, max_iterations=-1)
    ),
    output=OutputSpec(directory=base / "no" / "such" / "dir"),
)
for violation in validate(config).violations:
    print(violation.kind.value, violation.location, violation.message, sep="\\t")
'''
"""別プロセスで違反の並びを書き出す小さな台本。

`PYTHONHASHSEED` を変えて実行し、出力が一致することで写像の走査順に依存していない
ことを示す（要件 8.2）。
"""


def _config(
    directory: Path,
    *,
    methods: tuple[MethodSpec, ...] = (GAUSSIAN,),
    preprocess: PreprocessSpec | None = None,
    paths: tuple[str, ...] = ("data/a.csv",),
    weight: str | int | None = None,
    columns: tuple[ColumnSpec, ...] | None = None,
) -> RunConfig:
    """検証対象の実行条件を組み立てる。既定は違反を 1 件も含まない。

    ``weight`` は測定誤差を表す列の指定である（要件 1.3）。既定の ``None`` は
    「誤差列を指定していない」を意味し、要件 1.10 の検査対象にならない。

    ``columns`` は y 列ごとの列指定の並びである（要件 1.11）。複数列を扱う検査だけが
    渡す。既定は ``weight`` から組み立てた 1 件の並びである。
    """
    return RunConfig(
        inputs=InputSpec(
            paths=paths,
            columns=(
                columns
                if columns is not None
                else (ColumnSpec(x="time", y="signal", weight=weight),)
            ),
        ),
        methods=methods,
        preprocess=preprocess if preprocess is not None else PreprocessSpec(),
        output=OutputSpec(directory=directory),
    )


def _kinds(result: PreflightResult) -> list[ViolationKind]:
    return [violation.kind for violation in result.violations]


def _locations(result: PreflightResult) -> list[str]:
    return [violation.location for violation in result.violations]


def _only(result: PreflightResult) -> ConfigViolation:
    """違反がちょうど 1 件であることを確かめて取り出す。"""
    assert len(result.violations) == 1, f"違反が 1 件ではない: {result.violations}"
    return result.violations[0]


def _smoother(
    kind: SmootherKind, options: dict[str, float | int], name: str = "sm"
) -> MethodSpec:
    return MethodSpec(name=name, kind="smoother", smoother=kind, options=options)


class TestValidConfiguration:
    """完了状態: 正常な設定では検査を通過する。"""

    def test_no_violations_means_ok(self, tmp_path: Path) -> None:
        """違反が無ければ ok。"""
        result = validate(_config(tmp_path))

        assert result.ok is True
        assert result.violations == ()

    def test_the_result_cannot_be_mutated_after_construction(self, tmp_path: Path) -> None:
        """結果は生成後に変更できない。"""
        result = validate(_config(tmp_path))

        with pytest.raises(FrozenInstanceError):
            result.violations = ()  # type: ignore[misc]

    def test_a_single_violation_makes_ok_false(self, tmp_path: Path) -> None:
        """違反が 1 件でもあれば ok は偽。"""
        result = validate(
            _config(tmp_path, methods=(MethodSpec(name="u", kind="builtin", builtin="nope"),))
        )

        assert result.ok is False

    def test_a_config_covering_three_routes_and_four_methods_passes(self, tmp_path: Path) -> None:
        """3 経路と 4 手法をすべて含む設定が通過する。"""
        def model(x: float, a: float) -> float:
            return a * x

        methods = (
            GAUSSIAN,
            MethodSpec(
                name="expr", kind="expression", expression="a * x + b", initial={"a": 1.0, "b": 0.0}
            ),
            MethodSpec(name="func", kind="callable", function=model, initial={"a": 1.0}),
            _smoother(SmootherKind.LINEAR, {}, name="lin"),
            _smoother(SmootherKind.POLYNOMIAL, {"degree": 3}, name="poly"),
            _smoother(SmootherKind.SPLINE, {"lam": 0.5}, name="spl"),
            _smoother(SmootherKind.MOVING_AVERAGE, {"window": 7, "polyorder": 2}, name="mav"),
        )

        result = validate(_config(tmp_path, methods=methods))

        assert result.violations == ()

    def test_a_smoother_with_options_omitted_passes(self, tmp_path: Path) -> None:
        """既定値が適用される形は違反ではない（要件 5.4）。

        平滑化スプラインは既定値を持たず、省略できない（要件 5.5）。ここに並べない
        のはそのためである。
        """
        methods = (
            _smoother(SmootherKind.POLYNOMIAL, {}, name="poly"),
            _smoother(SmootherKind.MOVING_AVERAGE, {}, name="mav"),
        )

        assert validate(_config(tmp_path, methods=methods)).violations == ()


class TestWhetherTheModelResolves:
    """要件 3.4: 解決できないモデル指定は処理を開始せず報告する。"""

    def test_an_unknown_builtin_model_name_is_a_violation(self, tmp_path: Path) -> None:
        """未知の組込モデル名は違反。"""
        result = validate(
            _config(tmp_path, methods=(MethodSpec(name="u", kind="builtin", builtin="nope"),))
        )

        violation = _only(result)
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED
        assert "nope" in violation.message
        assert violation.location == "method[u].builtin"

    def test_an_uninterpretable_expression_is_a_violation(self, tmp_path: Path) -> None:
        """解釈できない数式は違反。"""
        method = MethodSpec(name="bad", kind="expression", expression="a * (x +")

        result = validate(_config(tmp_path, methods=(method,)))

        assert ViolationKind.MODEL_UNRESOLVED in _kinds(result)

    def test_an_unspecified_smoother_is_a_violation(self, tmp_path: Path) -> None:
        """平滑化手法が未指定なら違反。"""
        method = MethodSpec(name="sm", kind="smoother", smoother=None)

        result = validate(_config(tmp_path, methods=(method,)))

        assert _only(result).kind is ViolationKind.MODEL_UNRESOLVED

    def test_options_of_an_unresolvable_method_are_not_checked(self, tmp_path: Path) -> None:
        """手法が定まらなければ選択肢の制約も定まらない。無関係な違反を増やさない。"""
        method = MethodSpec(name="sm", kind="smoother", smoother=None, options={"window": 4})

        result = validate(_config(tmp_path, methods=(method,)))

        assert _kinds(result) == [ViolationKind.MODEL_UNRESOLVED]


class TestInitialValuesAreMandatory:
    """要件 4.3: 組込以外のモデルでは初期値の指定が必須である。"""

    def test_an_expression_model_without_initials_is_a_violation(self, tmp_path: Path) -> None:
        """初期値のない数式モデルは違反。"""
        method = MethodSpec(name="expr", kind="expression", expression="a * x + b")

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_REQUIRED
        assert violation.location == "method[expr].initial"

    def test_a_user_function_without_initials_is_a_violation(self, tmp_path: Path) -> None:
        """初期値のない利用者定義関数は違反。"""
        def model(x: float, a: float, b: float) -> float:
            return a * x + b

        method = MethodSpec(name="func", kind="callable", function=model)

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.INITIAL_REQUIRED
        )

    def test_initials_for_only_some_parameters_is_also_a_violation(self, tmp_path: Path) -> None:
        """残りが基盤ライブラリの既定値になり、当てはめ時に異常終了する。"""
        method = MethodSpec(
            name="expr", kind="expression", expression="a * x + b", initial={"a": 1.0}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_REQUIRED
        assert "b" in violation.message

    def test_a_builtin_model_without_initials_is_not_a_violation(self, tmp_path: Path) -> None:
        """自動推定を持つため必須ではない（要件 4.1）。データは実行時に与えられる。"""
        assert validate(_config(tmp_path)).violations == ()


class TestAReservedNameUsedAsAValueInAnExpression:
    """要件 3.7: 予約名の値参照は本ゲートで収集され、数式欄が報告される。

    利用者は 4 次多項式 ``a*x**4 + ... + e`` を書いて「4 次式は使えないのか」と報告した。
    当時の報告は初期値欄を指し、`e` が予約名であることに触れていなかったため、原因が
    次数にあるように読めた。本クラスは、報告が**数式欄に置き換わった**状態を固定する。
    初期値欄を指す報告が再び現れれば、利用者は同じ誤解に戻る。
    """

    QUARTIC_WITH_E = "a*x**4 + b*x**3 + c*x**2 + d*x + e"
    """報告のあった式。`e` はネイピア数として値に解決されうる予約名である。"""

    CONFUSING_WORDING = "解決したモデルに存在しない"
    """置き換えられた側の文言（`models.resolver` が未知パラメータに対して出す）。

    これが出るのは `e` がパラメータとして扱われたときだけである。文言そのものを
    書き下すのは、`resolver` の当該経路を import して比べると、経路が使われなく
    なったことと文言が変わったことを区別できないためである。

    **否定の主張だけでは空振りする。** この文言が改訂されると「出ないこと」は
    自動的に成り立ってしまう。文言が実際に出る経路（初期値に未知のパラメータを
    書いた形）を正の側から主張し、綴りが変わった時点で検査が落ちるようにする
    （:meth:`test_the_confusing_wording_really_is_what_the_other_path_says`）。
    """

    def _method(self, initial: dict[str, float] | None = None) -> MethodSpec:
        return MethodSpec(
            name="quartic",
            kind="expression",
            expression=self.QUARTIC_WITH_E,
            initial=initial or {},
        )

    def test_the_gate_collects_it_as_an_unresolved_model(self, tmp_path: Path) -> None:
        """完了状態: 初期値を与えた形では違反 1 件のみで、箇所は数式欄である。"""
        result = validate(_config(tmp_path, methods=(self._method(_QUARTIC_INITIALS),)))

        violation = _only(result)
        assert result.ok is False
        assert violation.kind is ViolationKind.MODEL_UNRESOLVED
        assert violation.location == "method[quartic].expression"

    def test_the_report_names_the_symbol_and_calls_it_reserved(self, tmp_path: Path) -> None:
        """要件 3.7: 記号名・予約名である旨・別名の案内が本ゲートまで届く。"""
        message = _only(
            validate(_config(tmp_path, methods=(self._method(_QUARTIC_INITIALS),)))
        ).message

        assert "'e'" in message
        assert "予約名" in message
        assert "別の名前" in message

    def test_no_report_points_at_the_initial_values(self, tmp_path: Path) -> None:
        """完了状態: 初期値欄を指す報告が出ない。

        `e` に初期値を書いたことが原因であるかのような報告は、原因が数式欄にある以上
        利用者を誤った方向へ誘導する。
        """
        result = validate(_config(tmp_path, methods=(self._method(_QUARTIC_INITIALS),)))

        assert _locations(result) == ["method[quartic].expression"]

    def test_the_confusing_wording_is_gone_whether_or_not_initials_are_given(
        self, tmp_path: Path
    ) -> None:
        """置き換えの本体: 「パラメータが存在しない」は初期値の有無を問わず出ない。

        初期値を与えない形では、初期値必須（要件 4.3）が併せて報告されるため違反は
        2 件になる。これは既存の意図した挙動であり、ここで固定するのは件数ではなく
        **紛らわしい文言が 1 件も出ないこと**である。
        """
        for initial in (_QUARTIC_INITIALS, None):
            result = validate(_config(tmp_path, methods=(self._method(initial),)))
            messages = [violation.message for violation in result.violations]

            assert all(self.CONFUSING_WORDING not in message for message in messages), messages
            assert any("予約名" in message for message in messages), messages

    def test_the_confusing_wording_really_is_what_the_other_path_says(
        self, tmp_path: Path
    ) -> None:
        """上の検査が空振りしないための対。

        `CONFUSING_WORDING` は本ファイルが書き下した綴りである。綴りが実装から
        ずれると、上の「出ないこと」は文言が存在しないだけで成り立ってしまう。
        文言が実際に出る経路——予約名を含まない式に、モデルが持たないパラメータの
        初期値を書いた形——で綴りを正の側から主張する。
        """
        method = MethodSpec(
            name="named",
            kind="expression",
            expression="a*x + b",
            initial={"a": 1.0, "b": 1.0, "unknown": 1.0},
        )
        result = validate(_config(tmp_path, methods=(method,)))
        messages = [violation.message for violation in result.violations]

        assert any(self.CONFUSING_WORDING in message for message in messages), messages

    def test_omitting_the_initials_still_reports_the_expression_first(
        self, tmp_path: Path
    ) -> None:
        """初期値を与えない形の既存挙動（要件 4.3）を据え置く。

        数式欄の報告が初期値必須の報告を隠さないこと、初期値必須の報告が数式欄の報告を
        押し出さないことの双方を固定する。
        """
        result = validate(_config(tmp_path, methods=(self._method(),)))

        assert _kinds(result) == [
            ViolationKind.MODEL_UNRESOLVED,
            ViolationKind.INITIAL_REQUIRED,
        ]
        assert _locations(result) == ["method[quartic].expression", "method[quartic].initial"]

    def test_renaming_the_symbol_makes_the_quartic_pass(self, tmp_path: Path) -> None:
        """要件 3.7 の案内どおりに直せば通ること。4 次式そのものは使える。

        この主張がないと、上の各検査は「4 次式が一律に拒まれる」実装でも通ってしまう。
        """
        renamed = MethodSpec(
            name="quartic",
            kind="expression",
            expression="a*x**4 + b*x**3 + c*x**2 + d*x + f",
            initial={"a": 1.0, "b": 1.0, "c": 1.0, "d": 1.0, "f": 1.0},
        )

        assert validate(_config(tmp_path, methods=(renamed,))).violations == ()


class TestConsistencyOfInitialsAndBounds:
    """要件 4.6: 初期値が上下限の外にあれば処理を開始せず報告する。"""

    def test_an_initial_outside_the_given_bounds_is_a_violation(self, tmp_path: Path) -> None:
        """指定された上下限の外にある初期値は違反。"""
        method = MethodSpec(
            name="gauss",
            kind="builtin",
            builtin="gaussian",
            initial={"amplitude": 20.0},
            bounds={"amplitude": (0.0, 10.0)},
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_OUT_OF_BOUNDS
        assert "amplitude" in violation.message

    def test_an_initial_outside_the_intrinsic_bounds_is_also_a_violation(
        self, tmp_path: Path
    ) -> None:
        """ガウシアンの幅は負を取れない。基盤ライブラリは黙って丸めるため先に止める。"""
        method = MethodSpec(
            name="gauss", kind="builtin", builtin="gaussian", initial={"sigma": -1.0}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.INITIAL_OUT_OF_BOUNDS
        assert "sigma" in violation.message


class TestSmootherOptionConstraints:
    """要件 5.4: 手法固有の選択肢は当てはめエンジンの定数を出所として検証する。"""

    def test_an_unknown_option_name_is_a_violation(self, tmp_path: Path) -> None:
        """未知の選択肢名は違反。"""
        method = _smoother(SmootherKind.POLYNOMIAL, {"windows": 5})

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert "windows" in violation.message
        assert violation.location == "method[sm].options"

    def test_options_given_to_a_method_that_has_none_is_also_a_violation(
        self, tmp_path: Path
    ) -> None:
        """選択肢を持たない手法への指定も違反。"""
        method = _smoother(SmootherKind.LINEAR, {"degree": 2})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    @pytest.mark.parametrize("window", [4, 0, -3, 2.0, 5.5])
    def test_the_window_must_be_a_positive_odd_number(
        self, tmp_path: Path, window: float | int
    ) -> None:
        """窓長は正の奇数でなければ違反。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": window})

        violations = validate(_config(tmp_path, methods=(method,))).violations

        assert violations, f"窓長 {window} が通過した"
        assert all(v.kind is ViolationKind.SMOOTHER_OPTION_INVALID for v in violations)

    @pytest.mark.parametrize("window", [1, 3, 5, 11])
    def test_a_positive_odd_window_passes(self, tmp_path: Path, window: int) -> None:
        """正の奇数の窓長は通過する。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": window})

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_a_negative_polyorder_is_a_violation(self, tmp_path: Path) -> None:
        """多項式次数が負なら違反。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 5, "polyorder": -1})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    def test_a_polyorder_at_or_above_the_window_is_a_violation(self, tmp_path: Path) -> None:
        """多項式次数が窓長以上なら違反。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 5, "polyorder": 5})

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert "polyorder" in violation.message

    def test_an_unspecified_window_is_judged_against_the_default(self, tmp_path: Path) -> None:
        """既定の窓長が適用されるため、それを超える次数は実行時に破綻する。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"polyorder": 6})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    def test_a_non_integer_polyorder_is_a_violation(self, tmp_path: Path) -> None:
        """多項式次数が整数でなければ違反。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 5, "polyorder": 1.5})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    @pytest.mark.parametrize("degree", [-1, 2.5])
    def test_the_polynomial_regression_degree_is_a_non_negative_integer(
        self, tmp_path: Path, degree: float | int
    ) -> None:
        """多項式回帰の次数は非負整数。"""
        method = _smoother(SmootherKind.POLYNOMIAL, {"degree": degree})

        assert _only(validate(_config(tmp_path, methods=(method,)))).kind is (
            ViolationKind.SMOOTHER_OPTION_INVALID
        )

    def test_polynomial_regression_of_degree_0_passes(self, tmp_path: Path) -> None:
        """次数 0 の多項式回帰は通過する。"""
        method = _smoother(SmootherKind.POLYNOMIAL, {"degree": 0})

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    @pytest.mark.parametrize("lam", [0, -1.0])
    def test_the_smoothing_parameter_must_be_positive(
        self, tmp_path: Path, lam: float | int
    ) -> None:
        """平滑化パラメータは正でなければ違反。"""
        method = _smoother(SmootherKind.SPLINE, {"lam": lam})

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert "lam" in violation.message

    def test_an_unspecified_smoothing_parameter_is_a_violation(self, tmp_path: Path) -> None:
        """要件 5.5: 未指定のスプラインは実行前に拒否する。

        未指定だと基盤ライブラリの GCV 探索が働き、同一設定・同一入力の再実行で
        当てはめ値が揺れる（要件 8.2 が成立しない）。報告は「不正」ではなく、
        何を指定すべきかと、なぜ必須なのかを伝える。
        """
        violation = _only(
            validate(_config(tmp_path, methods=(_smoother(SmootherKind.SPLINE, {}),)))
        )

        assert violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
        assert violation.location == "method[sm].options"
        assert smoothing.SPLINE_LAMBDA_OPTION in violation.message
        assert "必須" in violation.message
        assert "再現性" in violation.message

    def test_a_spline_with_a_smoothing_parameter_passes(self, tmp_path: Path) -> None:
        """平滑化パラメータを指定したスプラインは通過する。"""
        assert (
            validate(
                _config(tmp_path, methods=(_smoother(SmootherKind.SPLINE, {"lam": 1e-2}),))
            ).violations
            == ()
        )

    def test_an_unspecified_smoothing_parameter_does_not_cut_off_other_violations(
        self, tmp_path: Path
    ) -> None:
        """要件 5.5 の検査も、最初の違反で打ち切らないという契約の内側にある。"""
        methods = (
            _smoother(SmootherKind.SPLINE, {}, name="spl"),
            _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4}, name="mav"),
            MethodSpec(name="u", kind="builtin", builtin="nope"),
        )

        result = validate(
            _config(
                tmp_path,
                methods=methods,
                preprocess=PreprocessSpec(x_min=10.0, x_max=0.0),
            )
        )

        assert _kinds(result) == [
            ViolationKind.SMOOTHER_OPTION_INVALID,
            ViolationKind.SMOOTHER_OPTION_INVALID,
            ViolationKind.MODEL_UNRESOLVED,
            ViolationKind.CONFIG_INVALID,
        ]

    def test_an_unspecified_and_an_unknown_option_are_reported_together(
        self, tmp_path: Path
    ) -> None:
        """未知の選択肢名を弾いても、必須の選択肢が欠けている事実は消えない。"""
        method = _smoother(SmootherKind.SPLINE, {"smooth": 1.0})

        result = validate(_config(tmp_path, methods=(method,)))

        assert len(result.violations) == 2
        assert all(
            violation.kind is ViolationKind.SMOOTHER_OPTION_INVALID
            for violation in result.violations
        )
        assert [("必須" in v.message) for v in result.violations].count(True) == 1

    def test_several_option_violations_of_one_method_come_back_together(
        self, tmp_path: Path
    ) -> None:
        """同一手法の複数の選択肢違反が一度に返る。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4, "polyorder": -1})

        assert len(validate(_config(tmp_path, methods=(method,))).violations) == 2

    def test_the_builtin_model_degree_is_judged_by_the_resolution_layer(
        self, tmp_path: Path
    ) -> None:
        """平滑化の制約検証が組込モデルにまで及ばないことを確かめる（検査の二重化防止）。"""
        method = MethodSpec(
            name="poly", kind="builtin", builtin="polynomial", options={"degree": -1}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.CONFIG_INVALID


class TestParametersGivenToASmoother:
    """要件 4.4、4.5、8.5: 平滑化手法はパラメータの指定を受け付けない。

    平滑化手法も推定結果としては名前付きパラメータを返す（要件 5.3）。受け付けないのは
    解き方の側の理由であり、閉形式で解く以上、パラメータは結果として出てくるもので
    あって探索の出発点や範囲として与えられるものではない。

    `initial` / `bounds` / `fixed` は当てはめに一切効かないため、黙って捨てず実行前に
    拒否する。捨てると `smoother = "linear"` に `bounds` を添えた設定が exit=0 で
    上限の 985 倍の推定値を返し、同じ指定を `builtin = "linear"` に書いた場合
    （exit=2）と結果が食い違う。タスク 6.3 が `expression` に添えた `options` を
    拒否したのと同じ扱いである。
    """

    @pytest.mark.parametrize(
        ("field", "value"),
        [
            ("initial", {"slope": 99.0}),
            ("bounds", {"slope": (0.0, 0.001)}),
            ("fixed", {"slope": 1.0}),
        ],
    )
    def test_a_parameter_spec_alone_is_a_violation(
        self, tmp_path: Path, field: str, value: dict[str, object]
    ) -> None:
        """パラメータ指定は単独でも違反。"""
        method = MethodSpec(
            name="sm", kind="smoother", smoother=SmootherKind.LINEAR, **{field: value}
        )

        violation = _only(validate(_config(tmp_path, methods=(method,))))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == f"method[sm].{field}"
        assert "slope" in violation.message
        assert SmootherKind.LINEAR.value in violation.message

    def test_all_three_specs_are_reported(self, tmp_path: Path) -> None:
        """最初の 1 件で打ち切らない。3 か所を 1 回の実行で直せる。"""
        method = MethodSpec(
            name="sm",
            kind="smoother",
            smoother=SmootherKind.LINEAR,
            initial={"slope": 99.0},
            bounds={"slope": (0.0, 0.001)},
            fixed={"intercept": 1.0},
        )

        result = validate(_config(tmp_path, methods=(method,)))

        assert _locations(result) == [
            "method[sm].initial",
            "method[sm].bounds",
            "method[sm].fixed",
        ]
        assert _kinds(result) == [ViolationKind.CONFIG_INVALID] * 3

    def test_parameter_names_are_listed_in_name_order(self, tmp_path: Path) -> None:
        """要件 8.2 の決定性: 写像の走査順に報告内容が左右されない。"""
        method = MethodSpec(
            name="sm",
            kind="smoother",
            smoother=SmootherKind.LINEAR,
            initial={"slope": 1.0, "intercept": 0.0, "amplitude": 2.0},
        )

        message = _only(validate(_config(tmp_path, methods=(method,)))).message

        assert message.index("amplitude") < message.index("intercept")
        assert message.index("intercept") < message.index("slope")

    def test_reported_together_with_option_violations(self, tmp_path: Path) -> None:
        """選択肢の検査を打ち切らない（全項目を検査してから返すという契約）。"""
        method = MethodSpec(
            name="sm",
            kind="smoother",
            smoother=SmootherKind.SPLINE,
            initial={"slope": 1.0},
        )

        result = validate(_config(tmp_path, methods=(method,)))

        assert _kinds(result) == [
            ViolationKind.CONFIG_INVALID,
            ViolationKind.SMOOTHER_OPTION_INVALID,
        ]

    def test_does_not_cut_off_violations_of_other_methods(self, tmp_path: Path) -> None:
        """他の手法の違反を打ち切らない。"""
        methods = (
            MethodSpec(
                name="sm",
                kind="smoother",
                smoother=SmootherKind.LINEAR,
                bounds={"slope": (0.0, 0.001)},
            ),
            MethodSpec(name="u", kind="builtin", builtin="nope"),
        )

        result = validate(_config(tmp_path, methods=methods))

        assert _kinds(result) == [
            ViolationKind.CONFIG_INVALID,
            ViolationKind.MODEL_UNRESOLVED,
        ]

    @pytest.mark.parametrize(
        ("kind", "options"),
        [
            (SmootherKind.LINEAR, {}),
            (SmootherKind.POLYNOMIAL, {"degree": 2}),
            (SmootherKind.SPLINE, {"lam": 1e-2}),
            (SmootherKind.MOVING_AVERAGE, {"window": 5}),
        ],
    )
    def test_a_smoother_without_parameters_passes(
        self, tmp_path: Path, kind: SmootherKind, options: dict[str, float | int]
    ) -> None:
        """誤検出の回帰止め。4 手法のいずれも従来どおり実行できる。"""
        assert validate(_config(tmp_path, methods=(_smoother(kind, options),))).violations == ()

    def test_builtin_models_still_accept_parameter_specs(self, tmp_path: Path) -> None:
        """要件 4.2、4.4、4.5 の経路を塞がない。"""
        method = MethodSpec(
            name="lin",
            kind="builtin",
            builtin="linear",
            initial={"slope": 0.5},
            bounds={"slope": (0.0, 1.0)},
            fixed={"intercept": 0.0},
        )

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_expression_models_still_accept_parameter_specs(self, tmp_path: Path) -> None:
        """数式モデルはパラメータ指定を引き続き受け付ける。"""
        method = MethodSpec(
            name="expr",
            kind="expression",
            expression="a * x + b",
            initial={"a": 1.0},
            bounds={"a": (0.0, 2.0)},
            fixed={"b": 0.0},
        )

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_parameter_specs_of_an_unresolvable_method_are_not_checked(
        self, tmp_path: Path
    ) -> None:
        """手法が定まらなければ、何を指定できるかも定まらない（選択肢と同じ扱い）。"""
        method = MethodSpec(name="sm", kind="smoother", smoother=None, initial={"slope": 1.0})

        result = validate(_config(tmp_path, methods=(method,)))

        assert _kinds(result) == [ViolationKind.MODEL_UNRESOLVED]


class TestErrorColumnGivenToAWeightlessMethod:
    """要件 1.10: 点ごとの重みを扱えない手法に誤差列を与えた設定を実行前に拒否する。

    黙って無視すると、測定誤差を与えた利用者がそれを反映した結果として読む。実行ログの
    警告は `summary.csv` だけを読む利用者に届かない。平滑化手法へのパラメータ指定を
    拒否するのと同じ扱いである（要件 4.4、4.5）。

    **対象は列挙ではなく `engines.smoothing` の宣言から導く。** 拒否する手法の一覧を
    ここが独自に持つと、スプラインが重みを扱えるようになったとき（タスク 11.1）と同じ
    形で、宣言と拒否対象が食い違う。
    """

    def test_each_weightless_method_has_its_own_reason(self) -> None:
        """宣言に手法が加わったとき、理由の追加漏れに気づけること（要件 1.10）。

        理由が漏れると一般化した説明に落ちる。利用者には「なぜこの手法では駄目なのか」が
        伝わらず、次の一手も選べない。宣言側には `test_全手法について宣言がある` があるが、
        理由側には対応する検査が無かった。
        """
        weightless = {kind for kind, uses in smoothing.SMOOTHER_USES_WEIGHTS.items() if not uses}

        reasons = set(preflight_module._NO_WEIGHT_SUPPORT_REASONS)
        assert weightless <= reasons, (
            "重みを扱えないと宣言した手法に個別の理由が無い: "
            f"{sorted(k.value for k in weightless - reasons)}"
        )

    WEIGHT_COLUMN = "err"

    def test_a_moving_average_with_an_error_column_is_a_violation(self, tmp_path: Path) -> None:
        """移動平均と誤差列の組み合わせは違反。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        violation = _only(validate(_config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == "method[sm].smoother"

    def test_the_report_names_the_method_the_location_and_the_next_step(
        self, tmp_path: Path
    ) -> None:
        """「反映できない」で終えない。理由・場所・直し方の 3 つを載せる。

        `_why_not_applicable` の precedent に倣う。理由の分からない拒否は、設定の
        書き直しではなく手法の乗り換えを招く。
        """
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        message = _only(
            validate(_config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN))
        ).message

        # 当該手法を名指しする
        assert SmootherKind.MOVING_AVERAGE.value in message
        # 直すべき設定箇所を名指しする。どの y 列の指定かが分かる形で載せる（要件 1.11）
        assert "input.columns[0].weight" in message
        # 「重みを扱えない」の実体を述べる。畳み込み係数が窓長と多項式次数だけで
        # 決まる以上、点ごとの重みを置く場所が無い
        assert "窓長" in message
        assert "多項式次数" in message
        # 取れる道を両方示す
        assert "削除" in message
        assert SmootherKind.SPLINE.value in message

    @pytest.mark.parametrize(
        ("kind", "options"),
        [
            (SmootherKind.LINEAR, {}),
            (SmootherKind.POLYNOMIAL, {"degree": 2}),
            (SmootherKind.SPLINE, {"lam": 1e-2}),
        ],
    )
    def test_a_weight_using_smoother_passes_with_an_error_column(
        self, tmp_path: Path, kind: SmootherKind, options: dict[str, float | int]
    ) -> None:
        """誤検出の回帰止め。タスク 11.1 でスプラインが重みを扱うようになった。"""
        method = _smoother(kind, options)

        result = validate(_config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN))

        assert result.violations == ()

    @pytest.mark.parametrize(
        "method",
        [
            MethodSpec(name="lin", kind="builtin", builtin="linear"),
            MethodSpec(name="gauss", kind="builtin", builtin="gaussian"),
            MethodSpec(
                name="expr",
                kind="expression",
                expression="a * x + b",
                initial={"a": 1.0, "b": 0.0},
            ),
        ],
    )
    def test_a_model_function_fit_passes_with_an_error_column(
        self, tmp_path: Path, method: MethodSpec
    ) -> None:
        """要件 1.3 の主たる経路を塞がない。最小二乗はいずれも重みを用いる。"""
        result = validate(_config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN))

        assert result.violations == ()

    def test_an_error_column_on_any_y_column_is_a_violation(self, tmp_path: Path) -> None:
        """要件 1.10、1.12: 判定は「いずれかの y 列に誤差列が対応付けられているか」。

        先頭の列だけを見る実装だと、2 列目にだけ誤差列を書いた設定が素通りする。
        素通りすれば、測定誤差を与えた利用者がそれを反映した結果として当てはめを読む。
        """
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})
        columns = (
            ColumnSpec(x="time", y="signal"),
            ColumnSpec(x="time", y="other", weight=self.WEIGHT_COLUMN),
        )

        violation = _only(validate(_config(tmp_path, methods=(method,), columns=columns)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert "input.columns[1].weight" in violation.message

    def test_the_report_names_every_column_that_carries_an_error_column(
        self, tmp_path: Path
    ) -> None:
        """要件 1.10: 消すべき指定を取りこぼさずに挙げる。

        1 つだけ挙げると、利用者はそれを消してもう一度拒否される。無駄な往復を避ける。
        """
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})
        columns = (
            ColumnSpec(x="time", y="a", weight="err_a"),
            ColumnSpec(x="time", y="b"),
            ColumnSpec(x="time", y="c", weight="err_c"),
        )

        message = _only(validate(_config(tmp_path, methods=(method,), columns=columns))).message

        assert "input.columns[0].weight" in message
        assert "input.columns[2].weight" in message
        assert "input.columns[1].weight" not in message

    def test_several_y_columns_without_any_error_column_pass(self, tmp_path: Path) -> None:
        """偽の警告を出さない。誤差列がどの列にも無ければ従来どおり実行できる。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})
        columns = (
            ColumnSpec(x="time", y="signal"),
            ColumnSpec(x="time", y="other"),
        )

        assert validate(_config(tmp_path, methods=(method,), columns=columns)).violations == ()

    def test_a_weight_using_smoother_passes_with_error_columns_on_several_y_columns(
        self, tmp_path: Path
    ) -> None:
        """誤検出の回帰止め。重みを扱う手法は列が何本あっても通る。"""
        method = _smoother(SmootherKind.SPLINE, {"lam": 1e-2})
        columns = (
            ColumnSpec(x="time", y="a", weight="err_a"),
            ColumnSpec(x="time", y="b", weight="err_b"),
        )

        assert validate(_config(tmp_path, methods=(method,), columns=columns)).violations == ()

    def test_a_positional_error_column_on_a_later_y_column_is_covered(
        self, tmp_path: Path
    ) -> None:
        """`0` は偽値だが指定である。並びの途中でも同じ扱いになること。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})
        columns = (
            ColumnSpec(x=0, y=1),
            ColumnSpec(x=0, y=2, weight=0),
        )

        result = validate(_config(tmp_path, methods=(method,), columns=columns))

        assert _kinds(result) == [ViolationKind.CONFIG_INVALID]

    def test_a_moving_average_without_an_error_column_passes(self, tmp_path: Path) -> None:
        """完了状態: 指定しなければ従来どおり実行できる。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_a_positionally_given_error_column_is_also_covered(self, tmp_path: Path) -> None:
        """列指定は名前でも位置でもよい（`ColumnSpec`）。0 は偽値だが指定である。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {})

        result = validate(_config(tmp_path, methods=(method,), weight=0))

        assert _kinds(result) == [ViolationKind.CONFIG_INVALID]

    def test_does_not_cut_off_option_violations_of_the_same_method(self, tmp_path: Path) -> None:
        """全項目を検査してから返すという本ゲートの契約は手法 1 件の内側でも成り立つ。"""
        method = _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4})

        result = validate(_config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN))

        assert _kinds(result) == [
            ViolationKind.SMOOTHER_OPTION_INVALID,
            ViolationKind.CONFIG_INVALID,
        ]

    def test_does_not_cut_off_violations_of_other_methods_the_output_or_preprocessing(
        self, tmp_path: Path
    ) -> None:
        """他の手法と出力先と前処理の違反を打ち切らない。"""
        methods = (
            _smoother(SmootherKind.MOVING_AVERAGE, {}, name="mav"),
            MethodSpec(name="u", kind="builtin", builtin="nope"),
        )

        result = validate(
            RunConfig(
                inputs=InputSpec(
                    paths=("data/a.csv",),
                    columns=(ColumnSpec(x="time", y="signal", weight="err"),),
                ),
                methods=methods,
                preprocess=PreprocessSpec(x_min=10.0, x_max=0.0),
                output=OutputSpec(directory=tmp_path / "no" / "such" / "dir"),
            )
        )

        assert _locations(result) == [
            "method[mav].smoother",
            "method[u].builtin",
            "output_dir",
            "preprocess.x_min",
        ]

    def test_an_unresolvable_method_is_not_checked(self, tmp_path: Path) -> None:
        """手法が定まらなければ重みを扱えるかも定まらない（選択肢と同じ扱い）。"""
        method = MethodSpec(name="sm", kind="smoother", smoother=None)

        result = validate(_config(tmp_path, methods=(method,), weight=self.WEIGHT_COLUMN))

        assert _kinds(result) == [ViolationKind.MODEL_UNRESOLVED]

    def test_the_rejected_methods_are_derived_from_the_declaration(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """宣言を書き換えれば拒否の対象も変わる。列挙の二重所有を排除した証拠。

        `SMOOTHER_USES_WEIGHTS` を差し替えて、線形回帰が拒否側・移動平均が通過側に
        入れ替わることを確かめる。ゲートが独自の一覧を持っていればここで落ちる。
        """
        from curvefit import preflight

        flipped = {
            **smoothing.SMOOTHER_USES_WEIGHTS,
            SmootherKind.LINEAR: False,
            SmootherKind.MOVING_AVERAGE: True,
        }
        monkeypatch.setattr(preflight, "SMOOTHER_USES_WEIGHTS", flipped)

        linear = validate(
            _config(
                tmp_path,
                methods=(_smoother(SmootherKind.LINEAR, {}),),
                weight=self.WEIGHT_COLUMN,
            )
        )
        moving = validate(
            _config(
                tmp_path,
                methods=(_smoother(SmootherKind.MOVING_AVERAGE, {}),),
                weight=self.WEIGHT_COLUMN,
            )
        )

        assert _kinds(linear) == [ViolationKind.CONFIG_INVALID]
        assert moving.violations == ()


class TestWhereTheDefaultsComeFrom:
    """既定値は `engines.smoothing` が単独で所有する。preflight は独自に持たない。"""

    def test_the_constants_are_referenced_directly(self) -> None:
        """定数をそのまま参照している。"""
        from curvefit import preflight

        assert preflight.SMOOTHER_OPTION_DEFAULTS is smoothing.SMOOTHER_OPTION_DEFAULTS
        assert preflight.SMOOTHER_OPTION_NAMES is smoothing.SMOOTHER_OPTION_NAMES

    def test_replacing_a_default_changes_the_judgement(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """既定値を写し取っていれば、エンジン側の定数を替えても判定は変わらない。"""
        from curvefit import preflight

        method = _smoother(SmootherKind.MOVING_AVERAGE, {"polyorder": 6})
        assert validate(_config(tmp_path, methods=(method,))).violations != ()

        widened = {**smoothing.SMOOTHER_OPTION_DEFAULTS}
        widened[SmootherKind.MOVING_AVERAGE] = {
            smoothing.MOVING_AVERAGE_WINDOW_OPTION: 9,
            smoothing.MOVING_AVERAGE_POLYORDER_OPTION: 0,
        }
        monkeypatch.setattr(preflight, "SMOOTHER_OPTION_DEFAULTS", widened)

        assert validate(_config(tmp_path, methods=(method,))).violations == ()

    def test_the_defaults_themselves_are_not_violations(self, tmp_path: Path) -> None:
        """エンジンが適用する既定値の組が、本ゲートの制約を満たすことの回帰検出。

        スプラインの平滑化パラメータは既定値を持たない必須の選択肢であり（要件 5.5）、
        既定値の妥当性という問いの対象外である。ここでは正当な値を補って比較する。
        """
        for kind, defaults in smoothing.SMOOTHER_OPTION_DEFAULTS.items():
            options = dict(defaults)
            if kind is SmootherKind.SPLINE:
                options[smoothing.SPLINE_LAMBDA_OPTION] = 1e-2
            method = _smoother(kind, options)

            assert validate(_config(tmp_path, methods=(method,))).violations == (), kind


class TestOutputDestinationWritability:
    """要件 7.7: 書き込めない出力先は処理を開始せず報告する。"""

    @requires_permission_bits
    def test_an_unwritable_directory_is_a_violation(self, tmp_path: Path) -> None:
        """書き込めないディレクトリは違反。"""
        directory = tmp_path / "locked"
        directory.mkdir()
        directory.chmod(stat.S_IRUSR | stat.S_IXUSR)
        try:
            result = validate(_config(directory))
        finally:
            directory.chmod(stat.S_IRWXU)

        violation = _only(result)
        assert violation.kind is ViolationKind.OUTPUT_NOT_WRITABLE
        assert str(directory) in violation.message

    def test_a_destination_whose_parent_is_missing_is_a_violation(self, tmp_path: Path) -> None:
        """親ごと存在しない出力先は違反。"""
        result = validate(_config(tmp_path / "no" / "such" / "dir"))

        assert _only(result).kind is ViolationKind.OUTPUT_NOT_WRITABLE

    def test_an_uncreated_destination_with_an_existing_parent_is_not_a_violation(
        self, tmp_path: Path
    ) -> None:
        """親が存在すれば未作成でも違反にならない。"""
        assert validate(_config(tmp_path / "out")).violations == ()


class TestValidityOfTheConfigStructure:
    """要件 8.5、2.1: データに依存しない設定の誤りは実行前に止める。"""

    def test_an_inverted_fit_range_is_a_violation(self, tmp_path: Path) -> None:
        """前処理層は検証しない。通すと点数不足として黙って失敗する。"""
        spec = PreprocessSpec(x_min=10.0, x_max=0.0)

        violation = _only(validate(_config(tmp_path, preprocess=spec)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location.startswith("preprocess")

    def test_a_range_with_equal_bounds_is_not_a_violation(self, tmp_path: Path) -> None:
        """上下限が等しい区間は違反ではない。"""
        spec = PreprocessSpec(x_min=1.0, x_max=1.0)

        assert validate(_config(tmp_path, preprocess=spec)).violations == ()

    def test_a_one_sided_range_is_not_a_violation(self, tmp_path: Path) -> None:
        """片側だけの区間指定は違反ではない。"""
        spec = PreprocessSpec(x_min=10.0)

        assert validate(_config(tmp_path, preprocess=spec)).violations == ()

    @pytest.mark.parametrize("sigma", [0.0, -1.0])
    def test_the_outlier_threshold_must_be_positive(self, tmp_path: Path, sigma: float) -> None:
        """0 以下では残差が 0 でない全点が外れ値になる。"""
        spec = PreprocessSpec(outlier=OutlierSpec(sigma=sigma))

        violation = _only(validate(_config(tmp_path, preprocess=spec)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == "preprocess.outlier.sigma"

    def test_a_negative_iteration_limit_is_a_violation(self, tmp_path: Path) -> None:
        """反復上限が負なら違反。"""
        spec = PreprocessSpec(outlier=OutlierSpec(max_iterations=-1))

        violation = _only(validate(_config(tmp_path, preprocess=spec)))

        assert violation.kind is ViolationKind.CONFIG_INVALID
        assert violation.location == "preprocess.outlier.max_iterations"

    def test_an_iteration_limit_of_0_is_not_a_violation(self, tmp_path: Path) -> None:
        """反復上限 0 は違反ではない。"""
        spec = PreprocessSpec(outlier=OutlierSpec(max_iterations=0))

        assert validate(_config(tmp_path, preprocess=spec)).violations == ()

    def test_ranges_are_not_checked_when_outlier_removal_is_disabled(self, tmp_path: Path) -> None:
        """外れ値除去が無効なら値域は検査しない。"""
        assert validate(_config(tmp_path, preprocess=PreprocessSpec(outlier=None))).violations == ()

    def test_several_outlier_setting_violations_come_back_together(self, tmp_path: Path) -> None:
        """外れ値設定の複数の違反が一度に返る。"""
        spec = PreprocessSpec(outlier=OutlierSpec(sigma=0.0, max_iterations=-1))

        assert len(validate(_config(tmp_path, preprocess=spec)).violations) == 2


class TestExistenceOfInputPaths:
    """入力パスの存在は検査しない。0 件は正常、不存在は個別の失敗（要件 1.4/1.5）。"""

    def test_a_direct_spec_for_a_missing_file_passes(self, tmp_path: Path) -> None:
        """存在しないファイルの直接指定は通過する。"""
        config = _config(tmp_path, paths=(str(tmp_path / "missing.csv"),))

        assert validate(config).ok is True

    def test_a_spec_for_a_missing_directory_also_passes(self, tmp_path: Path) -> None:
        """存在しないディレクトリの指定も通過する。"""
        config = _config(tmp_path, paths=(str(tmp_path / "no_such_dir"),))

        assert validate(config).ok is True

    def test_a_spec_for_an_empty_directory_also_passes(self, tmp_path: Path) -> None:
        """空のディレクトリ指定も通過する。"""
        empty = tmp_path / "empty"
        empty.mkdir()

        assert validate(_config(tmp_path, paths=(str(empty),))).ok is True


class TestResolutionIndependentOfData:
    """設計の Implementation Notes: モデル解決は `sample=None` で行う。"""

    def test_no_data_is_passed_to_the_resolution(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """解決にデータを渡さない。"""
        from curvefit import preflight

        samples: list[object] = []
        original = preflight.resolve

        def spy(spec: MethodSpec, sample: object) -> object:
            samples.append(sample)
            return original(spec, None)

        monkeypatch.setattr(preflight, "resolve", spy)
        validate(_config(tmp_path, methods=(GAUSSIAN, _smoother(SmootherKind.LINEAR, {}))))

        assert samples == [None, None]

    def test_auto_guess_capability_is_not_judged_here(self, tmp_path: Path) -> None:
        """データが無くても組込モデルは通過する。推定はジョブ実行時に行う。"""
        result = validate(_config(tmp_path, methods=(GAUSSIAN,)))

        assert result.ok is True


class TestCollectingAllViolationsAtOnce:
    """完了状態: 複数の違反を含む設定に対して全違反が一度に返る。"""

    def _every_category(self, tmp_path: Path) -> RunConfig:
        """6 種類の違反分類すべてを 1 つの設定に含める。"""

        def model(x: float, a: float) -> float:
            return a * x

        methods = (
            MethodSpec(name="unknown", kind="builtin", builtin="nope"),
            MethodSpec(name="expr", kind="expression", expression="a * x + b"),
            MethodSpec(name="gauss", kind="builtin", builtin="gaussian", initial={"sigma": -1.0}),
            _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4}, name="mav"),
        )
        return RunConfig(
            inputs=InputSpec(paths=("data/a.csv",), columns=(ColumnSpec(x="time", y="signal"),)),
            methods=methods,
            preprocess=PreprocessSpec(x_min=10.0, x_max=0.0),
            output=OutputSpec(directory=tmp_path / "no" / "such" / "dir"),
        )

    def test_violations_of_every_kind_come_back_together(self, tmp_path: Path) -> None:
        """全分類の違反が一度に返る。"""
        result = validate(self._every_category(tmp_path))

        assert Counter(_kinds(result)) == Counter(
            [
                ViolationKind.MODEL_UNRESOLVED,
                ViolationKind.INITIAL_REQUIRED,
                ViolationKind.INITIAL_OUT_OF_BOUNDS,
                ViolationKind.SMOOTHER_OPTION_INVALID,
                ViolationKind.OUTPUT_NOT_WRITABLE,
                ViolationKind.CONFIG_INVALID,
            ]
        )

    def test_the_count_matches_the_number_of_kinds(self, tmp_path: Path) -> None:
        """件数は分類の数と一致する。"""
        assert len(validate(self._every_category(tmp_path)).violations) == 6

    def test_every_kind_is_covered(self, tmp_path: Path) -> None:
        """検査項目の抜けを検出する。分類を増やしたら本テストが落ちる。"""
        assert set(_kinds(validate(self._every_category(tmp_path)))) == set(ViolationKind)

    def test_does_not_stop_at_the_first_method(self, tmp_path: Path) -> None:
        """最初の手法で打ち切らない。"""
        methods = (
            MethodSpec(name="a", kind="builtin", builtin="nope"),
            MethodSpec(name="b", kind="builtin", builtin="also_nope"),
            MethodSpec(name="c", kind="builtin", builtin="still_nope"),
        )

        result = validate(_config(tmp_path, methods=methods))

        assert _locations(result) == ["method[a].builtin", "method[b].builtin", "method[c].builtin"]

    def test_no_kind_ever_raises(self, tmp_path: Path) -> None:
        """利用者が書いた内容に対して例外を送出しない（設計の Error Strategy）。"""
        methods = (
            MethodSpec(
                name="x", kind="smoother", smoother=SmootherKind.SPLINE, options={"lam": "近い"}
            ),  # type: ignore[dict-item]
            MethodSpec(
                name="y",
                kind="smoother",
                smoother=SmootherKind.MOVING_AVERAGE,
                options={"window": None},
            ),  # type: ignore[dict-item]
        )

        result = validate(_config(tmp_path, methods=methods))

        assert not result.ok


class TestDeterminismOfViolationOrder:
    """要件 8.2: 同一の実行条件なら違反の並びも同一になる。"""

    def test_repeated_calls_keep_the_same_order(self, tmp_path: Path) -> None:
        """繰り返し呼んでも並びが変わらない。"""
        config = _config(
            tmp_path / "no" / "such" / "dir",
            methods=(
                MethodSpec(name="u", kind="builtin", builtin="nope"),
                _smoother(SmootherKind.MOVING_AVERAGE, {"window": 4, "polyorder": -1}),
            ),
            preprocess=PreprocessSpec(x_min=10.0, x_max=0.0, outlier=OutlierSpec(sigma=-1.0)),
        )

        first = validate(config).violations

        assert all(validate(config).violations == first for _ in range(5))

    def test_the_order_of_unknown_option_names_is_also_fixed(self, tmp_path: Path) -> None:
        """未知の選択肢名の並びも固定される。"""
        method = _smoother(SmootherKind.LINEAR, {"zeta": 1, "alpha": 2, "mu": 3})

        result = validate(_config(tmp_path, methods=(method,)))

        assert [v.message for v in result.violations] == sorted(
            v.message for v in result.violations
        ), "未知の選択肢は名前順に並べる"

    def test_the_order_is_unchanged_across_hash_seeds(self, tmp_path: Path) -> None:
        """写像の走査順に依存していないことを、別プロセスで確かめる（要件 8.2）。"""
        script = tmp_path / "order.py"
        script.write_text(ORDER_SCRIPT, encoding="utf-8")
        outputs = set()
        for seed in ("0", "1", "12345"):
            environment = {**os.environ, "PYTHONHASHSEED": seed, "PYTHONPATH": str(ROOT / "src")}
            completed = subprocess.run(
                [sys.executable, str(script), str(tmp_path)],
                capture_output=True,
                text=True,
                env=environment,
                check=True,
            )
            outputs.add(completed.stdout)

        assert len(outputs) == 1, outputs
        assert outputs.pop().strip(), "違反が 1 件も出ていない"


class TestTheRouteFromAConfigFile:
    """`config` が値域の検証を委ねた項目を、本ゲートが受け取って判定する。"""

    def _load(self, tmp_path: Path, text: str) -> RunConfig:
        path = tmp_path / "config.toml"
        path.write_text(text, encoding="utf-8")
        result = load_config(path, {})
        assert isinstance(result[0], RunConfig), result
        return result[0]

    def test_this_gate_catches_range_violations_from_the_config_file(self, tmp_path: Path) -> None:
        """設定ファイルの値域違反を本ゲートが捕まえる。"""
        text = f"""
[input]
paths = ["data/a.csv"]

[input.columns]
x = "time"
y = "signal"

[[methods]]
name = "mav"
smoother = "moving_average"
options = {{ window = 4 }}

[preprocess]
x_min = 10.0
x_max = 0.0

[preprocess.outlier]
sigma = 0.0

[output]
directory = {str(tmp_path)!r}
"""
        result = validate(self._load(tmp_path, text))

        assert Counter(_kinds(result)) == Counter(
            [
                ViolationKind.SMOOTHER_OPTION_INVALID,
                ViolationKind.CONFIG_INVALID,
                ViolationKind.CONFIG_INVALID,
            ]
        )

    def test_this_gate_catches_options_attached_to_an_expression_model(
        self, tmp_path: Path
    ) -> None:
        """数式・関数の経路に選択肢の意味はない（要件 8.5）。黙って捨てると、設定
        ファイルの記述と実際の実行条件が食い違ったまま当てはめが成功する。"""
        text = f"""
[input]
paths = ["data/a.csv"]

[input.columns]
x = "time"
y = "signal"

[[methods]]
name = "decay"
expression = "a * exp(-b * x) + c"
initial = {{ a = 1.0, b = 0.1, c = 0.0 }}
options = {{ degree = 3, window = 7, totally_bogus = 1 }}

[output]
directory = {str(tmp_path / "out")!r}
"""
        result = validate(self._load(tmp_path, text))

        assert result.ok is False
        assert _kinds(result) == [ViolationKind.CONFIG_INVALID]
        assert _locations(result) == ["method[decay].options"]
        message = result.violations[0].message
        assert message.index("degree") < message.index("totally_bogus") < message.index("window")

    def test_a_correct_config_file_passes(self, tmp_path: Path) -> None:
        """正しい設定ファイルは通過する。"""
        text = f"""
[input]
paths = ["data/*.csv"]

[input.columns]
x = 0
y = 1

[[methods]]
name = "gauss"
builtin = "gaussian"

[[methods]]
name = "mav"
smoother = "moving_average"
options = {{ window = 7, polyorder = 2 }}

[output]
directory = {str(tmp_path / "out")!r}
"""
        assert validate(self._load(tmp_path, text)).ok is True


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が上位層やライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse((SRC / "preflight.py").read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class TestDependencyExposure:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_does_not_import_upper_layers(self) -> None:
        """上位層を import しない。"""
        forbidden = {"curvefit.pipeline", "curvefit.api", "curvefit.cli"}

        assert not (_imported_modules() & forbidden)

    def test_does_not_directly_import_underlying_libraries(self) -> None:
        """基盤ライブラリを直接 import しない。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval", "numpy"}, (
                f"preflight.py が {imported} を import している"
            )

    def test_imports_the_validation_sources_from_existing_modules(self) -> None:
        """検証の出所を既存モジュールから取り込む。"""
        expected = {
            "curvefit.config",
            "curvefit.engines.smoothing",
            "curvefit.errors",
            "curvefit.models.resolver",
            "curvefit.preprocess",
            "curvefit.writers",
        }

        assert expected <= _imported_modules()

    def test_does_not_define_the_defaults_itself(self) -> None:
        """モジュール変数に数値の既定値を持たないことを構文木で確かめる。

        注釈を付けるだけで検査をすり抜けないよう、`ast.Assign` と `ast.AnnAssign` の
        両方を見る。
        """
        tree = ast.parse((SRC / "preflight.py").read_text(encoding="utf-8"))
        for node in tree.body:
            if not isinstance(node, (ast.Assign, ast.AnnAssign)):
                continue
            numbers = [
                inner.value
                for inner in ast.walk(node)
                if isinstance(inner, ast.Constant)
                and isinstance(inner.value, (int, float))
                and not isinstance(inner.value, bool)
            ]

            assert not numbers, f"モジュール変数に数値の既定値がある: {ast.unparse(node)}"
