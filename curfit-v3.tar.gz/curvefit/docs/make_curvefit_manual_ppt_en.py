"""curvefit User Manual PowerPoint generator (English)

Content is taken from README.md, `curvefit --help`, and the TOML notation in
`src/curvefit/config.py`. When a command or a configuration key changes, update
the corresponding slide in this script (and in the Japanese counterpart,
make_curvefit_manual_ppt.py).
"""
import pathlib

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

# ---- Color palette ----
INK      = RGBColor(0x1A, 0x1A, 0x1A)   # body text
PAPER    = RGBColor(0xFA, 0xF7, 0xF2)   # background (cream)
ACCENT   = RGBColor(0xD9, 0x77, 0x57)   # coral
ACCENT2  = RGBColor(0x2E, 0x4A, 0x62)   # deep blue
GRAY     = RGBColor(0x6B, 0x66, 0x60)   # secondary text
WHITE    = RGBColor(0xFF, 0xFF, 0xFF)
CARDBG   = RGBColor(0xFF, 0xFF, 0xFF)
RULE     = RGBColor(0xE2, 0xDC, 0xD3)   # hairline
CODEBG   = RGBColor(0x2B, 0x2B, 0x2B)
CODEFG   = RGBColor(0xE6, 0xE6, 0xE6)
CODEKEY  = RGBColor(0x9C, 0xDC, 0xFE)   # highlighted token in code
GOOD     = RGBColor(0x3A, 0x7D, 0x44)
BAD      = RGBColor(0xB5, 0x3A, 0x2E)
WARNBG   = RGBColor(0xFB, 0xF0, 0xE8)

FONT   = "Calibri"
FONTM  = "Consolas"

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)
SW, SH = prs.slide_width, prs.slide_height
BLANK = prs.slide_layouts[6]

DEFAULT_ROW_HEIGHT = Inches(0.42)


# ---- Overflow detection ----------------------------------------------------
# Sizing a box by line count alone lets an over-wide line wrap and collide with
# whatever sits below it. Estimate the drawn width first and fail on the spot.

def _width_pt(text, size, mono):
    """Estimated drawn width in points."""
    em = 0.60 if mono else 0.48          # width of one character, in em
    return len(text) * em * size


def fits(text, size, width_in, mono=False, where=""):
    """Fail when the text does not fit. width_in is the usable width in inches."""
    limit = width_in * 72.0
    got = _width_pt(text, size, mono)
    if got > limit:
        raise AssertionError(
            f"overflow {where}: {got:.0f}pt > {limit:.0f}pt / {size}pt / {text!r}")
    return text


def bg(slide, color=PAPER):
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = color


def box(slide, left, t, w, h, fill=None, line=None, line_w=1.0, round_=False):
    shp = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if round_ else MSO_SHAPE.RECTANGLE, left, t, w, h)
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    return shp


def txt(slide, left, t, w, h, runs, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP,
        space_after=6, line_spacing=1.0):
    """runs: list of paragraphs; each paragraph is a list of (text, size, color, bold, font)."""
    tb = slide.shapes.add_textbox(left, t, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = 0
    tf.margin_right = 0
    tf.margin_top = 0
    tf.margin_bottom = 0
    for i, para in enumerate(runs):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(space_after)
        p.space_before = Pt(0)
        p.line_spacing = line_spacing
        for (text, size, color, bold, font) in para:
            r = p.add_run()
            r.text = text
            r.font.size = Pt(size)
            r.font.color.rgb = color
            r.font.bold = bold
            r.font.name = font
    return tb


def run_(text, size=14, color=INK, bold=False, font=FONT):
    return (text, size, color, bold, font)


def header(slide, title, num):
    box(slide, 0, 0, SW, Inches(1.05), fill=WHITE)
    box(slide, 0, Inches(1.05), SW, Pt(3), fill=ACCENT)
    box(slide, Inches(0.5), Inches(0.28), Pt(8), Inches(0.5), fill=ACCENT)
    txt(slide, Inches(0.72), Inches(0.22), Inches(10.5), Inches(0.7),
        [[run_(title, 26, INK, True)]], anchor=MSO_ANCHOR.MIDDLE)
    label = f"{num:02d}" if isinstance(num, int) else str(num)
    txt(slide, Inches(11.6), Inches(0.22), Inches(1.3), Inches(0.7),
        [[run_(label, 26, ACCENT, True)]], align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE)


def footer(slide):
    txt(slide, Inches(0.72), Inches(7.02), Inches(8), Inches(0.24),
        [[run_("curvefit User Manual", 9, GRAY, False)]])


def wrap(text, size, width_in, mono=False):
    """Wrap on word boundaries, which is what English needs."""
    limit = width_in * 72.0
    lines: list[str] = []
    current = ""
    for word in text.split(" "):
        candidate = f"{current} {word}" if current else word
        if _width_pt(candidate, size, mono) > limit and current:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def code(slide, left, t, w, lines, size=13, title=None):
    """A code block. Each entry is a string, or a (string, color) pair."""
    # Measured: one drawn line is the type size times the leading, plus padding.
    # A fixed value clips the last line.
    lh = Inches(size * 1.18 / 72.0 + 0.048)
    top = t
    if title:
        fits(title, 12, w.inches, where="code title")
        txt(slide, left, top, w, Inches(0.3), [[run_(title, 12, GRAY, True)]])
        top = top + Inches(0.34)
    inner = w.inches - 0.44
    for line in lines:
        fits(line[0] if isinstance(line, tuple) else line, size, inner, mono=True,
             where="code")
    h = lh * len(lines) + Inches(0.34)
    box(slide, left, top, w, h, fill=CODEBG, round_=True)
    paras = []
    for line in lines:
        if isinstance(line, tuple):
            text, color = line
        else:
            text, color = line, CODEFG
        paras.append([run_(text if text else " ", size, color, False, FONTM)])
    txt(slide, left + Inches(0.22), top + Inches(0.17), w - Inches(0.44),
        lh * len(lines) + Inches(0.04), paras, space_after=0, line_spacing=1.18)
    return top + h


def card(slide, left, t, w, h, title, body, accent=ACCENT, title_size=15, body_size=12.5):
    """The body wraps at the measured width; the box grows when it must.

    The h that is passed in is treated as a lower bound.
    """
    inner = w.inches - 0.5
    fits(title, title_size, inner, where="card title")
    wrapped = []
    for line in body:
        wrapped.extend(wrap(line, body_size, inner))
    need = Inches(0.68 + 0.22) + Inches(body_size * 1.22 / 72.0 + 0.03) * len(wrapped)
    h = max(h, need)
    box(slide, left, t, w, h, fill=CARDBG, line=RULE, round_=True)
    box(slide, left, t + Inches(0.18), Pt(5), h - Inches(0.36), fill=accent)
    txt(slide, left + Inches(0.28), t + Inches(0.2), w - Inches(0.5), Inches(0.35),
        [[run_(title, title_size, INK, True)]])
    txt(slide, left + Inches(0.28), t + Inches(0.68), w - Inches(0.5), h - Inches(0.85),
        [[run_(line, body_size, GRAY, False)] for line in wrapped], space_after=0,
        line_spacing=1.22)
    return t + h


def table(slide, left, t, widths, rows, head_fill=ACCENT2, row_h=None,
          size=12.5, mono_cols=()):
    """A plain table. rows[0] is drawn as the header. widths is a list of Inches."""
    # Evaluate the default per call: an Inches() default is evaluated once at
    # import time and then shared.
    row_h = DEFAULT_ROW_HEIGHT if row_h is None else row_h
    x = left
    total = sum(widths, Inches(0))
    box(slide, left, t, total, row_h, fill=head_fill)
    for w, cell in zip(widths, rows[0], strict=False):
        txt(slide, x + Inches(0.14), t, w - Inches(0.2), row_h,
            [[run_(cell, size, WHITE, True)]], anchor=MSO_ANCHOR.MIDDLE)
        x += w
    y = t + row_h
    for i, row in enumerate(rows[1:]):
        fill = WHITE if i % 2 == 0 else RGBColor(0xF4, 0xF1, 0xEC)
        box(slide, left, y, total, row_h, fill=fill, line=RULE, line_w=0.5)
        x = left
        for j, (w, cell) in enumerate(zip(widths, row, strict=False)):
            font = FONTM if j in mono_cols else FONT
            fits(cell, size, w.inches - 0.2, mono=(j in mono_cols), where="table cell")
            txt(slide, x + Inches(0.14), y, w - Inches(0.2), row_h,
                [[run_(cell, size, INK, False, font)]], anchor=MSO_ANCHOR.MIDDLE)
            x += w
        y += row_h
    return y


def note(slide, left, t, w, text, kind="warn", size=12.5):
    """A callout bar. The body wraps at the measured width and sets the height."""
    fill, mark, color = (WARNBG, "!", BAD) if kind == "warn" else (
        RGBColor(0xEE, 0xF4, 0xEE), "✓", GOOD)
    lines = wrap(text, size, w.inches - 0.95)
    h = max(Inches(0.54), Inches(0.3) + Inches(size * 1.25 / 72.0 + 0.03) * len(lines))
    box(slide, left, t, w, h, fill=fill, round_=True)
    box(slide, left, t + Inches(0.12), Pt(5), h - Inches(0.24), fill=color)
    txt(slide, left + Inches(0.26), t, Inches(0.4), h, [[run_(mark, 15, color, True)]],
        anchor=MSO_ANCHOR.MIDDLE)
    txt(slide, left + Inches(0.72), t, w - Inches(0.95), h,
        [[run_(line, size, INK, False)] for line in lines], anchor=MSO_ANCHOR.MIDDLE,
        space_after=0, line_spacing=1.25)
    return t + h


# ============================================================
# 1. Title
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s, ACCENT2)
box(s, 0, Inches(2.35), SW, Inches(2.6), fill=RGBColor(0x26, 0x3E, 0x52))
box(s, Inches(0.9), Inches(2.65), Pt(10), Inches(2.0), fill=ACCENT)
txt(s, Inches(1.25), Inches(2.75), Inches(11), Inches(1.0),
    [[run_("curvefit", 54, WHITE, True, FONTM)]], anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.27), Inches(3.75), Inches(11), Inches(0.8),
    [[run_("User Manual", 30, RGBColor(0xF0, 0xD9, 0xC9), True)]],
    anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.27), Inches(5.25), Inches(11), Inches(0.9),
    [[run_("Fit measurement data in one batch, reproducibly, from a single configuration file",
        16, RGBColor(0xC9, 0xD6, 0xE0), False)],
     [run_("The same configuration and the same input give the same result, "
           "for anyone, at any time",
        16, RGBColor(0xC9, 0xD6, 0xE0), False)]], space_after=8)
txt(s, Inches(1.27), Inches(6.6), Inches(11), Inches(0.4),
    [[run_("version 0.1.0 / Python 3.11 or later", 12, RGBColor(0x9F, 0xB3, 0xC2), False)]])

# ============================================================
# 2. Contents
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Contents", 0)
items = [
    ("1", "What this tool does", "The problem it solves, and the overall flow"),
    ("2", "First steps", "Install / a minimal configuration / run"),
    ("3", "Writing the configuration", "Input, methods, preprocessing, output"),
    ("4", "Choosing a method", "Built-in models / expressions / regression"),
    ("5", "Reading the outputs", "Summary table, plots, curve CSV, run record"),
    ("6", "Reading instrument CSV", "Delimiters / positions / multiple channels"),
    ("7", "Using the command", "Run-time overrides and exit codes"),
    ("8", "When something fails", "What the preflight check tells you"),
    ("9", "Using it from Python", "The library entry points"),
    ("10", "Things to watch out for", "Safety, precision, breaking changes"),
]
for i, (n, title, sub) in enumerate(items):
    col, row = i // 5, i % 5
    x = Inches(0.72) + Inches(6.3) * col
    y = Inches(1.55) + Inches(1.09) * row
    box(s, x, y, Inches(5.85), Inches(0.92), fill=CARDBG, line=RULE, round_=True)
    box(s, x, y, Inches(0.72), Inches(0.92), fill=ACCENT2)
    txt(s, x, y, Inches(0.72), Inches(0.92), [[run_(n, 22, WHITE, True)]],
        align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    txt(s, x + Inches(0.95), y + Inches(0.14), Inches(4.7), Inches(0.35),
        [[run_(title, 15, INK, True)]])
    txt(s, x + Inches(0.95), y + Inches(0.52), Inches(4.7), Inches(0.3),
        [[run_(sub, 11.5, GRAY, False)]])
footer(s)

# ============================================================
# 3. What this tool does
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "What this tool does", 1)
txt(s, Inches(0.72), Inches(1.45), Inches(12), Inches(0.4),
    [[run_("Processing one file at a time in a spreadsheet, with a throwaway script per job, "
        "makes the procedure personal to whoever wrote it and impossible to reproduce later.",
        14.5, INK, False)]])

card(s, Inches(0.72), Inches(2.1), Inches(3.9), Inches(2.0), "What it solves",
     ["- Process many files in a single run",
      "- Compare several models in one table",
      "- Same configuration, same result, every time",
      "- Keep the run conditions on record"], accent=GOOD)
card(s, Inches(4.82), Inches(2.1), Inches(3.9), Inches(2.0), "Two kinds of fitting",
     ["(a) Non-linear least squares",
      "     estimates the parameters of a model",
      "(b) Regression and smoothing",
      "     assumes no model formula"], accent=ACCENT2)
card(s, Inches(8.92), Inches(2.1), Inches(3.7), Inches(2.0), "Two ways to use it",
     ["- Command line (CLI)",
      "     hand it a configuration file",
      "- Python library",
      "     import it into your own code"], accent=ACCENT)

txt(s, Inches(0.72), Inches(4.45), Inches(12), Inches(0.35),
    [[run_("The overall flow", 15, INK, True)]])
flow = [
    ("Configuration\n(TOML)", ACCENT2),
    ("Preflight\ncheck", ACCENT),
    ("Read and\npreprocess", ACCENT2),
    ("Fit", ACCENT2),
    ("Output", GOOD),
]
fx = Inches(0.72)
for i, (label, color) in enumerate(flow):
    box(s, fx, Inches(4.9), Inches(2.02), Inches(1.0), fill=color, round_=True)
    txt(s, fx, Inches(4.9), Inches(2.02), Inches(1.0),
        [[run_(part, 13.5, WHITE, True)] for part in label.split("\n")],
        align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, space_after=2)
    if i < len(flow) - 1:
        txt(s, fx + Inches(2.05), Inches(4.9), Inches(0.45), Inches(1.0),
            [[run_("▶", 15, GRAY, True)]], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    fx += Inches(2.5)
note(s, Inches(0.72), Inches(6.15), Inches(11.9),
     "When the preflight check finds a violation, nothing is run at all. A mistake affects "
     "every job equally, so rather than writing part of the output and then stopping, the "
     "tool writes nothing and reports every violation at once.", kind="ok")
footer(s)

# ============================================================
# 4. First steps
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "First steps", 2)

txt(s, Inches(0.72), Inches(1.4), Inches(5.9), Inches(0.3),
    [[run_("1. Install", 15, INK, True)]])
code(s, Inches(0.72), Inches(1.78), Inches(5.9), [
    "python3 -m venv .venv",
    "source .venv/bin/activate",
    "pip install -e \".[dev]\"",
])

txt(s, Inches(0.72), Inches(3.05), Inches(5.9), Inches(0.3),
    [[run_("2. Write a configuration file (run.toml)", 15, INK, True)]])
code(s, Inches(0.72), Inches(3.43), Inches(5.9), [
    ("[input]", CODEKEY),
    'paths = ["data"]',
    "header = true",
    ("[input.columns]", CODEKEY),
    'x = "time"',
    'y = "signal"',
    ("[[methods]]", CODEKEY),
    'name = "line"',
    'builtin = "linear"',
    ("[output]", CODEKEY),
    'directory = "out"',
], size=11.5)

txt(s, Inches(7.0), Inches(1.4), Inches(5.6), Inches(0.3),
    [[run_("3. Run it", 15, INK, True)]])
code(s, Inches(7.0), Inches(1.78), Inches(5.6), [
    "curvefit run.toml",
])

txt(s, Inches(7.0), Inches(2.62), Inches(5.6), Inches(0.3),
    [[run_("4. Look at the output", 15, INK, True)]])
code(s, Inches(7.0), Inches(3.0), Inches(5.6), [
    "out/",
    ("  summary.csv", GOOD),
    "  execution.json",
    "  run.log",
    "  plots/",
    ("    sample__signal__line__0000.png", GOOD),
], size=12)

card(s, Inches(7.0), Inches(4.8), Inches(5.6), Inches(1.2), "These four steps are all there is",
     ["Write down which data, how to fit it, and where to put the results.",
      "As long as you hand over the same file, the result is the same."], body_size=12)
note(s, Inches(0.72), Inches(6.42), Inches(11.9),
     "Save the configuration file as UTF-8 without a BOM. Notepad on Windows adds one by "
     "default, making line 1 a syntax error.")
footer(s)

# ============================================================
# 5. Writing the configuration
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Writing the configuration — four sections", 3)

code(s, Inches(0.72), Inches(1.4), Inches(4.15), [
    ("[input]", CODEKEY),
    'paths = ["data/*.csv"]',
    'delimiter = ","',
    "header = true",
    "",
    ("[input.columns]", CODEKEY),
    'x = "time"',
    'y = "signal"',
    'weight = "sigma"',
    "",
    ("[[methods]]", CODEKEY),
    'name = "gauss"',
    'builtin = "gaussian"',
    "initial = { amplitude = 2.0 }",
    "fixed   = { center = 1.0 }",
    "bounds.amplitude =",
    "  { min = 0.0, max = 10.0 }",
], size=11.5, title="1. Which data / 2. How to fit it")

code(s, Inches(5.1), Inches(1.4), Inches(3.55), [
    'failure_policy = "skip"',
    "",
    ("[preprocess]", CODEKEY),
    "x_min = 0.0",
    "x_max = 10.0",
    "",
    ("[preprocess.outlier]", CODEKEY),
    "sigma = 3.0",
    "max_iterations = 3",
    "",
    ("[output]", CODEKEY),
    'directory = "out"',
    "write_summary = true",
    "write_plot    = true",
    "write_curve   = false",
], size=11.5, title="3. What to drop / 4. Where to write")

txt(s, Inches(8.9), Inches(1.4), Inches(3.72), Inches(0.3),
    [[run_("Only four sections", 15, INK, True)]])
sections = [
    ("[input]", "which data to read", ACCENT2),
    ("[[methods]]", "how to fit it (repeatable)", ACCENT),
    ("[preprocess]", "what to drop before fitting", ACCENT2),
    ("[output]", "where and what to write", GOOD),
]
sy = Inches(1.8)
for key, desc, col in sections:
    box(s, Inches(8.9), sy, Inches(3.72), Inches(0.68), fill=CARDBG, line=RULE, round_=True)
    box(s, Inches(8.9), sy + Inches(0.13), Pt(5), Inches(0.42), fill=col)
    txt(s, Inches(9.15), sy + Inches(0.09), Inches(2.2), Inches(0.28),
        [[run_(key, 12.5, col, True, FONTM)]])
    txt(s, Inches(9.15), sy + Inches(0.38), Inches(3.3), Inches(0.26),
        [[run_(desc, 11, GRAY, False)]])
    sy += Inches(0.76)

txt(s, Inches(8.9), Inches(4.95), Inches(3.72), Inches(0.3),
    [[run_("Values that trip people up", 15, INK, True)]])
table(s, Inches(8.9), Inches(5.33), [Inches(1.3), Inches(2.42)],
      [["Key", "Accepted values"],
       ["header", "omitted / true / false"],
       ["x, y", "name, or position (integer)"],
       ["bounds", "{ min = .., max = .. }"]],
      mono_cols=(0,), size=11, row_h=Inches(0.38))

note(s, Inches(0.72), Inches(6.32), Inches(7.93),
     "List several [[methods]] to compare them in a single run.", kind="ok", size=12)
footer(s)

# ============================================================
# 6. Choosing a method
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Choosing a method — three routes", 4)
txt(s, Inches(0.72), Inches(1.4), Inches(12), Inches(0.35),
    [[run_("Each [[methods]] entry carries ", 14, INK, False),
      run_("builtin", 14, ACCENT, True, FONTM),
      run_(" / ", 14, INK, False), run_("expression", 14, ACCENT, True, FONTM),
      run_(" / ", 14, INK, False), run_("smoother", 14, ACCENT, True, FONTM),
      run_(" - ", 14, INK, False), run_("exactly one of them", 14, INK, True),
      run_(". The key you write decides the kind of method.", 14, INK, False)]])

y = code(s, Inches(0.72), Inches(1.95), Inches(3.85), [
    ("[[methods]]", CODEKEY),
    'name = "gauss"',
    'builtin = "gaussian"',
], size=12, title="1. Built-in model")
txt(s, Inches(0.72), y + Inches(0.15), Inches(3.85), Inches(1.6),
    [[run_("linear", 12.5, INK, True, FONTM), run_("  straight line", 12.5, GRAY)],
     [run_("polynomial", 12.5, INK, True, FONTM),
      run_("  degree sets the order", 12.5, GRAY)],
     [run_("gaussian", 12.5, INK, True, FONTM), run_("  Gaussian", 12.5, GRAY)],
     [run_("exponential", 12.5, INK, True, FONTM), run_("  exponential", 12.5, GRAY)]],
    space_after=5)

y = code(s, Inches(4.85), Inches(1.95), Inches(3.85), [
    ("[[methods]]", CODEKEY),
    'name = "mine"',
    'expression = "a * x + b"',
], size=12, title="2. Write the formula yourself")
txt(s, Inches(4.85), y + Inches(0.15), Inches(3.85), Inches(1.6),
    [[run_("x is the independent variable; every other", 12.5, GRAY)],
     [run_("symbol becomes a parameter. Give starting", 12.5, GRAY)],
     [run_("values with initial - unlike a built-in model,", 12.5, GRAY)],
     [run_("nothing is estimated from the data.", 12.5, GRAY)]], space_after=5)

y = code(s, Inches(8.98), Inches(1.95), Inches(3.62), [
    ("[[methods]]", CODEKEY),
    'name = "spl"',
    'smoother = "spline"',
    "options = { lam = 0.01 }",
], size=12, title="3. Regression and smoothing")
txt(s, Inches(8.98), y + Inches(0.15), Inches(3.62), Inches(1.6),
    [[run_("linear / polynomial", 12.5, INK, True, FONTM)],
     [run_("spline", 12.5, INK, True, FONTM), run_("  lam is required", 12.5, GRAY)],
     [run_("moving_average", 12.5, INK, True, FONTM)],
     [run_("spline and moving_average return no", 12, GRAY)],
     [run_("parameters.", 12, GRAY)]], space_after=5)

note(s, Inches(0.72), Inches(5.16), Inches(11.9),
     "Reserved names cannot be expression parameters; only pi may be used as a value. "
     "Calls such as exp(x) still work.", size=12)
note(s, Inches(0.72), Inches(5.82), Inches(11.9),
     "Uncertainty columns (weights) act on linear, polynomial and spline. "
     "Only moving_average ignores them.", kind="ok", size=12)
note(s, Inches(0.72), Inches(6.42), Inches(11.9),
     "There is no separate kind = \"...\" declaration, so a configuration whose declaration "
     "contradicts its content cannot be written.", kind="ok", size=12)
footer(s)

# ============================================================
# 7. Reading the outputs
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Reading the outputs", 5)
table(s, Inches(0.72), Inches(1.4),
      [Inches(3.0), Inches(5.6), Inches(3.3)],
      [["Path", "Contents", "Controlled by"],
       ["summary.csv", "every result, one parameter per row", "write_summary"],
       ["plots/*.png", "data points with the fitted curve", "write_plot (default true)"],
       ["curves/*.csv", "the fitted curve and the residuals", "write_curve (default false)"],
       ["execution.json", "run conditions, timestamp, overrides", "always written"],
       ["run.log", "outcome and failure reason per target", "always written"]],
      mono_cols=(0, 2), size=12.5)

txt(s, Inches(0.72), Inches(4.55), Inches(12), Inches(0.35),
    [[run_("How output files are named", 15, INK, True)]])
box(s, Inches(0.72), Inches(4.95), Inches(6.4), Inches(0.62), fill=CODEBG, round_=True)
txt(s, Inches(0.95), Inches(4.95), Inches(6.0), Inches(0.62),
    [[run_("{source}__{column}__{method}__{job}", 15, CODEFG, True, FONTM)]],
    anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(7.35), Inches(4.9), Inches(5.3), Inches(0.8),
    [[run_("Both the input file and the column appear.", 12.5, GRAY)],
     [run_("Two columns of one file never overwrite", 12.5, GRAY)],
     [run_("each other.", 12.5, GRAY)]], space_after=3)

txt(s, Inches(0.72), Inches(5.8), Inches(12), Inches(0.35),
    [[run_("The first four summary columns say which result a row is", 15, INK, True)]])
ident = [
    ("source_id", "absolute path of the input file"),
    ("column_label", "as written in the configuration"),
    ("column_name", "resolved header name"),
    ("method_name", "the name in [[methods]]"),
]
ix = Inches(0.72)
for key, desc in ident:
    box(s, ix, Inches(6.2), Inches(2.92), Inches(0.72), fill=CARDBG, line=RULE, round_=True)
    txt(s, ix + Inches(0.16), Inches(6.26), Inches(2.7), Inches(0.26),
        [[run_(key, 12.5, ACCENT, True, FONTM)]])
    txt(s, ix + Inches(0.16), Inches(6.54), Inches(2.66), Inches(0.34),
        [[run_(desc, 10.5, GRAY, False)]])
    ix += Inches(3.0)
footer(s)

# ============================================================
# 8. Reading instrument CSV (delimiters)
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Reading instrument CSV — delimiters", 6)
note(s, Inches(0.72), Inches(1.35), Inches(11.9),
     "The file extension guarantees nothing. Some instruments emit column-aligned, "
     "space-separated output under a .csv name.")

txt(s, Inches(0.72), Inches(2.2), Inches(5.9), Inches(0.3),
    [[run_("Separated by runs of spaces", 15, INK, True)]])
code(s, Inches(0.72), Inches(2.58), Inches(5.9), [
    ("[input]", CODEKEY),
    'paths = ["data"]',
    ("delimiter = '\\s+'      # runs of whitespace", GOOD),
])
txt(s, Inches(0.72), Inches(3.85), Inches(5.9), Inches(0.6),
    [[run_("Two or more characters are read as a regular expression. "
        "From the command line: curvefit run.toml --delimiter '\\s+'.", 12.5, GRAY)]])

txt(s, Inches(0.72), Inches(4.55), Inches(5.9), Inches(0.3),
    [[run_("A regular expression still preserves every last bit", 13, GOOD, True)]])

txt(s, Inches(7.0), Inches(2.2), Inches(5.6), Inches(0.3),
    [[run_("Three ways to write it; one of them is wrong", 15, INK, True)]])
table(s, Inches(7.0), Inches(2.58), [Inches(2.5), Inches(3.1)],
      [["Written as", "Result"],
       ["delimiter = '\\s+'", "works (recommended)"],
       ["delimiter = \"\\\\s+\"", "works"],
       ["delimiter = \"\\s+\"", "TOML syntax error"]],
      mono_cols=(0,), size=12)

note(s, Inches(7.0), Inches(4.52), Inches(5.6),
     "delimiter = \" \" does not work. A run of spaces counts as empty columns, so the "
     "column count differs per row and the read fails.")

card(s, Inches(0.72), Inches(5.58), Inches(11.9), Inches(1.2),
     "The first thing you reach for is not the answer",
     ["Writing delimiter = \" \" for space-separated data is the natural guess, and it cannot "
      "be read. The answer is '\\s+'. A literal string (single quotes) needs no escaping and "
      "is the hardest form to get wrong."])
footer(s)

# ============================================================
# 9. Specifying columns (positions, multiple channels)
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Specifying columns — positions and channels", 6)

txt(s, Inches(0.72), Inches(1.35), Inches(5.9), Inches(0.3),
    [[run_("Column names differ per file? Use positions", 15, INK, True)]])
code(s, Inches(0.72), Inches(1.73), Inches(5.9), [
    ("[input.columns]", CODEKEY),
    "x = 0        # zero-based position",
    "y = 1        # an integer is always a position",
])
txt(s, Inches(0.72), Inches(3.0), Inches(5.9), Inches(0.75),
    [[run_("Instruments often put the channel name in the header, so it changes from file to "
        "file. Positions let one configuration cover them all, and a header decorated with "
        "# or similar makes no difference.", 12.5, GRAY)]])

txt(s, Inches(7.0), Inches(1.35), Inches(5.6), Inches(0.3),
    [[run_("Several channels in one file? Use a list", 15, INK, True)]])
code(s, Inches(7.0), Inches(1.73), Inches(5.6), [
    ("[input.columns]", CODEKEY),
    'x = "time"',
    'y = ["signal", "ref"]',
    'weight = ["sigma_signal", "sigma_ref"]',
], size=12)
txt(s, Inches(7.0), Inches(3.18), Inches(5.6), Inches(0.75),
    [[run_("One run covers every channel. Uncertainty columns take a list of the same length: "
        "the i-th weight belongs to the i-th y.", 12.5, GRAY)]])

txt(s, Inches(0.72), Inches(3.95), Inches(12), Inches(0.3),
    [[run_("The outputs are kept apart per column", 15, INK, True)]])
code(s, Inches(0.72), Inches(4.33), Inches(11.9), [
    "out/summary.csv",
    ("out/plots/multi__signal__lin__0000.png", GOOD),
    ("out/plots/multi__ref__lin__0001.png", GOOD),
], size=13)

note(s, Inches(0.72), Inches(5.75), Inches(5.9),
     "Lists of unequal length are rejected before anything runs.")
note(s, Inches(7.0), Inches(5.75), Inches(5.6),
     "The job count is inputs x columns x methods, not the number of files.", kind="ok")
footer(s)

# ============================================================
# 10. Using the command
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Using the command", 7)
code(s, Inches(0.72), Inches(1.4), Inches(11.9), [
    "curvefit run.toml                    # run from the configuration alone",
    "curvefit run.toml -i data/ -o out/   # swap the input and the output",
    "curvefit --help                      # every option, and the exit codes",
])

txt(s, Inches(0.72), Inches(2.75), Inches(6.4), Inches(0.3),
    [[run_("The options you will actually use", 15, INK, True)]])
table(s, Inches(0.72), Inches(3.13), [Inches(2.5), Inches(3.9)],
      [["Option", "What it does"],
       ["-i / --input", "where the input is; repeatable"],
       ["-o / --output", "the output directory"],
       ["--delimiter", "delimiter (2+ chars is a regex)"],
       ["--y-column", "replaces the column list with one"],
       ["--failure-policy", "skip / fail_fast"],
       ["--quiet", "hide progress and totals"]],
      mono_cols=(0,), size=12, row_h=Inches(0.38))

txt(s, Inches(7.35), Inches(2.75), Inches(5.3), Inches(0.3),
    [[run_("Three distinct exit codes", 15, INK, True)]])
table(s, Inches(7.35), Inches(3.13), [Inches(0.9), Inches(4.4)],
      [["Code", "Meaning"],
       ["0", "every job succeeded"],
       ["1", "at least one failed, or it was stopped"],
       ["2", "preflight stopped it; nothing ran"]],
      mono_cols=(0,), size=12, row_h=Inches(0.42))

card(s, Inches(7.35), Inches(5.0), Inches(5.3), Inches(1.5), "stdout stays empty while running",
     ["Progress, totals and violations all go to stderr.",
      "curvefit run.toml > result.txt keeps working."])

note(s, Inches(0.72), Inches(5.85), Inches(6.4),
     "--y-column replaces the whole list with one entry, and so does --weight-column. "
     "Replace only one of them and the counts no longer match, so the run is rejected.")
footer(s)

# ============================================================
# 11. When something fails
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "When something fails", 8)
txt(s, Inches(0.72), Inches(1.4), Inches(12), Inches(0.35),
    [[run_("The preflight check reports violations ", 14.5, INK, False),
      run_("all at once", 14.5, ACCENT, True),
      run_(", not one at a time, so you are never forced into a fix-and-rerun loop.",
        14.5, INK, False)]])
code(s, Inches(0.72), Inches(1.9), Inches(11.9), [
    ("model_unresolved        method[line].builtin", BAD),
    ("smoother_option_invalid method[ma].options", BAD),
    ("config_invalid          preprocess.x_min", BAD),
    ("config_invalid          preprocess.outlier.sigma", BAD),
], size=13, title="Example output (exit code 2; not a single job has run)")

txt(s, Inches(0.72), Inches(3.65), Inches(12), Inches(0.3),
    [[run_("Common stumbling blocks", 15, INK, True)]])
table(s, Inches(0.72), Inches(4.03), [Inches(4.3), Inches(4.0), Inches(3.6)],
      [["Symptom", "Cause", "Fix"],
       ["syntax error on line 1", "the file has a BOM", "save as UTF-8, no BOM"],
       ["column count differs per row", "delimiter = \" \" was used", "delimiter = '\\s+'"],
       ["rejected: unknown escape", "delimiter = \"\\s+\" was used", "'\\s+' or \"\\\\s+\""],
       ["stopped: counts do not match", "y and weight lists differ", "make them equal"],
       ["downstream steps broke", "names and columns changed", "see chapter 10"]],
      size=12, row_h=Inches(0.4))
footer(s)

# ============================================================
# 12. Using it from Python
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Using it from Python", 9)
txt(s, Inches(0.72), Inches(1.4), Inches(12), Inches(0.35),
    [[run_("The CLI is a thin wrapper over the library and ", 14.5, INK, False),
      run_("takes the same execution path", 14.5, INK, True),
      run_(", so both give identical results.", 14.5, INK, False)]])

code(s, Inches(0.72), Inches(1.95), Inches(6.1), [
    "from pathlib import Path",
    "from curvefit import run_from_config, BatchReport",
    "",
    "result = run_from_config(Path(\"run.toml\"))",
    "if isinstance(result, BatchReport):",
    "    print(result.n_success, result.n_failure)",
    "else:",
    "    for violation in result.violations:",
    "        print(violation.kind, violation.location)",
], size=12, title="Run a batch from a configuration file")

code(s, Inches(7.2), Inches(1.95), Inches(5.4), [
    "from curvefit import fit_series",
    "",
    "outcome = fit_series(series, method)",
], size=12, title="Fit a single in-memory series")

card(s, Inches(7.2), Inches(3.35), Inches(5.4), Inches(1.5),
     "fit_series leaves no files behind",
     ["It takes the same execution path as a batch run, yet writes nothing at all.",
      "The curve data comes back with the result."])

note(s, Inches(0.72), Inches(4.88), Inches(6.1),
     "A violation returns a PreflightResult, not an exception.", kind="ok")

txt(s, Inches(0.72), Inches(5.62), Inches(11.9), Inches(0.3),
    [[run_("Passing your own table? Read it with the same setting", 15, INK, True)]])
code(s, Inches(0.72), Inches(6.0), Inches(11.9), [
    ('frame = pd.read_csv(path, float_precision="round_trip")', GOOD),
], size=13)
footer(s)

# ============================================================
# 13. Things to watch out for
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Things to watch out for", 10)

box(s, Inches(0.72), Inches(1.4), Inches(11.9), Inches(1.35), fill=WARNBG, round_=True)
box(s, Inches(0.72), Inches(1.58), Pt(6), Inches(0.99), fill=BAD)
txt(s, Inches(1.05), Inches(1.55), Inches(11.3), Inches(0.35),
    [[run_("Safety — never run a configuration file you received from someone else",
        16, BAD, True)]])
txt(s, Inches(1.05), Inches(1.98), Inches(11.3), Inches(0.6),
    [[run_("The formula string under expression is evaluated. That carries the same risk as "
        "running arbitrary Python code. Read the file before you run it.", 13, INK, False)]])

card(s, Inches(0.72), Inches(2.95), Inches(5.85), Inches(1.6), "Reading precision",
     ["CSV is read with float_precision=\"round_trip\", preserving every last bit.",
      "The default parser changes the lowest bit of about 46% of values, measured.",
      "The library cannot recover a value that arrived degraded."],
     accent=ACCENT2, body_size=12)

card(s, Inches(6.77), Inches(2.95), Inches(5.85), Inches(1.6), "How reproducibility is held",
     ["Same configuration, same input: a rerun matches byte for byte.",
      "An option given both in the file and on the command line takes the command line.",
      "Overrides are kept in execution.json with the before and after values."],
     accent=GOOD, body_size=12)

txt(s, Inches(0.72), Inches(5.1), Inches(12), Inches(0.3),
    [[run_("Breaking changes from the previous version", 15, INK, True)]])
table(s, Inches(0.72), Inches(5.46), [Inches(6.3), Inches(5.6)],
      [["Change", "Impact"],
       ["output file names now contain the column",
        "names change even with a single y column"],
       ["summary.csv gained column_label and column_name",
        "readers using column positions break; use names"]],
      size=12, row_h=Inches(0.48))
footer(s)

# ============================================================
# 14. Quick reference
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Quick reference", 11)
txt(s, Inches(0.72), Inches(1.35), Inches(6.0), Inches(0.3),
    [[run_("What you want, and what to write", 15, INK, True)]])
table(s, Inches(0.72), Inches(1.73), [Inches(2.9), Inches(3.4)],
      [["What you want", "What to write"],
       ["a whole folder", "paths = [\"data\"]"],
       ["only some files", "paths = [\"data/run_*.csv\"]"],
       ["compare models", "several [[methods]]"],
       ["several channels", "y = [\"ch1\", \"ch2\"]"],
       ["names change per file", "x = 0 / y = 1"],
       ["space-separated output", "delimiter = '\\s+'"],
       ["the curve data too", "write_curve = true"],
       ["stop at the first failure", "failure_policy = \"fail_fast\""]],
      mono_cols=(1,), size=12, row_h=Inches(0.4))

txt(s, Inches(7.2), Inches(1.35), Inches(5.4), Inches(0.3),
    [[run_("Worth remembering", 15, INK, True)]])
tips = [
    ("The configuration is the source of truth",
     "Same configuration and input, same result. It travels."),
    ("Violations arrive all at once",
     "On exit code 2, nothing has been written"),
    ("Output names carry the column",
     "{source}__{column}__{method}__{job}; no overwrites"),
    ("The job count is not the file count",
     "inputs x columns x methods"),
    ("stdout stays empty while running",
     "Redirection keeps working"),
]
ty = Inches(1.73)
for title, body in tips:
    box(s, Inches(7.2), ty, Inches(5.4), Inches(0.92), fill=CARDBG, line=RULE, round_=True)
    box(s, Inches(7.2), ty + Inches(0.16), Pt(5), Inches(0.6), fill=ACCENT)
    txt(s, Inches(7.48), ty + Inches(0.14), Inches(5.0), Inches(0.3),
        [[run_(title, 13, INK, True)]])
    txt(s, Inches(7.48), ty + Inches(0.5), Inches(5.0), Inches(0.32),
        [[run_(body, 11, GRAY, False)]])
    ty += Inches(1.0)

card(s, Inches(0.72), Inches(5.42), Inches(6.0), Inches(1.1), "If you get stuck",
     ["curvefit --help lists every option and the exit codes.",
      "The reasoning behind the spec is kept under .kiro/specs/."], body_size=12)
footer(s)

# ============================================================
# 15. Closing
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s, ACCENT2)
box(s, Inches(0.9), Inches(2.9), Pt(10), Inches(1.4), fill=ACCENT)
txt(s, Inches(1.25), Inches(2.9), Inches(11), Inches(0.7),
    [[run_("The same configuration and the same input", 26, WHITE, True)]],
    anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.25), Inches(3.6), Inches(11), Inches(0.7),
    [[run_("give the same result, for anyone, at any time.", 26, WHITE, True)]],
    anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.27), Inches(4.75), Inches(11), Inches(0.4),
    [[run_("curvefit User Manual", 14, RGBColor(0xC9, 0xD6, 0xE0), False)]])

out = str(pathlib.Path(__file__).with_name("curvefit_User_Manual_EN.pptx"))
prs.save(out)
print(f"saved: {out}  ({len(prs.slides._sldIdLst)} slides)")
