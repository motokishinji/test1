"""数式文字列によるモデル指定の解釈（要件 3.2、3.4）。

本モジュールが所有するのは「式をモデル実体に変換できるか」の判定と、
「式中のどの記号が推定対象パラメータか」の確定の 2 点のみである。
初期値・上下限・固定の束縛は :mod:`curvefit.models.resolver` が担う。

式の構文解析と評価そのものは lmfit の ``ExpressionModel``（内部で asteval を使う）が
所有する。本モジュールは式を渡し、解釈失敗を検出する責任のみを持つ。asteval を直接
import はしない。

独立変数は ``x`` に固定する。式中の記号のうち独立変数と、asteval が既に知っている
名前（``exp`` や ``pi`` など）を除いたものが推定対象パラメータである。抽出順は式中の
出現順であり、呼び出しごとに変化しない。要件 8.2 の再現性は、ここで確定した順序が
そのまま出力の並びに伝わることに依存する。

除外は静かである。そのため asteval が既に知っている名前を **値として** 参照した式は、
:data:`VALUE_CONSTANTS` に挙げた円周率を除き、解釈できない式として扱う（要件 3.6〜3.8）。
関数として呼び出す場合は従来どおり受け入れる（要件 3.8）。予約名の一覧は持たない。
「値として参照されたのにモデルのパラメータにならなかった」という間接的な条件で判定する
ため、評価器が持つ名前の増減に追随する必要がなく、asteval を直接 import せずに済む。

解釈できない式は例外ではなく :class:`~curvefit.errors.ConfigViolation` として返す。
実行前ゲートが違反を最初の 1 件で打ち切らずに全件収集できるようにするためである。

.. warning::

   asteval は ``eval()`` よりも制限されているものの、作者自身が完全なサンドボックスでは
   ないと明記している。数式文字列は実行者自身が記述するもの（信頼境界の内側）という
   前提であり、第三者から受け取った設定ファイルをそのまま実行してはならない。
"""

from __future__ import annotations

import ast
from dataclasses import dataclass

from lmfit.models import ExpressionModel

from curvefit.errors import ConfigViolation, ViolationKind

INDEPENDENT_VARIABLE = "x"
"""独立変数を表す記号。この名前はパラメータとして扱わない。

設計の Risks が指摘するとおり、除外規則を暗黙に持つと「x が推定対象になっていた」
という誤りが静かに混入する。名前をここで明示的に固定する。
"""

DEFAULT_LOCATION = "method.expression"
"""解釈失敗を報告する既定の箇所。呼び出し側が設定ファイル内の位置を渡して上書きする。"""

VALUE_CONSTANTS: frozenset[str] = frozenset({"pi"})
"""数式中で値として参照してよい予約名（要件 3.6）。

集合であり順序を持たない。ドキュメント同期検査から突き合わせる際は、順序に依存しない
形（整列または集合同士）で比較する。要素が 2 つ以上になると反復順がハッシュ種に依存し、
列として比較すると実行ごとに結果が変わる。
"""


@dataclass(frozen=True)
class ExpressionModelSpec:
    """解釈できた数式モデル 1 件の内容。"""

    expression: str
    """前後の空白を取り除いた式。実行条件の記録にはこの正規化後の文字列を用いる。"""

    parameter_names: tuple[str, ...]
    """推定対象パラメータの名前。式中の出現順で、重複はない（要件 3.2、3.5）。"""

    independent_variable: str = INDEPENDENT_VARIABLE
    """独立変数の名前。パラメータには含まれない。"""

    def create(self) -> object:
        """モデル実体を新たに 1 つ組み立てて返す。

        当てはめはジョブごとに解決し直されるため、呼び出しごとに独立した実体を返す。
        実体を使い回すと、前のジョブのパラメータ状態が次のジョブに漏れる。

        :return: 当てはめエンジンが利用するモデル実体（lmfit のモデル）
        :raises ValueError: 検証を経ていない式で本クラスを直接生成した場合。
            :func:`build_expression_model` が返した仕様では発生しない
        :raises SyntaxError: 同上（式が構文として成立しない場合）
        """
        return ExpressionModel(self.expression, independent_vars=[self.independent_variable])


def _unresolved(expression: str, reason: str, location: str) -> ConfigViolation:
    """解釈失敗を、原因となった式と理由を含む違反として組み立てる（要件 3.4）。"""
    return ConfigViolation(
        kind=ViolationKind.MODEL_UNRESOLVED,
        location=location,
        message=f"数式 {expression!r} をモデルとして解釈できない。{reason}",
    )


def _referenced_names(tree: ast.Expression) -> list[str]:
    """式が参照している記号名を、出現順・重複なしで返す。"""
    seen: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and node.id not in seen:
            seen.append(node.id)
    return seen


def _called_names(tree: ast.Expression) -> list[str]:
    """関数として呼び出されている記号名を、出現順・重複なしで返す。"""
    seen: list[str] = []
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id not in seen
        ):
            seen.append(node.func.id)
    return seen


def _value_referenced_names(tree: ast.Expression) -> list[str]:
    """値として参照されている記号名を、出現順・重複なしで返す（要件 3.8）。

    「参照された名前 − 呼び出された名前」の差集合では ``exp + a*exp(x)`` の ``exp`` が
    消えて検出漏れになる。同じ名前を値と関数の双方で使えるため、名前ごとではなく
    ``ast.Name`` の **出現位置ごと** に、それが :class:`ast.Call` の被呼び出し位置に
    あるかを見て分類する。

    真偽値リテラルは対象にならない。``True`` / ``False`` は :class:`ast.Constant` として
    解析され :class:`ast.Name` ではないため、``a*x + True`` は ``a*x + 1`` と同じ扱いになる。
    """
    called_positions = {
        id(node.func)
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }
    seen: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and id(node) not in called_positions and node.id not in seen:
            seen.append(node.id)
    return seen


def _reserved_value_reason(name: str, also_called: bool) -> str:
    """値として参照された予約名 1 件について報告する理由を組み立てる（要件 3.7）。

    記号名と「予約名である」旨は常に含める。とるべき対処は 2 通りに分かれる。
    式中で関数としても呼ばれているなら呼び出しの括弧の抜けであり、値としてしか
    現れないならパラメータの意図で予約名と衝突している。
    """
    advice = (
        "同じ式で関数としても呼び出しているため、呼び出しの括弧が抜けていないか確認する。"
        if also_called
        else "推定対象パラメータとする場合は別の名前を用いる。"
    )
    return (
        f"記号 {name!r} を値として参照しているが、これはフィッティングツールが"
        f"あらかじめ意味を与えている予約名である。{advice}"
    )


def build_expression_model(
    expression: str, location: str = DEFAULT_LOCATION
) -> ExpressionModelSpec | ConfigViolation:
    """数式文字列をモデルとして解釈し、推定対象パラメータを確定する。

    次のいずれかに当てはまる式は解釈できないものとして扱う。いずれも当てはめの実行時に
    不可解な失敗として現れるより、実行前に指定内容を示して報告するほうが利用者の
    修正コストが低い（設計の Error Strategy）。

    - 空の式、または構文として成立しない式。モデル式は 1 つの式として書く
    - 独立変数 ``x`` を含まない式。データの関数になっていない
    - 未定義の関数を呼び出している式。未知記号をパラメータとして扱う規則の下では、
      綴り誤りの関数名が黙ってパラメータになり、当てはめ時に初めて破綻する
    - 円周率以外の予約名を値として参照している式。パラメータの意図で書かれた記号が
      黙って定数に解決され、利用者が意図したモデルとは異なるモデルが当てはめられる
      （要件 3.6〜3.8）
    - 推定対象パラメータを 1 つも持たない式。推定するものがなく、要件 2.4 の
      「点数がパラメータ数を下回るか」の判定も意味を失う

    :param expression: 設定で指定された数式文字列
    :param location: 違反を報告する際に示す箇所（設定ファイル内の位置または引数名）
    :return: 解釈できた場合は :class:`ExpressionModelSpec`、
        できなかった場合は :class:`~curvefit.errors.ConfigViolation`（要件 3.4）
    """
    text = expression.strip()
    if not text:
        return _unresolved(text, "式が空である。", location)

    try:
        # mode="eval" は式 1 つだけを受け入れる。文（代入・import・複数文）は
        # モデル式ではないため、ここで構文として弾かれる。
        tree = ast.parse(text, mode="eval")
    except SyntaxError as error:
        return _unresolved(
            text,
            f"構文として成立しない（{error.msg}）。モデル式は 1 つの式として記述する。",
            location,
        )

    if INDEPENDENT_VARIABLE not in _referenced_names(tree):
        return _unresolved(
            text,
            f"独立変数 {INDEPENDENT_VARIABLE!r} を含まないため、データの関数にならない。",
            location,
        )

    try:
        model = ExpressionModel(text, independent_vars=[INDEPENDENT_VARIABLE])
    except Exception as error:  # noqa: BLE001 - 基盤ライブラリの例外を外に漏らさない
        return _unresolved(
            text,
            f"式の解釈に失敗した（{type(error).__name__}: {error}）。",
            location,
        )

    parameter_names = tuple(model.param_names)

    # 呼び出されている名前は 2 つの判定が共に使う。走査は 1 度で足りる。
    called_names = _called_names(tree)
    called = set(called_names)
    unknown_calls = [
        name
        for name in called_names
        if name in parameter_names or name == INDEPENDENT_VARIABLE
    ]
    if unknown_calls:
        return _unresolved(
            text,
            f"未定義の関数 {', '.join(repr(name) for name in unknown_calls)} を"
            "呼び出している。関数名の綴りを確認する。",
            location,
        )

    # この判定は「パラメータが 1 つもない」より先に置く。`e * x` のように双方が同時に
    # 成立する式では、利用者にとって「`e` は予約名である」のほうが原因に近い。
    reserved_as_value = [
        name
        for name in _value_referenced_names(tree)
        if name != INDEPENDENT_VARIABLE
        and name not in parameter_names
        and name not in VALUE_CONSTANTS
    ]
    if reserved_as_value:
        return _unresolved(
            text,
            "".join(_reserved_value_reason(name, name in called) for name in reserved_as_value),
            location,
        )

    if not parameter_names:
        return _unresolved(
            text,
            f"推定対象のパラメータが 1 つもない。独立変数 {INDEPENDENT_VARIABLE!r} 以外の"
            "未知の記号を少なくとも 1 つ含める。",
            location,
        )

    return ExpressionModelSpec(expression=text, parameter_names=parameter_names)
