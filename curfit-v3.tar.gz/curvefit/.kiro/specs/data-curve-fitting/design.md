# Technical Design: data-curve-fitting

## Overview

**Purpose**: 本機能は、測定データ・実験データへのフィッティングを一括かつ再現可能に実行する手段を、解析担当者に提供する。Excel 等での 1 件ずつの手作業と、案件ごとの使い捨てスクリプトを置き換える。

**Users**: Python と数値計算の基礎知識を持つが解析が本業ではない担当者が、(a) 設定ファイルと CLI による日次のバッチ処理、(b) 自身の解析スクリプトからのライブラリ呼び出し、の 2 経路で利用する。両経路は同一の実行エンジンを共有し、同一の入力と実行条件に対して同一の結果を返す。

**Impact**: 新規プロジェクトであり既存システムへの影響はない。本設計は `src/curvefit/` 配下のパッケージを新規に構築する。

### Goals

- モデル関数の非線形最小二乗フィットと、モデル式を前提としない回帰・スムージングを、単一の当てはめ契約の下に統合する
- 入力集合とモデル集合の直積をジョブ一覧として展開し、複数ファイル処理と複数モデル比較を単一の実行経路で扱う
- 設定ファイルと実行条件の記録により、同一設定・同一入力での再実行が出力物レベルで同一になることを保証する
- 数百件規模のバッチを一般的な作業用 PC で数分以内に完了する
- 設定起因の誤りは 1 件も処理せずに全件分をまとめて報告し、データ個別の失敗はバッチを止めない

### Non-Goals

- 最良モデルの自動選択・自動判定。結果を比較可能な形で提示するところまでを担う
- ジョブの並列実行。逐次実行で性能目標を満たす設計とし、並列化は導入しない
- 複数ピークの自動検出・分離、機械学習による予測モデルの学習
- Excel ファイル・測定装置固有フォーマットの直接読み込み
- GUI / Web による対話的操作
- 出力物の長期保管・データベース管理・外部システム連携

## Boundary Commitments

### This Spec Owns

- **当てはめ契約** — `FitEngine` プロトコルと、その入力型 `DataSeries` / `PreparedMethod`、出力型 `EngineOutcome`。最小二乗と平滑化はこの契約の実装として並置される
- **結果の正規化表現** — `FitSuccess` / `FitFailure` / `ParameterEstimate` / `GoodnessOfFit` / `PreprocessReport` / `ExecutionRecord`。基盤ライブラリ固有の結果型を外部に露出させない責任を持つ
- **実行前検証のゲート** — 設定・モデル指定・出力先の妥当性を、ジョブを 1 件も実行する前に一括判定する
- **ジョブ展開規則** — 入力集合 × **y 列集合** × モデル集合の直積、およびその決定的な順序（要件 6.1、6.8）
- **対象の識別子の構成規則** — 処理対象は「入力ファイル 1 件と y 列 1 件の組」であり、その表示名（列ラベル）の導出規則をここで所有する（要件 7.6）
- **出力物の形式と命名規則** — サマリ CSV の列構成、曲線・残差 CSV、グラフ画像、実行ログ、実行条件の記録
- **実行条件の権威的表現** — `RunConfig`。設定ファイルと CLI 引数を統合した唯一の実行条件であり、記録・再実行はこの表現の上でのみ成立する

### Out of Boundary

- **数値最適化アルゴリズムそのもの** — 最小二乗の反復解法、信頼領域法、平滑化スプラインの節点選択は lmfit / SciPy が所有する。本設計はパラメータの組み立てと結果の正規化のみを担う
- **不確かさの伝播計算** — 標準誤差の算出は lmfit と `uncertainties` が所有する
- **数式文字列の構文解析と評価** — asteval が所有する。本設計は式を渡し、解釈失敗を検出する責任のみを持つ
- **入力フォーマットの変換** — 装置固有形式・Excel から CSV/TSV への変換は利用者側の責任
- **出力物の保管・共有・版管理**
- **端末への進捗描画** — ライブラリは `ProgressObserver` への通知までを担い、端末表示は CLI が担う

### Allowed Dependencies

- **lmfit**（BSD-3-Clause、`>=1.3`）— `models`（モデルの組み立てと解決）の内部でのみ使用する。エンジン層は `models` が返した `PreparedModel` を受け取るだけで lmfit を直接 import しない。`Model` / `Parameters` / `ModelResult` 型を `curvefit.types` の公開型に露出させてはならない
- **asteval**（`>=1.0.6`）— lmfit 経由で使用。下限は本プロジェクトが明示的に固定する（GHSA-vp47-9734-prjw 対応、`research.md` 参照）
- **SciPy**（`>=1.14`）— 平滑化エンジンの内部でのみ使用
- **NumPy**（`>=2.0`）— 全層で使用してよい。数値配列の共通表現
- **pandas**（`>=2.0`）— `readers` でのみ使用（`writers` は標準の `csv` を使う）。エンジン層・前処理層は NumPy 配列のみを扱う
- **matplotlib**（`>=3.8`）— `plotting` でのみ使用。他モジュールからの import を禁止する
- **tomllib**（標準ライブラリ、Python 3.11+）— `config` でのみ使用
- **依存方向の制約** — `errors → types → models → preprocess → engines → readers/writers/plotting/execution/logging_setup → config → preflight → pipeline → api → cli`。各モジュールは左側からのみ import する。特に **ライブラリ側モジュールが `cli` を import することを禁止する**（`FitFailure` が `FailureReason` を参照するため、レイヤ 0 内では `errors` が依存ゼロ、`types` がそれを参照する向きになる）

### Revalidation Triggers

以下の変更は、本 spec の利用者・後続 spec に再検証を要求する。

- `DataSeries` / `FitOutcome` / `RunConfig` のフィールド追加・型変更・意味変更
- `InputSpec.columns` の多重度（1 件 → 並び）の変更、または**列ラベルの導出規則**の変更。出力名・サマリ表・実行記録の 3 か所に同時に効く
- サマリ CSV の列構成、または出力ファイル命名規則の変更
- 設定ファイルのキー体系、または CLI 引数と設定ファイルの優先順位の変更
- 実行前検証と実行中失敗の振り分け（どのエラーがバッチを止めるか）の変更
- **数式中で値として参照できる予約名の集合（`VALUE_CONSTANTS`）の変更。** 追加は従来拒んでいた式を通し、削除は従来通っていた式を拒む。どちらも利用者の設定ファイルに直接効く
- `FitEngine` プロトコルのシグネチャ変更
- Python 下限バージョン、または lmfit / SciPy の下限バージョンの引き上げ
- 逐次実行から並列実行への変更（ジョブ順序・ログ順序の決定性に影響するため）

## Architecture

### Architecture Pattern & Boundary Map

**Selected pattern**: 単方向レイヤ構成。steering の `structure.md` が定める「出力 → 当てはめ → 入力 の逆流を避ける」「ライブラリが CLI を import してはならない」という制約を、レイヤ順序としてそのまま表現する。ヘキサゴナルおよびプラグイン方式は、実装が 1 つしかない間接層を生むため却下した（`research.md` の Architecture Pattern Evaluation 参照）。

```mermaid
graph TB
    subgraph L0[Layer 0 基盤型]
        Types[types]
        Errors[errors]
    end
    subgraph L1[Layer 1 当てはめコア]
        Models[models]
        Preprocess[preprocess]
        Engines[engines]
    end
    subgraph L2[Layer 2 入出力]
        Readers[readers]
        Writers[writers]
        Plotting[plotting]
        Execution[execution]
        LoggingSetup[logging_setup]
    end
    subgraph L3[Layer 3 実行条件]
        Config[config]
        Preflight[preflight]
    end
    subgraph L4[Layer 4 実行]
        Pipeline[pipeline]
        Api[api]
    end
    subgraph L5[Layer 5 入口]
        Cli[cli]
    end

    Models --> Types
    Preprocess --> Types
    Engines --> Models
    Engines --> Types
    Readers --> Types
    Writers --> Types
    Plotting --> Types
    Preflight --> Config
    Preflight --> Models
    Preflight --> Writers
    Pipeline --> Engines
    Pipeline --> Preprocess
    Pipeline --> Readers
    Pipeline --> Writers
    Pipeline --> Plotting
    Pipeline --> Execution
    Api --> Pipeline
    Api --> Preflight
    Cli --> Api
```

**Key decisions**（図に現れない判断のみ記す）:

- **エンジン層は入出力を持たない** — `engines` と `preprocess` はファイル・端末・ログに触れない純粋な計算として保つ。合成データによる検証（steering `tech.md` のテスト方針）はこの分離に依存する
- **`readers` / `writers` / `plotting` を独立モジュールに分割し、`io` という名前のサブパッケージを作らない** — 標準ライブラリの `io` を陰に隠す事故を構造的に排除する
- **`pipeline` が唯一の実行経路** — CLI 専用の実行経路を作らない。要件 9.3 の「CLI とライブラリで同一結果」を、テストではなく構造で保証する
- **進捗は通知、表示は CLI** — `ProgressObserver` プロトコルにより、ライブラリ層に端末描画を持ち込まない

### Technology Stack

| Layer | Choice / Version | Role in Feature | Notes |
|-------|------------------|-----------------|-------|
| CLI | Python `argparse`（標準ライブラリ） | 引数解析、終了コード、進捗描画 | 追加依存を避ける。要件 9.2 の指定項目は入力・設定・出力先に限られ argparse で足りる |
| 当てはめコア | lmfit `>=1.3` | 名前付きパラメータ、上下限、固定、組込モデルの `guess()`、標準誤差 | 要件 4 とほぼ 1 対 1 で対応。`research.md` の採用判断を参照 |
| 当てはめコア | SciPy `>=1.14` | 平滑化（`make_smoothing_spline`、`savgol_filter`） | `UnivariateSpline` は legacy のため使用しない |
| 当てはめコア | NumPy `>=2.0` | 数値配列の共通表現、多項式回帰（`numpy.polynomial`） | lmfit `>=1.3` の下限に合わせる |
| データ入出力 | pandas `>=2.0` | CSV/TSV 読み込み、DataFrame 入力 | `readers` に閉じる（`writers` は標準の `csv` のみ） |
| 可視化 | matplotlib `>=3.8` | フィット曲線の重ね描き画像 | `Figure` に Agg キャンバスを直結。プロセス大域のバックエンドは変更しない。`plotting` に閉じる |
| 設定 | `tomllib`（標準ライブラリ） | 設定ファイル読み込み | Python `>=3.11` を要求する根拠 |
| 式解釈 | asteval `>=1.0.6` | 数式文字列モデルの評価（lmfit 経由） | 下限は脆弱性対応のため本プロジェクトで固定 |
| 実行環境 | Python `>=3.11`、venv | 開発・実行環境 | steering `tech.md` の venv 方針に従う |

## File Structure Plan

### Directory Structure

```
pyproject.toml                      # 依存定義、コンソールエントリポイント、Python 下限 3.11
src/curvefit/
├── __init__.py                     # 公開 API の再エクスポート（api と types のみ）
├── types.py                        # 全層が共有する凍結データクラス。ロジックを持たない
├── errors.py                        # FailureReason / ConfigViolation の分類定義
├── models/
│   ├── __init__.py
│   ├── registry.py                 # 組込モデル名 → lmfit Model の対応表と guess 可否
│   ├── expression.py               # 数式文字列 → lmfit ExpressionModel、パラメータ名抽出
│   └── resolver.py                 # 3 経路の指定を PreparedMethod に一本化
├── preprocess.py                   # 区間限定・欠損除去・外れ値除去と件数集計
├── engines/
│   ├── __init__.py                 # PreparedMethod からエンジンを選択する dispatch
│   ├── base.py                     # FitEngine プロトコル、EngineOutcome 型
│   ├── least_squares.py            # lmfit による最小二乗。ModelResult を正規化
│   └── smoothing.py                # 線形/多項式回帰、平滑化スプライン、移動平均
├── readers.py                      # CSV/TSV/NDArray/DataFrame → DataSeries
├── writers.py                      # サマリ CSV、曲線・残差 CSV、前処理 CSV、出力先検証、命名規則
├── plotting.py                     # FigureCanvasAgg を直接使用、Figure 再利用、画像保存
├── execution.py                    # ExecutionRecord の構築、ライブラリバージョン収集
├── logging_setup.py                # 実行ログのハンドラ構成
├── config.py                       # TOML 読み込み、CLI 上書き適用、RunConfig 構築
├── preflight.py                    # 実行前検証。違反を一括収集
├── pipeline.py                     # ジョブ展開、逐次実行、失敗集約、進捗通知
├── api.py                          # 公開ファサード fit_series / run_batch / run_from_config
└── cli.py                          # argparse 配線、進捗描画、終了コード
tests/
├── unit/                           # models / preprocess / engines の純粋計算
├── integration/                    # readers / config / pipeline / writers の結線
├── e2e/                            # CLI 経由の通し実行、再現性、CLI とライブラリの一致
└── performance/                    # 規模と応答性、メモリ頭打ち
```

### Modified Files

予約名の衝突の検出（要件 3.2 の改訂、3.6〜3.8 の追加）で変更するファイル。
**`build_expression_model` の戻り値の型は変えない**（`ExpressionModelSpec | ConfigViolation`）。
したがって `models.resolver` 以降の層に変更は要らない。

| ファイル | 変更内容 | 要件 |
|---|---|---|
| `src/curvefit/models/expression.py` | `VALUE_CONSTANTS` と `_value_referenced_names` の追加。値参照の予約名を `MODEL_UNRESOLVED` 違反として返す判定を 1 つ足す | 3.2, 3.6, 3.7, 3.8 |
| `docs/manual_facts.py` | 値として使える予約名の宣言（`EXPRESSION_VALUE_CONSTANTS`）を足し、`DETAILED_ONLY` に加える | 3.6 |
| `tests/docs/test_manuals_stay_in_sync.py` | 新しい宣言と `VALUE_CONSTANTS` の突き合わせを一致検査の列挙に加える。**加えないと宣言が増えても突き合わせは行われない**。本文突き合わせの一致規則を語境界に改める | 3.6 |
| `tests/unit/test_models_expression.py` | 記号の分類・許可集合・案内の 2 分岐・判定順序・真偽値リテラルの検査 | 3.2, 3.6, 3.7, 3.8 |
| `tests/integration/test_preflight.py` | 違反が実行前ゲートまで届き、報告箇所が数式欄であることの検査 | 3.7 |
| `tests/integration/test_api.py` | 違反時に処理単位が 1 件も走らないことの検査 | 3.7 |
| `tests/unit/test_reserved_name_nonregression.py`（新規） | 予約名の関数呼び出しと円周率の値参照が保たれることを、検査一式の原文から集めて性質として主張する | 3.6, 3.8 |
| `tests/integration/test_expression_nonregression.py`（新規） | 予約名を含まない式の推定値を、改訂前の実測値に許容差なしで固定する | 3.2 |
| `docs/make_curvefit_manual_docx.py` | 詳細版（日本語）の数式の節に予約名の注意と、破壊的変更の 1 行を追記 | 3.6, 3.7, 3.8 |
| `docs/make_curvefit_manual_docx_en.py` | 同（英語） | 3.6, 3.7, 3.8 |
| `docs/make_curvefit_manual_ppt.py` | スライド版（日本語）の手法の節に予約名の注意を 1 行追記 | 3.6, 3.7 |
| `docs/make_curvefit_manual_ppt_en.py` | 同（英語） | 3.6, 3.7 |
| `README.md` | 数式指定の注意として予約名に触れる | 3.6, 3.7 |

**新しい宣言は `DETAILED_ONLY` に置く。** 同期検査は宣言中の名前を「全 4 スクリプトに
現れること」を課す群と「詳細版のみに課す」群に分けている。`pi` という綴りを
スライドに書くことまで強制するのは、スライドを要点に絞る方針と合わない。スライドには
予約名の注意を文として入れるが、`pi` の記載は必須としない。

**本文突き合わせの一致規則を語境界に改める。** 現在の同期検査は `name not in source`
という部分文字列一致であり、`pi` は本文中の `pip install` に一致してしまう（実測: 4 つの
生成スクリプトと `README.md` のすべてで `"pi" in source` が真、語としての一致は偽）。
この規則のままでは宣言を足しても検査が空振りし、**注意文を丸ごと削っても緑のまま**に
なる。既に宣言済みの名前には空振りが無いことを確認済みであり、`pi` が最初に露出する
例である。語境界での一致に改め、短い名前でも効く形にする。

**スライド版の注意も変異で守る。** `DETAILED_ONLY` は詳細版 2 本にしか課されないため、
スライド 2 本の注意 1 行はどの検査にも守られない。スライドにも課す共通の手掛かりを
1 つ決め、4 本すべてで突き合わせる。
**検査ファイルも表に載せる。** タスクの `_Boundary:` にしか書かないと、どのタスクが
どの検査を足すのかが表から読めず、実装時に取りこぼしやすい。

前回の改訂（列軸の追加、要件 1.11〜1.13・6.8・7.3・7.6）で変更したファイルの一覧は
git の履歴にある。本節は進行中の改訂の範囲を示す。

**変更しないもの**

- `src/curvefit/errors.py` — 既存の `ViolationKind.MODEL_UNRESOLVED` で足りる。新しい種別を足すと、利用者が区別する必要のない粒度が増える
- `src/curvefit/models/resolver.py` — 違反を受けたら早期に戻る経路が既にあり（`return (built,)`）、新しい違反もその経路を通る
- `src/curvefit/preflight.py` — 判定を実行前ゲートに置くと、ライブラリから `resolver` を直接使う経路で検出されない

## System Flows

### バッチ実行フロー

```mermaid
sequenceDiagram
    participant User as 利用者
    participant Cli as cli
    participant Api as api
    participant Preflight as preflight
    participant Pipeline as pipeline
    participant Engine as engines
    participant Out as writers plotting

    User->>Cli: コマンド実行
    Cli->>Api: run_from_config
    Api->>Preflight: 実行条件を検証
    alt 違反あり
        Preflight-->>Api: 違反一覧
        Api-->>Cli: PreflightResult 違反一覧
        Cli-->>User: 全違反を提示し終了コード 2
    else 違反なし
        Api->>Pipeline: ジョブ展開して実行
        loop ソート済みジョブごと
            Pipeline->>Pipeline: 読み込みと前処理
            Pipeline->>Engine: 当てはめ
            Engine-->>Pipeline: EngineOutcome
            Pipeline->>Out: 出力書き出し
            Pipeline-->>Cli: 進捗通知
        end
        Pipeline-->>Api: BatchReport
        Api-->>Cli: BatchReport
        Cli-->>User: 成功失敗サマリと終了コード
    end
```

実行前ゲートを通過するまでジョブを 1 件も実行しない点が、このフローの中心的な判断である。設定の誤りは全件に等しく影響するため、部分的に処理を進めてから失敗するより、何も書き出さずに全違反を提示するほうが利用者の修正コストが低い。

### 失敗の振り分け

```mermaid
flowchart TB
    Start[エラー検出] --> Kind{発生箇所}
    Kind -->|設定 モデル指定 出力先| Pre[実行前ゲート]
    Kind -->|個別データの処理中| Item[ジョブ単位の失敗]
    Pre --> Collect[違反を蓄積し全件検査を継続]
    Collect --> Abort[1 件も実行せず終了 コード 2]
    Item --> Policy{failure_policy}
    Policy -->|skip 既定| Record[FitFailure として記録し次のジョブへ]
    Policy -->|fail_fast| Stop[残りを中止し それまでの結果を保持]
    Record --> Summary[成功失敗サマリ]
    Stop --> Summary
```

データ個別の失敗を例外ではなく `FitFailure` という値として運ぶことで、要件 6.4 の「スキップして継続」と要件 6.6 の「成功失敗サマリ」が同じ集約処理に載る。例外で表現すると、継続のたびに握りつぶしが発生し、集約が漏れやすくなる。

## Requirements Traceability

| Requirement | Summary | Components | Interfaces | Flows |
|-------------|---------|------------|------------|-------|
| 1.1 | CSV/TSV の列指定読み込み（y 列ごとに系列） | readers, pipeline | `read_delimited`、`Job.columns` | バッチ実行 |
| 1.2 | 配列・DataFrame も同一手順・同一構造 | readers, api | `read_arrays`, `read_frame`, `fit_series` | バッチ実行 |
| 1.3 | 対応付けられた誤差列を重みに反映 | readers, engines.least_squares, engines.smoothing | `ColumnSpec.weight`、`DataSeries.weights` | — |
| 1.4 | 列が存在しない場合の報告 | readers, pipeline | `FailureReason.COLUMN_NOT_FOUND` | 失敗の振り分け |
| 1.5 | 処理対象ごとの有効データ 0 件の報告 | readers, pipeline | `FailureReason.NO_VALID_DATA` | 失敗の振り分け |
| 1.11 | y 列を 1 つ以上指定できる | config, pipeline | `InputSpec.columns`、`expand_jobs` | バッチ実行 |
| 1.12 | y 列と誤差列の 1 対 1 対応 | config | `_build_columns` | — |
| 1.13 | 個数不一致を実行前に拒否 | config | `ViolationKind.CONFIG_INVALID` | 失敗の振り分け |
| 1.6 | 見出し行の有無の指定に従う | readers, config | `read_delimited` の `header` | — |
| 1.7 | 見出し行が曖昧な入力の報告 | readers | `FailureReason.HEADER_AMBIGUOUS` | 失敗の振り分け |
| 1.8 | 読み取れない入力ファイルの報告 | pipeline | `FailureReason.INPUT_UNREADABLE` | 失敗の振り分け |
| 1.9 | 読み取りで値を変えない | readers | `pd.read_csv(float_precision="round_trip")` | 単体 |
| 1.10 | 重みを扱えない手法への誤差列指定の拒否 | preflight, engines.smoothing | `ViolationKind.CONFIG_INVALID` | 失敗の振り分け |
| 2.1 | フィット区間の限定 | preprocess | `apply_preprocess` | — |
| 2.2 | 欠損・不正行の除去と件数記録 | preprocess | `PreprocessReport.n_dropped_invalid` | — |
| 2.3 | 外れ値除去と件数の記録 | preprocess | `PreprocessReport.n_dropped_outlier` | — |
| 2.4 | 点数不足の検出 | preprocess, pipeline | `FailureReason.INSUFFICIENT_POINTS` | 失敗の振り分け |
| 3.1 | 組込モデルの名前選択 | models.registry | `BUILTIN_MODELS` | — |
| 3.2 | 数式文字列の解釈 | models.expression | `build_expression_model` | — |
| 3.3 | ユーザー定義関数の受け入れ | models.resolver, api | `MethodSpec.function` | — |
| 3.4 | モデル解決失敗の報告 | models.resolver, preflight | `ViolationKind.MODEL_UNRESOLVED` | 失敗の振り分け |
| 3.5 | パラメータ名を結果の識別子に使用 | models.resolver, writers | `ParameterEstimate.name` | — |
| 3.6 | 値として使える予約名を `pi` に限る | models.expression | `VALUE_CONSTANTS` | — |
| 3.7 | 予約名の値参照を実行前に拒む | models.expression | `build_expression_model` | 失敗の振り分け |
| 3.8 | 予約名の関数呼び出しは受け入れる | models.expression | `_value_referenced_names` | — |
| 4.1 | 組込モデルの初期値自動推定 | models.resolver, engines.least_squares | `PreparedModel._parameters`（`guess()` の結果）、非収束時は `EngineFailure.initial_values` | — |
| 4.2 | 初期値の明示指定が自動推定に優先 | models.resolver | `MethodSpec.initial` | — |
| 4.3 | 任意モデルで初期値未指定はエラー | preflight | `ViolationKind.INITIAL_REQUIRED` | 失敗の振り分け |
| 4.4 | パラメータ上下限の適用 | models.resolver, engines.least_squares | `MethodSpec.bounds` | — |
| 4.5 | 特定パラメータの固定 | models.resolver, engines.least_squares | `MethodSpec.fixed` | — |
| 4.4, 4.5 | 平滑化手法へのパラメータ指定の拒否 | preflight | `ViolationKind.CONFIG_INVALID` | 失敗の振り分け |
| 4.6 | 初期値と上下限の矛盾検出 | preflight | `ViolationKind.INITIAL_OUT_OF_BOUNDS` | 失敗の振り分け |
| 4.7 | 非収束の記録と初期値の報告 | engines.least_squares | `EngineFailure.initial_values` | 失敗の振り分け |
| 5.1 | 回帰・スムージング 4 手法 | engines.smoothing | `SmootherKind` | — |
| 5.2 | モデル関数フィットと同一手順 | engines.base, pipeline | `FitEngine` | バッチ実行 |
| 5.3 | パラメータと適合度を同一形式で出力 | engines.smoothing, writers | `EngineSuccess` | — |
| 5.4 | 手法固有設定の既定値適用と記録 | models.registry, models.resolver, engines.least_squares, engines.smoothing, pipeline, execution | `EngineSuccess.applied_defaults` → `collect_applied_defaults` | バッチ実行 |
| 5.5 | 平滑化スプラインの平滑化パラメータの必須性 | preflight, engines.smoothing | `ViolationKind.SMOOTHER_OPTION_INVALID` | 失敗の振り分け |
| 6.1 | 複数ファイルの各処理対象を一括処理 | pipeline | `expand_jobs` | バッチ実行 |
| 6.2 | 同一データへの複数モデル適用と比較 | pipeline, writers | `expand_jobs`, `write_summary` | バッチ実行 |
| 6.3 | 進捗の表示 | pipeline, cli | `ProgressObserver` | バッチ実行 |
| 6.4 | 既定はスキップして継続 | pipeline | `FailurePolicy.SKIP` | 失敗の振り分け |
| 6.5 | fail-fast で中止 | pipeline | `FailurePolicy.FAIL_FAST` | 失敗の振り分け |
| 6.6 | 成功件数と失敗件数のサマリ | pipeline, cli | `BatchReport` | バッチ実行 |
| 6.7 | 進捗表示の抑止と、抑止時も失敗を報告すること | cli | `FailureOnlyProgress` | バッチ実行 |
| 6.8 | y 列 × モデルの直積 | pipeline | `expand_jobs`、`_build_jobs` | バッチ実行 |
| 7.1 | パラメータ推定値と標準誤差 | engines.least_squares | `ParameterEstimate.stderr` | — |
| 7.2 | 決定係数と RMSE | engines.base | `GoodnessOfFit` | — |
| 7.3 | 全対象を 1 つのサマリ CSV に。行が入力と列を識別する | writers, types | `write_summary`、`FitOutcome.column_label` | バッチ実行 |
| 7.4 | グラフ画像を既定で保存 | plotting | `render_fit_plot` | バッチ実行 |
| 7.5 | 曲線・残差 CSV をオプトイン出力 | writers | `write_curve` | バッチ実行 |
| 2.5 | 外れ値と判定した点の x・実測値・反復回数の出力 | preprocess, types, writers, pipeline | `PreprocessReport.outlier_points` → `write_preprocess` | バッチ実行 |
| 7.6 | 出力名が入力と y 列の双方を識別する | writers, readers | `build_output_stem`、`column_label` | — |
| 7.7 | 出力先が書けない場合の中止 | writers, preflight | `ViolationKind.OUTPUT_NOT_WRITABLE` | 失敗の振り分け |
| 8.1 | 設定ファイルによる実行条件定義 | config | `load_config` | — |
| 8.2 | 同一設定・同一入力で同一結果 | pipeline, writers | `expand_jobs` の決定的順序 | バッチ実行 |
| 8.3 | 実行条件・入力と列の識別・日時の記録 | execution | `ExecutionRecord` | — |
| 8.4 | 成否と失敗理由の実行ログ | logging_setup, pipeline | `run.log` | バッチ実行 |
| 8.5 | 設定ファイル不備での中止 | config, preflight | `ViolationKind.CONFIG_INVALID` | 失敗の振り分け |
| 2.1（実行前検証の側） | フィット区間の逆転指定 | preflight | `ViolationKind.CONFIG_INVALID` | 失敗の振り分け |
| 9.1 | ライブラリ API の提供 | api | `fit_series`, `run_batch` | — |
| 9.2 | CLI からの実行 | cli | `main` | バッチ実行 |
| 9.3 | CLI とライブラリで同一結果 | api, pipeline | 単一実行経路 | バッチ実行 |
| 9.4 | CLI 引数の優先と上書き記録 | config, execution | `OverrideRecord` | — |
| 9.5 | 終了コードの区別 | cli | `ExitCode` | バッチ実行 |
| 10.1 | 数百ファイル規模の処理 | pipeline | 逐次実行 | バッチ実行 |
| 10.2 | 一般 PC で数分以内 | plotting, pipeline | Figure 再利用 | バッチ実行 |
| 10.3 | 資源制約時の中断と結果保持 | pipeline | `BatchReport.aborted` | 失敗の振り分け |
| 10.4 | 常駐メモリが件数に比例しないこと | pipeline, types | `FitSuccess.without_curve` | 性能テスト |

## Components and Interfaces

| Component | Layer | Intent | Req Coverage | Key Dependencies (P0/P1) | Contracts |
|-----------|-------|--------|--------------|--------------------------|-----------|
| types | 0 | 全層が共有する凍結データ型 | 1.2, 2.5, 5.3, 7.1, 7.2 | なし | State |
| errors | 0 | 失敗理由と設定違反の分類 | 1.4, 1.5, 2.4, 3.4, 4.3, 4.6, 4.7, 7.7, 8.5 | なし | State |
| models.resolver | 1 | 3 経路のモデル指定を単一表現に解決 | 3.1–3.5, 4.1, 4.2, 4.4, 4.5 | lmfit (P0), asteval (P1) | Service |
| preprocess | 1 | 区間限定・欠損除去・外れ値除去 | 2.1–2.5 | NumPy (P0) | Service |
| engines.base | 1 | 当てはめ契約と適合度算出 | 5.2, 7.2 | types (P0) | Service |
| engines.least_squares | 1 | lmfit による最小二乗と結果正規化 | 1.3, 4.1, 4.4, 4.5, 4.7, 7.1 | lmfit (P0) | Service |
| engines.smoothing | 1 | 回帰・平滑化 4 手法 | 1.3, 1.10, 5.1, 5.3, 5.4, 5.5 | SciPy (P0), NumPy (P0) | Service |
| readers | 2 | 入力 3 経路の正規化 | 1.1–1.5 | pandas (P0) | Service |
| writers | 2 | CSV 出力、出力先検証、命名規則 | 2.5, 7.3, 7.5, 7.6, 7.7 | （標準 csv のみ） | Service, Batch |
| plotting | 2 | グラフ画像生成 | 7.4, 10.2 | matplotlib (P0) | Service |
| execution | 2 | 実行条件の記録 | 5.4, 8.3, 9.4 | なし | State |
| logging_setup | 2 | 実行ログのハンドラ構成 | 8.4 | なし | — |
| config | 3 | 設定ファイルと CLI 引数の統合 | 8.1, 8.5, 9.4 | tomllib (P0) | Service, State |
| preflight | 3 | 実行前一括検証 | 1.10, 3.4, 4.3, 4.4, 4.5, 4.6, 5.4, 5.5, 7.7, 8.5, 2.1 | config (P0), models (P0), writers (P0) | Service |
| pipeline | 4 | ジョブ展開・逐次実行・失敗集約 | 6.1–6.6, 8.2, 8.4, 10.1, 10.3 | engines (P0), readers (P0), writers (P0) | Service, Batch |
| api | 4 | 公開ファサード | 1.2, 9.1, 9.3 | pipeline (P0), preflight (P0) | Service |
| cli | 5 | 引数解析・進捗描画・終了コード | 6.3, 6.7, 9.2, 9.4, 9.5 | api (P0) | Service |

### Layer 0: 基盤型

#### types

| Field | Detail |
|-------|--------|
| Intent | 全層が共有する凍結データ型を定義する。ロジックと副作用を持たない |
| Requirements | 1.2, 5.3, 7.1, 7.2, 7.3, 7.6 |

**Responsibilities & Constraints**

- 本モジュールは他の `curvefit` モジュールを一切 import しない
- すべての型は `@dataclass(frozen=True)` とし、生成後に変更されない
- lmfit / SciPy / matplotlib の型を一切露出させない。これは Allowed Dependencies の制約を型レベルで担保する手段である

**Contracts**: Service [ ] / API [ ] / Event [ ] / Batch [ ] / State [x]

##### State Management

```python
FloatArray: TypeAlias = NDArray[np.float64]

@dataclass(frozen=True)
class DataSeries:
    source_id: str                      # 入力の識別子。ファイルパスまたは呼び出し元指定のラベル
    x: FloatArray
    y: FloatArray
    weights: FloatArray | None = None   # 誤差列由来の重み。未指定なら None
    column_name: str | None = None      # 7.3 解決後の y 列の見出し名。見出しが無ければ None

@dataclass(frozen=True)
class ParameterEstimate:
    name: str
    value: float
    stderr: float | None                # 算出不能なら None（ヤコビアン不足時）
    fixed: bool

@dataclass(frozen=True)
class GoodnessOfFit:
    r_squared: float
    rmse: float
    n_points: int
    n_varied_params: int

@dataclass(frozen=True)
class PreprocessReport:
    n_input: int
    n_dropped_invalid: int
    n_dropped_out_of_range: int
    n_dropped_outlier: int
    outlier_points: tuple[OutlierPoint, ...]   # 2.5 除外した点。除去順

@dataclass(frozen=True)
class OutlierPoint:
    x: float
    y: float
    iteration: int      # 何回目の反復で除外したか（1 起点）

@dataclass(frozen=True)
class CurveData:
    x: FloatArray
    y_observed: FloatArray
    y_fit: FloatArray
    residual: FloatArray

@dataclass(frozen=True)
class FitSuccess:
    source_id: str
    method_name: str
    parameters: tuple[ParameterEstimate, ...]   # 平滑化でパラメータを持たない場合は空
    goodness: GoodnessOfFit
    curve: CurveData | None                    # 一括処理では書き出し後に手放す（10.4）
    preprocess: PreprocessReport
    column_label: str | None = None            # 7.6 y 列の識別子。系列直接指定では None
    column_name: str | None = None             # 7.3 解決後の見出し名。読み込み後にのみ埋まる

@dataclass(frozen=True)
class FitFailure:
    source_id: str
    method_name: str
    reason: FailureReason
    message: str
    preprocess: PreprocessReport | None = None  # 前処理到達前の失敗では None
    column_label: str | None = None             # 7.6
    column_name: str | None = None              # 7.3 読み込みに至らない失敗では None

FitOutcome: TypeAlias = FitSuccess | FitFailure
```

- Invariants: `FitSuccess.curve` が `None` でないとき、その 4 配列は同一長であり `goodness.n_points` はその長さと一致する。`None` になるのは一括処理で曲線を手放した後に限る（要件 10.4）。単一系列の経路（`api.fit_series`）は常に保持する
- Invariants: `ParameterEstimate.fixed` が `True` のとき `stderr` は `None`
- Invariants: **2 つの列識別子は既定値 `None` を持つ。** 既定値を外すと全構築地点（実測 82 か所）に
  波及し、型の追加が層をまたぐ変更になる。代償として「刻み忘れても型が黙って通る」余地が残るため、
  **実際に埋まっていることは振る舞い側（`pipeline` の刻印と E2E のサマリ突合）で押さえる**
- Invariants: **見出し名を持つなら綴りも持つ。** `column_label` が `None` になるのは系列直接指定の
  経路に限り、その経路は `column_name` も持たない。この対偶を型の生成時に検証する
- Invariants: **結果は自身の識別子を自分で持つ。** `source_id` / `column_label` / `method_name` の 3 つで 処理対象と手法が一意に定まる（要件 7.3、7.6）。`writers.write_summary` は結果の並びだけを受け取り `Job` を知らないため、識別子を結果の外に置くと出力側から対象を特定できない。**依存方向（`writers` は `pipeline` を import できない）がこの配置を決めている**
- Postconditions: `column_label` が `None` になるのは、呼び出し元が系列を直接渡した経路（`api.fit_series`）に限る。この経路は列の概念を持たず、出力物も書かない
- Validation: **既定値が決まる時期は手法によって違う。** 組込モデルの既定値（多項式の次数）は登録簿がモデルを組み立てる時点で決まるため `PreparedModel.applied_defaults` に載る。平滑化の既定値（窓長・次数）は当てはめ時に `engines.smoothing` が適用するため解決結果には載らない。この非対称は意図的である。解決層に平滑化の既定値を持たせると、実際に適用する側と 2 か所で所有することになる（要件 5.4）。いずれの経路も最終的には `EngineSuccess.applied_defaults` に集まり、同じ利用者入力なら手法の書き方によらず同一に記録される
- Validation: **自動推定を使ったか否かの真偽値は記録しない。** 再現や解釈に要るのは推定された初期値そのものであり（要件 4.7 が非収束時に `EngineFailure.initial_values` として提示する）、真偽値 1 個では利用者の次の行動を助けない。要件 4.1 は「初期値を自動的に決定してフィットを開始する」ことだけを求めており、その旨の記録は求めていない

#### errors

| Field | Detail |
|-------|--------|
| Intent | 失敗理由と設定違反を、実行前ゲートと実行中失敗の 2 系統に分けて分類する |
| Requirements | 1.4, 1.5, 1.7, 2.4, 3.4, 4.3, 4.6, 4.7, 7.7, 8.5 |

**Responsibilities & Constraints**

- `FailureReason`（実行中失敗、ジョブ単位）と `ConfigViolation`（実行前違反、実行全体）を明確に分離する。この 2 つを 1 つの列挙に統合してはならない。統合すると「止めるべきか継続すべきか」が呼び出し側の判断に委ねられ、要件 6.4 の既定が崩れる

**Contracts**: State [x]

```python
class FailureReason(StrEnum):
    COLUMN_NOT_FOUND = "column_not_found"        # 1.4
    NO_VALID_DATA = "no_valid_data"              # 1.5
    INSUFFICIENT_POINTS = "insufficient_points"  # 2.4
    NOT_CONVERGED = "not_converged"              # 4.7
    HEADER_AMBIGUOUS = "header_ambiguous"        # 1.7
    INPUT_UNREADABLE = "input_unreadable"        # 1.8
    RESOURCE_EXHAUSTED = "resource_exhausted"    # 10.3

class ViolationKind(StrEnum):
    CONFIG_INVALID = "config_invalid"                    # 8.5
    MODEL_UNRESOLVED = "model_unresolved"                # 3.4
    INITIAL_REQUIRED = "initial_required"                # 4.3
    INITIAL_OUT_OF_BOUNDS = "initial_out_of_bounds"      # 4.6
    OUTPUT_NOT_WRITABLE = "output_not_writable"          # 7.7
    SMOOTHER_OPTION_INVALID = "smoother_option_invalid"  # 5.4 の制約違反

@dataclass(frozen=True)
class ConfigViolation:
    kind: ViolationKind
    location: str      # 設定ファイル内の位置、または CLI 引数名
    message: str
```

### Layer 1: 当てはめコア

#### models.resolver

| Field | Detail |
|-------|--------|
| Intent | 組込モデル名・数式文字列・Python 関数の 3 経路を、単一の `PreparedMethod` に解決する |
| Requirements | 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 4.1, 4.2, 4.4, 4.5 |

**Responsibilities & Constraints**

- 3 経路の差異を吸収し、以降の層がモデル指定の由来を知らずに済む状態を作る
- 初期値の解決順序を所有する。**明示指定 > 組込モデルの `guess()`** の優先順位（要件 4.2）はここでのみ実装される
- 数式文字列からパラメータ名を抽出し、要件 3.5 の識別子として確定する
- **抽出から漏れた記号を黙って捨てない。** 値として参照された記号がパラメータにならなかった場合、それは評価器が既に意味を持つ名前である。円周率 `pi` を除き、実行前の違反として返す（要件 3.6〜3.8）
- 解決失敗（未知のモデル名、式の解釈不能）を例外ではなく `ConfigViolation` として返す。実行前ゲートが全違反を収集できるようにするため

**Dependencies**

- External: lmfit — `Model` / `Parameters` / `ExpressionModel` の構築（P0）
- External: asteval — lmfit 経由の式評価。直接 import しない（P1）

**Contracts**: Service [x] / State [x]

##### Service Interface

```python
class SmootherKind(StrEnum):                                 # 5.1
    LINEAR = "linear"
    POLYNOMIAL = "polynomial"
    SPLINE = "spline"
    MOVING_AVERAGE = "moving_average"

@dataclass(frozen=True)
class MethodSpec:
    name: str                                            # 出力に現れる識別名
    kind: Literal["builtin", "expression", "callable", "smoother"]
    builtin: str | None = None                           # 3.1
    expression: str | None = None                        # 3.2
    function: Callable[..., FloatArray] | None = None    # 3.3
    smoother: SmootherKind | None = None                 # 5.1
    initial: Mapping[str, float] = field(default_factory=dict)                        # 4.2
    bounds: Mapping[str, tuple[float | None, float | None]] = field(default_factory=dict)  # 4.4
    fixed: Mapping[str, float] = field(default_factory=dict)                          # 4.5
    options: Mapping[str, float | int] = field(default_factory=dict)                  # 5.4

@dataclass(frozen=True)
class PreparedModel:
    display_name: str
    parameter_names: tuple[str, ...]
    applied_defaults: Mapping[str, float | int]   # 5.4 登録簿が補った選択肢の既定値
    _model: object              # lmfit.Model。engines.least_squares 以外は参照しない
    _parameters: object         # lmfit.Parameters

@dataclass(frozen=True)
class PreparedSmoother:
    display_name: str
    kind: SmootherKind
    options: Mapping[str, float | int]

PreparedMethod: TypeAlias = PreparedModel | PreparedSmoother

def resolve(spec: MethodSpec, sample: DataSeries | None) -> PreparedMethod | tuple[ConfigViolation, ...]:
    ...
```

- Preconditions: `spec.kind` に対応するフィールドが埋まっていること。`sample` は `guess()` に用いる代表データ。`None` の場合、組込モデルであっても自動推定は行われない
- Postconditions: 成功時、`PreparedModel._parameters` はすべてのパラメータについて初期値・上下限・`vary` が確定している
- Postconditions: 失敗時、検出したすべての違反を返す（最初の 1 件で打ち切らない）
- Invariants: `kind` が `"expression"` または `"callable"` のとき、`initial` にも `fixed` にも値のないパラメータが 1 つでもあれば必ず `INITIAL_REQUIRED` 違反を返す（要件 4.3）。基盤ライブラリの既定初期値は `-inf` であり、一部欠落を通すと当てはめ時に例外で異常終了する

**数式の記号の分類**（要件 3.2、3.6〜3.8）

式中の `ast.Name` を、出現位置によって 3 つに分ける。**分類は 1 か所で行い、
`build_expression_model` の戻り値としてのみ外に出る。**

| 分類 | 判定 | 扱い |
|---|---|---|
| 独立変数 | `INDEPENDENT_VARIABLE`（`x`）と一致 | パラメータにしない |
| 関数として呼ばれた名前 | `ast.Call.func` の位置に現れる | パラメータにしない。受け入れる（要件 3.8） |
| 値として参照された名前 | 上記いずれでもない位置に現れる | パラメータにする。ただし下記の例外 |

値として参照された名前のうち、**モデルのパラメータにならなかったもの**は、評価器が
既に意味を持つ名前である。`VALUE_CONSTANTS` に挙げた名前だけを許し、残りは
`MODEL_UNRESOLVED` 違反として返す（要件 3.7）。

**案内は 2 通りに分ける。** 要件 3.7 が最低限として求めるのは「別名を用いる」旨だが、
それだけでは遠回りをさせる場合がある。

| 当該の名前が式中で | 利用者の意図 | 添える案内 |
|---|---|---|
| 関数としても呼ばれている（`exp + a*exp(x)`） | 呼び出しの括弧を忘れた | 呼び出しの括弧が抜けていないか |
| 値としてしか現れない（`a*x + exp`、`… + e`） | パラメータのつもりだった | 別の名前を用いる |

いずれの場合も記号名と「予約名である」旨は必ず含める（要件 3.7）。

**判定の順序を決める。** 既存の判定は「未定義の関数呼び出し」→「パラメータが 1 つも
ない」の順に並ぶ。`e * x` のように新しい判定と「パラメータが 1 つもない」が同時に成立
する式があるため、**新しい判定を「パラメータが 1 つもない」より先に置く。** 利用者に
とって「`e` は予約名である」のほうが「パラメータが 1 つもない」より原因に近い。

```python
VALUE_CONSTANTS: frozenset[str] = frozenset({"pi"})
"""数式中で値として参照してよい予約名（要件 3.6）。

集合であり順序を持たない。ドキュメント同期検査から突き合わせる際は、順序に依存しない
形（整列または集合同士）で比較する。要素が 2 つ以上になると反復順がハッシュ種に依存し、
列として比較すると実行ごとに結果が変わる。
"""


def _value_referenced_names(tree: ast.Expression) -> list[str]:
    """値として参照されている記号名を、出現順・重複なしで返す（要件 3.8）。"""
```

**`VALUE_CONSTANTS` は 2 つの主張を同時に持つ。** 「その名前は予約名である」と
「値としての参照を許す」である。**前半を検査で固定する。** 仮に評価器が `pi` を
持たなくなると `pi` はパラメータに変わり、`a*sin(2*pi*x/b)+c` は 4 つ目のパラメータを
推定し始める。警告は出ない。これは本改訂が塞ごうとしている静かな食い違いと同じ型の
事故であり、偶然に頼ってはならない。`VALUE_CONSTANTS` の各要素について、それが
パラメータにならないことを単体検査で押さえる。

**予約名の一覧を持たない。** 判定は「値参照なのにパラメータにならなかった」という
間接的な条件で行う。これにより (a) 評価器が持つ 387 件の名前を複製せず、版が上がって
名前が増減しても追随が要らない、(b) 本モジュールが asteval を直接 import しない方針
（モジュール docstring）を保てる、(c) 387 件を検査で固定する必要がない。

**同じ名前を値と関数の双方で使った式も捉える。** `exp + a*exp(x)` のような式では、
「参照された名前 − 呼び出された名前」の差集合では `exp` が消えて検出漏れになる
（`research.md` の Research Needed 1）。`_value_referenced_names` は差集合ではなく
**`ast.Name` が `Call.func` の位置にあるかを見て**分類する。見逃しが静かであることは
本改訂が塞ごうとしている性質そのものであり、素朴な実装で残してよい穴ではない。

**真偽値リテラルは対象外である。** Python 3 では `True` / `False` は `ast.Constant`
として解析され `ast.Name` ではない。`a*x + True` は `a*x + 1` と書くのと同じであり、
リテラルの記述であって予約名の衝突ではない。一方 `little_endian` のような名前は
`ast.Name` であり判定に掛かる。**リテラルは通し、名前は拒む**という線引きになる
（`research.md` の Research Needed 2）。

**Implementation Notes**

- Integration: 組込モデルの `guess()` はデータに依存するため、複数ファイルを処理する場合は「どのデータで推定した初期値か」が問題になる。**ジョブごとに、そのジョブの入力データで `resolve` を呼び直す**。設定解決時に 1 回だけ推定して使い回す実装は、ファイルごとにスケールが異なるデータで収束を悪化させる
- Validation: 実行前ゲートでは `sample=None` で解決を試み、データに依存しない違反（未知モデル名、式の解釈不能、初期値必須、初期値と上下限の矛盾）のみを検出する
- Risks: 数式文字列のパラメータ名抽出は asteval の名前解決に依存する。`x` を独立変数として除外する規則を明示的に持つ必要がある
- Risks: **除外は静かである。** 評価器が既に意味を持つ名前（`e` や `sum`）を利用者がパラメータの意図で書いても、除外されたことは結果に現れない。実測では 4 次多項式の `e` が定数 2.718281828459045 に解決され、**終了コード 0・警告なし・r² = 0.9796 のまま上位桁の違う推定値**が出た（`research.md` の Gap Analysis）。要件 3.6〜3.8 はこの静かな経路を塞ぐためにある

#### preprocess

| Field | Detail |
|-------|--------|
| Intent | フィット前のデータ整形を、固定順序の 3 段階として適用し、除去件数を集計する |
| Requirements | 2.1, 2.2, 2.3, 2.4, 2.5 |

**Responsibilities & Constraints**

- 適用順序を所有する: **欠損・不正行の除去 → 区間限定 → 外れ値除去**。この順序は固定であり設定で変更できない。外れ値判定は区間内の残差に基づくため、区間限定より後でなければ意味が変わる
- 外れ値除去は「暫定フィット → 残差評価 → 除去 → 再フィット」の反復であり、当てはめエンジンを必要とする。エンジンをコールバックとして受け取り、`engines` への依存を持たない（依存方向の維持）
- 反復回数上限と閾値を明示的に持ち、既定値を実行条件に記録する（要件 8.2 の決定性）

**Contracts**: Service [x]

##### Service Interface

```python
@dataclass(frozen=True)
class OutlierSpec:
    sigma: float = 3.0
    max_iterations: int = 3

@dataclass(frozen=True)
class PreprocessSpec:
    x_min: float | None = None
    x_max: float | None = None
    outlier: OutlierSpec | None = None    # None なら外れ値除去を行わない

def apply_preprocess(
    series: DataSeries,
    spec: PreprocessSpec,
    min_points: int,
    provisional_fit: Callable[[DataSeries], FloatArray] | None = None,
    *,
    method_name: str,
) -> tuple[DataSeries, PreprocessReport] | FitFailure:
    ...
```

- Preconditions: `series.x` と `series.y` は同一長
- Postconditions: 返される `DataSeries` の点数が `min_points` 未満の場合、`FailureReason.INSUFFICIENT_POINTS` を持つ `FitFailure` を返す（要件 2.4）
- Postconditions: `PreprocessReport` の各カウントの合計は、元の点数と残った点数の差に一致する
- Invariants: 欠損除去は常に実行される（要件 2.2 は無条件の `shall`）。設定で無効化できない

**Implementation Notes**

- Validation: `min_points` は当てはめ手法の推定パラメータ数から呼び出し側が決める。前処理層は手法を知らない
- Validation: `method_name` は失敗報告の識別子としてのみ受け取り、値による分岐は行わない。`FitFailure` が `method_name` を必須とし、Error Categories が「データ個別の問題は `source_id` と `method_name` を必ず含める」と定めるため、空文字で埋めることは許されない。供給責任は `min_points` / `provisional_fit` と同じく `pipeline` が持つ
- Validation: `x_min > x_max` の逆転指定は前処理層では検証しない。点が 1 つも残らず `INSUFFICIENT_POINTS` になる。データに依存しない設定誤りであるため、`preflight` が `CONFIG_INVALID` として先に捕まえる
- Risks: `provisional_fit` が非収束の場合、外れ値除去を実行できない。1 回目から非収束であれば外れ値除去をスキップし、除去 0 件として記録して当てはめに進む。2 回目以降の非収束では、それ以前の収束した当てはめに基づく除外を保持したうえで反復を打ち切る。ここで失敗にすると、外れ値除去を有効にしただけで成功していたはずのジョブが落ちる
- Validation: 外れ値判定は `|residual| > sigma * sqrt(mean(residual**2))`。中心は残差自身から推定せず 0 に固定する。判定式はスケール不変であり、外れ値と判定されうる点数は `n / sigma**2` を超えない。既定 `sigma=3.0` では `n <= 9` の系列でどのような大きさの単一外れ値も除去されず、同程度の外れ値が `n / sigma**2` 点以上ある場合も除去 0 件になる。ロバスト尺度（MAD など）への変更は別途要件化する

#### engines.base / engines.least_squares / engines.smoothing

| Field | Detail |
|-------|--------|
| Intent | 当てはめの単一契約を定義し、最小二乗と平滑化をその実装として並置する |
| Requirements | 1.3, 4.1, 4.4, 4.5, 4.7, 5.1, 5.2, 5.3, 5.4, 7.1, 7.2 |

**Responsibilities & Constraints**

- `FitEngine` は本 spec が所有する当てはめ契約であり、要件 5.2 の「同一手順」を構造として実現する
- 適合度指標（R²、RMSE）の算出は `engines.base` に集約する。手法によらず残差ベースで統一する（要件 5.3、7.2）
- lmfit の `ModelResult` は `least_squares` の内部で `EngineSuccess` に正規化する。外へ漏らさない
- 入出力を一切持たない。ファイル・ログ・端末に触れない

**Dependencies**

- External: lmfit — 最小二乗の実行と標準誤差（P0）
- External: SciPy — `make_smoothing_spline`、`savgol_filter`（P0）
- External: NumPy — `numpy.polynomial.Polynomial.fit` による多項式回帰（P0）

**Contracts**: Service [x]

##### Service Interface

```python
# SmootherKind は models.resolver が所有する。依存方向が models → engines であるため
# models は engines を import できない。engines.smoothing は curvefit.models.resolver から import する。

@dataclass(frozen=True)
class EngineSuccess:
    parameters: tuple[ParameterEstimate, ...]
    y_fit: FloatArray
    applied_defaults: Mapping[str, float | int]

@dataclass(frozen=True)
class EngineFailure:
    reason: FailureReason
    message: str
    initial_values: Mapping[str, float]     # 4.7 が要求する報告内容

EngineOutcome: TypeAlias = EngineSuccess | EngineFailure

class FitEngine(Protocol):
    def fit(self, series: DataSeries, method: PreparedMethod) -> EngineOutcome: ...

def select_engine(method: PreparedMethod) -> FitEngine: ...

def compute_goodness(
    y_observed: FloatArray, y_fit: FloatArray, n_varied_params: int
) -> GoodnessOfFit: ...
```

- Preconditions: `series` は前処理済みであり、欠損を含まない
- Postconditions: `EngineSuccess.y_fit` は `series.x` と同一長
- Postconditions: 最小二乗で `weights` が与えられている場合、残差は重み付きで最小化される（要件 1.3）
- Postconditions: `fixed` 指定されたパラメータは `ParameterEstimate.fixed=True`、`value` は指定値と厳密に一致する（要件 4.5）
- Invariants: 上下限が指定されたパラメータの推定値は必ずその範囲内（要件 4.4）
- Invariants: 平滑化手法でパラメータを持たない場合、`parameters` は空タプル。適合度は必ず算出される（要件 5.3）

**Implementation Notes**

- Integration: **手法固有オプションの既定値は `engines.smoothing` がモジュール定数として単独で所有する**。`preflight` はこの定数を import して検証に用い、独自の既定値を持たない。既定値の定義が 2 か所に分かれると、検証に通った設定が実行時に別の値で動く事故が起こる。`savgol_filter` の「窓長は奇数かつ多項式次数より大きい」という制約の検証は `preflight` が行い、エンジンは検証済みを前提に動作する
- Integration: スプラインは `scipy.interpolate.make_smoothing_spline` を使う。`UnivariateSpline` は legacy のため使用しない
- Validation: 重みが効くかどうかは手法ごとに `engines.smoothing.SMOOTHER_USES_WEIGHTS` が宣言する。最小二乗（`engines.least_squares`）と平滑化の線形・多項式回帰は重み付き最小二乗そのもの、スプラインは `Σ w r² + λ∫f''²` を最小化する。移動平均だけが持たない（畳み込み係数が窓長と多項式次数だけで決まる）。**理由の文言も同じ宣言の隣に置く**（要件 1.10）
- Integration: 平滑化スプラインは `lam`（平滑化パラメータ）を **必須** の選択肢とする（要件 5.5）。既定値は持たず、未指定は `preflight` が `SMOOTHER_OPTION_INVALID` として実行前に拒否する。GCV による自動選択は呼び出しごとに 2 つの状態のいずれかに倒れ、同一プロセス内・プロセス間の双方で当てはめ値が揺れるため、要件 8.2 の同一結果が成立しない（実測: RMSE の絶対差 6e-14〜2e-12。`lam` を明示すると直接解法となり 8 回の実行で完全一致）。`preflight` は `lam > 0` も検証する
- Validation: 全変動が 0 の場合、残差も 0 なら R² は 1.0、残差が残るなら 0.0 とし除算を行わない。平均より当てはまりが悪い場合の負値はクランプしない
- Validation: `compute_goodness` は非有限な当てはめ値をそのまま通し、指標も非有限になる（NaN → R² も RMSE も NaN、inf → R² は -inf、RMSE は inf）。発散の検出は各エンジンの責任であり、`EngineFailure` として返す
- Validation: `n_varied_params` は R² の自由度調整には使わないが、`GoodnessOfFit` に保持して利用者がモデル比較時に参照できるようにする。要件 6.2 の比較は利用者の判断に委ねるため、本設計は指標を提示するのみで優劣を計算しない
- Risks: 標準誤差はヤコビアンがフルランクでない場合に算出できない。この場合 `stderr=None` とし、失敗にはしない。サマリ CSV では空欄として出力し、ログに警告を残す
- Risks: 移動平均のように自由度が定義しにくい手法では R² の解釈が通常と異なる。出力に手法名を必ず併記する

### Layer 2: 入出力

#### readers

| Field | Detail |
|-------|--------|
| Intent | CSV/TSV・NumPy 配列・pandas DataFrame の 3 経路を `DataSeries` に正規化する |
| Requirements | 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 7.3, 7.6 |

**Responsibilities & Constraints**

- 3 経路が同一の `DataSeries` に収束することで、要件 1.2 の「同一手順・同一構造」を構造的に保証する。経路ごとに異なる後続処理を持たせてはならない
- 数値変換できない値は `NaN` として通し、除去は `preprocess` が担う。読み込み層で除去すると、要件 2.2 の件数記録が分散する
- 列の欠損・有効データ 0 件を `FitFailure` として返す。例外を送出しない

**Contracts**: Service [x]

```python
@dataclass(frozen=True)
class ColumnSpec:
    x: str | int
    y: str | int
    weight: str | int | None = None       # 1.3

def read_delimited(path: Path, columns: ColumnSpec, delimiter: str | None = None, header: bool | None = None, *, method_name: str) -> DataSeries | FitFailure: ...
def read_frame(frame: pd.DataFrame, columns: ColumnSpec, source_id: str, *, method_name: str) -> DataSeries | FitFailure: ...
def read_arrays(x: ArrayLike, y: ArrayLike, source_id: str, sigma: ArrayLike | None = None, *, method_name: str) -> DataSeries | FitFailure: ...

def column_label(columns: ColumnSpec) -> str: ...          # 7.6
```

**D1: 複数の y 列を扱っても `readers` の契約は変えない。**「1 つの `ColumnSpec` = 1 つの
`DataSeries`」という関係は 3 経路すべてが共有しており、複数系列を返す形に広げると
配列経路（列の概念を持たない）を含む 3 経路の対称性が崩れる。**列の多重性はジョブ格子の
性質であって読み込みの性質ではない。** 複数化は `InputSpec.columns` が持ち、`pipeline` が
列ごとに `readers` を呼ぶ。

- Postconditions: `delimiter` が `None` の場合、拡張子から `.tsv` を tab、それ以外を comma として決定する
- Postconditions: **数値は往復厳密に解釈する**。これは 2 か所に効く。(a) 区切り文字つきファイルの読み込み（`float_precision="round_trip"`）、(b) **文字列から実数への変換全般**。既定の解釈は正確な丸めを行わず、実測で一様乱数の 35〜42% が変化し最大 7375 ulp ずれる。悪条件の当てはめでは推定値が相対 1.7e-08 動き、サマリ CSV の有効数字 10 桁という公約を超える
- Postconditions: (b) が必要なのは、列に欠測として認識されない文字列（機器のエラーコードなど）が **1 つ**混ざると列全体が文字列として扱われ、無関係な正常値まで再解釈されるためである（実測: 2000 点中 1 セルの巻き添えで他の 38.9% が劣化）。要件 2.2 はエラーコードの混在を想定内としており、それが残りのデータを巻き添えにしてはならない。表形式経路に文字列で数値が入る場合も同じ経路を通る
- Invariants: 3 関数はいずれも同一の `DataSeries` 不変条件を満たす。`x`、`y`、`weights` は同一長
- Postconditions: 第 3 系列は重みではなく測定誤差 σ である。σ → 1/σ の変換は `readers` だけが行うため（要件 1.3）、配列経路もファイル経路と同じ σ を受け取る。σ が 0 以下・非有限・逆数が発散する場合は重みを `NaN` とし、行の除去と件数記録は `preprocess` に委ねる
- Postconditions: `method_name` は失敗報告の識別子としてのみ受け取り、値による分岐は行わない（`apply_preprocess` と同じ理由）
- Postconditions: `header` は 3 状態を取る。`None`（未指定）は見出しありとして読むが、**位置による列指定かつ、位置で指定された列における先頭行の値がすべて数値として解釈できる場合は読まずに `HEADER_AMBIGUOUS` を返す**（要件 1.7）。先頭行全体を見るとラベル列・単位列・末尾カンマがあるだけで検査が素通りし、装置出力として最も普通の形で先頭の測定点が黙って失われる。`True` は見出しありとして読み、この検査を行わない（明示指定が推測に優先するという本プロジェクトの規約に従う）。`False` は先頭行からデータとして読む（要件 1.6）
- Postconditions: 見出し行の判定はファイル内容に依存するため `preflight` では検証できない。処理単位ごとの失敗として扱い、要件 6.4 どおり残りの処理は継続する
- Postconditions: 適用した `header` の値は実行条件として記録する（要件 8.3）
- Postconditions: `column_label` は **`ColumnSpec.y` に書かれた指定をそのまま文字列にする**。
  列名指定ならその名前、位置指定ならその位置の数字である。**ファイルの見出し行から読み直さない。**
  実データでは列名がファイルごとに変わるため（`research.md` の G2）、見出しから採ると同じ設定でも
  ファイルごとに別のラベルになり、さらに**ファイルを読む前に出力名を決められなくなる**。
  ジョブ展開の時点で名前が確定することは、要件 7.7 の出力先検証と要件 8.2 の決定性の前提である
- Postconditions: ラベルはファイル名に載るため、`build_output_stem` と同じ規則で安全でない文字を
  置き換える。置換の規則は `writers` が所有し、`readers` は素の文字列を返す
- Postconditions: **解決した y 列の見出し名を `DataSeries.column_name` に載せる**（要件 7.3）。見出しを持たない入力（`header = false`）と、列を解決できずに失敗した場合は `None` である。**この値は出力名には使わない。** 出力名はファイルを読む前に確定する必要があり（要件 7.7 の出力先検証と要件 8.2 の決定性）、見出し名は読んだ後にしか分からない。決定性の要る側と情報量の要る側を、2 つの場に分けて両立させる

#### writers / plotting

| Field | Detail |
|-------|--------|
| Intent | 出力物の形式・命名規則・出力先検証を所有する |
| Requirements | 2.5, 7.3, 7.4, 7.5, 7.6, 7.7, 10.2 |

**Responsibilities & Constraints**

- サマリ CSV の列構成を所有する。**1 行 = (source_id, column_label, method_name, parameter_name) の long 形式**とし、適合度指標は行内で繰り返す（要件 7.3）
- **列を 2 つ持つのは役割が違うためである。** `column_label` は**指定の綴り**であり、ファイルを読む前に確定して出力名にも入る。`column_name` は**解決後の見出し名**であり、読み込み後にしか埋まらない代わりに、位置で指定した場合でもどのチャネルかが分かる。実データでは列名がファイルごとに変わるため位置指定が主経路になり（`research.md` の G2）、`column_label` だけでは `1` / `2` という綴りしか残らない
- 出力ファイル名の一意性を所有する（要件 7.6）。**名前は入力ファイルと y 列の双方を識別する**。y 列が 1 件だけ指定された場合も同じ規則で組み立て、命名規則を 1 通りに保つ
- `plotting` は `Figure` に `FigureCanvasAgg` を直接結び付けて描画を画面非依存にし、`Figure` を 1 つ再利用する。**プロセス大域のバックエンドは変更しない**（実測でキャンバス直結のみでバイト同一の出力が得られる）。大域変更は要件 9.1 の対話環境からの利用を壊すため採らない。他モジュールから matplotlib を import してはならない

**Contracts**: Service [x] / Batch [x]

##### Batch / Job Contract

- Trigger: `pipeline` が各ジョブ完了時に呼ぶ（曲線 CSV・画像）、およびバッチ終了時に呼ぶ（サマリ CSV）
- Input / validation: 出力ディレクトリの書き込み可否は `preflight` が事前検証する
- Output / destination: `{output_dir}/summary.csv`、`{output_dir}/curves/{stem}.csv`、`{output_dir}/plots/{stem}.png`、`{output_dir}/preprocess/{stem}.csv`、`{output_dir}/run.log`、`{output_dir}/execution.json`
- Output / destination: `stem` は `{対象}__{列}__{手法}__{ジョブ番号}`。列は固定の位置に入るため、位置指定に由来する数字（`1` など）がジョブ番号と紛れない。`column_label` が `None` の経路は出力物を書かないため、名前の形は 1 通りのままである
- Idempotency & recovery: 同一設定での再実行は同一パスを上書きする。`stem` はジョブから決定的に導出される

```python
def check_output_writable(directory: Path) -> tuple[ConfigViolation, ...]: ...
def build_output_stem(source_id: str, column_label: str | None, method_name: str, index: int) -> str: ...
def write_summary(outcomes: Sequence[FitOutcome], path: Path) -> None: ...
def write_curve(success: FitSuccess, path: Path) -> None: ...
def write_preprocess(outcome: FitOutcome, path: Path) -> None: ...   # 2.5 除外した点
def render_fit_plot(success: FitSuccess, path: Path) -> None: ...
```

**サマリ CSV の列**

| 列 | 内容 | 要件 |
|----|------|------|
| `source_id` | 入力の識別子 | 8.3 |
| `column_label` | y 列の識別子。**指定の綴り**（列名または位置）。出力名にも入る | 7.3, 7.6 |
| `column_name` | 解決後の**見出し名**。見出しが無い入力や読み込み前の失敗では空 | 7.3 |
| `method_name` | 適用した手法名 | 6.2 |
| `status` | `success` / `failure` | 6.6 |
| `parameter_name` | パラメータ名。パラメータなしの手法では空 | 3.5 |
| `value` | 推定値 | 7.1 |
| `stderr` | 標準誤差。算出不能なら空 | 7.1 |
| `fixed` | 固定パラメータか | 4.5 |
| `r_squared`, `rmse`, `n_points` | 適合度指標。行内で繰り返す | 7.2 |
| `n_dropped_invalid`, `n_dropped_out_of_range`, `n_dropped_outlier` | 前処理の除去件数 | 2.2, 2.3 |
| `failure_reason`, `message` | 失敗時のみ | 1.4, 1.5, 2.4, 4.7 |

**前処理 CSV の列**（`{output_dir}/preprocess/{stem}.csv`）

| 列 | 内容 | 要件 |
|----|------|------|
| `x` | 外れ値と判定した点の独立変数 | 2.5 |
| `y_observed` | その点の実測値 | 2.5 |
| `iteration` | 何回目の反復で除外したか（1 起点） | 2.5 |

**Implementation Notes**

- Integration: **除外した点は専用の CSV に出す**（要件 2.5）。除外件数だけではどの測定点が消えたのかが利用者に届かず、入力 CSV と曲線 CSV の x を突き合わせて再構成させることになる。曲線 CSV に混ぜる案は退けた。曲線 CSV は**成功した処理単位にしか書かれず**（`pipeline._apply_outputs`）、しかもオプトインである（要件 7.5）。要件 2.5 は成功も出力指定も条件にしていない。外れ値を除いた結果として点数不足で落ちる場合（実測で再現）は、まさに x を知りたい場面でありながら曲線 CSV は存在しない
- Integration: **成否によらず、除外が 1 点以上あれば書く。** 「出力物を書き出すのは成功した場合に限る」という本層の規則から外れる唯一の出力である。理由は種類が違うことにある。図と曲線 CSV は**当てはめの結果**であり、失敗した対象に残ると出力ディレクトリの内容とサマリ表の成否が食い違う。前処理 CSV は**前処理が何をしたかの説明**であり、当てはめの成否とは独立に成立する。むしろ失敗した対象でこそ必要になる
- Integration: **系列を直接渡された処理単位では書かない**（要件 9.1、9.3）。`api.fit_series` は出力先を持たず、`_unwritten_output_directory()` が返す共有の一時領域が `output.directory` に入る。現在この経路で何も書かれないのは `write_plot` と `write_curve` が偽であることだけが理由であり、**フラグを持たない出力を足すと利用者の一時領域に書き込む**（実測で確認）。抑止の軸はフラグではなく `Job.series` の有無とする。既存の申し送り（`_unwritten_output_directory` は共有の一時領域を指す）と同じ軸である
- Integration: **オプトインにしない。** 要件 2.5 は出力の有効化を条件にしていない。除外点の報告は「利用者が明示的に求めた追加出力」ではなく「有効にした処理が何をしたかの説明」である。規模の問題も生じない。除外された点だけを並べるため、1 万行の入力で数点が除外される通常の場合は数百バイトに収まる（曲線 CSV は 1 万行で 740 KiB、要件 10.1 の上限規模で 361 MiB。実測）
- Integration: **除外が 0 件の処理単位はファイルを作らない。** 空のファイルが対象ごとに並ぶと、外れ値があった対象を探すのにファイルを開く必要が生じる。存在そのものが「この対象には除外があった」を意味する形にする
- Integration: 並びは**除去順**（反復順、反復内では入力の並び順）とする。`_remove_outliers` が既にこの順で返しており、順序は入力だけで決まる（要件 8.2）。反復回数を列に持つのは、1 回目で外れた点と 3 回目で外れた点が同じ確かさではないためである
- Integration: `outlier_x`（x の値のみ）を `outlier_points`（x・実測値・反復回数）に置き換える。実測値がないと利用者は元データを引かなければ「どんな点が外れ値とされたか」を判断できない。件数との一致（`len(outlier_points) == n_dropped_outlier`）は従来どおり型が検証する
- Integration: **行として残すのは外れ値だけである。** 欠損値・数値として解釈できない行・区間外の行は件数のみを記録する（要件 2.2、2.1）。これらは「読めなかった／範囲外だった」ことが入力を見れば分かる一方、外れ値は**ツールが判定した**結果であり、どの点をそう判定したのかは入力からは分からない
- Integration: **曲線 CSV とグラフは変更しない**（要件 7.4、7.5）。列構成を変えないため、`CURVE_COLUMNS` を利用者から見た契約として写している既存の検査（5 ファイル）に手を入れる必要がない。要件 2.5 が求めるのは出力ファイルへの記録であり、専用 CSV で満たされる。除外点を図に描き足すかは別の判断であり、本要件の範囲外とする
- Risks: 出力ディレクトリに `preprocess/` が加わることは Revalidation Triggers の「出力ファイル命名規則の変更」に触れる。ただし既存の成果物の形式・列・名前はいずれも変えないため、既存の利用者の読み取りは壊れない
- Validation: サマリ CSV の数値は有効数字 10 桁で出力する。報告物として意味のある桁に揃えるためであり、**再現性の担保が目的ではない**。曲線・残差 CSV とグラフは全精度のまま出力し、丸めはサマリ表に限る
- Validation: **丸めは再現性を保証しない。** 値が丸めの境界付近にあれば、揺れが最終桁の刻みより小さくても表記は変わる（必要条件であって十分条件ではない）。実測: 462 データ中 5 件が境界をまたぎ、同一設定・同一入力の 12 回実行で `summary.csv` が 2 種類になった。桁数を減らしても確率が下がるだけで解消しない。平滑化パラメータを必須にすることで直接解法となり、揺れそのものが消える（要件 5.5）
- Integration: **long 形式を選んだ理由** — モデルごとにパラメータ数と名前が異なるため、パラメータを列に展開する wide 形式では複数モデルを 1 つの表に収めた時点で列が破綻する。要件 7.3 の「1 つのサマリ表」と要件 6.2 の「モデルごとの結果を並べて比較」を同時に満たせるのは long 形式のみである。利用者が wide 形式を必要とする場合は pandas のピボットで得られる
- Integration: `build_output_stem` は `source_id` からパス区切りと親ディレクトリ参照を除去し、`{stem}__{列}__{method_name}__{ジョブ番号:04d}` を形とする。**ジョブ番号は常に付与する。** 本関数は 1 ジョブ分の情報しか受け取らないため、他ジョブとの衝突を判定できない。基本形 `{stem}__{列}__{method_name}` は単射ではなく、`run1/sample.csv` と `run2/sample.csv`、`a b.csv` と `a+b.csv`、`("a","_b")` と `("a_","b")` がいずれも同一の基本形に潰れる（実測で確認）。とくに 1 つ目はディレクトリ一括指定（要件 6.1）で最も普通に起きる形であり、条件付き付与では要件 7.6 の無条件保証を満たせない。ジョブ順序が決定的（要件 8.2）であるため、番号の付与も決定的である
- Integration: 出力ディレクトリは**親が存在する場合にのみ最終要素を作成する**。親の連なりごと存在しない指定は `OUTPUT_NOT_WRITABLE` として実行前に拒否する（要件 7.7）。深い打ち間違い（`./a/very/deep/typo/path`）が黙って成功し、利用者が意図した場所に何も無いという事態を防ぐ。1 階層の新規作成は打ち間違いと正当な新規指定を区別できないため許容する。`{output_dir}/curves/` `{output_dir}/plots/` の下位ディレクトリは `writers` が作成する
- Validation: `render_fit_plot` は `Figure` を再利用し、描画のたびに `Axes` をクリアする。ジョブごとの `Figure` 生成は、数百件規模でメモリが線形増加する既知の問題を招く（`research.md` 参照）
- Integration: **前処理 CSV は当てはめ結果より先に書く。** 図と曲線 CSV の書き込みは `OSError` を送出しうる（要件 10.3）。後に書くと、その例外で前処理が何をしたかの記録まで一緒に失われる。実測で再現した — 図の書き込みが失敗する状況で、除外 27 点の記録が残らなかった。前処理 CSV は当てはめ結果とは独立に成立する記録であり、中断の原因を追う手がかりでもある
- Integration: `run_job` は `_run_stages` に本体を委ね、前処理 CSV の書き出しが**どの返り口からも 1 度だけ**通るようにする。成功経路は `_run_stages` の中で当てはめ結果より先に書き終えるため、`run_job` 側は成功でない場合にのみ呼ぶ
- Integration: **平滑化スプラインは重みを反映する**（要件 1.3）。`make_smoothing_spline` は `w` 引数を持つ。当初「点ごとの重みを持ち込む場所が定義されていない」としたのは誤りであった。**渡すのは `weights` そのものではなく `weights ** 2` である。** 本プロジェクトの `weights` は残差に掛かる `1/σ` だが（lmfit の規約。`Σ (w·r)²` を最小化する）、SciPy の `w` は残差の**二乗**に掛かる（`Σ w·r² + λ∫f''²`）。実測で判定した — `lam` を極大にしてスプラインを直線に退化させ、重み付き直線回帰と比べたところ、二乗側の解釈との差が 3.7e-05、残差側との差が 1.2e-01 だった。同じ配列をそのまま渡すと、手法によって測定誤差の効き方が変わる
- Validation: **スプラインでは誤差列の絶対的な大きさが曲線を変える。** 目的関数が `Σ w·r² + λ∫f''²` であるため、重みの倍率は平滑化パラメータ λ と結び付く。σ をすべて 2 倍しても最小二乗・線形回帰・多項式回帰の結果は変わらないが、スプラインでは変わる（実測: σ を一様に 0.1 とすると重みなしとの最大差 4.2e-02、線形回帰は 5.6e-17）。相対的な重みの比較可能性（要件 6.2）は成立するが、σ の単位を変えるとスプラインの滑らかさが変わる点は利用者に伝わる必要がある
- Integration: **移動平均は重みを扱えないため、誤差列の指定を実行前に拒否する**（要件 1.10）。`savgol_filter` に重みの引数は無く、畳み込み係数は窓長と次数だけで決まる。黙って無視すると、測定誤差を与えた利用者がそれが効いた結果として読む。実行ログの警告だけでは、サマリ表だけを読む利用者に届かない。平滑化手法へのパラメータ指定を拒否するのと同じ扱いである（要件 4.4、4.5）
- - Risks: 出力先が実行途中で書けなくなる場合（ディスク枯渇）は `preflight` では検出できない。`RESOURCE_EXHAUSTED` として要件 10.3 の経路で扱う

#### execution / logging_setup

| Field | Detail |
|-------|--------|
| Intent | 実行条件の記録と実行ログの構成 |
| Requirements | 5.4, 8.3, 8.4, 9.4 |

**Responsibilities & Constraints**

- 実行条件の記録には **`InputSpec.columns` の並びをそのまま残す**（要件 8.3）。どの列を
  対象としたかが設定側の記述として残り、再実行が同じ対象集合を再構成できる
- 実行ログの 1 行は処理対象と手法を識別する。`column_label` を `source_id` と併記し、
  1 ファイルの複数チャネルが行として区別できるようにする（要件 8.4）

**Contracts**: State [x]

```python
@dataclass(frozen=True)
class OverrideRecord:
    key: str
    config_value: object | None
    cli_value: object

@dataclass(frozen=True)
class ExecutionRecord:
    started_at: str                              # UTC ISO 8601
    tool_version: str
    library_versions: Mapping[str, str]          # lmfit, asteval, scipy, numpy, pandas, matplotlib
    config_path: str | None
    resolved_config: Mapping[str, object]        # 8.3
    cli_overrides: tuple[OverrideRecord, ...]    # 9.4
    applied_defaults: Mapping[str, object]       # 5.4
```

**Implementation Notes**

- Integration: `execution.json` として出力ディレクトリに書き出す。設定は TOML で読むが記録は JSON で出す。機械可読性と、実行時に解決された値（既定値の適用結果を含む）を素直に表現できるため
- Validation: `library_versions` は要件が明示的に求めるものではないが、要件 8.2 の「同一結果」が同一環境を前提とするため、環境差を後から判別する手段として記録する
- Risks: `resolved_config` に入力ファイルの絶対パスが含まれる。共有時にパス情報が漏れる点は運用上の注意事項であり、steering の Product Boundaries どおり出力物の管理は利用者に委ねる

### Layer 3: 実行条件

#### config

| Field | Detail |
|-------|--------|
| Intent | 設定ファイルと CLI 引数を統合し、唯一の実行条件表現 `RunConfig` を構築する |
| Requirements | 1.11, 1.12, 1.13, 8.1, 8.5, 9.4 |

**Responsibilities & Constraints**

- CLI 引数が設定ファイルより優先する規則を所有する（要件 9.4）。この優先順位が実装される場所は本モジュールのみ
- 上書きが発生した項目を `OverrideRecord` として記録し、`execution` に渡す
- 解釈できない項目・必須項目の欠落を `ConfigViolation` として返す。例外を送出しない（要件 8.5）
- **`y` 列と誤差列の個数不一致を拒否する（要件 1.13）。** これは値域の検証ではなく
  **型に写せるかどうか**の問題である。`y` が N 個・`weight` が M 個で N ≠ M のとき、
  `tuple[ColumnSpec, ...]` はその不一致を表現できない。M > N なら余剰は捨てられ、
  M < N なら不足は `None` に潰れて「誤差列を指定しなかった」場合と区別できなくなる。
  **情報が本層で失われるため、実行前ゲートは `RunConfig` を見ても不一致を検出できない**
  （13.4 の実装とレビューで実測）。写せない指定を拒むのは本層の憲章の範囲内である

**Contracts**: Service [x] / State [x]

```python
class FailurePolicy(StrEnum):
    SKIP = "skip"              # 6.4 既定
    FAIL_FAST = "fail_fast"    # 6.5

@dataclass(frozen=True)
class InputSpec:
    paths: tuple[str, ...]         # ファイル・ディレクトリ・ワイルドカード
    columns: tuple[ColumnSpec, ...]   # 1.11 y 列ごとに 1 件。1 件でも並びで持つ
    delimiter: str | None = None
    header: bool | None = None     # 1.6 未指定 / true / false の 3 状態

@dataclass(frozen=True)
class OutputSpec:
    directory: Path
    write_summary: bool = True     # 7.3
    write_plot: bool = True        # 7.4 既定で出力
    write_curve: bool = False      # 7.5 オプトイン

@dataclass(frozen=True)
class RunConfig:
    inputs: InputSpec
    methods: tuple[MethodSpec, ...]
    preprocess: PreprocessSpec
    output: OutputSpec
    failure_policy: FailurePolicy = FailurePolicy.SKIP

def load_config(
    path: Path, overrides: Mapping[str, object]
) -> tuple[RunConfig, tuple[OverrideRecord, ...]] | tuple[ConfigViolation, ...]: ...
```

- Postconditions: 未知のキーは無視せず `CONFIG_INVALID` 違反として報告する。無視すると設定の綴り誤りが黙って効かなくなり、要件 8 の再現性の意図に反する
- Invariants: `methods` の順序は設定ファイルの記述順を保持する（要件 8.2 の決定性）
- Invariants: `InputSpec.header` は 3 状態を保つ。`None`（未指定）は `False`（見出しなし）と同じではなく、未指定のときだけ `readers` が要件 1.7 の曖昧さ検査を行う
- Invariants: 手法の種別は `builtin` / `expression` / `smoother` のうち**ちょうど 1 つ**を書くことで決まる。`kind` キーは持たない。宣言と実体の食い違いを表現できなくするためであり、利用者定義関数（要件 3.3）はライブラリ経由に限り設定ファイルからは指定できない
- Invariants: 設定ファイル中のパスは記述のまま保持し、設定ファイルからの相対解決は行わない（現在位置からの相対として扱う）。設定由来と実行時引数由来で基準が食い違うのを避けるため。解決後の絶対パスは実行条件の記録に残る
- Postconditions: 設定ファイルを読み込めない場合（不存在・ディレクトリ・権限不足・**UTF-8 として解釈できない符号化**）も `CONFIG_INVALID` の値として返し、例外を送出しない。実行前停止の経路を値の 1 本に保つため

**Open Questions / Risks**

- **誤差列の部分指定ができない。** 要件 1.13 は `y` と `weight` の個数一致を求めるため、
  「2 チャネルのうち 1 つだけ σ がある」形が表現できない。TOML に空値の記法がなく、
  並びの中で「この列は誤差なし」を書く手段がないことが背景にある。**実データで部分指定が
  必要になった時点で要件に差し戻す。** 設計側で迂回記法を先回りして作らない
- **`y` の重複指定（`y = [1, 1]`）は違反として拒否しない。** 同じ列を 2 度当てはめる指定は
  無駄ではあるが、出力名にはジョブ番号が入るため要件 7.6 の上書き禁止は保たれる。手法名の
  重複を違反とするのは名前が利用者の付けた識別子だからであり、列の指定は識別子ではない

#### preflight

| Field | Detail |
|-------|--------|
| Intent | ジョブを 1 件も実行する前に、実行条件の全違反を一括収集する |
| Requirements | 3.4, 4.3, 4.6, 5.4, 7.7, 8.5 |

**Responsibilities & Constraints**

- 「処理を開始しない」種類の要件をすべてここに集約する。この集約が本設計の中心的な判断であり、要件 6.4 の「継続」との境界を一意にする
- 最初の違反で打ち切らず、全項目を検査してから返す
- **`y` 列と誤差列の個数一致は検証しない。要件 1.13 は `config` が所有する**（`#### config` 参照）

**Contracts**: Service [x]

```python
@dataclass(frozen=True)
class PreflightResult:
    violations: tuple[ConfigViolation, ...]

    @property
    def ok(self) -> bool: ...

def validate(config: RunConfig) -> PreflightResult: ...
```

- Postconditions: `ok` が `True` の場合、以降の失敗はデータ個別の事由に限られる
- Invariants: 検査項目は (a) モデル解決可否 3.4、(b) 任意モデルの初期値必須 4.3、(c) 初期値と上下限の整合 4.6、(d) 平滑化オプションの制約 5.4 および平滑化スプラインの平滑化パラメータの必須性 5.5、(e) 平滑化手法に書かれたパラメータ指定の拒否 4.4/4.5/8.5、(f) 重みを扱えない手法への誤差列指定の拒否 1.10、(g) 出力先の書き込み可否 7.7、(h) 設定構造の妥当性 8.5 および 2.1 のフィット区間

**Implementation Notes**

- Validation: モデル解決は `sample=None` で行い、データに依存しない違反のみを検出する。組込モデルの `guess()` はジョブ実行時に改めて呼ばれる
- Risks: 入力パスの存在確認をここで行うか否かは判断が分かれる。**行わない**方針とする。ディレクトリ指定でファイルが 0 件の場合はジョブ 0 件として正常終了し、サマリに 0 件と記録する。存在しないファイルの直接指定は要件 1.4/1.5 の経路で個別失敗として扱う

### Layer 4: 実行

#### pipeline

| Field | Detail |
|-------|--------|
| Intent | ジョブ展開、逐次実行、失敗集約、進捗通知を担う唯一の実行経路 |
| Requirements | 1.11, 2.5, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.8, 8.2, 8.4, 10.1, 10.3 |

**Responsibilities & Constraints**

- 入力集合 × **y 列集合** × モデル集合の直積をジョブ一覧として展開する（要件 6.1、6.8）。3 つの軸で挙動が分岐しない構造を保証する。軸の順序は **入力 → 列 → 手法** であり、同一対象の各手法が隣り合う（要件 6.2 の横並び比較）うえ、同一ファイルの各列も隣接する
- **列ごとに `readers` を呼ぶ。** 処理単位ごとに読み直す形は現在の実装と同じであり、列軸の追加はその回数を掛け算で増やす。読み込みの契約（設計判断 D1）を保つ代償としてこれを受け入れる。
  **実測（10,000 行 1 列）は 23.0 ミリ秒で、これは図以外の費用 22.9 ミリ秒のほぼ全部である**（`research.md` の G4・D2）。2 列 × 3 手法なら同一ファイルを 6 回読み、必要最小の 2 回に対して 92 ミリ秒/ファイルが純粋な無駄になる。ただし同じ条件の総費用は約 1,038 ミリ秒/ファイルであり、**無駄は全体の約 9%** にとどまる。支配的なのは依然として描画の固定費（150 ミリ秒/ジョブ）である。
  読み込み結果をファイル単位で共有する案は採らない。共有すると `Job` が独立に実行できなくなり、要件 6.4 の「個別の失敗が他に波及しない」と要件 10.4 の常駐メモリの頭打ちの双方に影響する。9% の無駄はその代償として受け入れる
- **展開前に入力パスをソートする**。ファイルシステムの走査順は非決定的であり、ソートなしでは要件 8.2 が出力行順のレベルで破れる
- ディレクトリ指定は**再帰せず**、`.csv` / `.tsv` / `.txt`（大文字小文字を問わない）に絞り込む。一括指定に混入する付随ファイル（`.DS_Store` など）を、利用者が設定から直せない個別失敗にしないため。再帰と拡張子の拡張は `**` を含むワイルドカードによる明示指定が担う。ワイルドカードと直接指定は絞り込まない
- 入力指定の分類は**実在するパスを字義優先**とし、`glob` の特殊文字を含む綴りは実在しない場合にのみパターンとして解釈する。ブラケットを含む実在ファイル名がパターン扱いで 0 件に解決され、無報告で消えるのを防ぐ（要件 6.1）
- 失敗ポリシーを所有する。既定は継続、`fail_fast` 指定時のみ中止
- 進捗を `ProgressObserver` に通知する。端末描画は行わない

**Contracts**: Service [x] / Batch [x]

```python
@dataclass(frozen=True)
class Job:
    index: int
    source: str                # ファイルパス、または呼び出し元のラベル
    columns: ColumnSpec        # 1.11 この処理対象が読む x / y / weight の組
    column_label: str | None   # 7.6 出力名とサマリ表に載る y 列の識別子
    method: MethodSpec
    series: DataSeries | None = None   # 読み込み済みの系列（要件 9.1）。`None` なら `source` から読む。
                                       # 処理単位の同一性には含めない（compare=False）

class ProgressObserver(Protocol):
    def on_start(self, total_jobs: int, total_sources: int) -> None: ...
    def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None: ...
    def on_finish(self, report: BatchReport) -> None: ...

@dataclass(frozen=True)
class BatchReport:
    outcomes: tuple[FitOutcome, ...]
    n_success: int
    n_failure: int
    aborted: bool                    # fail_fast または資源枯渇で中断したか
    execution: ExecutionRecord

def expand_jobs(config: RunConfig) -> tuple[Job, ...]: ...

@dataclass(frozen=True)
class JobResult:
    outcome: FitOutcome
    applied_defaults: Mapping[str, float | int]   # 5.4 当てはめが実際に補った既定値

def run_job(job: Job, config: RunConfig) -> JobResult: ...
def run(config: RunConfig, execution: ExecutionRecord, observer: ProgressObserver | None = None, *, series: DataSeries | None = None, retain_curve: bool = False) -> BatchReport: ...
```

- Preconditions: `preflight.validate` が `ok` を返していること
- Postconditions: `len(outcomes) == n_success + n_failure`。中断時は実行済みジョブ分のみを含む（要件 10.3 の「それまでに完了した対象の結果を保持」）
- Postconditions: `outcomes` は**曲線データを保持しない**。`FitSuccess.curve` は書き出し後に手放し、推定値・適合度・成否のみを残す（要件 10.4）。全件分を保持すると常駐メモリが件数に正確に比例して増え、実測で 1 件あたり 4 配列 × 8 バイト × 行数（2 万行なら 625 KiB）、要件 10.1 の上限規模（500 件 × 5 万行）で約 800 MB に達する。曲線は `curves/*.csv` として既にディスクにあり、メモリ上の保持は重複である。単一系列の経路（`api.fit_series`）は従来どおり曲線を返す — 手放すのはバッチ経路に限る
- Postconditions: `run` が返す `BatchReport.execution` は、入力の `ExecutionRecord` に `applied_defaults` を反映したものである。既定値がどのオプションに適用されたかは当てはめが走って初めて確定するため、実行前に組み立てた記録をそのまま返してはならない。`MethodSpec` からの再計算は既定値の所有を 2 か所に分けるため禁じる（要件 5.4）
- Invariants: 同一 `RunConfig` と同一入力に対し、`expand_jobs` は常に同一順序のジョブ列を返す（要件 8.2）
- Raises: `expand_jobs` は、存在するが読み取れないディレクトリに対して `OSError` を送出する。0 件として黙らせると 1 ディレクトリ分の入力が無報告で消えるため。捕捉は `run` が担う
- Invariants: `failure_policy` が `SKIP` のとき、個別ジョブの失敗は `run` を中断させない

**Implementation Notes**

- Integration: ジョブごとに `models.resolver.resolve(spec, sample=series)` を呼び直す。組込モデルの初期値をそのジョブのデータから推定するため（要件 4.1）
- Integration: **`preprocess` への `min_points` と `provisional_fit` は `pipeline` が供給する**。`min_points` は解決済み `PreparedMethod` の**推定対象**パラメータ数（`parameter_names` から `MethodSpec.fixed` の指定を除いた個数）から導出し（要件 2.4 / 4.5。固定パラメータを数えると当てはめ可能なジョブが点数不足と誤報される）、`provisional_fit` は `select_engine` で得たエンジンを束ねたクロージャとして渡す。前処理層が手法を知らずに済む構造（要件 2.4 の判定に必要な情報だけを受け取る）は、この供給責任を `pipeline` に置くことで成立する
- Integration: `MemoryError`、**ジョブ展開時の `OSError`**、および出力書き込み時の `OSError` を捕捉し、`RESOURCE_EXHAUSTED` として `aborted=True` で終了する。それまでの `outcomes` とサマリ CSV は保持する（要件 10.3）。展開時に送出された場合 `outcomes` は空である。**入力読み込み時の `OSError`（存在しない・読み取れないファイル）はここに含めない。** 個別データの失敗（`INPUT_UNREADABLE`、要件 1.8）であり、要件 6.4 どおり既定ではスキップして継続する。1 件の綴り誤りで数百件のバッチが止まってはならない
- Integration: **入力指定が 0 件に解決された場合は、その指定を明示して実行ログに警告を残す**。ディレクトリの拡張子絞り込み、綴り誤り、マッチしないワイルドカードのいずれも 0 件になるが、黙って正常終了すると 1 ディレクトリ分の入力が無報告で消える（要件 6.1）
- Validation: 進捗通知には総ジョブ数と総入力数の両方を渡す。ジョブ数は入力数 × モデル数であり、利用者が直感的に把握するファイル数と一致しないため
- Risks: 逐次実行で要件 10.2 の性能目標を満たせない場合、並列化ではなくグラフ出力の既定値を見直す。並列化は要件 8.2 の決定性検証を著しく複雑にする

#### api

| Field | Detail |
|-------|--------|
| Intent | ライブラリ利用者に対する公開ファサード |
| Requirements | 1.2, 9.1, 9.3 |

**Contracts**: Service [x]

```python
def fit_series(
    series: DataSeries,
    method: MethodSpec,
    preprocess: PreprocessSpec | None = None,
) -> FitOutcome: ...

def run_batch(
    config: RunConfig,
    observer: ProgressObserver | None = None,
) -> BatchReport | PreflightResult: ...

def run_from_config(
    path: Path,
    overrides: Mapping[str, object] | None = None,
    observer: ProgressObserver | None = None,
) -> BatchReport | PreflightResult: ...

class PreflightAborted(RuntimeError):
    """実行前検証の違反。`fit_series` のみが送出する。

    `fit_series` の返り型 `FitOutcome` には違反を載せる欄がなく、`FailureReason` は
    実行中のデータ個別失敗の分類であって設定違反を表す語を持たない。`run_batch` と
    `run_from_config` は返り型に余地があるため値として返す。
    """
```

- Postconditions: `fit_series` は単一ジョブを `pipeline` と同一の処理順序で実行する。要件 9.3 の同一性は、CLI とライブラリが `pipeline.run` を共有することで構造的に保証される。差込口は `pipeline` 側の `Job.series` にあり、`run_job` が省くのは読み込みの 1 段だけである。`api` は当てはめの順序を持たない
- Postconditions: `fit_series` は出力物・実行ログ・実行条件の記録を一切書かず、一時ファイルも作らない。要件 8.3 / 8.4 の記録はファイル入力の経路が担う。返り値で結果を受け取る用途であり、利用者が指定していない場所に表や図を残す理由がない
- Invariants: 公開シグネチャに lmfit / SciPy / matplotlib の型を含めない

### Layer 5: 入口

#### cli

| Field | Detail |
|-------|--------|
| Intent | 引数解析、進捗描画、終了コードの決定 |
| Requirements | 6.3, 9.2, 9.4, 9.5 |

**Responsibilities & Constraints**

- `--y-column` は**列の並びを 1 件に置き換える**。複数列と位置指定は設定ファイルが担う。
  要件 9.2 は設定ファイル経由で全条件を実行できることを求めており、引数側の表現力を
  設定ファイルに揃える必要はない。並びを引数で表現できるようにすると、
  上書きの単位（並び全体か 1 要素か）が曖昧になる

**Contracts**: Service [x]

```python
class ExitCode(IntEnum):
    SUCCESS = 0            # 全ジョブ成功
    PARTIAL_FAILURE = 1    # 1 件以上の失敗、または中断
    CONFIG_ERROR = 2       # 実行前ゲートで停止

def main(argv: Sequence[str] | None = None) -> int: ...
```

- Postconditions: `ProgressObserver` の端末実装を提供し、`pipeline` に渡す（要件 6.3）
- Postconditions: CLI 引数は `config.load_config` の `overrides` として渡す。CLI 自身は優先順位を判断しない（要件 9.4 の実装箇所を 1 か所に保つ）
- Invariants: 本モジュールは `curvefit` の他モジュールから import されない

## Error Handling

### Error Strategy

エラーを 2 系統に分け、それぞれ異なる機構で運ぶ。

| 系統 | 表現 | 収集 | 帰結 |
|------|------|------|------|
| 実行前違反 | `ConfigViolation`（値） | `preflight` が全件収集 | ジョブを 1 件も実行せず終了コード 2 |
| 実行中失敗 | `FitFailure`（値） | `pipeline` が集約 | 既定は継続、`fail_fast` 時は中止。終了コード 1 |

例外を制御フローに使うのは、資源枯渇（`MemoryError` / `OSError`）の捕捉のみに限る。それ以外の想定内の失敗はすべて値として返す。steering `structure.md` の「失敗は値として運ぶ」に対応する。

**第 3 の系統として `UnexpectedConfigViolation`（例外）を置く。** これは上の 2 系統のいずれでもない。実行前ゲートを通過したはずの指定が処理単位ごとの解決で違反として返った場合、`pipeline` はこれを送出する。`preflight.validate` が `ok` を返していることは `pipeline.run` の Precondition であり、ここに違反が届くのは利用者のデータや設定ではなく**呼び出し側が Precondition を破ったこと**を意味する。値として返すと、呼び出し側の誤りが利用者向けの失敗報告に紛れる。`api` が公開する（要件 9.1 の利用者から見える名前である）。

### Error Categories and Responses

- **利用者の設定誤り**（実行前）— 該当箇所（設定ファイル内の位置または CLI 引数名）と、期待される値の形を提示する。全違反を一度に提示し、修正の往復を減らす
- **データ個別の問題**（実行中）— `source_id` と `method_name` を必ず含める。数百件のバッチでは対象を特定できないエラーは実質的に無価値である（steering `tech.md`）
- **収束しなかった場合** — 使用した初期値を併記する（要件 4.7）。利用者の次の行動が初期値の見直しであるため
- **資源枯渇** — 中断した対象を明示し、それまでの結果とサマリを保持する（要件 10.3）

### Monitoring

`run.log` に、実行開始時の解決済み設定、ジョブごとの成否と理由、終了時の成功/失敗件数を記録する（要件 8.4）。`stderr` は算出不能時に警告として記録する。ログ順序はジョブ順序に従い決定的である。

### 図中の日本語表示

`plotting` は実行環境に存在する日本語グリフを持つフォントを選び、選んだ名前を実行条件に `plot_font` として記録する（要件 8.3）。選定を記録するのは、同じ設定でも環境によって図の見た目が変わりうるためであり、後から差分の出どころを判別できるようにする。matplotlib の既定フォントは日本語グリフを持たず、題や軸ラベルが豆腐になる。**大域の `rcParams` は変更しない**（要件 9.1 のライブラリ利用者の環境を書き換えないため。`figure` ごとに指定する）。

## Testing Strategy

### Unit Tests

- `models.resolver`: 組込モデル名の解決（3.1）、未知名で `MODEL_UNRESOLVED`（3.4）、数式文字列からのパラメータ名抽出（3.2、3.5）、任意モデルで初期値未指定なら `INITIAL_REQUIRED`（4.3）、初期値が上下限外なら `INITIAL_OUT_OF_BOUNDS`（4.6）、明示初期値が `guess()` に優先すること（4.2）
- `models.expression`: 関数として呼ばれた予約名がパラメータにならず受け入れられること（3.8）、円周率 `pi` の値参照が従来どおり成功すること（3.6）、`pi` 以外の予約名の値参照が `MODEL_UNRESOLVED` になり**メッセージが記号名と別名の案内を含むこと**（3.7）、同じ名前を値と関数の双方で使った式でも値参照が検出されること（3.8）、真偽値リテラルは違反にならないこと（3.6）、**`VALUE_CONSTANTS` の各要素が実際にパラメータにならないこと**（3.6 の前提。評価器が当該の名前を持たなくなると、それが静かにパラメータに変わる）
- `preprocess`: 区間外の点が除外され件数が記録されること（2.1）、`NaN` と数値変換不能行の除去件数（2.2）、外れ値の除去件数の記録（2.3）と除外点の位置・実測値の記録（2.5）、残点数がパラメータ数未満で `INSUFFICIENT_POINTS`（2.4）、暫定フィット非収束時に外れ値除去をスキップして継続すること
- `engines.least_squares`: 既知パラメータで生成した合成データからの推定値復元（許容誤差内、7.1）、`stderr` が有限値になること（7.1）、`fixed` 指定パラメータが厳密に不変であること（4.5）、推定値が上下限内に収まること（4.4）、初期値なしの組込モデルが `guess()` で収束すること（4.1）、重み付き入力で重みが効くこと（1.3）、非収束時に初期値を含む `EngineFailure`（4.7）
- `engines.smoothing`: 4 手法それぞれが `EngineSuccess` を返すこと（5.1）、パラメータを持つ手法が最小二乗と同一形式で出力すること（5.3）、窓長未指定時に既定値が適用され `applied_defaults` に記録されること（5.4）
- `engines.base.compute_goodness`: 既知の残差に対する R² と RMSE の値（7.2）

### Integration Tests

- `preflight`: 予約名を値として使う数式が、実行前ゲートで `MODEL_UNRESOLVED` として収集されること（3.7）。報告箇所が `method[{手法名}].expression` であり、`initial` の「パラメータが存在しない」という紛らわしいメッセージに**置き換わる**こと（3.7）
- `readers`: 同一データを CSV・NumPy 配列・DataFrame で読み込み、`DataSeries` と最終的な推定値が一致すること（1.2）。誤差列指定で `weights` が設定されること（1.3）。存在しない列指定で `COLUMN_NOT_FOUND`（1.4）。全行が無効なファイルで `NO_VALID_DATA`（1.5）
- `config` + `preflight`: `y` と `weight` を並びで書けること、および 1 件だけの記法も受け付けること（1.11、1.12）。個数が一致しない指定が `CONFIG_INVALID` として実行前に拒否され、対応付けられない指定内容が示されること（1.13）。TOML の読み込みと `RunConfig` 構築（8.1）、CLI 上書きが設定ファイルに優先し `OverrideRecord` に残ること（9.4）、必須項目欠落と未知キーで `CONFIG_INVALID` を返し処理を開始しないこと（8.5）、書き込み不可なディレクトリで `OUTPUT_NOT_WRITABLE`（7.7）、複数違反が一度に返ること
- `pipeline`: 3 ファイル × 2 列 × 2 モデルで 12 ジョブに展開され、軸の順序が 入力 → 列 → 手法 であること（6.1、6.8、1.11）。列を 1 件だけ指定した場合も同じ規則で展開されること。3 ファイル × 2 モデルで 6 ジョブに展開されること（6.1、6.2）、入力順が非決定的でもジョブ順が常に同一になること（8.2）、1 件失敗しても残りが処理され `n_success`/`n_failure` が正しいこと（6.4、6.6）、`fail_fast` で最初の失敗以降が実行されず既存結果が保持されること（6.5）、`ProgressObserver` が総数と完了数を受け取ること（6.3）
- `writers`: 出力名が入力と y 列の双方を含み、**同一ファイルの別の列どうしが互いを上書きしないこと**（7.6）。y 列 1 件のときも名前に列が入ること。サマリ表の各行が `column_label` で対象の列を識別できること（7.3）。サマリ CSV の列構成と、パラメータ数の異なる 2 モデルが同一表に共存すること（7.3、6.2）、既定でプロットが生成され曲線 CSV が生成されないこと（7.4、7.5）、同名になりうる 2 入力で出力パスが衝突しないこと（7.6）
- `writers`: 外れ値を含む入力で前処理 CSV が書かれ、**除外した各点の x・実測値・反復回数が除去順に並ぶこと**（2.5）。除外 0 件ではファイルを作らないこと。**外れ値を除いた結果として失敗した処理単位でも書かれること**（2.5 は成功を条件にしない）。曲線 CSV の列構成が従来と一致すること（7.5 の非退行）。同一入力の再実行でバイト一致すること（8.2）

### E2E Tests

- CLI で 1 ディレクトリを処理し、サマリ CSV・プロット・ログ・実行条件記録が生成され終了コードが 0 になること（9.2、9.5、8.3、8.4）
- 同一設定・同一入力で 2 回実行し、サマリ CSV がタイムスタンプ列を除いて完全一致すること（8.2）
- 同一の入力と実行条件を、CLI とライブラリ `run_batch` の両方で実行し、推定値が一致すること（9.3）
- 失敗を含むバッチで終了コードが 1 になり、ログに `source_id` と失敗理由が記録されること（6.6、8.4、9.5）
- 設定ファイルに誤りがある状態で実行し、出力ディレクトリに何も生成されず終了コードが 2 になること（8.5）

### Performance Tests

- 500 ファイル × 10,000 行、グラフ出力あり、逐次実行で 5 分以内に完了すること（10.1、10.2）
- 同バッチ実行中の常駐メモリが頭打ちになり、ジョブ数に比例して増加しないこと（10.4）。matplotlib の Figure 再利用が機能していることの回帰検出を兼ねる
- 1 ファイル 100,000 行での単一フィットが実用時間内に完了すること（10.1 の上限側の確認）
- **既定実行の見張り**（`tests/performance/test_default_run_sentinel.py`、マーカーを付けない）— 8 件を 1 万行・グラフ出力ありで処理し、1 件あたりの時間を要件 10.2 から導いた上限（300 秒 ÷ 500 件 = 600 ミリ秒/件）で検査する。全規模の検証はマーカー配下に残したまま、**大きな劣化を既定実行で早く捕らえる**ためのものである。費用は約 2 秒。件数比例の費用（10.1）・常駐メモリ（10.4）・十万行の計算量は捕らえられない

## Security Considerations

本機能で固有の判断が必要なのは、数式文字列の評価に伴う任意コード実行リスクのみである。

- **信頼境界**: 設定ファイルは実行者自身が記述する前提であり、信頼境界の内側にある。数式文字列は asteval が評価するが、asteval は `eval()` より安全であるものの完全なサンドボックスではないと作者自身が明記している
- **依存下限の固定**: asteval `<=1.0.5` には sandbox escape の脆弱性がある（GHSA-vp47-9734-prjw、CVSS 8.4）。lmfit の依存宣言は `asteval>=1.0` と緩いため、本プロジェクトの `pyproject.toml` で `asteval>=1.0.6` を明示的に指定する
- **利用者への警告**: 第三者から受け取った設定ファイルをそのまま実行することは、任意の Python コードを実行することと同等のリスクを持つ。この旨を CLI のヘルプと README に明記する
- **ユーザー定義関数**: 要件 3.3 の Python 関数指定はライブラリ利用時のみであり、呼び出し元は既に任意コードを実行できる文脈にある。追加のリスクはない
- **出力パスの正規化**: `source_id` から出力ファイル名を導出する際、パス区切りと親ディレクトリ参照を除去し、出力が指定ディレクトリ外に書き出されないようにする

## Performance & Scalability

- **目標**: 500 ファイル × 10,000 行、グラフ出力ありで 5 分以内（要件 10.1、10.2 の「数百件」「数分以内」を測定可能な形にしたもの）
- **支配的コスト**: フィット自体はミリ秒オーダーであり、支配的なのはグラフ描画である。したがって最適化はまず描画に向ける
- **採用する対策**: Agg キャンバスの直結、`Figure` の再利用、`Axes` のクリアによる再描画、`pyplot` の不使用。ジョブごとの `Figure` 生成は数百件規模でメモリが線形増加する既知の問題を招く（実測: 200 対象で本方式 +2.6 MB に対し close 無しの pyplot は +599 MB）
- **採用しない対策**: 並列実行。要件 8.2 の決定性検証、ログ順序、失敗集約のすべてを複雑にする。目標未達の場合はグラフ出力の既定値（要件 7.4）を含めて要件側に差し戻す
- **スケール限界**: 数千ファイル規模は本設計の想定外である。到達した場合は Revalidation Triggers に従い再設計する
