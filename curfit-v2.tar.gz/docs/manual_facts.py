"""ユーザーマニュアルが列挙している実装上の事実。

**この表は宣言であって、実装からの読み取りではない。** 実装を import して作ると、
実装が変わったときに宣言も一緒に変わってしまい、「ドキュメントが古い」ことを
検出できなくなる。ここには手で書いた値だけを置く。

`tests/docs/test_manuals_stay_in_sync.py` が次の 2 方向を検査する。

1. ここに書いた値と実装の値が一致すること
   → 実装に項目を足す・消す・綴りを変えると落ちる
2. ここに書いたすべての名前が、4 つの生成スクリプトの本文に現れること
   → この表だけ直してドキュメント本文を直し忘れると落ちる

つまり「実装を変えたらドキュメントも直す」ことが人の注意ではなく検査で守られる。
落ちたときの手順は docs/README.md にある。
"""

# 設定ファイルのキー（src/curvefit/config.py）
TOP_LEVEL_KEYS = ("failure_policy", "input", "methods", "output", "preprocess")
INPUT_KEYS = ("columns", "delimiter", "header", "paths")
COLUMNS_KEYS = ("weight", "x", "y")
METHOD_KEYS = (
    "bounds",
    "builtin",
    "expression",
    "fixed",
    "initial",
    "name",
    "options",
    "smoother",
)
BOUND_KEYS = ("max", "min")
PREPROCESS_KEYS = ("outlier", "x_max", "x_min")
OUTLIER_KEYS = ("max_iterations", "sigma")
OUTPUT_KEYS = ("directory", "write_curve", "write_plot", "write_summary")

# 実行時引数で上書きできる項目（要件 9.4）
OVERRIDABLE_KEYS = (
    "failure_policy",
    "input.columns.weight",
    "input.columns.x",
    "input.columns.y",
    "input.delimiter",
    "input.header",
    "input.paths",
    "output.directory",
    "output.write_curve",
    "output.write_plot",
    "output.write_summary",
)

# 出力の列（src/curvefit/writers.py）
SUMMARY_COLUMNS = (
    "source_id",
    "column_label",
    "column_name",
    "method_name",
    "status",
    "parameter_name",
    "value",
    "stderr",
    "fixed",
    "r_squared",
    "rmse",
    "n_points",
    "n_dropped_invalid",
    "n_dropped_out_of_range",
    "n_dropped_outlier",
    "failure_reason",
    "message",
)
CURVE_COLUMNS = ("x", "y_observed", "y_fit", "residual")
PREPROCESS_COLUMNS = ("x", "y_observed", "iteration")
SUMMARY_SIGNIFICANT_DIGITS = 10

# 実行前検証の違反と、処理単位ごとの失敗理由（src/curvefit/errors.py）
VIOLATION_KINDS = (
    "config_invalid",
    "model_unresolved",
    "initial_required",
    "initial_out_of_bounds",
    "output_not_writable",
    "smoother_option_invalid",
)
FAILURE_REASONS = (
    "column_not_found",
    "no_valid_data",
    "insufficient_points",
    "not_converged",
    "header_ambiguous",
    "input_unreadable",
    "resource_exhausted",
)

# 手法（src/curvefit/models/registry.py、src/curvefit/engines/smoothing.py）
BUILTIN_MODELS = ("linear", "polynomial", "gaussian", "exponential")
SMOOTHERS = {
    "linear": (),
    "polynomial": ("degree",),
    "spline": ("lam",),
    "moving_average": ("window", "polyorder"),
}

# 実行記録のキー（src/curvefit/execution.py）
EXECUTION_RECORD_KEYS = (
    "started_at",
    "tool_version",
    "library_versions",
    "config_path",
    "resolved_config",
    "cli_overrides",
    "applied_defaults",
)

# 生成スクリプトと、それが書き出すファイル。README とテストの双方が参照する。
GENERATORS = {
    "make_curvefit_manual_ppt.py": "curvefit_ユーザーマニュアル.pptx",
    "make_curvefit_manual_ppt_en.py": "curvefit_User_Manual_EN.pptx",
    "make_curvefit_manual_docx.py": "curvefit_ユーザーマニュアル_詳細版.docx",
    "make_curvefit_manual_docx_en.py": "curvefit_User_Manual_Detailed_EN.docx",
}

# 詳細版（Word）だけが列挙する事実。スライドは要点に絞るため、これらは載せない。
DETAILED_ONLY = (
    "METHOD_KEYS",
    "BOUND_KEYS",
    "OUTLIER_KEYS",
    "OVERRIDABLE_KEYS",
    "SUMMARY_COLUMNS",
    "CURVE_COLUMNS",
    "PREPROCESS_COLUMNS",
    "VIOLATION_KINDS",
    "FAILURE_REASONS",
    "EXECUTION_RECORD_KEYS",
    "BUILTIN_MODELS",
)
