"""curvefit ユーザーマニュアル（詳細版）Word 文書生成スクリプト

スライド版（make_curvefit_manual_ppt.py）が「まず動かす」ための資料であるのに対し、
本書は**引ける資料**を目指す。設定項目・出力列・違反種別・失敗理由を網羅する。

内容の出どころはすべてコードと実行結果である。
  - 設定キー          : src/curvefit/config.py の *_KEYS
  - 組込モデル        : src/curvefit/models/registry.py（パラメータ名は実行して確認）
  - 平滑化の選択肢    : src/curvefit/engines/smoothing.py
  - 前処理と外れ値    : src/curvefit/preprocess.py
  - 出力列            : src/curvefit/writers.py
  - 違反種別・失敗理由: src/curvefit/errors.py
  - コマンド引数      : curvefit --help
コマンドや設定キーを変えたときは、本スクリプトの該当節も直すこと。
"""
import pathlib

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

FONT   = "Yu Gothic"
FONTM  = "Consolas"

INK    = RGBColor(0x1A, 0x1A, 0x1A)
GRAY   = RGBColor(0x5A, 0x55, 0x50)
ACCENT = RGBColor(0xB5, 0x5A, 0x38)
DEEP   = RGBColor(0x2E, 0x4A, 0x62)
BAD    = RGBColor(0xB5, 0x3A, 0x2E)
GOOD   = RGBColor(0x2F, 0x6B, 0x38)

CODE_FILL = "F2F0EC"
HEAD_FILL = "2E4A62"
WARN_FILL = "FBF0E8"
OK_FILL   = "EEF4EE"
ROW_FILL  = "F6F4F1"


# 目次に載せる見出し。本文の heading() 呼び出しと 1 対 1 で照合する。
OUTLINE = [
    (1, "1. はじめに"),
    (2, "1.1 本書の目的"),
    (2, "1.2 curvefit が解決すること"),
    (2, "1.3 用語"),
    (2, "1.4 全体の流れ"),
    (1, "2. 導入"),
    (2, "2.1 動作条件"),
    (2, "2.2 インストール"),
    (2, "2.3 開発時に使う検査"),
    (1, "3. 基本的な使い方"),
    (2, "3.1 最小構成"),
    (2, "3.2 生成される出力"),
    (2, "3.3 複数の手法を比較する"),
    (1, "4. 設定ファイル リファレンス"),
    (2, "4.1 全体構造"),
    (2, "4.2 [input]"),
    (2, "4.3 [input.columns]"),
    (2, "4.4 [[methods]]"),
    (2, "4.5 [preprocess]"),
    (2, "4.6 [preprocess.outlier]"),
    (2, "4.7 [output]"),
    (2, "4.8 設定ファイル全体の例"),
    (1, "5. 手法 リファレンス"),
    (2, "5.1 組込モデル（builtin）"),
    (2, "5.2 数式（expression）"),
    (2, "5.3 回帰・平滑化（smoother）"),
    (1, "6. 前処理"),
    (2, "6.1 範囲による除外"),
    (2, "6.2 外れ値除去"),
    (1, "7. 入力データの読み取り"),
    (2, "7.1 区切り文字"),
    (2, "7.2 見出し行"),
    (2, "7.3 列を位置で指定する"),
    (2, "7.4 1 つのファイルに測定チャネルが複数ある場合"),
    (2, "7.5 数値の読み取り精度"),
    (1, "8. 出力 リファレンス"),
    (2, "8.1 出力物の一覧"),
    (2, "8.2 出力ファイル名の規則"),
    (2, "8.3 summary.csv の列"),
    (2, "8.4 曲線 CSV と前処理 CSV の列"),
    (2, "8.5 execution.json"),
    (2, "8.6 run.log"),
    (1, "9. コマンドライン リファレンス"),
    (2, "9.1 書式"),
    (2, "9.2 オプション一覧"),
    (2, "9.3 上書きできる項目"),
    (2, "9.4 終了コード"),
    (2, "9.5 標準出力と標準エラー出力"),
    (1, "10. エラーと対処"),
    (2, "10.1 実行前検証の違反"),
    (2, "10.2 処理単位ごとの失敗"),
    (2, "10.3 よくあるつまずき"),
    (1, "11. Python ライブラリとして使う"),
    (2, "11.1 設定ファイルから一括実行する"),
    (2, "11.2 実行条件を組み立てて実行する"),
    (2, "11.3 メモリ上の 1 系列に当てはめる"),
    (2, "11.4 主な公開型"),
    (1, "12. 再現性とセキュリティ"),
    (2, "12.1 再現性"),
    (2, "12.2 セキュリティ"),
    (1, "13. 以前の版からの移行"),
    (1, "付録 A 設定項目の早見表"),
    (1, "付録 B 仕様と設計の記録"),
]

_outline_left = list(OUTLINE)

# ---------------------------------------------------------------- primitives

def _set_run_font(run, name, size=None, bold=None, color=None):
    """Word は欧文と日本語で別々にフォントを引くため、両方に同じ名前を入れる。"""
    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rfonts.set(qn(attr), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color


def _shade(element, fill):
    """段落または表セルに背景色を敷く。"""
    pr = element.get_or_add_pPr() if element.tag.endswith("}p") else element.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    pr.append(shd)


def _borders(paragraph, color="D8D2C8", size=6, sides=("top", "left", "bottom", "right")):
    pbdr = OxmlElement("w:pBdr")
    for side in sides:
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(size))
        el.set(qn("w:space"), "6")
        el.set(qn("w:color"), color)
        pbdr.append(el)
    paragraph._p.get_or_add_pPr().append(pbdr)


def _keep_with_next(paragraph):
    """見出しや表題が単独で改ページの底に残らないようにする。"""
    el = OxmlElement("w:keepNext")
    paragraph._p.get_or_add_pPr().append(el)


# ------------------------------------------------------------------ builders

def title_page(doc, title, subtitle, lines):
    for _ in range(4):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(p.add_run("curvefit"), FONTM, 40, True, DEEP)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(p.add_run(title), FONT, 26, True, INK)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(p.add_run(subtitle), FONT, 13, False, GRAY)
    doc.add_paragraph()
    for line in lines:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_run_font(p.add_run(line), FONT, 10.5, False, GRAY)


def heading(doc, text, level):
    # 目次と本文がずれたまま出力されるのを防ぐ。ずれたらその場で失敗させる。
    if text != "目次":
        assert _outline_left, f"目次に無い見出し: {text}"
        expected = _outline_left.pop(0)
        assert expected == (level, text), f"目次と本文の食い違い: {expected} != {(level, text)}"
    sizes = {1: 18, 2: 14, 3: 12}
    colors = {1: DEEP, 2: INK, 3: INK}
    p = doc.add_heading("", level=level)
    p.paragraph_format.space_before = Pt(30 if level == 1 else 12)
    p.paragraph_format.space_after = Pt(6)
    _set_run_font(p.add_run(text), FONT, sizes[level], True, colors[level])
    _keep_with_next(p)
    return p


def body(doc, text, size=10.5, color=INK, space_after=6):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.15
    _set_run_font(p.add_run(text), FONT, size, False, color)
    return p


def rich(doc, parts, size=10.5, space_after=6):
    """parts: (text, bold, mono, color) の並び。1 段落に混在させる。"""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.15
    for text, bold, mono, color in parts:
        _set_run_font(p.add_run(text), FONTM if mono else FONT, size, bold, color)
    return p


def bullets(doc, items, size=10.5):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.line_spacing = 1.15
        if isinstance(item, tuple):
            lead, rest = item
            _set_run_font(p.add_run(lead), FONTM, size, True, ACCENT)
            _set_run_font(p.add_run(rest), FONT, size, False, INK)
        else:
            _set_run_font(p.add_run(item), FONT, size, False, INK)


def code(doc, lines, size=9.5):
    """コードブロック。1 段落にまとめると改ページで分断されにくい。"""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.left_indent = Cm(0.3)
    p.paragraph_format.line_spacing = 1.0
    _shade(p._p, CODE_FILL)
    _borders(p)
    for i, line in enumerate(lines):
        if i:
            # 改行は独立した run に置く。text の代入は同じ run の内容を捨てるため、
            # 1 つの run に改行と文字を同居させると改行が消える。
            _set_run_font(p.add_run(), FONTM, size)
            p.runs[-1].add_break()
        _set_run_font(p.add_run(line if line else " "), FONTM, size, False, INK)
    return p


def callout(doc, text, kind="warn"):
    fill = WARN_FILL if kind == "warn" else OK_FILL
    color = BAD if kind == "warn" else GOOD
    mark = "注意" if kind == "warn" else "補足"
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.left_indent = Cm(0.3)
    p.paragraph_format.line_spacing = 1.15
    _shade(p._p, fill)
    _borders(p, color="D8D2C8")
    _set_run_font(p.add_run(f"{mark}  "), FONT, 10, True, color)
    _set_run_font(p.add_run(text), FONT, 10, False, INK)
    return p


def table(doc, headers, rows, widths=None, mono_cols=(), size=9.5):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    t.autofit = False
    # autofit を切るだけでは列幅の指定が無視される。レイアウトを固定にして初めて効く。
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    t._tbl.tblPr.append(layout)
    for i, text in enumerate(headers):
        cell = t.rows[0].cells[i]
        cell.text = ""
        _shade(cell._tc, HEAD_FILL)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(2)
        _set_run_font(p.add_run(text), FONT, size, True, RGBColor(0xFF, 0xFF, 0xFF))
        _keep_with_next(p)
    # 見出し行はページをまたぐたびに繰り返す。
    head_pr = t.rows[0]._tr.get_or_add_trPr()
    head_pr.append(OxmlElement("w:tblHeader"))
    head_pr.append(OxmlElement("w:cantSplit"))
    for r, row in enumerate(rows):
        tr = t.add_row()
        # 行がページ境界で断ち割られると、空の続き行が現れて読めなくなる。
        tr._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        cells = tr.cells
        for i, text in enumerate(row):
            cell = cells[i]
            cell.text = ""
            if r % 2:
                _shade(cell._tc, ROW_FILL)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.line_spacing = 1.05
            _set_run_font(p.add_run(text), FONTM if i in mono_cols else FONT, size, False, INK)
    if widths:
        # 幅はセル（w:tcW）と表の骨格（w:tblGrid）の両方に書く。片方だけでは
        # 描画側が骨格のほうを採り、指定が無視される。
        twips = [round(w * 566.93) for w in widths]
        grid = t._tbl.find(qn("w:tblGrid"))
        if grid is not None:
            for col, value in zip(grid.findall(qn("w:gridCol")), twips, strict=False):
                col.set(qn("w:w"), str(value))
        tbl_w = OxmlElement("w:tblW")
        tbl_w.set(qn("w:w"), str(sum(twips)))
        tbl_w.set(qn("w:type"), "dxa")
        t._tbl.tblPr.append(tbl_w)
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def caption(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(3)
    _set_run_font(p.add_run(text), FONT, 9, True, GRAY)
    _keep_with_next(p)
    return p


def toc(doc):
    """目次。Word で更新すればページ番号付きの自動目次に変わる。

    フィールドの「結果」として静的な見出し一覧を埋めておく。更新されない環境でも
    章立てが読めるようにするためである。
    """
    lead = doc.add_paragraph()
    run = lead.add_run()
    _set_run_font(run, FONT, 10.5)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    begin.set(qn("w:dirty"), "true")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = r'TOC \o "1-2" \h \z \u'
    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    for el in (begin, instr, sep):
        run._r.append(el)

    for level, text in OUTLINE:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.left_indent = Cm(0.0 if level == 1 else 0.8)
        _set_run_font(p.add_run(text), FONT, 11 if level == 1 else 10,
                      level == 1, DEEP if level == 1 else INK)

    tail = doc.add_paragraph()
    tail.paragraph_format.space_before = Pt(10)
    _set_run_font(tail.add_run(
        "※ Word で本文を全選択して F9 を押すと、ページ番号付きの目次に更新されます。"),
        FONT, 9, False, GRAY)
    run = tail.add_run()
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(end)


def page_number_footer(section):
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    _set_run_font(run, FONT, 9, False, GRAY)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for el in (begin, instr, end):
        run._r.append(el)


def header_text(section, text):
    p = section.header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    _set_run_font(p.add_run(text), FONT, 9, False, GRAY)


def page_break(doc):
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


# ------------------------------------------------------------------ document

doc = Document()

style = doc.styles["Normal"]
style.font.name = FONT
style.font.size = Pt(10.5)
style.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

section = doc.sections[0]
section.page_width = Cm(21.0)
section.page_height = Cm(29.7)
section.left_margin = Cm(2.2)
section.right_margin = Cm(2.0)
section.top_margin = Cm(2.0)
section.bottom_margin = Cm(2.0)
header_text(section, "curvefit ユーザーマニュアル（詳細版）")
page_number_footer(section)

title_page(
    doc,
    "ユーザーマニュアル（詳細版）",
    "入力データに対するフィッティングを一括かつ再現可能に実行するライブラリと CLI",
    [
        "version 0.1.0",
        "対象 Python: 3.11 以上",
    ],
)

page_break(doc)
heading(doc, "目次", 1)
toc(doc)

# ============================================================ 1
heading(doc, "1. はじめに", 1)

heading(doc, "1.1 本書の目的", 2)
body(doc,
     "本書は curvefit の詳細リファレンスである。設定ファイルの全項目、出力の全列、"
     "実行前検証が返す違反の全種別、処理単位ごとの失敗理由の全種別を網羅する。"
     "「まず動かす」ための資料はスライド版のユーザーマニュアルにあり、本書はその後に"
     "引くための資料である。")

heading(doc, "1.2 curvefit が解決すること", 2)
body(doc,
     "測定データを 1 件ずつ表計算で処理し、案件ごとに使い捨てのスクリプトを書く進め方は、"
     "手順が書いた人に固有のものになり、後から同じ結果を得られない。データ件数が増えれば"
     "作業時間もそのまま増える。")
body(doc, "curvefit は次の 2 種類の当てはめを、設定ファイル 1 枚で一括して実行する。")
bullets(doc, [
    "(a) 非線形最小二乗フィット — 利用者が指定したモデル関数のパラメータを推定する",
    "(b) 回帰・スムージング — モデル式を前提としない",
])
body(doc,
     "中核の価値は再現性である。同じ設定ファイルと同じ入力データであれば、"
     "誰がいつ実行しても同じ結果になり、出力はバイト単位で一致する。")

heading(doc, "1.3 用語", 2)
table(doc,
      ["用語", "意味"],
      [["処理対象", "1 つの入力ファイルの 1 つの y 列。1 ファイルに y 列が複数あれば、"
                    "そのファイルからは y 列の数だけ処理対象が生じる"],
       ["処理単位（ジョブ）", "処理対象と手法の組。実行される最小の単位であり、"
                              "件数は 入力数 × 列数 × 手法数 になる"],
       ["手法", "[[methods]] の 1 件。組込モデル・数式・回帰／平滑化のいずれか"],
       ["実行前検証（preflight）", "処理単位を 1 件も実行する前に、設定の違反を"
                                   "すべて集めて報告する段階"],
       ["違反", "実行前検証が検出する設定の誤り。1 件でもあれば何も実行されない"],
       ["失敗", "個別の処理単位で起きる異常。既定では残りの処理を続ける"]],
      widths=[4.2, 12.3])

heading(doc, "1.4 全体の流れ", 2)
body(doc, "設定ファイル → 実行前検証 → 読み込み・前処理 → 当てはめ → 出力 の順に進む。")
callout(doc,
        "実行前検証で違反が見つかった場合、処理単位は 1 件も実行されず、出力も書かれない。"
        "設定の誤りは全件に等しく効くため、途中まで書き出してから止まるより、"
        "何も書かずに違反を全件まとめて示すほうが修正の手数が少ない。", kind="ok")

# ============================================================ 2
heading(doc, "2. 導入", 1)

heading(doc, "2.1 動作条件", 2)
table(doc,
      ["項目", "内容"],
      [["Python", "3.11 以上（3.11 と 3.12 で継続的に検証している）"],
       ["依存ライブラリ", "lmfit / SciPy / NumPy / pandas / matplotlib / asteval"],
       ["文字コード", "設定ファイルは BOM 無しの UTF-8"]],
      widths=[4.2, 12.3])

heading(doc, "2.2 インストール", 2)
code(doc, [
    "python3 -m venv .venv",
    "source .venv/bin/activate",
    'pip install -e ".[dev]"',
])
body(doc, "導入できたことは次で確かめられる。使い方が表示されれば成功である。")
code(doc, ["curvefit --help"])

heading(doc, "2.3 開発時に使う検査", 2)
body(doc, "リポジトリを変更する場合は次の 3 つを通す。"
          "push と pull request で CI が同じものを回す。")
code(doc, [
    "ruff check src tests   # 規約違反",
    "mypy                   # 型の不整合",
    "pytest                 # 検査一式（性能テストは既定で除外）",
])

# ============================================================ 3
heading(doc, "3. 基本的な使い方", 1)

heading(doc, "3.1 最小構成", 2)
body(doc, "次の設定ファイルを run.toml として保存する。")
code(doc, [
    "[input]",
    'paths = ["data"]',
    "header = true",
    "",
    "[input.columns]",
    'x = "time"',
    'y = "signal"',
    "",
    "[[methods]]",
    'name = "line"',
    'builtin = "linear"',
    "",
    "[output]",
    'directory = "out"',
])
body(doc, "実行する。")
code(doc, ["curvefit run.toml"])

heading(doc, "3.2 生成される出力", 2)
body(doc, "data ディレクトリに sample.csv が 1 件あった場合、次が生成される。")
code(doc, [
    "out/",
    "  summary.csv",
    "  execution.json",
    "  run.log",
    "  plots/",
    "    sample__signal__line__0000.png",
])
body(doc,
     "曲線と残差の CSV は既定では書かれない。必要な場合は output.write_curve を true にする。")

heading(doc, "3.3 複数の手法を比較する", 2)
body(doc, "[[methods]] を並べると、1 回の実行で複数の手法を同じサマリ表に並べて比較できる。")
code(doc, [
    "[[methods]]",
    'name = "line"',
    'builtin = "linear"',
    "",
    "[[methods]]",
    'name = "quad"',
    'builtin = "polynomial"',
    "options = { degree = 2 }",
])

# ============================================================ 4
heading(doc, "4. 設定ファイル リファレンス", 1)

heading(doc, "4.1 全体構造", 2)
body(doc, "設定ファイルは TOML である。最上位に書けるキーは次の 5 つに限られ、"
          "これ以外は綴り誤りとして実行前に拒まれる。")
table(doc,
      ["キー", "型", "既定", "内容"],
      [["failure_policy", "文字列", '"skip"', '"skip" または "fail_fast"'],
       ["input", "テーブル", "必須", "どのデータを読むか"],
       ["methods", "テーブルの配列", "必須", "どう当てはめるか。[[methods]] として書く"],
       ["preprocess", "テーブル", "省略可", "当てはめ前に何を除くか"],
       ["output", "テーブル", "省略可", "どこへ何を出すか"]],
      widths=[3.4, 2.6, 2.0, 8.5], mono_cols=(0, 2))

heading(doc, "4.2 [input]", 2)
table(doc,
      ["キー", "型", "既定", "内容"],
      [["paths", "文字列の配列", "必須",
        "ファイル・ディレクトリ・ワイルドカードを指定できる。混在も可"],
       ["delimiter", "文字列", "拡張子から判定",
        "2 文字以上は正規表現として解釈する。4.7 を参照"],
       ["header", "真偽値", "未指定",
        "未指定 / true / false の 3 状態。未指定のまま判定できない入力は失敗になる"],
       ["columns", "テーブル", "必須", "4.3 を参照"]],
      widths=[3.0, 2.6, 3.0, 7.9], mono_cols=(0,))
body(doc, "ワイルドカードは ** を含めると下位ディレクトリを辿る。"
          "一致したディレクトリは対象から外れる。")

heading(doc, "4.3 [input.columns]", 2)
table(doc,
      ["キー", "型", "既定", "内容"],
      [["x", "文字列 または 整数", "必須", "列名、または 0 起点の位置。整数は常に位置"],
       ["y", "文字列／整数、またはその配列", "必須",
        "配列で書くと 1 回の実行で全チャネルを処理する"],
       ["weight", "y と同じ形", "省略可",
        "測定誤差 σ の列。y の i 番目に weight の i 番目が対応する"]],
      widths=[2.2, 4.0, 2.0, 8.3], mono_cols=(0,))
callout(doc,
        "y と weight の個数が一致しない指定は実行前に拒まれ、処理単位を 1 件も実行しない。")
body(doc, "重みは 1/σ として当てはめに効く（σ そのものではない）。"
          "誤差の大きい点ほど寄与が小さくなる。")

heading(doc, "4.4 [[methods]]", 2)
body(doc, "1 件が 1 つの手法を表す。何度でも書ける。")
table(doc,
      ["キー", "型", "内容"],
      [["name", "文字列", "出力ファイル名とサマリ表に現れる識別名。必須"],
       ["builtin", "文字列", "組込モデル名。5.1 を参照"],
       ["expression", "文字列", "数式。5.2 を参照"],
       ["smoother", "文字列", "回帰・平滑化の種類。5.3 を参照"],
       ["initial", "テーブル", "パラメータの初期値"],
       ["bounds", "テーブル", "パラメータの上下限。bounds.<名前> = { min = .., max = .. }"],
       ["fixed", "テーブル", "推定せず固定するパラメータと、その値"],
       ["options", "テーブル", "手法固有の選択肢（degree、lam、window、polyorder）"]],
      widths=[2.6, 2.4, 11.5], mono_cols=(0,))
callout(doc,
        "builtin / expression / smoother は、いずれか 1 つだけを書く。"
        "kind = \"...\" のような種類の宣言を別に持たないのは、"
        "宣言と実体が食い違う設定をそもそも書けないようにするためである。", kind="ok")
body(doc, "上下限を配列ではなくテーブルで書くのは、TOML に空値の記法が無く、"
          "片側だけの上下限を配列では表せないためである。")

heading(doc, "4.5 [preprocess]", 2)
table(doc,
      ["キー", "型", "既定", "内容"],
      [["x_min", "数値", "無し", "この値より小さい x の点を除く"],
       ["x_max", "数値", "無し", "この値より大きい x の点を除く"],
       ["outlier", "テーブル", "無し", "テーブルがあれば外れ値除去を行う。無ければ行わない"]],
      widths=[2.4, 2.0, 2.0, 10.1], mono_cols=(0,))

heading(doc, "4.6 [preprocess.outlier]", 2)
table(doc,
      ["キー", "型", "既定", "内容"],
      [["sigma", "数値", "3.0", "残差の散らばりの何倍を外れ値とみなすか。正の数"],
       ["max_iterations", "整数", "3", "「暫定フィット → 残差評価 → 除去」の繰り返し上限"]],
      widths=[3.2, 2.0, 1.6, 9.7], mono_cols=(0,))
body(doc, "詳細と既定値の盲点は 6.2 に述べる。")

heading(doc, "4.7 [output]", 2)
table(doc,
      ["キー", "型", "既定", "内容"],
      [["directory", "文字列", '"out"', "出力先ディレクトリ"],
       ["write_summary", "真偽値", "true", "サマリ CSV を書くか"],
       ["write_plot", "真偽値", "true", "グラフ画像を書くか"],
       ["write_curve", "真偽値", "false", "当てはめ曲線と残差の CSV を書くか"]],
      widths=[3.2, 2.0, 1.8, 9.5], mono_cols=(0, 2))

heading(doc, "4.8 設定ファイル全体の例", 2)
code(doc, [
    'failure_policy = "skip"',
    "",
    "[input]",
    'paths = ["data/*.csv"]',
    'delimiter = ","',
    "header = true",
    "",
    "[input.columns]",
    'x = "time"',
    'y = ["signal", "ref"]',
    'weight = ["sigma_signal", "sigma_ref"]',
    "",
    "[[methods]]",
    'name = "gauss"',
    'builtin = "gaussian"',
    "initial = { amplitude = 2.0 }",
    "fixed   = { center = 1.0 }",
    "bounds.amplitude = { min = 0.0, max = 10.0 }",
    "",
    "[preprocess]",
    "x_min = 0.0",
    "x_max = 10.0",
    "",
    "[preprocess.outlier]",
    "sigma = 3.0",
    "max_iterations = 3",
    "",
    "[output]",
    'directory = "out"',
    "write_summary = true",
    "write_plot    = true",
    "write_curve   = false",
])

# ============================================================ 5
heading(doc, "5. 手法 リファレンス", 1)
body(doc, "手法の種類は、[[methods]] にどのキーを書いたかで決まる。")

heading(doc, "5.1 組込モデル（builtin）", 2)
table(doc,
      ["名前", "パラメータ", "選択肢", "初期値の自動推定"],
      [["linear", "slope, intercept", "—", "可"],
       ["polynomial", "c0, c1, … c<degree>", "degree（既定 2）", "可"],
       ["gaussian", "amplitude, center, sigma", "—", "可"],
       ["exponential", "amplitude, decay", "—", "可"]],
      widths=[2.8, 5.4, 3.4, 4.9], mono_cols=(0, 1, 2))
body(doc, "組込モデルはいずれもデータから初期値を推定できるため、initial の指定は任意である。"
          "指定した場合はそちらが優先される。")
code(doc, [
    "[[methods]]",
    'name = "gauss"',
    'builtin = "gaussian"',
    "initial = { amplitude = 2.0, center = 5.0 }",
])

heading(doc, "5.2 数式（expression）", 2)
body(doc, "x を独立変数とし、残りの記号がパラメータになる。"
          "組込モデルと違いデータからの自動推定は行われないため、initial の指定が必須である。")
code(doc, [
    "[[methods]]",
    'name = "mine"',
    'expression = "a * x + b"',
    "initial = { a = 1.0, b = 0.0 }",
])
callout(doc,
        "数式文字列は評価される。第三者から受け取った設定ファイルをそのまま実行することは、"
        "任意の Python コードを実行することと同等のリスクを持つ。12 章を参照。")

heading(doc, "5.3 回帰・平滑化（smoother）", 2)
table(doc,
      ["名前", "選択肢", "既定", "制約", "パラメータ", "重み"],
      [["linear", "—", "—", "—", "slope, intercept", "使う"],
       ["polynomial", "degree", "2", "0 以上の整数", "c0 以降", "使う"],
       ["spline", "lam", "必須", "正の有限な数値", "返さない", "使う"],
       ["moving_average", "window", "5", "正の奇数", "返さない", "使わない"],
       ["", "polyorder", "0", "0 以上、window 未満", "", ""]],
      widths=[3.9, 2.4, 1.5, 3.4, 3.0, 2.3], mono_cols=(0, 1, 2))
body(doc, "moving_average は polyorder が 0 のとき窓内の単純平均になる。"
          "次数を上げると Savitzky-Golay 平滑化となり、ピーク形状を保ったまま平滑化できる。")
callout(doc,
        "spline は lam（平滑化の強さ）の指定が必須である。基盤ライブラリの自動選択に"
        "委ねる道は塞いである。自動選択は入力に応じて値が変わり、再現性の保証と両立しない。",
        kind="ok")
callout(doc,
        "spline と moving_average は当てはめ後の系列だけを返し、パラメータを 1 つも持たない。"
        "これらに initial や bounds を書くと実行前に拒まれる。")
code(doc, [
    "[[methods]]",
    'name = "spl"',
    'smoother = "spline"',
    "options = { lam = 0.01 }",
])

# ============================================================ 6
heading(doc, "6. 前処理", 1)
body(doc, "前処理は当てはめの前に点を除く。除いた件数はサマリ表に列として残る。")

heading(doc, "6.1 範囲による除外", 2)
body(doc, "x_min / x_max の範囲外にある点を除く。片側だけの指定もできる。"
          "除いた件数は n_dropped_out_of_range に入る。")

heading(doc, "6.2 外れ値除去", 2)
body(doc, "[preprocess.outlier] のテーブルがあるときだけ行う。手順は次を繰り返す。")
bullets(doc, [
    "暫定の当てはめを行う",
    "残差の散らばりを測る（中心を 0 に固定した二乗平均平方根）",
    "散らばりの sigma 倍を超える点を除く",
    "除く点が無くなるか、max_iterations 回に達したら終わる",
])
body(doc, "除いた件数は n_dropped_outlier に入り、除いた点そのものは前処理 CSV に出る。")

callout(doc,
        "既定値 sigma = 3.0 には盲点がある。いずれも「外れ値除去を有効にしたのに 1 点も"
        "除去されない」という形で現れ、警告も報告も出ない。")
body(doc, "判定は残差の比だけで決まり、その比は点数の平方根を越えない。このため次が起きる。")
bullets(doc, [
    "点数が 9 以下（一般に n ≦ sigma²）の系列では、単一の外れ値をどれほど大きくしても"
    "除去しない。外れ値自身が判定の尺度を同じだけ押し上げるためである",
    "同程度の大きさの外れ値が k ≧ n / sigma² 点あると、その k 点を除去しない。"
    "既定値では 12 点中の 2 点、20 点中の 3 点が該当する",
    "暫定当てはめが全点で一律にずれている場合、そのずれに対して十分大きくない外れ値は"
    "除去しない。既定値・12 点では、一律のずれの約 5.7 倍が必要になる",
])
body(doc, "点数の少ない系列や、外れ値を複数含む系列で除去を効かせるには、"
          "sigma を既定値より小さく指定する必要がある。")

# ============================================================ 7
heading(doc, "7. 入力データの読み取り", 1)

heading(doc, "7.1 区切り文字", 2)
body(doc, "拡張子は実体を保証しない。.csv を名乗りながら、桁揃えの空白で区切られた出力を"
          "返す装置がある。この形は delimiter を明示すれば読める。")
code(doc, [
    "[input]",
    'paths = ["data"]',
    "delimiter = '\\s+'",
])
body(doc, "delimiter は 2 文字以上を与えると正規表現として解釈される。"
          "TOML での書き方は 3 通りあり、うち 1 つは構文誤りになる。")
table(doc,
      ["書き方", "結果"],
      [["delimiter = '\\s+'", "通る。リテラル文字列なのでエスケープが要らない（推奨）"],
       ['delimiter = "\\\\s+"', "通る。基本文字列ではバックスラッシュを重ねる"],
       ['delimiter = "\\s+"', "TOML の構文誤り。未知のエスケープとして拒まれる"]],
      widths=[5.0, 11.5], mono_cols=(0,))
callout(doc,
        'delimiter = " " は使えない。空白の連なりが空の列として数えられ、'
        "行ごとに列数が食い違って読み込みに失敗する。空白区切りに対して最初に試したくなる"
        "書き方だが、正解は '\\s+' である。")
body(doc, "正規表現を指定しても値は最終ビットまで保たれる。")

heading(doc, "7.2 見出し行", 2)
body(doc, "header は未指定 / true / false の 3 状態を取る。未指定の場合は内容から判定を試み、"
          "判定できない入力は header_ambiguous として失敗する。"
          "装置出力のように見出しの有無が一定しない場合は明示するのが安全である。")

heading(doc, "7.3 列を位置で指定する", 2)
body(doc, "装置出力では測定チャネル名が列名に入り、ファイルごとに変わることがある。"
          "このときは列を位置で指定すると、同じ設定のまま一括処理できる。"
          "見出し行に # などの記号が付いていても影響を受けない。")
code(doc, [
    "[input.columns]",
    "x = 0",
    "y = 1",
])

heading(doc, "7.4 1 つのファイルに測定チャネルが複数ある場合", 2)
body(doc, "y に列の並びを書くと、1 回の実行ですべてのチャネルを処理する。"
          "誤差列も同じ長さの並びで書く。")
code(doc, [
    "[input.columns]",
    'x = "time"',
    'y = ["signal", "ref"]',
    'weight = ["sigma_signal", "sigma_ref"]',
])
body(doc, "出力ファイル名には列が入るため、同じファイルの別の列が互いを上書きすることはない。")
code(doc, [
    "out/plots/multi__signal__lin__0000.png",
    "out/plots/multi__ref__lin__0001.png",
])

heading(doc, "7.5 数値の読み取り精度", 2)
body(doc, "本ツールは CSV を float_precision=\"round_trip\" で読み、値を最終ビットまで保つ。")
callout(doc,
        "pandas.read_csv を自分で呼んだ表をライブラリに渡す場合は、同じ指定を行うこと。"
        "既定の解釈器は正確な丸めを行わず、実測で値の約 46% の最下位ビットが変わる。"
        "渡された時点で劣化した値はライブラリ側では回復できない。")
code(doc, ['frame = pd.read_csv(path, float_precision="round_trip")'])

# ============================================================ 8
heading(doc, "8. 出力 リファレンス", 1)

heading(doc, "8.1 出力物の一覧", 2)
table(doc,
      ["出力先", "内容", "制御"],
      [["summary.csv", "全結果を 1 行 1 パラメータで並べた表", "output.write_summary"],
       ["plots/*.png", "実測点と当てはめ曲線の重ね描き", "output.write_plot"],
       ["curves/*.csv", "当てはめ曲線と残差", "output.write_curve"],
       ["preprocess/*.csv", "外れ値として除いた点", "外れ値除去を行った場合"],
       ["execution.json", "適用した実行条件・実行日時・上書き履歴", "常に出力"],
       ["run.log", "処理対象ごとの成否と失敗理由", "常に出力"]],
      widths=[3.6, 8.0, 4.9], mono_cols=(0, 2))

heading(doc, "8.2 出力ファイル名の規則", 2)
code(doc, ["{対象}__{列}__{手法}__{処理単位番号}"])
body(doc, "入力ファイル名（拡張子を除く）と列、手法名、4 桁のゼロ詰め番号を 2 連アンダースコアで"
          "つなぐ。番号は常に付く。名前に使えない文字は置き換えられる。")
callout(doc,
        "y 列が 1 つだけの設定でも列は名前に入る。以前の版から出力名を当てにしている"
        "後段の手順があれば追随が要る。13 章を参照。", kind="ok")

heading(doc, "8.3 summary.csv の列", 2)
body(doc, "1 行が 1 つのパラメータを表す。パラメータを持たない手法や失敗した処理単位も"
          "行として現れる。数値は有効数字 10 桁で書く。")
table(doc,
      ["列", "内容"],
      [["source_id", "入力ファイルの絶対パス"],
       ["column_label", "設定ファイルに書いた綴り。位置で指定した場合は 1 のような数字"],
       ["column_name", "読み込み後に解決した見出し名。位置指定でもチャネル名が分かる"],
       ["method_name", "[[methods]] の name"],
       ["status", "success または failure"],
       ["parameter_name", "パラメータ名。パラメータを持たない手法では空"],
       ["value", "推定値"],
       ["stderr", "標準誤差。算出できない場合は空"],
       ["fixed", "固定したパラメータかどうか（True / False）"],
       ["r_squared", "決定係数"],
       ["rmse", "二乗平均平方根誤差"],
       ["n_points", "当てはめに使った点数"],
       ["n_dropped_invalid", "数値として読めず除いた点数"],
       ["n_dropped_out_of_range", "x の範囲指定で除いた点数"],
       ["n_dropped_outlier", "外れ値として除いた点数"],
       ["failure_reason", "失敗理由。10.2 の一覧を参照。成功時は空"],
       ["message", "失敗時の説明。成功時は空"]],
      widths=[5.2, 11.3], mono_cols=(0,))
body(doc, "実際の 1 行は次のようになる。")
code(doc, [
    "source_id,column_label,column_name,method_name,status,parameter_name,value,...",
    "/data/s.csv,signal,signal,lin,success,slope,2.5,1.239194266e-16,False,1,...",
], size=8.5)

heading(doc, "8.4 曲線 CSV と前処理 CSV の列", 2)
table(doc,
      ["ファイル", "列"],
      [["curves/*.csv", "x, y_observed, y_fit, residual"],
       ["preprocess/*.csv", "x, y_observed, iteration"]],
      widths=[4.4, 12.1], mono_cols=(0, 1))
body(doc, "サマリ表と違い、これらは全精度で書く。y_observed は当てはめ値ではなく実測値である。")

heading(doc, "8.5 execution.json", 2)
body(doc, "1 回の実行の条件をそのまま残す。次のキーを持つ。")
table(doc,
      ["キー", "内容"],
      [["started_at", "実行開始日時（UTC）"],
       ["tool_version", "curvefit の版"],
       ["library_versions", "依存ライブラリの版（lmfit / asteval / scipy / numpy / "
                            "pandas / matplotlib）"],
       ["config_path", "読み込んだ設定ファイルのパス"],
       ["resolved_config", "実際に適用された実行条件のすべて"],
       ["cli_overrides", "実行時引数で上書きした項目と、上書き前後の値"],
       ["applied_defaults", "利用者が書かず、既定値が使われた項目"]],
      widths=[4.4, 12.1], mono_cols=(0,))

heading(doc, "8.6 run.log", 2)
body(doc, "1 行が 1 つの出来事を表す。開始・処理単位ごとの結果・警告・終了が並ぶ。")
code(doc, [
    "2026-09-06T10:04:35Z INFO status=started config_path=r.toml ...",
    "2026-09-06T10:04:36Z INFO source_id='/data/s.csv' column_label='signal' "
    "method='lin' status=success",
    "2026-09-06T10:04:36Z WARNING source_id='/data/s.csv' column_label='ref' "
    "method='lin' parameter='slope' status=stderr_unavailable 標準誤差を算出できなかった",
    "2026-09-06T10:04:36Z INFO status=finished n_success=2 n_failure=0",
], size=8)
body(doc, "処理対象ごとの行には source_id と column_label と method が入るため、"
          "1 ファイルに複数チャネルがある場合でも行が区別できる。")

# ============================================================ 9
heading(doc, "9. コマンドライン リファレンス", 1)

heading(doc, "9.1 書式", 2)
code(doc, [
    "curvefit [設定ファイル] [オプション]",
    "",
    "curvefit run.toml",
    "curvefit run.toml -i data/ -o out/",
    "curvefit --help",
])
body(doc, "設定ファイルを省略すると使い方を表示して終了する。")

heading(doc, "9.2 オプション一覧", 2)
table(doc,
      ["オプション", "内容"],
      [["-h, --help", "使い方・オプション・終了コードを表示する"],
       ["--version", "版を表示する"],
       ["-i PATH, --input PATH",
        "入力の位置。ファイル・ディレクトリ・ワイルドカードを指定できる。複数回指定できる"],
       ["-o DIR, --output DIR", "出力先ディレクトリ"],
       ["--delimiter SEP",
        "区切り文字。2 文字以上は正規表現。桁揃えの空白には '\\s+' を指定する"],
       ["--header / --no-header", "先頭行を見出しとして扱うか"],
       ["--x-column NAME", "x 軸の列名。位置（整数）での指定は設定ファイルで行う"],
       ["--y-column NAME", "y 軸の列名。設定ファイルの列の並びを、この 1 件に置き換える"],
       ["--weight-column NAME", "測定誤差 σ の列名。並びをこの 1 件に置き換える"],
       ["--summary / --no-summary", "サマリ CSV を書き出すか"],
       ["--plot / --no-plot", "グラフ画像を書き出すか"],
       ["--curve / --no-curve", "当てはめ曲線と残差の CSV を書き出すか"],
       ["--failure-policy {skip,fail_fast}", "個別の失敗で継続するか、最初の失敗で止めるか"],
       ["--quiet", "進捗と集計を表示しない。違反と失敗の報告は表示する"]],
      widths=[5.6, 10.9], mono_cols=(0,))
callout(doc,
        "--y-column は列の並びを 1 件に置き換える。--weight-column も同じであるため、"
        "複数列の設定で片方だけを置き換えると個数が合わず、実行前に拒まれる。")

heading(doc, "9.3 上書きできる項目", 2)
body(doc, "同じ項目が設定ファイルと実行時引数の双方で指定された場合は実行時引数を優先する。"
          "上書きできるのは次の項目に限られる。")
table(doc,
      ["設定ファイルのキー", "対応する引数"],
      [["failure_policy", "--failure-policy"],
       ["input.paths", "-i / --input"],
       ["input.delimiter", "--delimiter"],
       ["input.header", "--header / --no-header"],
       ["input.columns.x", "--x-column"],
       ["input.columns.y", "--y-column"],
       ["input.columns.weight", "--weight-column"],
       ["output.directory", "-o / --output"],
       ["output.write_summary", "--summary / --no-summary"],
       ["output.write_plot", "--plot / --no-plot"],
       ["output.write_curve", "--curve / --no-curve"]],
      widths=[7.0, 9.5], mono_cols=(0, 1))
body(doc, "手法の一覧は上書きできない。1 件が複数のキーを持つ入れ子の並びであり、"
          "コマンドラインの 1 つの指定として意味を持つ形にならないためである。"
          "上書きした項目は execution.json に上書き前後の値とともに残る。")

heading(doc, "9.4 終了コード", 2)
table(doc,
      ["コード", "意味"],
      [["0", "全処理単位が成功した"],
       ["1", "1 件以上が失敗した、または中断した"],
       ["2", "実行前検証で停止した。処理単位を 1 件も実行していない"]],
      widths=[2.2, 14.3], mono_cols=(0,))

heading(doc, "9.5 標準出力と標準エラー出力", 2)
body(doc, "進捗・集計・違反はすべて標準エラー出力に書く。実行中の標準出力はどの状態でも空であり、"
          "リダイレクトによる取り回しを壊さない。--help と --version、"
          "および引数なしで実行した場合のヘルプだけは、"
          "利用者が明示的に要求した内容として標準出力に出る。")
code(doc, ["curvefit run.toml > result.txt"])

# ============================================================ 10
heading(doc, "10. エラーと対処", 1)

heading(doc, "10.1 実行前検証の違反", 2)
body(doc, "1 件でもあれば処理を開始しない。違反は 1 件ずつではなく全件まとめて報告するため、"
          "1 件直しては再実行する往復にならない。終了コードは 2 になる。")
code(doc, [
    "model_unresolved        method[line].builtin",
    "smoother_option_invalid method[ma].options",
    "config_invalid          preprocess.x_min",
    "config_invalid          preprocess.outlier.sigma",
])
table(doc,
      ["種別", "意味"],
      [["config_invalid", "設定ファイルの解釈不能、必須項目の欠落、未知のキー"],
       ["model_unresolved", "組込モデル名が未知、または数式文字列を解釈できない"],
       ["initial_required", "組込以外のモデルで初期値が指定されていない"],
       ["initial_out_of_bounds", "指定された初期値が指定された上下限の範囲外にある"],
       ["output_not_writable", "出力先に書き込めない"],
       ["smoother_option_invalid", "平滑化手法固有の選択肢が制約を満たさない"]],
      widths=[5.2, 11.3], mono_cols=(0,))

heading(doc, "10.2 処理単位ごとの失敗", 2)
body(doc, "個別のデータで起きる異常であり、既定（failure_policy = \"skip\"）では"
          "当該処理単位を飛ばして残りを続ける。理由はサマリ表の failure_reason 列と"
          "run.log に残る。終了コードは 1 になる。")
table(doc,
      ["理由", "意味"],
      [["column_not_found", "指定された列が入力に存在しない"],
       ["no_valid_data", "有効なデータ点が 1 件も存在しない"],
       ["insufficient_points", "前処理後の点数が推定対象パラメータ数を下回る"],
       ["not_converged", "当てはめが収束しなかった"],
       ["header_ambiguous", "見出し行の有無が未指定で、先頭行の解釈が定まらない"],
       ["input_unreadable", "指定された入力ファイルが存在しない、または読み取れない"],
       ["resource_exhausted", "メモリ枯渇や書き込み不能により処理を継続できない"]],
      widths=[5.2, 11.3], mono_cols=(0,))
body(doc, "failure_policy = \"fail_fast\" を指定すると、最初の失敗を検出した時点で"
          "残りの処理を中止する。")

heading(doc, "10.3 よくあるつまずき", 2)
table(doc,
      ["症状", "原因", "対処"],
      [["1 行目から構文誤りになる", "設定ファイルに BOM が付いている",
        "BOM 無しの UTF-8 で保存する"],
       ["列数が行ごとに食い違う", 'delimiter = " " と書いた', "delimiter = '\\s+'"],
       ["未知のエスケープで拒まれる", 'delimiter = "\\s+" と書いた',
        "'\\s+' か \"\\\\s+\""],
       ["個数不一致で実行前に停止する", "y と weight の並びの長さが違う", "両方を同数にする"],
       ["外れ値除去が 1 点も除かない", "点数に対して sigma が大きい", "6.2 を参照"],
       ["spline が実行前に拒まれる", "lam を指定していない", "options = { lam = 0.01 }"],
       ["後段の手順がずれた", "出力名とサマリ列が変わった", "13 章を参照"]],
      widths=[5.4, 5.6, 5.5])

# ============================================================ 11
heading(doc, "11. Python ライブラリとして使う", 1)
body(doc, "CLI はライブラリの薄いラッパーであり、同じ実行経路を通る。"
          "CLI とライブラリで結果は一致する。")

heading(doc, "11.1 設定ファイルから一括実行する", 2)
code(doc, [
    "from pathlib import Path",
    "from curvefit import run_from_config, BatchReport",
    "",
    'result = run_from_config(Path("run.toml"))',
    "if isinstance(result, BatchReport):",
    "    print(result.n_success, result.n_failure)",
    "else:",
    "    for violation in result.violations:",
    "        print(violation.kind, violation.location)",
])
callout(doc,
        "違反があった場合は例外ではなく PreflightResult が返る。"
        "実行前に止まる経路を値 1 本に保つことで、"
        "呼び出し側が同じ判断を値と例外の 2 通りで持たずに済む。", kind="ok")

heading(doc, "11.2 実行条件を組み立てて実行する", 2)
body(doc, "設定ファイルを介さず、RunConfig を組み立てて run_batch に渡すこともできる。"
          "戻り値の扱いは run_from_config と同じである。")
code(doc, [
    "from curvefit import run_batch",
    "",
    "result = run_batch(config)",
])

heading(doc, "11.3 メモリ上の 1 系列に当てはめる", 2)
code(doc, [
    "from curvefit import fit_series",
    "",
    "outcome = fit_series(series, method)",
])
body(doc, "一括処理と同一の実行経路を通しつつ、ファイルを 1 つも書かない。"
          "曲線データは保持したまま返る。")

heading(doc, "11.4 主な公開型", 2)
table(doc,
      ["名前", "内容"],
      [["BatchReport", "一括処理の集計。n_success / n_failure を持つ"],
       ["PreflightResult", "実行前検証で停止した結果。violations を持つ"],
       ["ConfigViolation", "違反 1 件。kind / location / message を持つ"],
       ["DataSeries", "1 系列の入力。source_id を持つ"],
       ["FitOutcome", "1 処理単位の結果。FitSuccess または FitFailure"],
       ["ParameterEstimate", "パラメータ 1 件の推定結果"],
       ["GoodnessOfFit", "適合度指標（r_squared / rmse）"],
       ["CurveData", "当てはめ曲線と残差"],
       ["ExecutionRecord", "実行記録。8.5 の内容に対応する"]],
      widths=[4.6, 11.9], mono_cols=(0,))

# ============================================================ 12
heading(doc, "12. 再現性とセキュリティ", 1)

heading(doc, "12.1 再現性", 2)
body(doc, "同じ設定ファイルと同じ入力データであれば、再実行の出力はバイト単位で一致する。"
          "処理単位の順序も決定的であり、入力 → 列 → 手法 の順に展開される。"
          "実行日時のように実行ごとに変わる値は execution.json と run.log にのみ現れる。")
bullets(doc, [
    "適用した実行条件は execution.json の resolved_config に残る",
    "実行時引数で上書きした項目は cli_overrides に上書き前後の値ごと残る",
    "利用者が書かず既定値が使われた項目は applied_defaults に残る",
    "依存ライブラリの版は library_versions に残る",
])

heading(doc, "12.2 セキュリティ", 2)
callout(doc,
        "設定ファイルに記述する数式文字列は評価される。第三者から受け取った設定ファイルを"
        "そのまま実行しないこと。任意の Python コードを実行することと同等のリスクを持つ。"
        "実行前に中身を読むこと。")

# ============================================================ 13
heading(doc, "13. 以前の版からの移行", 1)
body(doc, "1 つの入力ファイルに測定チャネルが複数ある場合に対応した改訂で、"
          "次の 2 点が変わった。いずれも後段の手順に影響しうる。")
table(doc,
      ["変更", "影響", "対処"],
      [["出力ファイル名に列が入るようになった",
        "y 列が 1 つだけの設定でも名前が変わる",
        "出力名を当てにした手順を追随させる"],
       ["サマリ CSV に column_label と column_name の 2 列が増えた（2 列目と 3 列目）",
        "列を位置で読む後段はずれる",
        "名前引き（csv.DictReader）に直す"]],
      widths=[6.2, 5.2, 5.1])
body(doc, "推定値そのものは変わらない。単一の y 列を指定した既存の設定は、"
          "改訂前と同じ推定値・同じサマリ内容を返す（サマリ表に増えた 2 列を除けば"
          "1 文字も変わらないことを実測で確認している）。")

# ============================================================ 付録
heading(doc, "付録 A 設定項目の早見表", 1)
table(doc,
      ["キー", "既定", "内容"],
      [["failure_policy", '"skip"', "個別の失敗で継続するか止めるか"],
       ["input.paths", "必須", "入力の位置。複数指定できる"],
       ["input.delimiter", "拡張子から判定", "区切り文字。2 文字以上は正規表現"],
       ["input.header", "未指定", "先頭行を見出しとして扱うか"],
       ["input.columns.x", "必須", "x 列。名前または位置"],
       ["input.columns.y", "必須", "y 列。名前・位置・それらの並び"],
       ["input.columns.weight", "無し", "誤差 σ の列。y と同数"],
       ["methods[].name", "必須", "手法の識別名"],
       ["methods[].builtin", "—", "組込モデル名"],
       ["methods[].expression", "—", "数式"],
       ["methods[].smoother", "—", "回帰・平滑化の種類"],
       ["methods[].initial", "無し", "初期値"],
       ["methods[].bounds", "無し", "上下限"],
       ["methods[].fixed", "無し", "固定するパラメータ"],
       ["methods[].options", "手法ごと", "degree / lam / window / polyorder"],
       ["preprocess.x_min", "無し", "下限より小さい x を除く"],
       ["preprocess.x_max", "無し", "上限より大きい x を除く"],
       ["preprocess.outlier.sigma", "3.0", "外れ値とみなす散らばりの倍率"],
       ["preprocess.outlier.max_iterations", "3", "除去の繰り返し上限"],
       ["output.directory", '"out"', "出力先"],
       ["output.write_summary", "true", "サマリ CSV を書くか"],
       ["output.write_plot", "true", "グラフを書くか"],
       ["output.write_curve", "false", "曲線 CSV を書くか"]],
      widths=[7.2, 2.6, 6.7], mono_cols=(0, 1))

heading(doc, "付録 B 仕様と設計の記録", 1)
body(doc, "この機能がどう決まったかは .kiro/specs/data-curve-fitting/ に残してある。")
table(doc,
      ["ファイル", "内容", "開くとよいとき"],
      [["requirements.md", "要件と受け入れ基準（EARS 形式）",
        "この挙動は意図されたものかを確かめたいとき"],
       ["design.md", "境界・依存方向・各層の契約・試験戦略",
        "コードを変える前に、触ってよい範囲を知りたいとき"],
       ["tasks.md", "実装タスクと、実装中に得た申し送り",
        "同じ失敗を繰り返したくないとき"],
       ["research.md", "依存ライブラリの調査と、設計判断に至った経緯",
        "なぜこのライブラリなのかを知りたいとき"]],
      widths=[4.0, 6.2, 6.3], mono_cols=(0,))

assert not _outline_left, f"本文に現れなかった見出し: {_outline_left}"

out = str(pathlib.Path(__file__).with_name("curvefit_ユーザーマニュアル_詳細版.docx"))
doc.save(out)
print(f"saved: {out}")
