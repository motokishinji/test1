"""curvefit ユーザーマニュアル パワーポイント生成スクリプト

内容は README.md / `curvefit --help` / `src/curvefit/config.py` の TOML 記法から採った。
コマンドや設定キーを変えたときは、このスクリプトの該当スライドも直すこと。
"""
import pathlib

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

# ---- カラーパレット ----
INK      = RGBColor(0x1A, 0x1A, 0x1A)   # 濃いテキスト
PAPER    = RGBColor(0xFA, 0xF7, 0xF2)   # 背景(クリーム)
ACCENT   = RGBColor(0xD9, 0x77, 0x57)   # コーラル
ACCENT2  = RGBColor(0x2E, 0x4A, 0x62)   # 深い青
GRAY     = RGBColor(0x6B, 0x66, 0x60)   # サブテキスト
WHITE    = RGBColor(0xFF, 0xFF, 0xFF)
CARDBG   = RGBColor(0xFF, 0xFF, 0xFF)
RULE     = RGBColor(0xE2, 0xDC, 0xD3)   # 罫線
CODEBG   = RGBColor(0x2B, 0x2B, 0x2B)
CODEFG   = RGBColor(0xE6, 0xE6, 0xE6)
CODEKEY  = RGBColor(0x9C, 0xDC, 0xFE)   # コード内の強調
GOOD     = RGBColor(0x3A, 0x7D, 0x44)
BAD      = RGBColor(0xB5, 0x3A, 0x2E)
WARNBG   = RGBColor(0xFB, 0xF0, 0xE8)

FONT   = "Meiryo"
FONTM  = "Consolas"

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)
SW, SH = prs.slide_width, prs.slide_height
BLANK = prs.slide_layouts[6]

DEFAULT_ROW_HEIGHT = Inches(0.42)


# ---- はみ出しの検出 -------------------------------------------------------
# 行数だけで高さを決めると、実際の文字幅を超えた行が折り返し、下の要素と重なる。
# 描く前に幅を見積もり、収まらない行はその場で失敗させる。

def _width_pt(text, size, mono):
    """描画幅の見積もり（pt）。全角は半角の 2 倍として数える。"""
    em = 0.60 if mono else 0.55          # 半角 1 文字あたりの em 比
    units = sum(2.0 if ord(ch) > 0x2E80 else 1.0 for ch in text)
    return units * em * size


def fits(text, size, width_in, mono=False, where=""):
    """収まらなければ失敗させる。width_in は使える幅（インチ）。"""
    limit = width_in * 72.0
    got = _width_pt(text, size, mono)
    if got > limit:
        raise AssertionError(
            f"はみ出し {where}: {got:.0f}pt > {limit:.0f}pt / {size}pt / {text!r}")
    return text


def bg(slide, color=PAPER):
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = color


def box(slide, left, t, w, h, fill=None, line=None, line_w=1.0, round_=False):
    shp = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if round_ else MSO_SHAPE.RECTANGLE, left, t, w, h)
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    return shp


def txt(slide, left, t, w, h, runs, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP,
        space_after=6, line_spacing=1.0):
    """runs: 段落のリスト。各段落は (text, size, color, bold, font) のリスト。"""
    tb = slide.shapes.add_textbox(left, t, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = 0
    tf.margin_right = 0
    tf.margin_top = 0
    tf.margin_bottom = 0
    for i, para in enumerate(runs):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(space_after)
        p.space_before = Pt(0)
        p.line_spacing = line_spacing
        for (text, size, color, bold, font) in para:
            r = p.add_run()
            r.text = text
            r.font.size = Pt(size)
            r.font.color.rgb = color
            r.font.bold = bold
            r.font.name = font
    return tb


def run_(text, size=14, color=INK, bold=False, font=FONT):
    return (text, size, color, bold, font)


def header(slide, title, num):
    box(slide, 0, 0, SW, Inches(1.05), fill=WHITE)
    box(slide, 0, Inches(1.05), SW, Pt(3), fill=ACCENT)
    box(slide, Inches(0.5), Inches(0.28), Pt(8), Inches(0.5), fill=ACCENT)
    txt(slide, Inches(0.72), Inches(0.22), Inches(10.5), Inches(0.7),
        [[run_(title, 26, INK, True)]], anchor=MSO_ANCHOR.MIDDLE)
    label = f"{num:02d}" if isinstance(num, int) else str(num)
    txt(slide, Inches(11.6), Inches(0.22), Inches(1.3), Inches(0.7),
        [[run_(label, 26, ACCENT, True)]], align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE)


def footer(slide):
    txt(slide, Inches(0.72), Inches(7.02), Inches(8), Inches(0.24),
        [[run_("curvefit ユーザーマニュアル", 9, GRAY, False)]])


def wrap(text, size, width_in, mono=False):
    """実幅で折り返す。日本語は単語境界を持たないため 1 文字ずつ詰める。"""
    limit = width_in * 72.0
    lines: list[str] = []
    current = ""
    for ch in text:
        if _width_pt(current + ch, size, mono) > limit and current:
            lines.append(current)
            current = ch
        else:
            current += ch
    if current:
        lines.append(current)
    # 禁則処理。行頭に句読点や閉じ括弧が残ると読みにくい。
    head_forbidden = "、。，．）」』】〉》!?！？・ー"
    fixed = []
    for line in lines:
        while line and line[0] in head_forbidden and fixed:
            fixed[-1] += line[0]
            line = line[1:]
        fixed.append(line)
    return [line for line in fixed if line]


def code(slide, left, t, w, lines, size=13, title=None):
    """コードブロック。lines は文字列、または (文字列, 色) の組のリスト。"""
    # 実測: 描画される 1 行は 文字寸法 x 行間 + 行間の余白。固定値では最終行が切れる。
    lh = Inches(size * 1.18 / 72.0 + 0.048)
    top = t
    if title:
        fits(title, 12, w.inches, where="code title")
        txt(slide, left, top, w, Inches(0.3), [[run_(title, 12, GRAY, True)]])
        top = top + Inches(0.34)
    inner = w.inches - 0.44
    for line in lines:
        fits(line[0] if isinstance(line, tuple) else line, size, inner, mono=True,
             where="code")
    h = lh * len(lines) + Inches(0.34)
    box(slide, left, top, w, h, fill=CODEBG, round_=True)
    paras = []
    for line in lines:
        if isinstance(line, tuple):
            text, color = line
        else:
            text, color = line, CODEFG
        paras.append([run_(text if text else " ", size, color, False, FONTM)])
    txt(slide, left + Inches(0.22), top + Inches(0.17), w - Inches(0.44),
        lh * len(lines) + Inches(0.04), paras, space_after=0, line_spacing=1.18)
    return top + h


def card(slide, left, t, w, h, title, body, accent=ACCENT, title_size=15, body_size=12.5):
    """本文は実幅で折り返し、必要なら箱を伸ばす。渡した h は下限として扱う。"""
    inner = w.inches - 0.5
    fits(title, title_size, inner, where="card title")
    wrapped = []
    for line in body:
        wrapped.extend(wrap(line, body_size, inner))
    need = Inches(0.68 + 0.22) + Inches(body_size * 1.22 / 72.0 + 0.03) * len(wrapped)
    h = max(h, need)
    box(slide, left, t, w, h, fill=CARDBG, line=RULE, round_=True)
    box(slide, left, t + Inches(0.18), Pt(5), h - Inches(0.36), fill=accent)
    txt(slide, left + Inches(0.28), t + Inches(0.2), w - Inches(0.5), Inches(0.35),
        [[run_(title, title_size, INK, True)]])
    txt(slide, left + Inches(0.28), t + Inches(0.68), w - Inches(0.5), h - Inches(0.85),
        [[run_(line, body_size, GRAY, False)] for line in wrapped], space_after=0,
        line_spacing=1.22)
    return t + h


def table(slide, left, t, widths, rows, head_fill=ACCENT2, row_h=None,
          size=12.5, mono_cols=()):
    """簡易表。rows[0] を見出しとして描く。widths は Inches のリスト。"""
    # 既定値は呼び出しのたびに評価させる。Inches() を既定引数に書くと
    # 取り込み時に 1 度だけ評価され、値が共有される。
    row_h = DEFAULT_ROW_HEIGHT if row_h is None else row_h
    x = left
    total = sum(widths, Inches(0))
    box(slide, left, t, total, row_h, fill=head_fill)
    for w, cell in zip(widths, rows[0], strict=False):
        txt(slide, x + Inches(0.14), t, w - Inches(0.2), row_h,
            [[run_(cell, size, WHITE, True)]], anchor=MSO_ANCHOR.MIDDLE)
        x += w
    y = t + row_h
    for i, row in enumerate(rows[1:]):
        fill = WHITE if i % 2 == 0 else RGBColor(0xF4, 0xF1, 0xEC)
        box(slide, left, y, total, row_h, fill=fill, line=RULE, line_w=0.5)
        x = left
        for j, (w, cell) in enumerate(zip(widths, row, strict=False)):
            font = FONTM if j in mono_cols else FONT
            fits(cell, size, w.inches - 0.2, mono=(j in mono_cols), where="table cell")
            txt(slide, x + Inches(0.14), y, w - Inches(0.2), row_h,
                [[run_(cell, size, INK, False, font)]], anchor=MSO_ANCHOR.MIDDLE)
            x += w
        y += row_h
    return y


def note(slide, left, t, w, text, kind="warn", size=12.5):
    """注意書きの帯。本文は実幅で折り返し、行数に応じて高さを決める。"""
    fill, mark, color = (WARNBG, "！", BAD) if kind == "warn" else (
        RGBColor(0xEE, 0xF4, 0xEE), "✓", GOOD)
    lines = wrap(text, size, w.inches - 0.85)
    h = max(Inches(0.54), Inches(0.3) + Inches(size * 1.25 / 72.0 + 0.03) * len(lines))
    box(slide, left, t, w, h, fill=fill, round_=True)
    box(slide, left, t + Inches(0.12), Pt(5), h - Inches(0.24), fill=color)
    txt(slide, left + Inches(0.26), t, Inches(0.35), h, [[run_(mark, 15, color, True)]],
        anchor=MSO_ANCHOR.MIDDLE)
    txt(slide, left + Inches(0.62), t, w - Inches(0.85), h,
        [[run_(line, size, INK, False)] for line in lines], anchor=MSO_ANCHOR.MIDDLE,
        space_after=0, line_spacing=1.25)
    return t + h


# ============================================================
# 1. タイトル
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s, ACCENT2)
box(s, 0, Inches(2.35), SW, Inches(2.6), fill=RGBColor(0x26, 0x3E, 0x52))
box(s, Inches(0.9), Inches(2.65), Pt(10), Inches(2.0), fill=ACCENT)
txt(s, Inches(1.25), Inches(2.75), Inches(11), Inches(1.0),
    [[run_("curvefit", 54, WHITE, True, FONTM)]], anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.27), Inches(3.75), Inches(11), Inches(0.8),
    [[run_("ユーザーマニュアル", 30, RGBColor(0xF0, 0xD9, 0xC9), True)]],
    anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.27), Inches(5.25), Inches(11), Inches(0.9),
    [[run_("測定データへの当てはめを、設定ファイル 1 枚で一括かつ再現可能に実行する", 16,
        RGBColor(0xC9, 0xD6, 0xE0), False)],
     [run_("同じ設定と同じ入力なら、誰がいつ実行しても同じ結果になる", 16,
        RGBColor(0xC9, 0xD6, 0xE0), False)]], space_after=8)
txt(s, Inches(1.27), Inches(6.6), Inches(11), Inches(0.4),
    [[run_("version 0.1.0 / Python 3.11 以上", 12, RGBColor(0x9F, 0xB3, 0xC2), False)]])

# ============================================================
# 2. 目次
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "目次", 0)
items = [
    ("1", "これは何をする道具か", "解決する問題と全体の流れ"),
    ("2", "はじめの一歩", "導入 / 最小の設定ファイル / 実行"),
    ("3", "設定ファイルの書き方", "入力・手法・前処理・出力の 4 つの区画"),
    ("4", "手法を選ぶ", "組込モデル / 数式 / 回帰・平滑化"),
    ("5", "出力物を読む", "サマリ表・グラフ・曲線 CSV・実行記録"),
    ("6", "測定装置の CSV を読む", "区切り文字 / 位置指定 / 複数チャネル"),
    ("7", "コマンドの使い方", "実行時の上書きと終了コード"),
    ("8", "うまくいかないとき", "実行前検証が教えること"),
    ("9", "Python から使う", "ライブラリとしての入口"),
    ("10", "注意事項", "安全性・精度・以前の版からの変更"),
]
for i, (n, title, sub) in enumerate(items):
    col, row = i // 5, i % 5
    x = Inches(0.72) + Inches(6.3) * col
    y = Inches(1.55) + Inches(1.09) * row
    box(s, x, y, Inches(5.85), Inches(0.92), fill=CARDBG, line=RULE, round_=True)
    box(s, x, y, Inches(0.72), Inches(0.92), fill=ACCENT2)
    txt(s, x, y, Inches(0.72), Inches(0.92), [[run_(n, 22, WHITE, True)]],
        align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    txt(s, x + Inches(0.95), y + Inches(0.14), Inches(4.7), Inches(0.35),
        [[run_(title, 15, INK, True)]])
    txt(s, x + Inches(0.95), y + Inches(0.52), Inches(4.7), Inches(0.3),
        [[run_(sub, 11.5, GRAY, False)]])
footer(s)

# ============================================================
# 3. これは何をする道具か
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "これは何をする道具か", 1)
txt(s, Inches(0.72), Inches(1.45), Inches(12), Inches(0.4),
    [[run_("データ 1 件ずつを表計算で処理し、案件ごとに使い捨てのスクリプトを書く——"
        "この手順は属人化し、後から再現できない。", 14.5, INK, False)]])

card(s, Inches(0.72), Inches(2.1), Inches(3.9), Inches(2.0), "解決すること",
     ["・多数のファイルを 1 回でまとめて処理",
      "・複数のモデルを同じ表に並べて比較",
      "・同じ設定なら何度でも同じ結果",
      "・実行条件を記録に残して後から追える"], accent=GOOD)
card(s, Inches(4.82), Inches(2.1), Inches(3.9), Inches(2.0), "当てはめの 2 種類",
     ["(a) 非線形最小二乗フィット",
      "　　モデル関数のパラメータを推定する",
      "(b) 回帰・スムージング",
      "　　モデル式を前提としない"], accent=ACCENT2)
card(s, Inches(8.92), Inches(2.1), Inches(3.7), Inches(2.0), "2 つの使い方",
     ["・コマンド（CLI）",
      "　　設定ファイルを渡して一括実行",
      "・Python ライブラリ",
      "　　import して自分の処理に組み込む"], accent=ACCENT)

txt(s, Inches(0.72), Inches(4.45), Inches(12), Inches(0.35),
    [[run_("全体の流れ", 15, INK, True)]])
flow = [
    ("設定ファイル\n(TOML)", ACCENT2),
    ("実行前検証", ACCENT),
    ("読み込み\n前処理", ACCENT2),
    ("当てはめ", ACCENT2),
    ("出力", GOOD),
]
fx = Inches(0.72)
for i, (label, color) in enumerate(flow):
    box(s, fx, Inches(4.9), Inches(2.02), Inches(1.0), fill=color, round_=True)
    txt(s, fx, Inches(4.9), Inches(2.02), Inches(1.0),
        [[run_(part, 13.5, WHITE, True)] for part in label.split("\n")],
        align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, space_after=2)
    if i < len(flow) - 1:
        txt(s, fx + Inches(2.05), Inches(4.9), Inches(0.45), Inches(1.0),
            [[run_("▶", 15, GRAY, True)]], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    fx += Inches(2.5)
note(s, Inches(0.72), Inches(6.15),  Inches(11.9),
     "実行前検証で違反が見つかった場合、処理は 1 件も実行されない。"
     "誤りは全件に等しく効くため、途中まで書き出してから止まるより、"
     "何も書かずに違反を全件まとめて示す。", kind="ok")
footer(s)

# ============================================================
# 4. はじめの一歩
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "はじめの一歩", 2)

txt(s, Inches(0.72), Inches(1.4), Inches(5.9), Inches(0.3),
    [[run_("① 導入する", 15, INK, True)]])
code(s, Inches(0.72), Inches(1.78), Inches(5.9), [
    "python3 -m venv .venv",
    "source .venv/bin/activate",
    "pip install -e \".[dev]\"",
])

txt(s, Inches(0.72), Inches(3.05), Inches(5.9), Inches(0.3),
    [[run_("② 設定ファイルを書く（run.toml）", 15, INK, True)]])
code(s, Inches(0.72), Inches(3.43), Inches(5.9), [
    ("[input]", CODEKEY),
    'paths = ["data"]',
    "header = true",
    ("[input.columns]", CODEKEY),
    'x = "time"',
    'y = "signal"',
    ("[[methods]]", CODEKEY),
    'name = "line"',
    'builtin = "linear"',
    ("[output]", CODEKEY),
    'directory = "out"',
], size=11.5)

txt(s, Inches(7.0), Inches(1.4), Inches(5.6), Inches(0.3),
    [[run_("③ 実行する", 15, INK, True)]])
code(s, Inches(7.0), Inches(1.78), Inches(5.6), [
    "curvefit run.toml",
])

txt(s, Inches(7.0), Inches(2.62), Inches(5.6), Inches(0.3),
    [[run_("④ 出力を見る", 15, INK, True)]])
code(s, Inches(7.0), Inches(3.0), Inches(5.6), [
    "out/",
    ("  summary.csv", GOOD),
    "  execution.json",
    "  run.log",
    "  plots/",
    ("    sample__signal__line__0000.png", GOOD),
], size=12)

card(s, Inches(7.0), Inches(4.8), Inches(5.6), Inches(1.2), "この 4 段階だけ覚えればよい",
     ["「どのデータを・どう当てはめ・どこへ出すか」を書いて渡す。",
      "同じファイルを渡す限り、結果は何度でも同じになる。"], body_size=12)
note(s, Inches(0.72), Inches(6.42), Inches(11.9),
     "設定ファイルは BOM 無しの UTF-8 で保存する。"
     "Windows のメモ帳の既定保存は BOM を付けるため、1 行目から構文誤りになる。")
footer(s)

# ============================================================
# 5. 設定ファイルの全体像
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "設定ファイルの書き方 — 4 つの区画", 3)

code(s, Inches(0.72), Inches(1.4), Inches(4.15), [
    ("[input]", CODEKEY),
    'paths = ["data/*.csv"]',
    'delimiter = ","',
    "header = true",
    "",
    ("[input.columns]", CODEKEY),
    'x = "time"',
    'y = "signal"',
    'weight = "sigma"',
    "",
    ("[[methods]]", CODEKEY),
    'name = "gauss"',
    'builtin = "gaussian"',
    "initial = { amplitude = 2.0 }",
    "fixed   = { center = 1.0 }",
    "bounds.amplitude =",
    "  { min = 0.0, max = 10.0 }",
], size=11.5, title="① どのデータを / ② どう当てはめる")

code(s, Inches(5.1), Inches(1.4), Inches(3.55), [
    'failure_policy = "skip"',
    "",
    ("[preprocess]", CODEKEY),
    "x_min = 0.0",
    "x_max = 10.0",
    "",
    ("[preprocess.outlier]", CODEKEY),
    "sigma = 3.0",
    "max_iterations = 3",
    "",
    ("[output]", CODEKEY),
    'directory = "out"',
    "write_summary = true",
    "write_plot    = true",
    "write_curve   = false",
], size=11.5, title="③ 何を除く / ④ どこへ出す")

txt(s, Inches(8.9), Inches(1.4), Inches(3.72), Inches(0.3),
    [[run_("区画は 4 つだけ", 15, INK, True)]])
sections = [
    ("[input]", "どのデータを読むか", ACCENT2),
    ("[[methods]]", "どう当てはめるか（複数可）", ACCENT),
    ("[preprocess]", "何を除いてから当てはめるか", ACCENT2),
    ("[output]", "どこへ何を出すか", GOOD),
]
sy = Inches(1.8)
for key, desc, col in sections:
    box(s, Inches(8.9), sy, Inches(3.72), Inches(0.68), fill=CARDBG, line=RULE, round_=True)
    box(s, Inches(8.9), sy + Inches(0.13), Pt(5), Inches(0.42), fill=col)
    txt(s, Inches(9.15), sy + Inches(0.09), Inches(2.2), Inches(0.28),
        [[run_(key, 12.5, col, True, FONTM)]])
    txt(s, Inches(9.15), sy + Inches(0.38), Inches(3.3), Inches(0.26),
        [[run_(desc, 11, GRAY, False)]])
    sy += Inches(0.76)

txt(s, Inches(8.9), Inches(4.95), Inches(3.72), Inches(0.3),
    [[run_("迷いやすい値の書き方", 15, INK, True)]])
table(s, Inches(8.9), Inches(5.33), [Inches(1.3), Inches(2.42)],
      [["キー", "取りうる値"],
       ["header", "省略 / true / false"],
       ["x, y", "列名または位置（整数）"],
       ["bounds", "{ min = .., max = .. }"]],
      mono_cols=(0,), size=11, row_h=Inches(0.38))

note(s, Inches(0.72), Inches(6.32), Inches(7.93),
     "[[methods]] を並べると、1 回の実行で複数の手法を比較できる。",
     kind="ok", size=12)
footer(s)


# ============================================================
# 6. 手法を選ぶ
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "手法を選ぶ — 3 つの経路", 4)
txt(s, Inches(0.72), Inches(1.4), Inches(12), Inches(0.35),
    [[run_("[[methods]] には ", 14, INK, False), run_("builtin", 14, ACCENT, True, FONTM),
      run_(" / ", 14, INK, False), run_("expression", 14, ACCENT, True, FONTM),
      run_(" / ", 14, INK, False), run_("smoother", 14, ACCENT, True, FONTM),
      run_(" の ", 14, INK, False), run_("いずれか 1 つ", 14, INK, True),
      run_(" を書く。書いたキーが手法の種類を決める。", 14, INK, False)]])

y = code(s, Inches(0.72), Inches(1.95), Inches(3.85), [
    ("[[methods]]", CODEKEY),
    'name = "gauss"',
    'builtin = "gaussian"',
], size=12, title="① 組込モデル")
txt(s, Inches(0.72), y + Inches(0.15), Inches(3.85), Inches(1.6),
    [[run_("linear", 12.5, INK, True, FONTM), run_("　直線", 12.5, GRAY)],
     [run_("polynomial", 12.5, INK, True, FONTM),
      run_("　多項式（degree で次数）", 12.5, GRAY)],
     [run_("gaussian", 12.5, INK, True, FONTM), run_("　ガウス関数", 12.5, GRAY)],
     [run_("exponential", 12.5, INK, True, FONTM), run_("　指数関数", 12.5, GRAY)]],
    space_after=5)

y = code(s, Inches(4.85), Inches(1.95), Inches(3.85), [
    ("[[methods]]", CODEKEY),
    'name = "mine"',
    'expression = "a * x + b"',
], size=12, title="② 数式を自分で書く")
txt(s, Inches(4.85), y + Inches(0.15), Inches(3.85), Inches(1.6),
    [[run_("x を独立変数として、残りの記号がパラメータになる。", 12.5, GRAY)],
     [run_("初期値は initial で与える。組込モデルと違い、", 12.5, GRAY)],
     [run_("データからの自動推定は行われない。", 12.5, GRAY)]], space_after=5)

y = code(s, Inches(8.98), Inches(1.95), Inches(3.62), [
    ("[[methods]]", CODEKEY),
    'name = "spl"',
    'smoother = "spline"',
    "options = { lam = 0.01 }",
], size=12, title="③ 回帰・平滑化")
txt(s, Inches(8.98), y + Inches(0.15), Inches(3.62), Inches(1.6),
    [[run_("linear / polynomial", 12.5, INK, True, FONTM)],
     [run_("spline", 12.5, INK, True, FONTM), run_("　lam が必須", 12.5, GRAY)],
     [run_("moving_average", 12.5, INK, True, FONTM)],
     [run_("spline と moving_average はパラメータを返さない。", 12, GRAY)]], space_after=5)

note(s, Inches(0.72), Inches(5.82), Inches(11.9),
     "誤差列（重み）は linear / polynomial / spline に効く。"
     "moving_average だけが重みを使わない。", kind="ok", size=12)
note(s, Inches(0.72), Inches(6.42), Inches(11.9),
     "kind = \"...\" のような種類の宣言は持たない。宣言と実体が食い違う設定を"
     "そもそも書けないようにするためである。", kind="ok", size=12)
footer(s)

# ============================================================
# 7. 出力物を読む
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "出力物を読む", 5)
table(s, Inches(0.72), Inches(1.4),
      [Inches(3.0), Inches(5.6), Inches(3.3)],
      [["出力先", "内容", "制御"],
       ["summary.csv", "全結果を 1 行 1 パラメータで並べた表", "write_summary"],
       ["plots/*.png", "実測点と当てはめ曲線の重ね描き", "write_plot（既定 true）"],
       ["curves/*.csv", "当てはめ曲線と残差", "write_curve（既定 false）"],
       ["execution.json", "適用した実行条件・実行日時・上書き履歴", "常に出力"],
       ["run.log", "処理対象ごとの成否と失敗理由", "常に出力"]],
      mono_cols=(0, 2), size=12.5)

txt(s, Inches(0.72), Inches(4.55), Inches(12), Inches(0.35),
    [[run_("出力ファイル名の規則", 15, INK, True)]])
box(s, Inches(0.72), Inches(4.95), Inches(6.4), Inches(0.62), fill=CODEBG, round_=True)
txt(s, Inches(0.95), Inches(4.95), Inches(6.0), Inches(0.62),
    [[run_("{対象}__{列}__{手法}__{処理単位番号}", 15, CODEFG, True, FONTM)]],
    anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(7.35), Inches(4.9), Inches(5.3), Inches(0.8),
    [[run_("入力ファイルと列の双方が名前に入る。", 12.5, GRAY)],
     [run_("同じファイルの別の列が互いを上書きすることはない。", 12.5, GRAY)]],
    space_after=3)

txt(s, Inches(0.72), Inches(5.8), Inches(12), Inches(0.35),
    [[run_("サマリ表の先頭 4 列が「どの結果か」を示す", 15, INK, True)]])
ident = [
    ("source_id", "入力ファイルの絶対パス"),
    ("column_label", "設定に書いた綴り。位置指定なら 1 のような数字"),
    ("column_name", "解決した見出し名。位置指定でもチャネル名が分かる"),
    ("method_name", "[[methods]] の name"),
]
ix = Inches(0.72)
for key, desc in ident:
    box(s, ix, Inches(6.2), Inches(2.92), Inches(0.72), fill=CARDBG, line=RULE, round_=True)
    txt(s, ix + Inches(0.16), Inches(6.26), Inches(2.7), Inches(0.26),
        [[run_(key, 12.5, ACCENT, True, FONTM)]])
    txt(s, ix + Inches(0.16), Inches(6.54), Inches(2.66), Inches(0.34),
        [[run_(desc, 10.5, GRAY, False)]])
    ix += Inches(3.0)
footer(s)

# ============================================================
# 8. 測定装置の CSV を読む（区切り文字）
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "測定装置の CSV を読む — 区切り文字", 6)
note(s, Inches(0.72), Inches(1.35), Inches(11.9),
     "拡張子は実体を保証しない。.csv を名乗りながら、"
     "桁揃えの空白で区切られた出力を返す装置がある。")

txt(s, Inches(0.72), Inches(2.2), Inches(5.9), Inches(0.3),
    [[run_("可変長の空白で区切られている場合", 15, INK, True)]])
code(s, Inches(0.72), Inches(2.58), Inches(5.9), [
    ("[input]", CODEKEY),
    'paths = ["data"]',
    ("delimiter = '\\s+'      # 可変長の空白", GOOD),
])
txt(s, Inches(0.72), Inches(3.85), Inches(5.9), Inches(0.6),
    [[run_("delimiter は 2 文字以上を与えると正規表現として解釈される。"
        "コマンドからは curvefit run.toml --delimiter '\\s+'。", 12.5, GRAY)]])

txt(s, Inches(0.72), Inches(4.55), Inches(5.9), Inches(0.3),
    [[run_("正規表現を指定しても値は最終ビットまで保たれる", 13, GOOD, True)]])

txt(s, Inches(7.0), Inches(2.2), Inches(5.6), Inches(0.3),
    [[run_("TOML での書き方は 3 通り、うち 1 つは誤り", 15, INK, True)]])
table(s, Inches(7.0), Inches(2.58), [Inches(2.5), Inches(3.1)],
      [["書き方", "結果"],
       ["delimiter = '\\s+'", "通る（推奨）"],
       ["delimiter = \"\\\\s+\"", "通る"],
       ["delimiter = \"\\s+\"", "TOML の構文誤り"]],
      mono_cols=(0,), size=12)

note(s, Inches(7.0), Inches(4.52), Inches(5.6),
     "delimiter = \" \" は使えない。空白の連なりが空の列として数えられ、"
     "行ごとに列数が食い違って読み込みに失敗する。")

card(s, Inches(0.72), Inches(5.58), Inches(11.9), Inches(1.2),
     "最初に試したくなる書き方が正解ではない",
     ["空白区切りに対して delimiter = \" \" と書くのは自然だが読めない。正解は '\\s+' である。"
      "リテラル文字列（シングルクォート）で書けばエスケープが要らず、最も間違いにくい。"])
footer(s)

# ============================================================
# 9. 列の指定（位置・複数チャネル）
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "列の指定 — 位置指定と複数チャネル", 6)

txt(s, Inches(0.72), Inches(1.35), Inches(5.9), Inches(0.3),
    [[run_("列名がファイルごとに違う場合 → 位置で指定", 15, INK, True)]])
code(s, Inches(0.72), Inches(1.73), Inches(5.9), [
    ("[input.columns]", CODEKEY),
    "x = 0        # 0 起点の位置",
    "y = 1        # 整数は常に位置",
])
txt(s, Inches(0.72), Inches(3.0), Inches(5.9), Inches(0.75),
    [[run_("装置出力では測定チャネル名が列名に入り、ファイルごとに変わることがある。"
        "位置で指定すれば同じ設定のまま一括処理できる。見出し行に # などの記号が"
        "付いていても影響を受けない。", 12.5, GRAY)]])

txt(s, Inches(7.0), Inches(1.35), Inches(5.6), Inches(0.3),
    [[run_("1 ファイルにチャネルが複数ある場合 → 並びで指定", 15, INK, True)]])
code(s, Inches(7.0), Inches(1.73), Inches(5.6), [
    ("[input.columns]", CODEKEY),
    'x = "time"',
    'y = ["signal", "ref"]',
    'weight = ["sigma_signal", "sigma_ref"]',
], size=12)
txt(s, Inches(7.0), Inches(3.18), Inches(5.6), Inches(0.75),
    [[run_("1 回の実行ですべてのチャネルを処理する。誤差列も同じ長さの並びで書き、"
        "y の i 番目に weight の i 番目が対応する。", 12.5, GRAY)]])

txt(s, Inches(0.72), Inches(3.95), Inches(12), Inches(0.3),
    [[run_("出力は列ごとに分かれる", 15, INK, True)]])
code(s, Inches(0.72), Inches(4.33), Inches(11.9), [
    "out/summary.csv",
    ("out/plots/multi__signal__lin__0000.png", GOOD),
    ("out/plots/multi__ref__lin__0001.png", GOOD),
], size=13)

note(s, Inches(0.72), Inches(5.75), Inches(5.9),
     "個数が一致しない指定は実行前に拒まれ、処理単位を 1 件も実行しない。")
note(s, Inches(7.0), Inches(5.75), Inches(5.6),
     "進捗の処理単位数は 入力数 × 列数 × 手法数 であり、ファイル数とは一致しない。",
     kind="ok")
footer(s)

# ============================================================
# 10. コマンドの使い方
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "コマンドの使い方", 7)
code(s, Inches(0.72), Inches(1.4), Inches(11.9), [
    "curvefit run.toml                    # 設定ファイルだけで実行",
    "curvefit run.toml -i data/ -o out/   # 入力と出力先を差し替え",
    "curvefit --help                      # 指定できる項目の一覧",
])

txt(s, Inches(0.72), Inches(2.75), Inches(6.4), Inches(0.3),
    [[run_("よく使う実行時引数", 15, INK, True)]])
table(s, Inches(0.72), Inches(3.13), [Inches(2.5), Inches(3.9)],
      [["引数", "働き"],
       ["-i / --input", "入力の位置。複数回指定できる"],
       ["-o / --output", "出力先ディレクトリ"],
       ["--delimiter", "区切り文字（2 文字以上は正規表現）"],
       ["--y-column", "列の並びを、この 1 件に置き換える"],
       ["--failure-policy", "skip / fail_fast"],
       ["--quiet", "進捗と集計を表示しない"]],
      mono_cols=(0,), size=12, row_h=Inches(0.38))

txt(s, Inches(7.35), Inches(2.75), Inches(5.3), Inches(0.3),
    [[run_("終了コードは 3 状態を区別する", 15, INK, True)]])
table(s, Inches(7.35), Inches(3.13), [Inches(0.9), Inches(4.4)],
      [["コード", "意味"],
       ["0", "全処理単位が成功した"],
       ["1", "1 件以上が失敗した、または中断した"],
       ["2", "実行前検証で停止した（1 件も実行していない）"]],
      mono_cols=(0,), size=12, row_h=Inches(0.42))

card(s, Inches(7.35), Inches(5.0), Inches(5.3), Inches(1.5), "標準出力は実行中つねに空",
     ["進捗・集計・違反はすべて標準エラー出力に書く。",
      "curvefit run.toml > result.txt のような取り回しを壊さない。"])

note(s, Inches(0.72), Inches(5.85), Inches(6.4),
     "--y-column は並びを 1 件に置き換える。--weight-column も同じなので、"
     "片方だけを置き換えると個数が合わず拒まれる。")
footer(s)

# ============================================================
# 11. うまくいかないとき
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "うまくいかないとき", 8)
txt(s, Inches(0.72), Inches(1.4), Inches(12), Inches(0.35),
    [[run_("実行前検証は、違反を 1 件ずつでなく", 14.5, INK, False),
      run_("全件まとめて", 14.5, ACCENT, True),
      run_(" 報告する。1 件直しては再実行する往復を強いない。", 14.5, INK, False)]])
code(s, Inches(0.72), Inches(1.9), Inches(11.9), [
    ("model_unresolved        method[line].builtin", BAD),
    ("smoother_option_invalid method[ma].options", BAD),
    ("config_invalid          preprocess.x_min", BAD),
    ("config_invalid          preprocess.outlier.sigma", BAD),
], size=13, title="出力例（終了コード 2。処理単位は 1 件も実行されていない）")

txt(s, Inches(0.72), Inches(3.65), Inches(12), Inches(0.3),
    [[run_("よくあるつまずき", 15, INK, True)]])
table(s, Inches(0.72), Inches(4.03), [Inches(4.3), Inches(4.0), Inches(3.6)],
      [["症状", "原因", "対処"],
       ["1 行目から構文誤り", "設定ファイルに BOM が付いている", "BOM 無し UTF-8 で保存"],
       ["列数が行ごとに食い違う", "delimiter = \" \" と書いた", "delimiter = '\\s+'"],
       ["未知のエスケープで拒まれる", "delimiter = \"\\s+\" と書いた", "'\\s+' か \"\\\\s+\""],
       ["個数不一致で実行前に停止", "y と weight の並びの長さが違う", "両方を同数にする"],
       ["後段の手順がずれた", "出力名とサマリ列が変わった", "「注意事項」を参照"]],
      size=12, row_h=Inches(0.4))
footer(s)

# ============================================================
# 12. Python から使う
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "Python から使う", 9)
txt(s, Inches(0.72), Inches(1.4), Inches(12), Inches(0.35),
    [[run_("CLI はライブラリの薄いラッパーであり、", 14.5, INK, False),
      run_("同じ実行経路を通る", 14.5, INK, True),
      run_("。CLI とライブラリで結果は一致する。", 14.5, INK, False)]])

code(s, Inches(0.72), Inches(1.95), Inches(6.1), [
    "from pathlib import Path",
    "from curvefit import run_from_config, BatchReport",
    "",
    "result = run_from_config(Path(\"run.toml\"))",
    "if isinstance(result, BatchReport):",
    "    print(result.n_success, result.n_failure)",
    "else:",
    "    for violation in result.violations:",
    "        print(violation.kind, violation.location)",
], size=12, title="設定ファイルから一括実行する")

code(s, Inches(7.2), Inches(1.95), Inches(5.4), [
    "from curvefit import fit_series",
    "",
    "outcome = fit_series(series, method)",
], size=12, title="メモリ上の 1 系列に当てはめる")

card(s, Inches(7.2), Inches(3.35), Inches(5.4), Inches(1.5),
     "fit_series は出力物を残さない",
     ["一括処理と同一の実行経路を通しつつ、ファイルは 1 つも書かない。",
      "曲線データは保持したまま返る。"])

note(s, Inches(0.72), Inches(4.88), Inches(6.1),
     "違反があれば例外ではなく PreflightResult が返る。", kind="ok")

txt(s, Inches(0.72), Inches(5.62), Inches(11.9), Inches(0.3),
    [[run_("自分で読み込んだ表を渡す場合は、同じ読み取り指定を行うこと", 15, INK, True)]])
code(s, Inches(0.72), Inches(6.0), Inches(11.9), [
    ('frame = pd.read_csv(path, float_precision="round_trip")', GOOD),
], size=13)
footer(s)

# ============================================================
# 13. 注意事項
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "注意事項", 10)

box(s, Inches(0.72), Inches(1.4), Inches(11.9), Inches(1.35), fill=WARNBG, round_=True)
box(s, Inches(0.72), Inches(1.58), Pt(6), Inches(0.99), fill=BAD)
txt(s, Inches(1.05), Inches(1.55), Inches(11.3), Inches(0.35),
    [[run_("安全性 — 第三者から受け取った設定ファイルをそのまま実行しないこと", 16, BAD, True)]])
txt(s, Inches(1.05), Inches(1.98), Inches(11.3), Inches(0.6),
    [[run_("設定ファイルの expression に書いた数式文字列は評価される。"
        "任意の Python コードを実行することと同等のリスクを持つ。実行前に中身を読むこと。",
        13, INK, False)]])

card(s, Inches(0.72), Inches(2.95), Inches(5.85), Inches(1.6), "読み取り精度",
     ["CSV を float_precision=\"round_trip\" で読み、値を最終ビットまで保つ。",
      "既定の解釈器は実測で値の約 46% の最下位ビットを変える。",
      "劣化した値はライブラリ側では回復できない。"], accent=ACCENT2, body_size=12)

card(s, Inches(6.77), Inches(2.95), Inches(5.85), Inches(1.6), "再現性の担保",
     ["同じ設定と同じ入力なら、再実行の出力はバイト単位で一致する。",
      "設定と実行時引数の双方で指定された項目は実行時引数が優先される。",
      "上書きは execution.json に前後の値ごと残る。"], accent=GOOD, body_size=12)

txt(s, Inches(0.72), Inches(5.0), Inches(12), Inches(0.3),
    [[run_("以前の版からの変更（破壊的）", 15, INK, True)]])
table(s, Inches(0.72), Inches(5.38), [Inches(6.3), Inches(5.6)],
      [["変更", "影響"],
       ["出力ファイル名に列が入るようになった",
        "y 列が 1 つだけの設定でも名前が変わる"],
       ["サマリ CSV に column_label / column_name の 2 列が増えた",
        "列を位置で読む後段はずれる。名前引きに直すこと"]],
      size=12, row_h=Inches(0.48))
footer(s)

# ============================================================
# 14. 早見表
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s)
header(s, "早見表", 11)
txt(s, Inches(0.72), Inches(1.35), Inches(6.0), Inches(0.3),
    [[run_("やりたいこと → 書くこと", 15, INK, True)]])
table(s, Inches(0.72), Inches(1.73), [Inches(2.9), Inches(3.4)],
      [["やりたいこと", "書くこと"],
       ["フォルダをまとめて処理", "paths = [\"data\"]"],
       ["一部のファイルだけ", "paths = [\"data/run_*.csv\"]"],
       ["複数モデルを比較", "[[methods]] を並べる"],
       ["複数チャネルを処理", "y = [\"ch1\", \"ch2\"]"],
       ["列名が毎回変わる", "x = 0 / y = 1"],
       ["空白区切りの装置出力", "delimiter = '\\s+'"],
       ["曲線データも欲しい", "write_curve = true"],
       ["最初の失敗で止めたい", "failure_policy = \"fail_fast\""]],
      mono_cols=(1,), size=12, row_h=Inches(0.4))

txt(s, Inches(7.2), Inches(1.35), Inches(5.4), Inches(0.3),
    [[run_("覚えておくとよいこと", 15, INK, True)]])
tips = [
    ("設定ファイルが唯一の正", "同じ設定と同じ入力なら結果は同じ。手順を人に渡せる"),
    ("違反は全件まとめて出る", "終了コード 2 のときは何も書き出されていない"),
    ("出力名に列が入る", "{対象}__{列}__{手法}__{番号}。上書き事故が起きない"),
    ("進捗の件数はファイル数と違う", "入力数 × 列数 × 手法数"),
    ("標準出力は実行中つねに空", "リダイレクトを壊さない"),
]
ty = Inches(1.73)
for title, body in tips:
    box(s, Inches(7.2), ty, Inches(5.4), Inches(0.92), fill=CARDBG, line=RULE, round_=True)
    box(s, Inches(7.2), ty + Inches(0.16), Pt(5), Inches(0.6), fill=ACCENT)
    txt(s, Inches(7.48), ty + Inches(0.14), Inches(5.0), Inches(0.3),
        [[run_(title, 13, INK, True)]])
    txt(s, Inches(7.48), ty + Inches(0.5), Inches(5.0), Inches(0.32),
        [[run_(body, 11, GRAY, False)]])
    ty += Inches(1.0)

card(s, Inches(0.72), Inches(5.42), Inches(6.0), Inches(1.1), "困ったら",
     ["curvefit --help に、指定できる項目と終了コードが出る。",
      "仕様の根拠は .kiro/specs/ に残してある。"], body_size=12)
footer(s)

# ============================================================
# 15. 裏表紙
# ============================================================
s = prs.slides.add_slide(BLANK)
bg(s, ACCENT2)
box(s, Inches(0.9), Inches(2.9), Pt(10), Inches(1.4), fill=ACCENT)
txt(s, Inches(1.25), Inches(2.9), Inches(11), Inches(0.7),
    [[run_("同じ設定ファイルと同じ入力なら、", 26, WHITE, True)]], anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.25), Inches(3.6), Inches(11), Inches(0.7),
    [[run_("誰がいつ実行しても同じ結果になる。", 26, WHITE, True)]], anchor=MSO_ANCHOR.MIDDLE)
txt(s, Inches(1.27), Inches(4.75), Inches(11), Inches(0.4),
    [[run_("curvefit ユーザーマニュアル", 14, RGBColor(0xC9, 0xD6, 0xE0), False)]])

out = str(pathlib.Path(__file__).with_name("curvefit_ユーザーマニュアル.pptx"))
prs.save(out)
print(f"saved: {out}  ({len(prs.slides.__iter__.__self__._sldIdLst)} slides)")
