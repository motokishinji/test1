"""curvefit User Manual (detailed) Word generator - English

The slide deck (make_curvefit_manual_ppt_en.py) is for getting started; this
document is meant to be looked things up in. It covers every configuration key,
every output column, every preflight violation and every failure reason.

Everything here comes from the code and from actual runs:
  - configuration keys : src/curvefit/config.py, the *_KEYS tuples
  - built-in models    : src/curvefit/models/registry.py (parameter names were
                         obtained by constructing the models)
  - smoother options   : src/curvefit/engines/smoothing.py
  - preprocessing      : src/curvefit/preprocess.py
  - output columns     : src/curvefit/writers.py
  - violations/failures: src/curvefit/errors.py
  - command options    : curvefit --help
When a command or a configuration key changes, update the matching section here
and in the Japanese counterpart, make_curvefit_manual_docx.py.
"""
import pathlib

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

FONT   = "Calibri"
FONTM  = "Consolas"

INK    = RGBColor(0x1A, 0x1A, 0x1A)
GRAY   = RGBColor(0x5A, 0x55, 0x50)
ACCENT = RGBColor(0xB5, 0x5A, 0x38)
DEEP   = RGBColor(0x2E, 0x4A, 0x62)
BAD    = RGBColor(0xB5, 0x3A, 0x2E)
GOOD   = RGBColor(0x2F, 0x6B, 0x38)

CODE_FILL = "F2F0EC"
HEAD_FILL = "2E4A62"
WARN_FILL = "FBF0E8"
OK_FILL   = "EEF4EE"
ROW_FILL  = "F6F4F1"


# Headings that appear in the table of contents. Checked one-to-one against the
# heading() calls in the body, so the two can never drift apart.
OUTLINE = [
    (1, "1. Introduction"),
    (2, "1.1 What this document is for"),
    (2, "1.2 What curvefit solves"),
    (2, "1.3 Terminology"),
    (2, "1.4 The overall flow"),
    (1, "2. Getting set up"),
    (2, "2.1 Requirements"),
    (2, "2.2 Installation"),
    (2, "2.3 Checks used during development"),
    (1, "3. Basic usage"),
    (2, "3.1 A minimal configuration"),
    (2, "3.2 What gets written"),
    (2, "3.3 Comparing several methods"),
    (1, "4. Configuration file reference"),
    (2, "4.1 Overall structure"),
    (2, "4.2 [input]"),
    (2, "4.3 [input.columns]"),
    (2, "4.4 [[methods]]"),
    (2, "4.5 [preprocess]"),
    (2, "4.6 [preprocess.outlier]"),
    (2, "4.7 [output]"),
    (2, "4.8 A complete configuration file"),
    (1, "5. Method reference"),
    (2, "5.1 Built-in models (builtin)"),
    (2, "5.2 Expressions (expression)"),
    (2, "5.3 Regression and smoothing (smoother)"),
    (1, "6. Preprocessing"),
    (2, "6.1 Dropping points by range"),
    (2, "6.2 Outlier removal"),
    (1, "7. Reading the input data"),
    (2, "7.1 Delimiters"),
    (2, "7.2 Header rows"),
    (2, "7.3 Specifying columns by position"),
    (2, "7.4 Several measurement channels in one file"),
    (2, "7.5 Numeric reading precision"),
    (1, "8. Output reference"),
    (2, "8.1 What gets produced"),
    (2, "8.2 How output files are named"),
    (2, "8.3 Columns of summary.csv"),
    (2, "8.4 Columns of the curve and preprocess CSV"),
    (2, "8.5 execution.json"),
    (2, "8.6 run.log"),
    (1, "9. Command line reference"),
    (2, "9.1 Synopsis"),
    (2, "9.2 Options"),
    (2, "9.3 What can be overridden"),
    (2, "9.4 Exit codes"),
    (2, "9.5 Standard output and standard error"),
    (1, "10. Errors and what to do about them"),
    (2, "10.1 Preflight violations"),
    (2, "10.2 Per-job failures"),
    (2, "10.3 Common stumbling blocks"),
    (1, "11. Using curvefit as a Python library"),
    (2, "11.1 Running a batch from a configuration file"),
    (2, "11.2 Building the run conditions yourself"),
    (2, "11.3 Fitting a single in-memory series"),
    (2, "11.4 The main public types"),
    (1, "12. Reproducibility and security"),
    (2, "12.1 Reproducibility"),
    (2, "12.2 Security"),
    (1, "13. Migrating from the previous version"),
    (1, "Appendix A  Configuration quick reference"),
    (1, "Appendix B  Specification and design records"),
]

_outline_left = list(OUTLINE)

# ---------------------------------------------------------------- primitives

def _set_run_font(run, name, size=None, bold=None, color=None):
    """Word resolves Latin and East Asian faces separately; set both."""
    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rfonts.set(qn(attr), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color


def _shade(element, fill):
    """Fill the background of a paragraph or a table cell."""
    pr = element.get_or_add_pPr() if element.tag.endswith("}p") else element.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    pr.append(shd)


def _borders(paragraph, color="D8D2C8", size=6, sides=("top", "left", "bottom", "right")):
    pbdr = OxmlElement("w:pBdr")
    for side in sides:
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(size))
        el.set(qn("w:space"), "6")
        el.set(qn("w:color"), color)
        pbdr.append(el)
    paragraph._p.get_or_add_pPr().append(pbdr)


def _keep_with_next(paragraph):
    """Stop a heading from being stranded at the foot of a page."""
    paragraph._p.get_or_add_pPr().append(OxmlElement("w:keepNext"))


# ------------------------------------------------------------------ builders

def title_page(doc, title, subtitle, lines):
    for _ in range(4):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(p.add_run("curvefit"), FONTM, 40, True, DEEP)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(p.add_run(title), FONT, 26, True, INK)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(p.add_run(subtitle), FONT, 13, False, GRAY)
    doc.add_paragraph()
    for line in lines:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_run_font(p.add_run(line), FONT, 10.5, False, GRAY)


def heading(doc, text, level):
    # Fail on the spot if the body and the table of contents disagree.
    if text != "Contents":
        assert _outline_left, f"heading missing from the outline: {text}"
        expected = _outline_left.pop(0)
        assert expected == (level, text), f"outline mismatch: {expected} != {(level, text)}"
    sizes = {1: 18, 2: 14, 3: 12}
    colors = {1: DEEP, 2: INK, 3: INK}
    p = doc.add_heading("", level=level)
    p.paragraph_format.space_before = Pt(30 if level == 1 else 12)
    p.paragraph_format.space_after = Pt(6)
    _set_run_font(p.add_run(text), FONT, sizes[level], True, colors[level])
    _keep_with_next(p)
    return p


def body(doc, text, size=10.5, color=INK, space_after=6):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.15
    _set_run_font(p.add_run(text), FONT, size, False, color)
    return p


def bullets(doc, items, size=10.5):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.line_spacing = 1.15
        _set_run_font(p.add_run(item), FONT, size, False, INK)


def code(doc, lines, size=9.5):
    """A code block, kept in one paragraph so it resists being split."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.left_indent = Cm(0.3)
    p.paragraph_format.line_spacing = 1.0
    _shade(p._p, CODE_FILL)
    _borders(p)
    for i, line in enumerate(lines):
        if i:
            # The break needs its own run: assigning .text discards whatever the
            # run already holds, which would silently swallow the break.
            _set_run_font(p.add_run(), FONTM, size)
            p.runs[-1].add_break()
        _set_run_font(p.add_run(line if line else " "), FONTM, size, False, INK)
    return p


def callout(doc, text, kind="warn"):
    fill = WARN_FILL if kind == "warn" else OK_FILL
    color = BAD if kind == "warn" else GOOD
    mark = "Caution" if kind == "warn" else "Note"
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.left_indent = Cm(0.3)
    p.paragraph_format.line_spacing = 1.15
    _shade(p._p, fill)
    _borders(p, color="D8D2C8")
    _set_run_font(p.add_run(f"{mark}  "), FONT, 10, True, color)
    _set_run_font(p.add_run(text), FONT, 10, False, INK)
    return p


def table(doc, headers, rows, widths=None, mono_cols=(), size=9.5):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    t.autofit = False
    # Turning autofit off is not enough on its own: the column widths are only
    # honoured once the layout is fixed.
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    t._tbl.tblPr.append(layout)
    for i, text in enumerate(headers):
        cell = t.rows[0].cells[i]
        cell.text = ""
        _shade(cell._tc, HEAD_FILL)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(2)
        _set_run_font(p.add_run(text), FONT, size, True, RGBColor(0xFF, 0xFF, 0xFF))
        _keep_with_next(p)
    # Repeat the header row whenever the table crosses a page boundary.
    head_pr = t.rows[0]._tr.get_or_add_trPr()
    head_pr.append(OxmlElement("w:tblHeader"))
    head_pr.append(OxmlElement("w:cantSplit"))
    for r, row in enumerate(rows):
        tr = t.add_row()
        # A row torn across a page boundary leaves an empty continuation row.
        tr._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        cells = tr.cells
        for i, text in enumerate(row):
            cell = cells[i]
            cell.text = ""
            if r % 2:
                _shade(cell._tc, ROW_FILL)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.line_spacing = 1.05
            _set_run_font(p.add_run(text), FONTM if i in mono_cols else FONT, size, False, INK)
    if widths:
        # Widths go both on the cells (w:tcW) and on the table grid
        # (w:tblGrid). With only one of them set, the renderer follows the grid
        # and the request is ignored.
        twips = [round(w * 566.93) for w in widths]
        grid = t._tbl.find(qn("w:tblGrid"))
        if grid is not None:
            for col, value in zip(grid.findall(qn("w:gridCol")), twips, strict=False):
                col.set(qn("w:w"), str(value))
        tbl_w = OxmlElement("w:tblW")
        tbl_w.set(qn("w:w"), str(sum(twips)))
        tbl_w.set(qn("w:type"), "dxa")
        t._tbl.tblPr.append(tbl_w)
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def toc(doc):
    """Contents. Updating the field in Word turns this into a live TOC.

    A static list is planted as the field result so the chapter structure is
    readable even where the field is never updated.
    """
    lead = doc.add_paragraph()
    run = lead.add_run()
    _set_run_font(run, FONT, 10.5)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    begin.set(qn("w:dirty"), "true")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = r'TOC \o "1-2" \h \z \u'
    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    for el in (begin, instr, sep):
        run._r.append(el)

    for level, text in OUTLINE:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.left_indent = Cm(0.0 if level == 1 else 0.8)
        _set_run_font(p.add_run(text), FONT, 11 if level == 1 else 10,
                      level == 1, DEEP if level == 1 else INK)

    tail = doc.add_paragraph()
    tail.paragraph_format.space_before = Pt(10)
    _set_run_font(tail.add_run(
        "Select the whole document in Word and press F9 to turn this into a table of "
        "contents with page numbers."), FONT, 9, False, GRAY)
    run = tail.add_run()
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(end)


def page_number_footer(section):
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    _set_run_font(run, FONT, 9, False, GRAY)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for el in (begin, instr, end):
        run._r.append(el)


def header_text(section, text):
    p = section.header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    _set_run_font(p.add_run(text), FONT, 9, False, GRAY)


def page_break(doc):
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


# ------------------------------------------------------------------ document

doc = Document()

style = doc.styles["Normal"]
style.font.name = FONT
style.font.size = Pt(10.5)
style.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

section = doc.sections[0]
section.page_width = Cm(21.0)
section.page_height = Cm(29.7)
section.left_margin = Cm(2.2)
section.right_margin = Cm(2.0)
section.top_margin = Cm(2.0)
section.bottom_margin = Cm(2.0)
header_text(section, "curvefit User Manual (detailed)")
page_number_footer(section)

title_page(
    doc,
    "User Manual (detailed)",
    "Fit measurement data in one batch, reproducibly, from a single configuration file",
    ["version 0.1.0", "Requires Python 3.11 or later"],
)

page_break(doc)
heading(doc, "Contents", 1)
toc(doc)

# ============================================================ 1
heading(doc, "1. Introduction", 1)

heading(doc, "1.1 What this document is for", 2)
body(doc,
     "This is the detailed reference for curvefit. It covers every configuration key, every "
     "output column, every violation the preflight check can report, and every reason an "
     "individual job can fail. The material for getting started is in the slide deck; this "
     "document is what you reach for afterwards.")

heading(doc, "1.2 What curvefit solves", 2)
body(doc,
     "Processing measurement data one file at a time in a spreadsheet, with a throwaway "
     "script per job, makes the procedure personal to whoever wrote it and impossible to "
     "reproduce later. As the number of files grows, the working time grows with it.")
body(doc, "curvefit runs two kinds of fitting in one batch, from a single configuration file.")
bullets(doc, [
    "(a) Non-linear least squares - estimates the parameters of a model function you specify",
    "(b) Regression and smoothing - assumes no model formula",
])
body(doc,
     "Reproducibility is the central value. Given the same configuration file and the same "
     "input data, anyone running it at any time gets the same result, and the output matches "
     "byte for byte.")

heading(doc, "1.3 Terminology", 2)
table(doc,
      ["Term", "Meaning"],
      [["target", "One y column of one input file. A file with several y columns yields one "
                  "target per column"],
       ["job", "A target paired with a method. This is the unit that actually runs, and the "
               "count is inputs x columns x methods"],
       ["method", "One [[methods]] entry: a built-in model, an expression, or "
                  "regression/smoothing"],
       ["preflight", "The stage that collects every configuration violation before a single "
                     "job runs"],
       ["violation", "A configuration error found by preflight. One is enough to stop "
                     "everything"],
       ["failure", "Something that goes wrong in an individual job. By default the rest of "
                   "the run continues"]],
      widths=[3.0, 13.5])

heading(doc, "1.4 The overall flow", 2)
body(doc, "Configuration file, preflight check, read and preprocess, fit, output - in that order.")
callout(doc,
        "When the preflight check finds a violation, not a single job runs and nothing is "
        "written. A configuration error affects every job equally, so writing part of the "
        "output and then stopping costs more to recover from than writing nothing and "
        "reporting every violation at once.", kind="ok")

# ============================================================ 2
heading(doc, "2. Getting set up", 1)

heading(doc, "2.1 Requirements", 2)
table(doc,
      ["Item", "Detail"],
      [["Python", "3.11 or later (3.11 and 3.12 are exercised continuously)"],
       ["Dependencies", "lmfit / SciPy / NumPy / pandas / matplotlib / asteval"],
       ["Encoding", "The configuration file must be UTF-8 without a BOM"]],
      widths=[3.6, 12.9])

heading(doc, "2.2 Installation", 2)
code(doc, [
    "python3 -m venv .venv",
    "source .venv/bin/activate",
    'pip install -e ".[dev]"',
])
body(doc, "Confirm the installation with the following. Seeing the usage text means it worked.")
code(doc, ["curvefit --help"])

heading(doc, "2.3 Checks used during development", 2)
body(doc, "If you change the repository, these three have to pass. CI runs the same three on "
          "every push and pull request.")
code(doc, [
    "ruff check src tests   # style violations",
    "mypy                   # type inconsistencies",
    "pytest                 # the test suite (performance tests excluded by default)",
])

# ============================================================ 3
heading(doc, "3. Basic usage", 1)

heading(doc, "3.1 A minimal configuration", 2)
body(doc, "Save the following as run.toml.")
code(doc, [
    "[input]",
    'paths = ["data"]',
    "header = true",
    "",
    "[input.columns]",
    'x = "time"',
    'y = "signal"',
    "",
    "[[methods]]",
    'name = "line"',
    'builtin = "linear"',
    "",
    "[output]",
    'directory = "out"',
])
body(doc, "Run it.")
code(doc, ["curvefit run.toml"])

heading(doc, "3.2 What gets written", 2)
body(doc, "With a single sample.csv in the data directory, the following is produced.")
code(doc, [
    "out/",
    "  summary.csv",
    "  execution.json",
    "  run.log",
    "  plots/",
    "    sample__signal__line__0000.png",
])
body(doc, "The curve and residual CSV is not written by default. Set output.write_curve to "
          "true when you need it.")

heading(doc, "3.3 Comparing several methods", 2)
body(doc, "List several [[methods]] entries and one run compares them in the same summary table.")
code(doc, [
    "[[methods]]",
    'name = "line"',
    'builtin = "linear"',
    "",
    "[[methods]]",
    'name = "quad"',
    'builtin = "polynomial"',
    "options = { degree = 2 }",
])

# ============================================================ 4
heading(doc, "4. Configuration file reference", 1)

heading(doc, "4.1 Overall structure", 2)
body(doc, "The configuration file is TOML. Only the following five keys may appear at the top "
          "level; anything else is treated as a misspelling and rejected before the run.")
table(doc,
      ["Key", "Type", "Default", "Meaning"],
      [["failure_policy", "string", '"skip"', 'either "skip" or "fail_fast"'],
       ["input", "table", "required", "which data to read"],
       ["methods", "array of tables", "required", "how to fit it; written as [[methods]]"],
       ["preprocess", "table", "optional", "what to drop before fitting"],
       ["output", "table", "optional", "where and what to write"]],
      widths=[3.2, 2.8, 2.2, 8.3], mono_cols=(0, 2))

heading(doc, "4.2 [input]", 2)
table(doc,
      ["Key", "Type", "Default", "Meaning"],
      [["paths", "array of strings", "required",
        "files, directories or wildcards; they may be mixed"],
       ["delimiter", "string", "from the extension",
        "two or more characters are read as a regular expression; see 7.1"],
       ["header", "boolean", "unset",
        "unset / true / false. An input that cannot be judged while unset fails"],
       ["columns", "table", "required", "see 4.3"]],
      widths=[2.6, 2.8, 3.0, 8.1], mono_cols=(0,))
body(doc, "A wildcard containing ** descends into subdirectories. Matches that are "
          "directories are excluded.")

heading(doc, "4.3 [input.columns]", 2)
table(doc,
      ["Key", "Type", "Default", "Meaning"],
      [["x", "string or integer", "required",
        "column name, or a zero-based position. An integer is always a position"],
       ["y", "string/integer, or a list", "required",
        "given a list, one run processes every channel"],
       ["weight", "same shape as y", "optional",
        "the uncertainty column. The i-th weight belongs to the i-th y"]],
      widths=[2.0, 3.4, 2.2, 8.9], mono_cols=(0,))
callout(doc,
        "If y and weight do not have the same number of entries, the run is rejected before "
        "a single job is executed.")
body(doc, "The weight enters the fit as 1/sigma, not as sigma itself, so points with larger "
          "uncertainty contribute less.")

heading(doc, "4.4 [[methods]]", 2)
body(doc, "One entry describes one method. Write as many as you like.")
table(doc,
      ["Key", "Type", "Meaning"],
      [["name", "string", "the identifier used in output file names and the summary. Required"],
       ["builtin", "string", "a built-in model name; see 5.1"],
       ["expression", "string", "a formula; see 5.2"],
       ["smoother", "string", "the kind of regression or smoothing; see 5.3"],
       ["initial", "table", "starting values for the parameters"],
       ["bounds", "table", "parameter bounds: bounds.<name> = { min = .., max = .. }"],
       ["fixed", "table", "parameters to hold fixed, and the value to hold them at"],
       ["options", "table", "method-specific options (degree, lam, window, polyorder)"]],
      widths=[2.4, 2.0, 12.1], mono_cols=(0,))
callout(doc,
        "Write exactly one of builtin, expression and smoother. There is no separate "
        'kind = "..." declaration, which makes a configuration whose declaration contradicts '
        "its content impossible to express.", kind="ok")
body(doc, "Bounds are a table rather than an array because TOML has no notation for an empty "
          "value, so an array cannot express a bound on one side only.")

heading(doc, "4.5 [preprocess]", 2)
table(doc,
      ["Key", "Type", "Default", "Meaning"],
      [["x_min", "number", "none", "drop points whose x is below this value"],
       ["x_max", "number", "none", "drop points whose x is above this value"],
       ["outlier", "table", "none",
        "outlier removal runs if the table is present, and not otherwise"]],
      widths=[2.2, 2.0, 2.0, 10.3], mono_cols=(0,))

heading(doc, "4.6 [preprocess.outlier]", 2)
table(doc,
      ["Key", "Type", "Default", "Meaning"],
      [["sigma", "number", "3.0",
        "how many times the residual spread counts as an outlier. Must be positive"],
       ["max_iterations", "integer", "3",
        "cap on the fit / measure / drop cycle"]],
      widths=[3.2, 2.0, 1.6, 9.7], mono_cols=(0,))
body(doc, "Section 6.2 covers the algorithm, and the blind spots of the default value.")

heading(doc, "4.7 [output]", 2)
table(doc,
      ["Key", "Type", "Default", "Meaning"],
      [["directory", "string", '"out"', "the output directory"],
       ["write_summary", "boolean", "true", "write the summary CSV"],
       ["write_plot", "boolean", "true", "write the plot images"],
       ["write_curve", "boolean", "false", "write the fitted curve and residual CSV"]],
      widths=[3.2, 2.0, 1.8, 9.5], mono_cols=(0, 2))

heading(doc, "4.8 A complete configuration file", 2)
code(doc, [
    'failure_policy = "skip"',
    "",
    "[input]",
    'paths = ["data/*.csv"]',
    'delimiter = ","',
    "header = true",
    "",
    "[input.columns]",
    'x = "time"',
    'y = ["signal", "ref"]',
    'weight = ["sigma_signal", "sigma_ref"]',
    "",
    "[[methods]]",
    'name = "gauss"',
    'builtin = "gaussian"',
    "initial = { amplitude = 2.0 }",
    "fixed   = { center = 1.0 }",
    "bounds.amplitude = { min = 0.0, max = 10.0 }",
    "",
    "[preprocess]",
    "x_min = 0.0",
    "x_max = 10.0",
    "",
    "[preprocess.outlier]",
    "sigma = 3.0",
    "max_iterations = 3",
    "",
    "[output]",
    'directory = "out"',
    "write_summary = true",
    "write_plot    = true",
    "write_curve   = false",
])

# ============================================================ 5
heading(doc, "5. Method reference", 1)
body(doc, "The kind of method is decided by which key you write in [[methods]].")

heading(doc, "5.1 Built-in models (builtin)", 2)
table(doc,
      ["Name", "Parameters", "Options", "Starting values"],
      [["linear", "slope, intercept", "-", "estimated from the data"],
       ["polynomial", "c0, c1, ... c<degree>", "degree (default 2)", "estimated from the data"],
       ["gaussian", "amplitude, center, sigma", "-", "estimated from the data"],
       ["exponential", "amplitude, decay", "-", "estimated from the data"]],
      widths=[2.8, 5.2, 3.4, 5.1], mono_cols=(0, 1, 2))
body(doc, "Every built-in model can estimate its starting values from the data, so initial is "
          "optional. When you do supply it, your values win.")
code(doc, [
    "[[methods]]",
    'name = "gauss"',
    'builtin = "gaussian"',
    "initial = { amplitude = 2.0, center = 5.0 }",
])

heading(doc, "5.2 Expressions (expression)", 2)
body(doc, "x is the independent variable and every other symbol becomes a parameter. Unlike a "
          "built-in model, nothing is estimated from the data, so initial is required.")
code(doc, [
    "[[methods]]",
    'name = "mine"',
    'expression = "a * x + b"',
    "initial = { a = 1.0, b = 0.0 }",
])
callout(doc,
        "The formula string is evaluated. Running a configuration file you received from "
        "someone else carries the same risk as running arbitrary Python code. See chapter 12.")

heading(doc, "5.3 Regression and smoothing (smoother)", 2)
table(doc,
      ["Name", "Options", "Default", "Constraint", "Parameters", "Weights"],
      [["linear", "-", "-", "-", "slope, intercept", "used"],
       ["polynomial", "degree", "2", "integer, 0 or more", "c0 onwards", "used"],
       ["spline", "lam", "required", "positive finite number", "none", "used"],
       ["moving_average", "window", "5", "positive odd number", "none", "ignored"],
       ["", "polyorder", "0", "0 or more, below window", "", ""]],
      widths=[3.4, 2.3, 1.7, 3.9, 3.1, 2.1], mono_cols=(0, 1, 2))
body(doc, "With polyorder at 0, moving_average is a plain mean over the window. Raising the "
          "order turns it into Savitzky-Golay smoothing, which preserves peak shape.")
callout(doc,
        "spline requires lam, the smoothing strength. Delegating it to the underlying "
        "library's automatic selection was deliberately ruled out: the value it picks depends "
        "on the input, which is incompatible with the reproducibility guarantee.", kind="ok")
callout(doc,
        "spline and moving_average return only the smoothed series and carry no parameters at "
        "all. Writing initial or bounds for them is rejected before the run.")
code(doc, [
    "[[methods]]",
    'name = "spl"',
    'smoother = "spline"',
    "options = { lam = 0.01 }",
])

# ============================================================ 6
heading(doc, "6. Preprocessing", 1)
body(doc, "Preprocessing drops points before the fit. How many were dropped is recorded in the "
          "summary table.")

heading(doc, "6.1 Dropping points by range", 2)
body(doc, "Points outside x_min / x_max are dropped; either bound may be given on its own. "
          "The count goes into n_dropped_out_of_range.")

heading(doc, "6.2 Outlier removal", 2)
body(doc, "This runs only when the [preprocess.outlier] table is present. The cycle is:")
bullets(doc, [
    "perform a provisional fit",
    "measure the spread of the residuals (root mean square about a fixed centre of 0)",
    "drop points beyond sigma times that spread",
    "stop when nothing more is dropped, or after max_iterations rounds",
])
body(doc, "The count goes into n_dropped_outlier, and the dropped points themselves are "
          "written to the preprocess CSV.")

callout(doc,
        "The default sigma = 3.0 has blind spots. Each of them shows up as \"I enabled outlier "
        "removal and nothing was removed\", with no warning and no report.")
body(doc, "The test depends only on the ratio between residuals, and that ratio can never "
          "exceed the square root of the number of points. Hence the following.")
bullets(doc, [
    "With 9 points or fewer (in general n <= sigma squared), a single outlier is never "
    "removed however large it is, because the outlier itself lifts the yardstick by the same "
    "amount",
    "When k >= n / sigma squared outliers of comparable size are present, none of those k "
    "points is removed. At the default that is 2 points out of 12, or 3 out of 20",
    "When the provisional fit is uniformly offset across all points, an outlier that is not "
    "large relative to that offset is not removed. At the default, with 12 points, roughly "
    "5.7 times the offset is needed",
])
body(doc, "To make removal bite on short series, or on series holding several outliers, sigma "
          "has to be set below the default.")

# ============================================================ 7
heading(doc, "7. Reading the input data", 1)

heading(doc, "7.1 Delimiters", 2)
body(doc, "The file extension guarantees nothing. Some instruments emit column-aligned, "
          "space-separated output under a .csv name. Such files read fine once delimiter is "
          "stated explicitly.")
code(doc, [
    "[input]",
    'paths = ["data"]',
    "delimiter = '\\s+'",
])
body(doc, "Two or more characters are read as a regular expression. TOML offers three ways to "
          "write it, one of which is a syntax error.")
table(doc,
      ["Written as", "Result"],
      [["delimiter = '\\s+'", "works; a literal string needs no escaping (recommended)"],
       ['delimiter = "\\\\s+"', "works; a basic string doubles the backslash"],
       ['delimiter = "\\s+"', "TOML syntax error; rejected as an unknown escape"]],
      widths=[5.0, 11.5], mono_cols=(0,))
callout(doc,
        'delimiter = " " does not work. A run of spaces counts as empty columns, the column '
        "count then differs from row to row, and the read fails. It is the first thing one "
        "reaches for with space-separated data, and the answer is '\\s+'.")
body(doc, "A regular expression still preserves every last bit of the values.")

heading(doc, "7.2 Header rows", 2)
body(doc, "header has three states: unset, true and false. While unset, curvefit tries to "
          "judge from the content, and an input it cannot judge fails as header_ambiguous. "
          "Where the presence of a header is not consistent, as with instrument output, "
          "stating it explicitly is the safe course.")

heading(doc, "7.3 Specifying columns by position", 2)
body(doc, "Instruments often put the channel name in the header, so it changes from file to "
          "file. Specifying the columns by position lets one configuration cover them all, and "
          "a header decorated with # or similar makes no difference.")
code(doc, [
    "[input.columns]",
    "x = 0",
    "y = 1",
])

heading(doc, "7.4 Several measurement channels in one file", 2)
body(doc, "Give y a list and one run processes every channel. The uncertainty columns take a "
          "list of the same length.")
code(doc, [
    "[input.columns]",
    'x = "time"',
    'y = ["signal", "ref"]',
    'weight = ["sigma_signal", "sigma_ref"]',
])
body(doc, "Output file names carry the column, so two columns of the same file never overwrite "
          "each other.")
code(doc, [
    "out/plots/multi__signal__lin__0000.png",
    "out/plots/multi__ref__lin__0001.png",
])

heading(doc, "7.5 Numeric reading precision", 2)
body(doc, 'curvefit reads CSV with float_precision="round_trip", preserving every last bit.')
callout(doc,
        "If you call pandas.read_csv yourself and hand the table to the library, use the same "
        "setting. The default parser does not round exactly: measured, it changes the lowest "
        "bit of about 46% of values, and the library cannot recover a value that arrived "
        "already degraded.")
code(doc, ['frame = pd.read_csv(path, float_precision="round_trip")'])

# ============================================================ 8
heading(doc, "8. Output reference", 1)

heading(doc, "8.1 What gets produced", 2)
table(doc,
      ["Path", "Contents", "Controlled by"],
      [["summary.csv", "every result, one parameter per row", "output.write_summary"],
       ["plots/*.png", "the data points with the fitted curve", "output.write_plot"],
       ["curves/*.csv", "the fitted curve and the residuals", "output.write_curve"],
       ["preprocess/*.csv", "the points dropped as outliers", "outlier removal being enabled"],
       ["execution.json", "run conditions, timestamp, override history", "always written"],
       ["run.log", "outcome and failure reason per target", "always written"]],
      widths=[3.6, 7.4, 5.5], mono_cols=(0, 2))

heading(doc, "8.2 How output files are named", 2)
code(doc, ["{source}__{column}__{method}__{job number}"])
body(doc, "The input file name without its extension, the column, the method name and a "
          "four-digit zero-padded number, joined with double underscores. The number is always "
          "present, and characters that cannot appear in a file name are replaced.")
callout(doc,
        "The column appears even when there is only one y column. Any downstream step that "
        "relies on the old names needs to follow; see chapter 13.", kind="ok")

heading(doc, "8.3 Columns of summary.csv", 2)
body(doc, "One row is one parameter. Methods that carry no parameters, and jobs that failed, "
          "still appear as rows. Numbers are written to 10 significant digits.")
table(doc,
      ["Column", "Meaning"],
      [["source_id", "absolute path of the input file"],
       ["column_label", "as written in the configuration; a number such as 1 when the column "
                        "was given by position"],
       ["column_name", "the header name resolved after reading, so the channel is identifiable "
                       "even for positional columns"],
       ["method_name", "the name in [[methods]]"],
       ["status", "success or failure"],
       ["parameter_name", "the parameter name; empty for methods without parameters"],
       ["value", "the estimate"],
       ["stderr", "the standard error; empty when it cannot be computed"],
       ["fixed", "whether the parameter was held fixed (True / False)"],
       ["r_squared", "coefficient of determination"],
       ["rmse", "root mean square error"],
       ["n_points", "points used in the fit"],
       ["n_dropped_invalid", "points dropped as unreadable numbers"],
       ["n_dropped_out_of_range", "points dropped by the x range"],
       ["n_dropped_outlier", "points dropped as outliers"],
       ["failure_reason", "the failure reason; see 10.2. Empty on success"],
       ["message", "explanation on failure. Empty on success"]],
      widths=[5.2, 11.3], mono_cols=(0,))
body(doc, "An actual row looks like this.")
code(doc, [
    "source_id,column_label,column_name,method_name,status,parameter_name,value,...",
    "/data/s.csv,signal,signal,lin,success,slope,2.5,1.239194266e-16,False,1,...",
], size=8.5)

heading(doc, "8.4 Columns of the curve and preprocess CSV", 2)
table(doc,
      ["File", "Columns"],
      [["curves/*.csv", "x, y_observed, y_fit, residual"],
       ["preprocess/*.csv", "x, y_observed, iteration"]],
      widths=[4.4, 12.1], mono_cols=(0, 1))
body(doc, "Unlike the summary table these are written at full precision. y_observed is the "
          "measured value, not the fitted one.")

heading(doc, "8.5 execution.json", 2)
body(doc, "This keeps the conditions of one run verbatim. It holds the following keys.")
table(doc,
      ["Key", "Contents"],
      [["started_at", "when the run started (UTC)"],
       ["tool_version", "the curvefit version"],
       ["library_versions", "versions of the dependencies (lmfit / asteval / scipy / numpy / "
                            "pandas / matplotlib)"],
       ["config_path", "path of the configuration file that was read"],
       ["resolved_config", "the run conditions actually applied, in full"],
       ["cli_overrides", "items overridden on the command line, with the values before and "
                         "after"],
       ["applied_defaults", "items the user did not write, where a default was used"]],
      widths=[4.4, 12.1], mono_cols=(0,))

heading(doc, "8.6 run.log", 2)
body(doc, "One line is one event: the start, the outcome of each job, warnings, and the finish.")
code(doc, [
    "2026-09-06T10:04:35Z INFO status=started config_path=r.toml ...",
    "2026-09-06T10:04:36Z INFO source_id='/data/s.csv' column_label='signal' "
    "method='lin' status=success",
    "2026-09-06T10:04:36Z WARNING source_id='/data/s.csv' column_label='ref' "
    "method='lin' parameter='slope' status=stderr_unavailable",
    "2026-09-06T10:04:36Z INFO status=finished n_success=2 n_failure=0",
], size=8)
body(doc, "Per-target lines carry source_id, column_label and method, so the lines stay "
          "distinguishable even when one file holds several channels.")

# ============================================================ 9
heading(doc, "9. Command line reference", 1)

heading(doc, "9.1 Synopsis", 2)
code(doc, [
    "curvefit [configuration file] [options]",
    "",
    "curvefit run.toml",
    "curvefit run.toml -i data/ -o out/",
    "curvefit --help",
])
body(doc, "Omitting the configuration file prints the usage text and exits.")

heading(doc, "9.2 Options", 2)
table(doc,
      ["Option", "Meaning"],
      [["-h, --help", "print the usage, the options and the exit codes"],
       ["--version", "print the version"],
       ["-i PATH, --input PATH",
        "where the input is: a file, a directory or a wildcard. May be repeated"],
       ["-o DIR, --output DIR", "the output directory"],
       ["--delimiter SEP",
        "the delimiter; two or more characters are a regular expression. Use '\\s+' for "
        "column-aligned instrument output"],
       ["--header / --no-header", "whether to treat the first row as a header"],
       ["--x-column NAME", "name of the x column; positions are set in the configuration file"],
       ["--y-column NAME", "name of the y column; replaces the configured column list with "
                           "this one entry"],
       ["--weight-column NAME", "name of the uncertainty column; likewise replaces the list"],
       ["--summary / --no-summary", "whether to write the summary CSV"],
       ["--plot / --no-plot", "whether to write the plot images"],
       ["--curve / --no-curve", "whether to write the curve and residual CSV"],
       ["--failure-policy {skip,fail_fast}",
        "continue past individual failures, or stop at the first one"],
       ["--quiet", "hide progress and totals; violations and failures are still reported"]],
      widths=[5.6, 10.9], mono_cols=(0,))
callout(doc,
        "--y-column replaces the whole column list with one entry, and --weight-column does "
        "the same. In a multi-column configuration, replacing only one of them leaves the "
        "counts unequal and the run is rejected before it starts.")

heading(doc, "9.3 What can be overridden", 2)
body(doc, "When the same item is given both in the configuration file and on the command line, "
          "the command line wins. Only the following can be overridden.")
table(doc,
      ["Configuration key", "Corresponding option"],
      [["failure_policy", "--failure-policy"],
       ["input.paths", "-i / --input"],
       ["input.delimiter", "--delimiter"],
       ["input.header", "--header / --no-header"],
       ["input.columns.x", "--x-column"],
       ["input.columns.y", "--y-column"],
       ["input.columns.weight", "--weight-column"],
       ["output.directory", "-o / --output"],
       ["output.write_summary", "--summary / --no-summary"],
       ["output.write_plot", "--plot / --no-plot"],
       ["output.write_curve", "--curve / --no-curve"]],
      widths=[7.0, 9.5], mono_cols=(0, 1))
body(doc, "The method list cannot be overridden: one entry is a nested structure of several "
          "keys, which does not reduce to a single command-line argument. Changing methods is "
          "the configuration file's job. Whatever is overridden is kept in execution.json "
          "together with the values before and after.")

heading(doc, "9.4 Exit codes", 2)
table(doc,
      ["Code", "Meaning"],
      [["0", "every job succeeded"],
       ["1", "at least one job failed, or the run was stopped"],
       ["2", "preflight stopped the run; not a single job was executed"]],
      widths=[2.2, 14.3], mono_cols=(0,))

heading(doc, "9.5 Standard output and standard error", 2)
body(doc, "Progress, totals and violations all go to standard error. Standard output stays "
          "empty during a run whatever happens, so redirection keeps working. Only --help, "
          "--version and the usage text printed when no argument is given go to standard "
          "output, as content the user explicitly asked for.")
code(doc, ["curvefit run.toml > result.txt"])

# ============================================================ 10
heading(doc, "10. Errors and what to do about them", 1)

heading(doc, "10.1 Preflight violations", 2)
body(doc, "One violation is enough to stop the run before it starts. Violations are reported "
          "all at once rather than one at a time, so you are never forced into a fix-and-rerun "
          "loop. The exit code is 2.")
code(doc, [
    "model_unresolved        method[line].builtin",
    "smoother_option_invalid method[ma].options",
    "config_invalid          preprocess.x_min",
    "config_invalid          preprocess.outlier.sigma",
])
table(doc,
      ["Kind", "Meaning"],
      [["config_invalid",
        "the configuration cannot be parsed, a required item is missing, or a key is unknown"],
       ["model_unresolved",
        "the built-in model name is unknown, or the formula cannot be interpreted"],
       ["initial_required", "a non-built-in model was given no starting values"],
       ["initial_out_of_bounds", "a starting value lies outside the bounds given for it"],
       ["output_not_writable", "the output directory cannot be written to"],
       ["smoother_option_invalid",
        "a smoothing option does not satisfy its constraint"]],
      widths=[5.2, 11.3], mono_cols=(0,))

heading(doc, "10.2 Per-job failures", 2)
body(doc, 'These happen on individual data. By default (failure_policy = "skip") the job is '
          "skipped and the rest of the run continues. The reason is recorded in the "
          "failure_reason column of the summary and in run.log. The exit code is 1.")
table(doc,
      ["Reason", "Meaning"],
      [["column_not_found", "the requested column is not present in the input"],
       ["no_valid_data", "there is not a single valid data point"],
       ["insufficient_points",
        "after preprocessing there are fewer points than parameters to estimate"],
       ["not_converged", "the fit did not converge"],
       ["header_ambiguous",
        "header is unset and the first row cannot be classified"],
       ["input_unreadable", "the input file does not exist, or cannot be read"],
       ["resource_exhausted",
        "the run cannot continue because memory ran out or writing failed"]],
      widths=[5.2, 11.3], mono_cols=(0,))
body(doc, 'With failure_policy = "fail_fast", the run stops as soon as the first failure is '
          "detected.")

heading(doc, "10.3 Common stumbling blocks", 2)
table(doc,
      ["Symptom", "Cause", "Fix"],
      [["syntax error on line 1", "the configuration file has a BOM",
        "save as UTF-8 without a BOM"],
       ["the column count differs per row", 'delimiter = " " was used', "delimiter = '\\s+'"],
       ["rejected as an unknown escape", 'delimiter = "\\s+" was used',
        "'\\s+' or \"\\\\s+\""],
       ["stopped before the run, counts unequal", "y and weight lists differ in length",
        "give them the same length"],
       ["outlier removal drops nothing", "sigma is too large for the point count",
        "see section 6.2"],
       ["spline is rejected before the run", "lam was not given",
        "options = { lam = 0.01 }"],
       ["a downstream step broke", "the output names and summary columns changed",
        "see chapter 13"]],
      widths=[5.6, 5.6, 5.3])

# ============================================================ 11
heading(doc, "11. Using curvefit as a Python library", 1)
body(doc, "The CLI is a thin wrapper over the library and takes the same execution path, so "
          "the two give identical results.")

heading(doc, "11.1 Running a batch from a configuration file", 2)
code(doc, [
    "from pathlib import Path",
    "from curvefit import run_from_config, BatchReport",
    "",
    'result = run_from_config(Path("run.toml"))',
    "if isinstance(result, BatchReport):",
    "    print(result.n_success, result.n_failure)",
    "else:",
    "    for violation in result.violations:",
    "        print(violation.kind, violation.location)",
])
callout(doc,
        "On a violation you get a PreflightResult back rather than an exception. Keeping the "
        "stop-before-running path down to a single value spares the caller from expressing the "
        "same decision twice, once as a value and once as an exception.", kind="ok")

heading(doc, "11.2 Building the run conditions yourself", 2)
body(doc, "You can bypass the configuration file, assemble a RunConfig and pass it to "
          "run_batch. The return value behaves exactly as it does for run_from_config.")
code(doc, [
    "from curvefit import run_batch",
    "",
    "result = run_batch(config)",
])

heading(doc, "11.3 Fitting a single in-memory series", 2)
code(doc, [
    "from curvefit import fit_series",
    "",
    "outcome = fit_series(series, method)",
])
body(doc, "It takes the same execution path as a batch run while writing no files at all. The "
          "curve data comes back with the result.")

heading(doc, "11.4 The main public types", 2)
table(doc,
      ["Name", "Contents"],
      [["BatchReport", "batch totals; carries n_success and n_failure"],
       ["PreflightResult", "the result of stopping at preflight; carries violations"],
       ["ConfigViolation", "one violation; carries kind, location and message"],
       ["DataSeries", "one input series; carries source_id"],
       ["FitOutcome", "the result of one job: either FitSuccess or FitFailure"],
       ["ParameterEstimate", "the estimate for one parameter"],
       ["GoodnessOfFit", "goodness-of-fit measures (r_squared, rmse)"],
       ["CurveData", "the fitted curve and the residuals"],
       ["ExecutionRecord", "the run record; matches the contents described in 8.5"]],
      widths=[4.6, 11.9], mono_cols=(0,))

# ============================================================ 12
heading(doc, "12. Reproducibility and security", 1)

heading(doc, "12.1 Reproducibility", 2)
body(doc, "Given the same configuration file and the same input data, a rerun matches byte for "
          "byte. Job order is deterministic too, expanded as inputs, then columns, then "
          "methods. Values that change from run to run, such as the timestamp, appear only in "
          "execution.json and run.log.")
bullets(doc, [
    "the run conditions actually applied are kept in resolved_config in execution.json",
    "items overridden on the command line are kept in cli_overrides with both values",
    "items where a default was used, because the user wrote none, are kept in applied_defaults",
    "the versions of the dependencies are kept in library_versions",
])

heading(doc, "12.2 Security", 2)
callout(doc,
        "The formula string in the configuration file is evaluated. Never run a configuration "
        "file you received from someone else as is: it carries the same risk as running "
        "arbitrary Python code. Read the file first.")

# ============================================================ 13
heading(doc, "13. Migrating from the previous version", 1)
body(doc, "The revision that added support for several measurement channels in one input file "
          "changed two things. Both can affect downstream steps.")
table(doc,
      ["Change", "Impact", "What to do"],
      [["output file names now contain the column",
        "names change even with a single y column",
        "update any step that relies on the old names"],
       ["summary.csv gained column_label and column_name (columns 2 and 3)",
        "readers that use column positions break",
        "read by name (csv.DictReader)"]],
      widths=[6.4, 5.1, 5.0])
body(doc, "The estimates themselves are unchanged. An existing configuration naming a single y "
          "column returns the same estimates and the same summary content as before; setting "
          "aside the two added columns, not one character differs, and this was verified by "
          "running both versions.")

# ============================================================ appendices
heading(doc, "Appendix A  Configuration quick reference", 1)
table(doc,
      ["Key", "Default", "Meaning"],
      [["failure_policy", '"skip"', "continue past individual failures, or stop"],
       ["input.paths", "required", "where the input is; several may be given"],
       ["input.delimiter", "from the extension", "delimiter; 2+ characters is a regex"],
       ["input.header", "unset", "whether the first row is a header"],
       ["input.columns.x", "required", "x column; name or position"],
       ["input.columns.y", "required", "y column; name, position, or a list of them"],
       ["input.columns.weight", "none", "uncertainty column; same count as y"],
       ["methods[].name", "required", "the identifier of the method"],
       ["methods[].builtin", "-", "built-in model name"],
       ["methods[].expression", "-", "formula"],
       ["methods[].smoother", "-", "kind of regression or smoothing"],
       ["methods[].initial", "none", "starting values"],
       ["methods[].bounds", "none", "bounds"],
       ["methods[].fixed", "none", "parameters held fixed"],
       ["methods[].options", "per method", "degree / lam / window / polyorder"],
       ["preprocess.x_min", "none", "drop points below this x"],
       ["preprocess.x_max", "none", "drop points above this x"],
       ["preprocess.outlier.sigma", "3.0", "spread multiple counted as an outlier"],
       ["preprocess.outlier.max_iterations", "3", "cap on removal rounds"],
       ["output.directory", '"out"', "output directory"],
       ["output.write_summary", "true", "write the summary CSV"],
       ["output.write_plot", "true", "write the plots"],
       ["output.write_curve", "false", "write the curve CSV"]],
      widths=[7.2, 3.0, 6.3], mono_cols=(0, 1))

heading(doc, "Appendix B  Specification and design records", 1)
body(doc, "How this feature was decided is recorded under .kiro/specs/data-curve-fitting/.")
table(doc,
      ["File", "Contents", "When to open it"],
      [["requirements.md", "requirements and acceptance criteria (EARS)",
        "to check whether a behaviour was intended"],
       ["design.md", "boundaries, dependency direction, contracts, test strategy",
        "before changing code, to learn what is safe to touch"],
       ["tasks.md", "implementation tasks and the notes left during implementation",
        "to avoid repeating a mistake already made"],
       ["research.md", "the dependency survey and how the design decisions were reached",
        "to learn why a given library was chosen"]],
      widths=[4.0, 6.2, 6.3], mono_cols=(0,))

assert not _outline_left, f"headings never reached in the body: {_outline_left}"

out = str(pathlib.Path(__file__).with_name("curvefit_User_Manual_Detailed_EN.docx"))
doc.save(out)
print(f"saved: {out}")
