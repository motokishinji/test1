"""実測値とフィット曲線を重ねたグラフ画像の生成（要件 7.4、10.2）。

本モジュールが所有するのは次の 3 点である。

1. **画像の内容** — 実測値の点と当てはめ曲線を同一の座標軸に重ねた図（要件 7.4）
2. **描画資源の寿命** — :class:`~matplotlib.figure.Figure` を 1 つだけ作り、対象ごとに
   内容をクリアして描き直す。生成し直さない（設計の Performance & Scalability）
3. **描画ライブラリの封じ込め** — matplotlib を import してよいのは本モジュールだけで
   ある（設計の Allowed Dependencies）

**描画は Agg キャンバスの直結で画面非依存にする。** 本モジュールは
:class:`~matplotlib.backends.backend_agg.FigureCanvasAgg` を
:class:`~matplotlib.figure.Figure` に直接結び付ける。この結び付けが効く範囲はその図の
描画経路だけであるため、大域のバックエンド設定が何であっても、また本モジュールの
import 後に利用者がそれを変えても、ここでの描画は Agg のまま行われる。実測でも、
大域が別バックエンドの環境で描いた画像は既定環境で描いたものとバイト単位で一致する。

**プロセス大域のバックエンドは変更しない。** ``matplotlib.use("Agg", force=True)`` は
採らない。上記のとおり画面非依存はキャンバス直結だけで達成できる一方、大域の強制は
プロセス全体の設定を書き換えるためである。要件 7.4 により画像出力は既定であり、
``pipeline`` は本モジュールを必ず取り込む。したがって大域を強制すると
``from curvefit import run_batch`` と書いただけで対話環境のインライン表示が黙って失われ、
要件 9.1 が求めるライブラリ・対話環境からの利用を壊す。得るもののない代償である
（writers / plotting の Responsibilities & Constraints）。

**``Figure`` は 1 つを使い回す。** 対象ごとの生成が数百件規模でメモリを線形に増加させる
ことは `research.md` の調査で裏付けられている。ループ内で図を生成・保存・破棄しても
バックエンド次第でプロセスのメモリが反復ごとに増え続け、夜間バッチが 60GB を消費した
事例が報告されている。加えて本モジュールは :mod:`matplotlib.pyplot` を
使わない。pyplot は生成した図を大域の図管理簿に登録して参照を保持し続けるため、
線形増加の経路そのものになる。図を自前で 1 つ持てば、この登録簿を一度も使わずに済む。

対象ごとの ``gc.collect()`` は行わない。バッチ処理の定石として知られるこの呼び出しは、
反復ごとに生成された図を回収するためのものである。本モジュールは図を生成しないため
回収すべき対象がなく、対象ごとの全世代 GC は要件 10.2 が守ろうとしている実行時間を
削るだけになる。

**逐次実行を前提とする。スレッド安全ではない。** 複数スレッドから同時に
:func:`render_fit_plot` を呼ぶと、共有する ``Axes`` の内容が互いに混ざる。設計は並列
実行を Non-Goals として明示的に排除しており（``pipeline`` は逐次実行）、本モジュールは
その前提に依存している。並列化を導入する場合、共有する描画資源の扱いは再設計を要する。

**画像は丸めずに全精度の値から描く。** 有効数字 10 桁の丸めはサマリ CSV に限る
（``writers`` の Validation）。

**表題は端末にある日本語対応フォントで描く。** matplotlib の既定フォント DejaVu Sans は
CJK のグリフを持たないため、対象名や手法名に日本語が含まれると表題が豆腐（□）になり、
1 文字ごとに欠落グリフの警告が出る（実測 11 件）。利用者は日本語話者であり、測定データの
ファイル名に日本語を使うことは普通である。
:data:`JAPANESE_FONT_CANDIDATES` を先頭から順に見て、導入済みの最初の 1 つを使う。
**特定のフォントの存在は前提にしない。** 1 つも導入されていなければ何も指定せず、従来
どおりの描画に退く。日本語を含まない対象の出力を、日本語フォントの不在で失うことはない。
選択結果は :func:`selected_japanese_font` から読み取れる（実行条件としての記録は呼び出し側
の責務。同関数の説明を参照）。フォント指定は本モジュールが描く文字の側に閉じて渡し、
**大域の ``rcParams`` は書き換えない**。理由は大域のバックエンドを強制しないのと同じで
ある。

**画像のバイト単位の一致は同一端末の中で成り立つ。** 選ばれるフォントは導入状況で変わり、
字形が変われば画像も変わる。要件 8.2 の再現性は同一環境を前提としており（設計の
execution Risks）、出力物は既に絶対パスを通じて端末依存である。

**書き込み中の :class:`OSError` は握り潰さない。** ディスク枯渇のような資源・環境の
失敗は要件 10.3 の系統であり、``pipeline`` が ``RESOURCE_EXHAUSTED`` として扱う。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from matplotlib import font_manager
from matplotlib.axes import Axes
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from curvefit.types import CurveData, FitSuccess

FIGURE_SIZE_INCHES: tuple[float, float] = (8.0, 5.0)
"""図の大きさ。報告資料にそのまま貼れる横長で、数百件を書き出しても現実的な大きさ。"""

FIGURE_DPI = 100
"""解像度。既定の rcParams に依存せず明示する（要件 8.2 の同一出力）。"""

FIGURE_FACECOLOR = "white"
"""図の背景色。既定の rcParams に依存せず明示する。"""

OBSERVED_LABEL = "observed"
FIT_LABEL = "fit"
"""凡例の表示名。既定フォントで確実に描ける ASCII に限る。

日本語の凡例は、日本語グリフを持つフォントが導入されていない環境で豆腐になる。
凡例は図の読み方そのものであり、環境によって読めなくなる代償は大きい。
"""

X_LABEL = "x"
Y_LABEL = "y"

TITLE_SEPARATOR = " / "
"""表題における対象名と手法名の区切り。どの対象のどの手法かを図だけで判別できるようにする。"""

OBSERVED_MARKER_SIZE = 4.0
"""実測値の点の大きさ。数千点でも図が黒く潰れない大きさ。"""

FIT_LINE_WIDTH = 1.5

IMAGE_FORMAT = "png"
"""出力形式。拡張子からの推測に任せず明示する（設計の Batch / Job Contract は PNG）。"""

IMAGE_METADATA: dict[str, str | None] = {"Software": None}
"""PNG に埋め込むメタデータ。``None`` は既定の埋め込みを打ち消す。

matplotlib は既定で ``Software`` チャンクに自身のバージョン文字列を書き込む。これが
残ると、同一の設定・同一の入力に対する出力物が matplotlib のバージョン差で一致しなく
なる（要件 8.2）。ライブラリのバージョンは ``execution.json`` に記録する設計であり
（``execution`` の library_versions）、画像に重ねて持たせる必要はない。

なお PNG では作成日時は既定で埋め込まれない（実測で確認）。時刻が入るのは SVG / PDF で
あり、本モジュールは PNG に限定しているためその経路には入らない。
"""

JAPANESE_FONT_CANDIDATES: tuple[str, ...] = (
    "Hiragino Sans",
    "Hiragino Kaku Gothic ProN",
    "Hiragino Kaku Gothic Pro",
    "Hiragino Maru Gothic Pro",
    "Yu Gothic",
    "YuGothic",
    "Meiryo",
    "MS Gothic",
    "Noto Sans CJK JP",
    "Noto Sans JP",
    "Source Han Sans JP",
    "IPAexGothic",
    "IPAGothic",
    "TakaoGothic",
    "VL Gothic",
)
"""表題に使う日本語対応フォントの候補。**先に並ぶものが優先される**（要件 7.4）。

macOS（Hiragino 系）・Windows（Yu Gothic / Meiryo / MS Gothic）・Linux（Noto / IPA /
Takao / VL）の順に、それぞれの環境で標準的に導入されている書体を並べる。**特定の 1 つの
存在を前提にしない。** 導入されているフォントは端末ごとに違い、どれか 1 つを必須にすると
その環境以外で出力を失う。

**順序を決めるのはこの表だけである。** 導入済みフォントの列挙は集合であり順序を持たない。
選択が列挙順に依存すると、同じ端末の同じ設定でも実行ごとに字形が変わりうる（要件 8.2）。
"""


def _installed_font_names() -> frozenset[str]:
    """この端末に導入されているフォント名の集合。

    集合として返すのは、呼び出し側が列挙順に依存できないようにするためである。優先順位は
    :data:`JAPANESE_FONT_CANDIDATES` の側だけが持つ。
    """
    return frozenset(entry.name for entry in font_manager.fontManager.ttflist)


_font_choice: tuple[str | None] | None = None
"""選択したフォント名を包んだ 1 要素の組。未解決のときだけ ``None`` を取る。

「未解決」と「解決した結果どれも無かった」を区別する必要があるため、``None`` を 2 つの
意味に使わず、解決済みであることを組の存在で表す。
"""


PLOT_FONT_KEY = "plot_font"
"""実行条件に載せるときの項目名（要件 7.4、8.3）。

記録への差し込みは呼び出し側（``api``）が行う。本モジュールは名前と値を出すところまでを
担う。名前をここに置くのは、項目の意味を知っているのが本モジュールだけだからである。
"""


def selected_japanese_font() -> str | None:
    """表題に使う日本語対応フォント名。1 つも導入されていなければ ``None``（要件 7.4）。

    初回の呼び出しで一度だけ決め、以降は同じ値を返す。フォント一覧の走査は数百件の
    ファイル走査を伴うことがあり、対象ごとに繰り返すと要件 10.2 の実行時間を削る。
    記憶することは決定性にも効く（同一プロセス内で選択が揺れない）。

    **選択結果は実行条件として記録されるべき値である。** 同じ設定でも端末によって字形が
    変わりうるため、どのフォントで描いたかを後から判別できなければならない。ただし記録の
    組み立て（``execution.build_execution_record``）は描画より前に走り、``execution`` は
    本モジュールと同じレイヤにある。したがって **本モジュールは読み取れる値を出すところ
    までを担い、記録への差し込みは呼び出し側（``pipeline`` / ``api``）が行う**。本関数は
    描画前でも呼べるため、記録の組み立て時点で値が確定する。

    :return: 選ばれたフォント名。日本語対応フォントが 1 つも無ければ ``None``
    """
    global _font_choice
    if _font_choice is None:
        installed = _installed_font_names()
        _font_choice = (
            next((name for name in JAPANESE_FONT_CANDIDATES if name in installed), None),
        )
    return _font_choice[0]


def _title_font_options() -> dict[str, Any]:
    """表題に渡すフォント指定。日本語対応フォントが無ければ空（従来どおりの描画）。

    指定は :meth:`~matplotlib.axes.Axes.set_title` に渡す引数として、**本モジュールが描く
    文字の側に閉じて** 効かせる。大域の ``rcParams`` は書き換えない。要件 7.4 により画像
    出力は既定であり ``pipeline`` は本モジュールを必ず取り込むため、大域を書き換えると
    ``import curvefit`` と書いただけで利用者の matplotlib 設定が黙って変わり、要件 9.1 が
    求めるライブラリ・対話環境からの利用を壊す。大域のバックエンドを強制しないのと同じ
    理由である。

    フォントが無い環境では **何も渡さない**。存在しない名前を渡すと matplotlib が
    ``findfont`` の警告を出したうえで既定フォントに落ちるため、退避先としては
    「指定しない」が正しい。
    """
    chosen = selected_japanese_font()
    return {} if chosen is None else {"fontfamily": chosen}


_canvas: tuple[Figure, Axes] | None = None
"""再利用する図と座標軸。全対象がこの 1 組を共有する。"""


def _shared_canvas() -> tuple[Figure, Axes]:
    """描画に使う図と座標軸を返す。初回のみ作り、以降は同じ実体を返す。

    図の生成をここに 1 か所だけ持つことで、対象ごとの生成が起こり得ない構造にする
    （設計の Performance & Scalability）。:mod:`matplotlib.pyplot` は使わない。pyplot 経由で
    作った図は大域の図管理簿に登録され、参照が残り続ける。

    キャンバスを明示的に Agg で結び付ける。結び付けの効果はこの図に閉じるため、大域の
    バックエンド設定に触れることなく、また大域が本モジュールの import 後に変えられても、
    ここでの描画は Agg のまま行われる（要件 9.1）。
    """
    global _canvas
    if _canvas is None:
        figure = Figure(
            figsize=FIGURE_SIZE_INCHES,
            dpi=FIGURE_DPI,
            facecolor=FIGURE_FACECOLOR,
        )
        FigureCanvasAgg(figure)
        _canvas = (figure, figure.add_subplot())
    return _canvas


def _draw(axes: Axes, success: FitSuccess, curve: CurveData) -> None:
    """1 対象分の内容を描く。呼び出し側が事前に ``Axes`` をクリアしていることを前提とする。

    実測値は点、当てはめ値は線で描く。両者を同じ形で描くと、どちらがデータでどちらが
    モデルかが図から読めなくなる。

    当てはめ曲線は x の昇順に並べ替えてから結ぶ。``CurveData`` の並び順は入力ファイルの
    行順であり、x について単調とは限らない。並べ替えずに結ぶと、モデルは滑らかなのに
    図だけが往復する折れ線になる。並べ替えは新しい配列を作り、渡された結果には触れない。

    表題には対象名と手法名をそのまま載せ、日本語対応フォントが見つかっていればそれを
    指定する（要件 7.4）。文字列そのものは変えない。非 ASCII を落とす・音訳するといった
    手当ては、どの対象のどの手法かを図だけで判別できるという表題の役目を壊す。軸の名前と
    凡例は ASCII の定数であり、既定フォントで確実に描けるため指定を要しない。

    **曲線は引数で受け取る。** :attr:`~curvefit.types.FitSuccess.curve` は解放されうる欄
    であり（要件 10.4）、解放済みかどうかの判断は入口（:func:`render_fit_plot`）に 1 か所
    だけ置く。ここで欄を読み直すと、同じ判断が 2 か所に分かれる。
    """
    order = np.argsort(curve.x, kind="stable")

    axes.plot(
        curve.x,
        curve.y_observed,
        linestyle="none",
        marker="o",
        markersize=OBSERVED_MARKER_SIZE,
        label=OBSERVED_LABEL,
    )
    axes.plot(
        curve.x[order],
        curve.y_fit[order],
        linestyle="-",
        linewidth=FIT_LINE_WIDTH,
        label=FIT_LABEL,
    )

    axes.set_title(
        f"{success.source_id}{TITLE_SEPARATOR}{success.method_name}",
        **_title_font_options(),
    )
    axes.set_xlabel(X_LABEL)
    axes.set_ylabel(Y_LABEL)
    axes.legend()


def render_fit_plot(success: FitSuccess, path: Path) -> None:
    """実測値とフィット曲線を重ねた画像を書き出す（要件 7.4）。

    描画資源は :func:`_shared_canvas` が持つ 1 組を使い回し、毎回クリアしてから描き直す。
    対象ごとに図を作ると数百件規模でメモリが線形に増加する（`research.md`)。

    渡された ``success`` は読むだけで、配列を書き換えない。当てはめ結果は凍結データで
    あり、出力の副作用で内容が変わると、後続の出力物（サマリ CSV、曲線 CSV）との
    突き合わせが成立しなくなる。

    :param success: 描画する成功結果。全精度の値をそのまま描く。曲線データを保持している
        こと
    :param path: 出力先のファイルパス。親ディレクトリは必要に応じて作る
        （``{output_dir}/plots/`` を作るのは出力側の責務）
    :raises ValueError: 曲線データが解放済み（``success.curve`` が ``None``）の場合。
        描画は解放より前に行われる（``pipeline`` の ``run_job`` → ``run``）ため、ここに
        解放済みの結果が届くのは呼び出し側の誤りである（要件 10.4）
    :raises OSError: 書き込みに失敗した場合。資源・環境の失敗は要件 10.3 の系統であり、
        値として飲み込まない
    """
    curve = success.curve
    if curve is None:
        # 点の無い図を書くと、出力ディレクトリの内容とサマリ表の成否が食い違う。
        raise ValueError(
            f"曲線データが解放済みの結果は描画できない"
            f"（source_id={success.source_id!r} method={success.method_name!r}）"
        )
    figure, axes = _shared_canvas()
    axes.clear()
    _draw(axes, success, curve)

    path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(
        path,
        format=IMAGE_FORMAT,
        dpi=FIGURE_DPI,
        facecolor=FIGURE_FACECOLOR,
        metadata=IMAGE_METADATA,
    )
