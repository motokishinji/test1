"""失敗理由と設定違反の分類。

本モジュールは自パッケージの他モジュールに依存しない。

分類を 2 系統に分けているのは意図的である。

- :class:`FailureReason` — 個別データの処理中に起きる失敗。既定ではバッチを止めず、
  値として集約される
- :class:`ViolationKind` — 実行前に検出する設定の不備。1 件でもあればジョブを
  1 件も実行せずに終了する

この 2 つを 1 つの列挙に統合すると「止めるべきか継続すべきか」の判断が呼び出し側に
漏れ、要件 6.4 の既定（スキップして継続）が崩れる。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class FailureReason(StrEnum):
    """処理単位ごとの失敗理由。バッチ全体は止めない。"""

    COLUMN_NOT_FOUND = "column_not_found"
    """指定された列が入力に存在しない（要件 1.4）。"""

    NO_VALID_DATA = "no_valid_data"
    """有効なデータ点が 1 件も存在しない（要件 1.5）。"""

    INSUFFICIENT_POINTS = "insufficient_points"
    """前処理後の点数が推定対象パラメータ数を下回る（要件 2.4）。"""

    NOT_CONVERGED = "not_converged"
    """当てはめが収束しなかった（要件 4.7）。"""

    HEADER_AMBIGUOUS = "header_ambiguous"
    """見出し行の有無が未指定で、先頭行を見出しと解釈してよいか定まらない（要件 1.7）。"""

    INPUT_UNREADABLE = "input_unreadable"
    """指定された入力ファイルが存在しない、または読み取れない（要件 1.8）。

    :attr:`RESOURCE_EXHAUSTED` と分けているのは、この失敗が処理全体を止めないためである。
    綴り誤りや共有先から消えた 1 ファイルは、その対象だけの失敗であり、既定では残りの
    処理を継続する（要件 6.4、10.1）。
    """

    RESOURCE_EXHAUSTED = "resource_exhausted"
    """メモリ枯渇や書き込み不能により処理を継続できない（要件 10.3）。"""


class ViolationKind(StrEnum):
    """実行前に検出する設定違反。1 件でもあれば処理を開始しない。"""

    CONFIG_INVALID = "config_invalid"
    """設定ファイルの解釈不能、必須項目の欠落、未知のキー（要件 8.5）。"""

    MODEL_UNRESOLVED = "model_unresolved"
    """組込モデル名が未知、または数式文字列を解釈できない（要件 3.4）。"""

    INITIAL_REQUIRED = "initial_required"
    """組込以外のモデルで初期値が指定されていない（要件 4.3）。"""

    INITIAL_OUT_OF_BOUNDS = "initial_out_of_bounds"
    """指定された初期値が指定された上下限の範囲外にある（要件 4.6）。"""

    OUTPUT_NOT_WRITABLE = "output_not_writable"
    """出力先に書き込めない（要件 7.7）。"""

    SMOOTHER_OPTION_INVALID = "smoother_option_invalid"
    """平滑化手法固有のオプションが制約を満たさない（要件 5.4、5.5）。

    値域を外れた指定（要件 5.4）に加え、平滑化スプラインで平滑化パラメータが
    指定されていない場合（要件 5.5）もこの種別で報告する。
    """


@dataclass(frozen=True)
class ConfigViolation:
    """実行前検証で検出した違反 1 件。

    `location` には設定ファイル内の位置または実行時引数名を入れる。数百件のバッチでは
    「どこが原因か」を特定できない報告は実質的に無価値であるため、必須項目とする。
    """

    kind: ViolationKind
    location: str
    message: str
