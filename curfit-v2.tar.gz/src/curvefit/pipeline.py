"""入力・y 列・手法の直積を展開し、逐次実行して結果を集約する。

担う要件は 1.11、6.1〜6.6、6.8、8.2、10.3 である。

本モジュールが所有するのは次の 3 点である。

1. **ジョブ展開規則**（設計の This Spec Owns） — 入力集合 × y 列集合 × 手法集合の
   直積を :class:`Job` の一覧として展開する。3 つの軸のいずれでも挙動が分岐しないため、
   複数ファイルの一括処理（要件 6.1）・複数 y 列の処理（要件 1.11、6.8）・同一データへの
   複数手法の適用（要件 6.2）が単一の経路に載る
2. **決定的な順序** — 展開前に入力を正規化してソートする。`glob` と
   :meth:`~pathlib.Path.iterdir` の返す順序はファイルシステム依存であり保証されない
   （``research.md`` の「再現性を破る要因の洗い出し」）。ソートしなければ、推定値
   そのものは同一でもサマリ CSV の行順と実行ログの記録順が実行ごとに変わり、
   要件 8.2 が出力物の水準で破れる
3. **入力指定の解釈** — ファイル・ディレクトリ・ワイルドカードの 3 通り（要件 6.1）を、
   対象ファイルの並びに解決する

**手法はソートしない。** 設定の記述順をそのまま保つ（要件 8.2 の決定性は、記述順の
保存によって満たす）。並べ替えると、利用者が設定ファイルで表した比較の並びが出力で
崩れる。

**軸の順序は 入力 → 列 → 手法 とする。** 同一データに対する各手法の結果がサマリ CSV で
隣り合い、要件 6.2 の「横並びで比較」がそのまま成立する。列を手法の外側・入力の内側に
挟むことで、同一ファイルの各列も隣接する。

**列ごとに読み込みを呼ぶ。** 同一ファイルの 2 列は同一ファイルを 2 度読む。読み込み結果を
ファイル単位で共有すると処理単位が独立に実行できなくなり、要件 6.4 の個別失敗の非波及と
要件 10.4 の常駐メモリの頭打ちの双方に影響する（設計の Responsibilities）。

正規化について
--------------

正規化は **絶対パス化と字句的な整理に限る**（:func:`normalize_source`）。
:meth:`~pathlib.Path.resolve` による symlink の解決と大文字小文字の畳み込みは
**行わない**。いずれも異なる 2 つの入力を 1 つに融合させうるためである。symlink と
その実体はどちらも利用者が明示した別々の対象であり、片方を黙って落とせば、指定した
はずのファイルが結果に現れない。大文字小文字の畳み込みは、大小を区別するファイル
システム上の ``A.csv`` と ``a.csv`` という別々のファイルを 1 件に潰す。逆に、区別
しないファイルシステム上で同一ファイルを 2 通りに綴った指定は 2 件として処理されるが、
こちらの代償は同じ処理が 2 回走ることに留まる。融合（結果の消失）と重複（余分な行）の
非対称性から、融合しない側を採る。

実在優先について
----------------

**実在する綴りは、パターンとしての解釈より優先して文字どおりに扱う。** ``*``、``?``、
``[`` を含む指定はワイルドカードの候補だが、その綴りのものが実際に存在する場合は
1 件のファイル（またはディレクトリ）として扱い、:mod:`glob` に渡さない。``[`` は
:mod:`glob` の文字クラスの開始でもあるため、この優先付けが無いと ``data/[2024]run.csv``
という **実在するファイル** の直接指定が一致 0 件に落ち、``da[t]a/`` という実在
ディレクトリは ``os.path.isdir`` に到達すらせず中身が丸ごと消える。測定日の括弧書きは
ありふれた命名であり、利用者は何の報告も受け取らない。これは要件 6.1 が避けようと
している事態そのものである。

この優先付けの代償は、実在するファイルを指す綴りをパターンとして使えないこと
（``a[1].csv`` で ``a1.csv`` を狙えない）に留まる。一方の代償は指定した入力が黙って
消えることであり、**取りこぼし（結果の消失）と取りすぎ（余分な 1 件）の非対称性**から、
消えない側を採る。実在しない綴りは従来どおりパターンとして展開されるため、通常の
ワイルドカード指定は影響を受けない。

存在確認について
----------------

**入力の存在は確認しない**（設計の Risks）。存在しないファイルの直接指定もそのまま
1 件の処理単位になり、要件 1.4/1.5 の個別失敗として扱われる。ディレクトリ指定で
ファイルが 0 件の場合は、処理単位 0 件の正常な実行である。

ただし **存在するディレクトリを読めない場合は :exc:`OSError` を送出する**。
0 件として黙らせると、1 ディレクトリ分の入力が何の報告もなく消える。これは要件 6.1 が
避けようとしている事態そのものである。資源・環境の失敗であって利用者が設定で直せる
ものではないため、返り値（処理単位の一覧）では表せない。捕捉と中断の判断はバッチ制御が
持つ（設計の Implementation Notes、要件 10.3）。

単一処理単位の実行
------------------

:func:`run_job` は 1 件の処理単位について **読み込み → モデル解決 → 前処理 → 当てはめ
→ 出力の適用** を順に通し、結果を :class:`JobResult` として返す。本モジュールが所有
するのは、この順序と、各層に渡す材料の供給責任である。

**処理単位は入力の位置と読み込み済みの系列のどちらでも表せる**（:attr:`Job.series`、
要件 9.1）。系列を伴う処理単位では読み込みの 1 段だけを省き、以降は同一の経路を通る。
メモリ上の系列を一時ファイルに書き出して読み直す往復を、呼び出し元に強いないための
差込口である。当てはめの手順を呼び出し元に持たせると、要件 9.3 の「CLI とライブラリで
同一結果」が構造ではなく規律で守られる状態になる（``api`` の docstring）。

1. **処理単位ごとのモデル解決**（要件 4.1） — 解決は処理単位ごとに、**その対象の**
   データを ``sample`` として呼び直す。設定解決時に一度だけ推定して使い回すと、
   ファイルごとにスケールの異なるデータで収束が悪化する（設計の Implementation Notes）
2. **最小点数と暫定当てはめの供給** — :func:`~curvefit.preprocess.apply_preprocess` に
   渡す ``min_points`` は解決済み手法の **推定対象** パラメータ数（固定指定を除いた
   個数、要件 4.5）から導出し、``provisional_fit`` は
   :func:`~curvefit.engines.select_engine` で得たエンジンを束ねたクロージャとして
   渡す。この供給責任をここに置くことで、前処理層は手法を知らずに済む
3. **短絡** — いずれかの段階が :class:`~curvefit.types.FitFailure` を返したら、以降の
   段階に進まずその結果をそのまま処理単位の結果とする。当てはめの結果である出力物
   （グラフ画像・曲線 CSV）の適用は成功時に限る
4. **重みを使えない手法の記録** — 重みを持つ系列に、重みを扱えない手法（移動平均）が
   当たる場合は実行ログに残す。:class:`~curvefit.types.FitOutcome` は重みの由来情報を
   持たないため、:class:`~curvefit.types.DataSeries` と解決済み手法を同時に持つ本層でしか
   判定できない。**設定として誤差列を指定した場合は実行前ゲートが拒否するため、本記録が
   出るのは読み込み済みの系列を直接渡す経路に限られる**（要件 1.10、
   :func:`_log_ignored_weights`）
5. **適用された既定値の中継**（要件 5.4） — 当てはめが実際に補った既定値
   （:class:`~curvefit.engines.base.EngineSuccess` の ``applied_defaults``）を
   :class:`JobResult` に載せて返す。既定値が実際に効いたと言えるのは、
   当てはめが走った処理単位に限る。:class:`~curvefit.types.FitOutcome` にはこれを
   載せる欄が無く、手法名（:attr:`Job.method`）と当てはめ結果を同時に持つのは本層だけ
   であるため、中継できる地点はここしかない。
   :class:`~curvefit.models.resolver.MethodSpec` からの
   再計算は、既定値の所有を当てはめ層と本層の 2 か所に分けるため禁じられている
   （設計の Postconditions）
6. **前処理 CSV の書き出し**（要件 2.5） — 外れ値として除外した点の記録を
   ``{出力先}/preprocess/{名前}.csv`` に書き出す。**本層で唯一、成否を条件にしない
   出力物である。** 図と曲線 CSV は当てはめの結果だが、この記録は前処理が何をしたかの
   説明であり、当てはめの成否とは独立に成立する。**ただし系列を直接渡された処理単位
   では書かない**（:attr:`Job.series`、要件 9.1）。その経路は出力先を持たず、実行条件の
   出力先は共有の一時領域を指す。理由の全体は :func:`_apply_preprocess_report` に記す

**バッチ制御は :func:`run` が持つ。** :func:`run_job` 自身は資源・環境の失敗
（:class:`MemoryError` / :class:`OSError`）を捕捉せず送出させる。ここで飲み込むと、
中断した対象を明示するという要件 10.3 の報告が成立しなくなる。

バッチ制御
----------

:func:`run` は、展開した処理単位を **逐次** 実行して結果を集約する
（:class:`BatchReport`）。本モジュールが所有するのは次の 6 点である。

1. **失敗ポリシー**（要件 6.4、6.5） — 個別の失敗は既定では処理を止めない。
   :attr:`~curvefit.config.FailurePolicy.FAIL_FAST` が指定された場合のみ最初の失敗で
   中止し、その場合もそれまでの結果を保持する
2. **資源枯渇の捕捉**（要件 10.3） — 例外を制御フローに使うのは
   :class:`MemoryError` と :class:`OSError` の捕捉に限る（設計の Error Strategy）。
   ジョブ展開時（読み取れないディレクトリ）・処理単位の実行中・出力の書き出し中の
   いずれで起きても :attr:`~curvefit.errors.FailureReason.RESOURCE_EXHAUSTED` として
   扱い、中断した対象を明示したうえでそれまでの結果とサマリを保持して終了する。
   :class:`UnexpectedConfigViolation` は捕捉しない。あれは呼び出し側の誤りであり、
   データの失敗ではない
3. **0 件に解決された入力指定の警告**（要件 6.1、8.4） — ディレクトリの拡張子絞り込み・
   綴り誤り・一致しないワイルドカードはいずれも 0 件になる。黙って正常終了すると
   1 ディレクトリ分の入力が無報告で消える
4. **進捗の通知**（要件 6.3） — :class:`ProgressObserver` に総処理単位数と総入力数の
   **双方** を渡す。処理単位数は入力数 × 列数 × 手法数であり、利用者が把握する
   ファイル数とは一致しない。**端末への描画は行わない**。描画は ``cli`` の担当である
5. **曲線データの解放**（要件 10.4） — 出力の適用（グラフ画像・曲線 CSV）が済んだ
   処理単位から :attr:`~curvefit.types.FitSuccess.curve` を手放し、集計結果には推定値・
   適合度・成否だけを残す。抱え続けると常駐メモリが件数に正確に比例して増える。解放は
   結果を :class:`BatchReport` に積む **前** に行う。積んでから最後にまとめて外しても、
   実行中の常駐メモリは減らない。**手放すかどうかは呼び出し元が明示する**
   （:func:`run` の ``retain_curve``）。単一系列の経路（:func:`~curvefit.api.fit_series`）
   だけが保持を選ぶ
6. **適用既定値の畳み込み**（要件 5.4） — 各処理単位が返した既定値を
   :func:`~curvefit.execution.collect_applied_defaults` で手法ごとにまとめ、
   実行条件の記録に反映して返す。実行前に組み立てた記録は既定値を持たないため、
   そのまま返すと要件 5.4 の記録が空になる。
   :class:`~curvefit.models.resolver.MethodSpec` からの再計算は、既定値の所有を
   当てはめ層と本層の 2 か所に分けるため禁じられている（設計の Postconditions）

**読み込み済みの系列を受け取った実行は出力先を持たない**（:func:`run` の ``series``、
要件 9.1）。処理単位はその系列 1 件 × 手法数に展開され、入力の走査は行わない。結果は
返り値でのみ渡るため、実行ログ・サマリ表・実行条件の記録を書き出す先が無い。上記 6 点の
制御そのものは経路によらず同一である。

**曲線を保持するかどうかは ``series`` の有無から推し量らない。** 単一系列の経路が曲線を
返す必要があるのは事実だが、それは「出力先を持たないこと」とは別の要求である。同じ真偽値
から 2 つの決定を導くと、片方だけを変えたい要求が出た時点で意味が割れる（``fit_series``
が「何も書かない」根拠が 2 か所にある件は既に残存リスクとして記録されている）。
:func:`run` は ``retain_curve`` という独立した指定で受け取る。

**並列化は行わない**（設計の Performance & Scalability）。要件 8.2 の決定性検証・
ログ順序・失敗集約のすべてを複雑にするためである。ログの順序は処理単位の順序に一致し、
処理単位の順序は :func:`expand_jobs` が決定的に定める。

依存方向は ``config`` までであり、``api`` と ``cli`` を import しない（設計の Allowed
Dependencies）。走査と出力以外の入出力を持たず、渡された実行条件を書き換えない。
"""

from __future__ import annotations

import glob
import logging
import os
from collections.abc import Callable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from pathlib import Path
from types import MappingProxyType
from typing import Protocol, overload

from curvefit.config import FailurePolicy, RunConfig
from curvefit.engines import (
    EngineFailure,
    EngineSuccess,
    FitEngine,
    compute_goodness,
    select_engine,
)
from curvefit.engines.smoothing import (
    NO_WEIGHT_SUPPORT_REASONS,
    POLYNOMIAL_DEGREE_OPTION,
    SMOOTHER_OPTION_DEFAULTS,
    SMOOTHER_USES_WEIGHTS,
)
from curvefit.errors import ConfigViolation, FailureReason
from curvefit.execution import (
    EXECUTION_RECORD_FILENAME,
    ExecutionRecord,
    collect_applied_defaults,
    write_execution_record,
)
from curvefit.logging_setup import (
    LOGGER_NAME,
    configure_run_log,
    log_outcome,
    log_run_start,
    log_summary,
)
from curvefit.models.resolver import (
    MethodSpec,
    PreparedMethod,
    PreparedModel,
    PreparedSmoother,
    SmootherKind,
    resolve,
)
from curvefit.plotting import render_fit_plot
from curvefit.preprocess import apply_preprocess
from curvefit.readers import ColumnSpec, column_label, read_delimited
from curvefit.types import (
    CurveData,
    DataSeries,
    FitFailure,
    FitOutcome,
    FitSuccess,
    FloatArray,
    PreprocessReport,
)
from curvefit.writers import (
    build_output_stem,
    write_curve,
    write_preprocess,
    write_summary,
)

WILDCARD_CHARACTERS: tuple[str, ...] = ("*", "?", "[")
"""この文字を含む指定をワイルドカードの候補とする（:mod:`glob` の特殊文字）。

**候補であって確定ではない。** その綴りのものが実在する場合は文字どおりのパスを採る
（本モジュールの docstring の「実在優先について」参照）。
"""

DIRECTORY_SUFFIXES: frozenset[str] = frozenset({".csv", ".tsv", ".txt"})
"""ディレクトリ指定で対象とする拡張子。大文字小文字は区別しない。

**この絞り込みはディレクトリ指定にのみ適用する。** ディレクトリ指定は中身を列挙しない
一括の指定であり、``README.md`` や ``.DS_Store`` のような付随ファイルが紛れ込む。
それらを処理単位にすると、利用者が設定ファイルからは直しようのない失敗がサマリに並ぶ。
ワイルドカードと直接指定は利用者自身が並びを書いたものなので、絞り込みを行わない。
"""

SUMMARY_FILENAME = "summary.csv"
"""全処理単位の結果をまとめたサマリ表のファイル名（設計の Batch / Job Contract）。"""

PLOT_SUBDIRECTORY = "plots"
"""グラフ画像を書き出す下位ディレクトリ（設計の Batch / Job Contract）。"""

CURVE_SUBDIRECTORY = "curves"
"""曲線・残差 CSV を書き出す下位ディレクトリ（設計の Batch / Job Contract）。"""

PREPROCESS_SUBDIRECTORY = "preprocess"
"""外れ値として除外した点を書き出す下位ディレクトリ（要件 2.5、設計の Batch / Job Contract）。

**この階層は除外があった処理単位についてのみ作られる**（``writers.write_preprocess``）。
存在そのものが「この対象には除外があった」を意味する形にしてある。
"""

PLOT_SUFFIX = ".png"
CURVE_SUFFIX = ".csv"
PREPROCESS_SUFFIX = ".csv"

MINIMUM_FIT_POINTS = 1
"""当てはめに進むために最低限必要な点数。

推定パラメータを持たない手法（平滑化スプライン・移動平均）でも、点が 1 つも残らない
系列を当てはめに渡す意味はない。0 点で進めると、適合度の算出が呼び出し側の誤りとして
例外になる（:func:`~curvefit.engines.base.compute_goodness`）か、手法ごとにばらばらの
理由で失敗するかのどちらかになる。要件 2.4 の点数不足として前処理層に判定させる。
"""

LINEAR_DEGREE = 1
"""線形回帰が当てはめる多項式の次数。係数は ``degree + 1`` 個（``slope`` と ``intercept``）。"""

WEIGHTS_IGNORED_STATUS = "weights_ignored"
"""誤差列が当てはめに反映されないことを表す語。実行ログの選り分けに用いる。"""

EMPTY_INPUT_STATUS = "empty_input"
"""入力指定が 0 件に解決されたことを表す語（要件 6.1、8.4）。実行ログの選り分けに用いる。"""

ABORTED_STATUS = "aborted"
"""バッチを中断したことを表す語（要件 6.5、10.3）。実行ログの選り分けに用いる。"""


@dataclass(frozen=True)
class Job:
    """1 件の処理単位（設計の Contracts）。

    入力 1 件と y 列 1 件と手法 1 件の組であり、この 3 軸の直積がバッチの全体になる
    （要件 1.11、6.8）。生成後に変更されない。実行の途中で対象・列・手法が書き換わると、
    記録と実際の実行が食い違い、要件 8.2 の再現性が成立しない。
    """

    index: int
    """処理単位の通し番号。0 起点で、最終的な実行順序に一致する。

    出力ファイル名の一部として使われる（:func:`~curvefit.writers.build_output_stem`、
    要件 7.6）。番号が確定するのは入力を並べ替えた **後** であり、この順序が決定的
    （要件 8.2）であるがゆえに、出力名も再実行で同一になる。
    """

    source: str
    """入力の識別子。ファイルの絶対パス、または呼び出し元が指定したラベル。

    :func:`expand_jobs` が組み立てる場合は常に絶対パスである。指定の表記の差
    （``data/a.csv`` と ``./data/a.csv``）を出力に持ち込まないため。
    """

    columns: ColumnSpec
    """この処理対象が読む x / y / 誤差列の組（要件 1.11）。

    **列は処理単位ごとに 1 件である。** 設定の列指定は y 列ごとの並び
    （:attr:`~curvefit.config.InputSpec.columns`）であり、その 1 要素がここに載る。
    読み込みは処理単位ごとに、**その列だけ** を対象に呼ぶ（:func:`_run_stages`）。

    **読み込み結果をファイル単位で共有しない**（設計の Responsibilities）。同一
    ファイルの 2 列は同一ファイルを 2 度読むが、共有すると処理単位が独立に実行できなく
    なり、要件 6.4 の「個別の失敗が他に波及しない」と要件 10.4 の常駐メモリの頭打ちの
    双方に影響する。実測で無駄になるのは総費用の約 9% であり（``research.md`` の
    G4・D2）、その代償として受け入れる。

    :attr:`series` を伴う処理単位では読み込みを行わないため、この値は参照されない。
    """

    column_label: str | None
    """出力名とサマリ表に載る y 列の識別子（要件 7.6）。

    :func:`~curvefit.readers.column_label` が :attr:`columns` の ``y`` の綴りから導く。
    ファイルの見出し行は読まない。処理単位を展開した時点で名前が定まることが、要件 7.7 の
    出力先検証と要件 8.2 の決定性の前提である。

    **読み込み済みの系列を直接渡す経路では ``None`` である**（:attr:`series`、要件 9.1）。
    その経路は列指定を読まず、系列そのものが処理対象であって、載せるべき y 列の綴りが
    存在しない。
    """

    method: MethodSpec
    """適用する手法の指定。**解決前** の表現である。

    解決は処理単位ごとに、その対象のデータを用いて呼び直す（設計の Implementation
    Notes、要件 4.1）。ここで解決済みの表現を持つと、組込モデルの初期値がどの対象の
    データから推定されたのか分からなくなる。
    """

    series: DataSeries | None = field(default=None, compare=False)
    """読み込み済みの系列。``None`` なら :attr:`source` の位置から読み込む。

    **要件 9.1 の対話利用のための差込口である。** ライブラリ利用では当てはめる系列が
    既にメモリ上にあり、それを入力の位置で表すには一時ファイルへの書き出しと読み直しが
    要る。この往復は値を変えないよう作れるが、系列 1 件ごとに実行時間と作業領域を使う。

    **差込口を読み込み段に置く。** :func:`run_job` が省くのは読み込みの 1 段だけであり、
    モデル解決・前処理・当てはめ・出力の順序は系列の由来によらず同一の経路を通る。
    呼び出し元に当てはめ手順を持たせると、要件 9.3 の「CLI とライブラリで同一結果」が
    構造ではなく規律で守られる状態になる（``api`` の docstring）。

    :func:`expand_jobs` が組み立てる処理単位では常に ``None`` である。

    **処理単位の同一性には含めない**（``compare=False``）。処理単位を識別するのは
    :attr:`source`、:attr:`columns`、:attr:`method` の 3 つであり、同じ対象を指す処理
    単位が系列の有無で別物になる理由はない。数値配列は要素ごとの比較を返すため、比較に含めると処理単位同士の
    比較が真偽値にならず :exc:`ValueError` になる。
    """


@dataclass(frozen=True)
class JobResult:
    """1 件の処理単位の実行結果（設計の Contracts）。

    当てはめ結果に加えて、**当てはめが実際に補った既定値** を運ぶ。要件 5.4 は既定値の
    適用を利用者に知らせるだけでなく「適用した値を実行条件として記録する」ことも求めて
    おり、その材料はこの経路でしか呼び出し元に届かない。

    :class:`~curvefit.types.FitOutcome` に欄を足さないのは、当てはめ結果が手法によらない
    共通の形（要件 5.3）であるためである。既定値は手法固有の選択肢に対してのみ生じ、
    そのような選択肢を持たない手法（線形・ガウシアン・指数、数式、利用者定義関数）では
    常に空になる。
    """

    outcome: FitOutcome
    """成功なら :class:`~curvefit.types.FitSuccess`、失敗ならその段階の
    :class:`~curvefit.types.FitFailure`。"""

    applied_defaults: Mapping[str, float | int] = field(default_factory=dict)
    """当てはめが補った既定値（要件 5.4）。利用者が明示した値は含まない。

    **失敗した処理単位では常に空である。** 当てはめに到達しなかった処理単位の既定値を
    記録すると、実行条件の記録が「実際に効いた値」ではなくなる。どの選択肢に既定値が
    効いたかを決めるのは本層より下であり（平滑化は ``engines.smoothing`` の
    ``_int_option``、組込モデルは選択肢がモデル実体の組み立てに要るため
    ``models.registry`` の ``BuiltinModelSpec.applied_defaults``）、本層はエンジンが
    返した結果を書き換えずに中継する。
    """

    def __post_init__(self) -> None:
        object.__setattr__(self, "applied_defaults", MappingProxyType(dict(self.applied_defaults)))


def normalize_source(text: str) -> str:
    """入力の指定を、比較と整列に使える一意な表記に直す。

    現在位置からの絶対パスにし、``.`` や ``..`` を字句的に畳む。**symlink の解決と
    大文字小文字の畳み込みは行わない**（本モジュールの docstring 参照）。

    :param text: 入力の指定。相対でも絶対でもよい
    :return: 絶対パスの文字列
    """
    # 抑止の理由: Path.resolve() は symlink を解決し大文字小文字を畳む。どちらも
    # 別々の入力を 1 つに融合させ、結果が静かに 1 件失われる（本関数の docstring）。
    return os.path.abspath(text)  # noqa: PTH100


def _is_wildcard(text: str) -> bool:
    """指定が :mod:`glob` の特殊文字を含むかを判定する。

    **これは分類の最終判断ではない。** 実在する綴りは、この判定が真でも文字どおりの
    パスとして扱う（:func:`expand_sources`、本モジュールの docstring の「実在優先に
    ついて」参照）。``[`` は文字クラスの開始でもあるため、判定だけで分岐させると
    ``[2024]run.csv`` のような実在ファイルが一致 0 件になる。
    """
    return any(character in text for character in WILDCARD_CHARACTERS)


def _expand_directory(text: str) -> list[str]:
    """ディレクトリ直下のデータファイルを集める（要件 6.1）。

    **再帰しない。** 再帰は ``**`` を含むワイルドカードによる明示指定に限る。
    ディレクトリ指定が下位を辿ると、出力先を入力の下に置いた場合に自身の出力を
    読み込む形が生まれ、利用者が指定の及ぶ範囲を予測できなくなる。

    走査順はファイルシステム依存であるため、ここでは整えない。整列は
    :func:`expand_sources` が全入力をまとめて行う。
    """
    return [
        str(entry)
        for entry in Path(text).iterdir()
        if entry.suffix.lower() in DIRECTORY_SUFFIXES and entry.is_file()
    ]


def _expand_wildcard(pattern: str) -> list[str]:
    """ワイルドカードに一致するファイルを集める（要件 6.1）。

    ``recursive=True`` により ``**`` が下位ディレクトリを辿る。再帰を利用者の明示的な
    選択にするための唯一の経路である。

    一致したディレクトリは対象から外す。読み込もうとしても利用者に直しようのない
    失敗になるだけであり、ディレクトリとして展開し直すと ``data/*`` と ``data/*.csv``
    で意味が食い違う。
    """
    # 抑止の理由: 利用者が書いた綴りをそのままパターンとして渡す。Path.glob は基点と
    # パターンへの分割を要し、絶対指定やドライブ文字で意味が変わる。
    return [
        matched
        for matched in glob.glob(pattern, recursive=True)  # noqa: PTH207
        if not os.path.isdir(matched)  # noqa: PTH112
    ]


def expand_sources(paths: Sequence[str]) -> tuple[str, ...]:
    """入力の指定を、重複のない整列済みの対象一覧に解決する（要件 6.1、8.2）。

    指定は 3 通りを取る。ワイルドカード（:data:`WILDCARD_CHARACTERS` を含み、かつ
    その綴りのものが **実在しない**）、ディレクトリ、それ以外は 1 件のファイルである。
    存在しない指定はファイルとして扱い、そのまま対象に含める（存在確認を行わないため。
    本モジュールの docstring 参照）。

    **実在する綴りはパターン解釈より優先する**（本モジュールの docstring の
    「実在優先について」参照）。``[2024]run.csv`` のような実在ファイルや ``da[t]a``
    のような実在ディレクトリを、``[`` を含むというだけでパターンとして解釈しない。

    **重複は排除する。** ディレクトリ指定とワイルドカードが同じファイルを指すことは
    普通に起こり、同じ対象を 2 回処理すれば同じ行がサマリに 2 度現れる。判定は
    :func:`normalize_source` の結果で行うため、表記の違う同一ファイルもまとめられる。

    :param paths: 入力の指定の並び（:class:`~curvefit.config.InputSpec` の ``paths``）
    :return: 絶対パスの並び。昇順に整列し、重複を含まない
    :raises OSError: 存在するディレクトリを読み取れない場合
    """
    collected: set[str] = set()
    for text in paths:
        collected.update(_expand_one(text))
    return tuple(sorted(collected))


def _expand_one(text: str) -> set[str]:
    """入力指定 1 件を、正規化済みの対象の集合に解決する。

    分類の規則は :func:`expand_sources` の説明どおりである。1 件ずつ解決できる形に
    切り出してあるのは、:func:`run` が **どの指定が 0 件になったか** を言えるように
    するためである（要件 6.1）。全指定をまとめた集合からは、0 件になった指定を
    特定できない。

    :raises OSError: 存在するディレクトリを読み取れない場合
    """
    # 抑止の理由: 入力指定は文字列のまま保持する（設計の決定）。ここで Path に写すと
    # 記述と保持値が食い違い、実行条件の記録が利用者の書いた綴りと一致しなくなる。
    if _is_wildcard(text) and not os.path.exists(text):  # noqa: PTH110
        matched = _expand_wildcard(text)
    elif os.path.isdir(text):  # noqa: PTH112
        matched = _expand_directory(text)
    else:
        matched = [text]
    return {normalize_source(item) for item in matched}


def expand_jobs(config: RunConfig) -> tuple[Job, ...]:
    """入力・y 列・手法の直積を、処理単位の一覧に展開する（要件 1.1、1.11、6.1、6.2、6.8、8.2）。

    軸の順序は **入力 → 列 → 手法** である。同一データに対する各手法の結果が隣り合い、
    要件 6.2 の「モデルごとの結果を横並びで比較」がサマリ CSV の行の並びとしてそのまま
    成立する。手法を内側に置いたまま列をその外側に挟むことで、同一ファイルの各列も
    隣接する。列を挟む位置を入力の外側にすると、同じファイルの結果がサマリ表の離れた
    位置に散る。

    対象は整列済み（:func:`expand_sources`）、列と手法は設定の記述順である。この 3 つが
    決まれば並びは一意に決まり、:attr:`Job.index` もまた決定的になる（要件 8.2）。

    **列を 1 つだけ指定した場合も規則は同じ**である。件数が入力数 × 手法数に戻るだけで、
    展開の経路は分岐しない。

    実行条件は読むだけで書き換えない。走査以外の入出力を持たない。

    :param config: 実行条件。``inputs.paths``、``inputs.columns``、``methods`` のみを
        参照する
    :return: 処理単位の一覧。``index`` は 0 起点の連番で、並びと一致する
    :raises OSError: 存在するディレクトリを読み取れない場合
    """
    return _build_jobs(
        expand_sources(config.inputs.paths), config.inputs.columns, config.methods, None
    )


def _series_jobs(
    series: DataSeries, columns: ColumnSpec, methods: Sequence[MethodSpec]
) -> tuple[Job, ...]:
    """読み込み済みの系列 1 件と手法集合の直積を、処理単位の一覧に展開する（要件 9.1）。

    対象は 1 件であり、走査も正規化も行わない。系列の識別子は呼び出し元が付けたラベル
    （:attr:`~curvefit.types.DataSeries.source_id`）であって位置ではないため、
    :func:`normalize_source` の絶対パス化を通すと利用者の付けた名前が失われる。

    **列軸は展開しない。** 当てはめる系列は 1 件であり、そこに y 列は 1 つしかない。
    列指定は読み込みを行わない本経路では参照されないが、:class:`Job` の欄を埋めるために
    運ぶ。出力名に載る識別子（:attr:`Job.column_label`）は ``None`` になる
    （:func:`_build_jobs`）。読みもしない列指定の綴りを出力名の材料にすると、利用者が
    付けた名前と無関係な文字列が出力に現れる。

    並びは手法の記述順である（要件 8.2）。:attr:`Job.index` の与え方は
    :func:`expand_jobs` と同一（:func:`_build_jobs`）であり、出力名の導出規則も
    そのまま成立する（要件 7.6）。
    """
    return _build_jobs((series.source_id,), (columns,), methods, series)


def _build_jobs(
    sources: Sequence[str],
    columns: Sequence[ColumnSpec],
    methods: Sequence[MethodSpec],
    series: DataSeries | None,
) -> tuple[Job, ...]:
    """対象・列・手法の直積を、通し番号つきの処理単位に組み立てる。

    軸の順序（入力 → 列 → 手法）と通し番号の与え方をここ 1 か所に置く。入力が
    ファイルでもメモリ上の系列でも並びの規則が同じであることが、要件 8.2 の決定性を
    経路によらず成立させる。

    :param series: 全処理単位に載せる読み込み済みの系列。``None`` なら
        :attr:`Job.source` の位置から読み込む処理単位になる。系列を伴う処理単位では
        列の識別子を載せない（:func:`_series_jobs`）
    """
    jobs: list[Job] = []
    for source in sources:
        for spec in columns:
            label = None if series is not None else column_label(spec)
            for method in methods:
                jobs.append(
                    Job(
                        index=len(jobs),
                        source=source,
                        columns=spec,
                        column_label=label,
                        method=method,
                        series=series,
                    )
                )
    return tuple(jobs)


# --- 単一処理単位の実行 ------------------------------------------------------------


class UnexpectedConfigViolation(RuntimeError):  # noqa: N818 - 公開名。改名は破壊的変更
    """実行前ゲートを通過したはずの指定が、実行時に違反として解決されたことを表す。

    :func:`~curvefit.models.resolver.resolve` は
    :class:`~curvefit.errors.ConfigViolation` を返しうるが、その違反はいずれもデータに
    依存しない。実行前ゲート（``preflight``）が同じ解決を ``sample=None`` で試みており
    （設計の Implementation Notes）、そこを通っていれば処理単位ごとの解決で新たな違反が
    出ることはない。``sample`` が加える処理は初期値の自動推定だけで、その失敗は違反に
    ならない（``models.resolver`` の ``_apply_auto_initial``）。

    **したがってここに違反が届くのは、設計の Preconditions（``preflight.validate`` が
    ``ok`` を返していること）が守られていない場合に限る。** これは利用者のデータや設定に
    起因する失敗ではなく呼び出し側の誤りであり、本プロジェクトの規約に従って値ではなく
    例外で伝える。:class:`~curvefit.types.FitFailure` に化けさせると、実行前に停止する
    べき設定の誤り（要件 8.5）が処理単位のスキップ件数に紛れ、利用者は違反の一覧を
    受け取れないまま結果だけを得る。:class:`~curvefit.errors.FailureReason` に対応する
    分類が無いことも、この違反が実行中の失敗ではないことを示している。

    バッチ制御（タスク 7.3）はこの例外を捕捉しない。捕捉すべきは資源枯渇
    （:class:`MemoryError` / :class:`OSError`）に限る（設計の Error Strategy）。
    """

    def __init__(self, violations: Sequence[ConfigViolation]) -> None:
        self.violations: tuple[ConfigViolation, ...] = tuple(violations)
        rendered = "; ".join(
            f"[{violation.kind.value}] {violation.location}: {violation.message}"
            for violation in self.violations
        )
        super().__init__(
            "実行前検証を通過していない手法指定が実行時に届いた"
            f"（違反 {len(self.violations)} 件）: {rendered}"
        )


def _resolve_for_job(spec: MethodSpec, series: DataSeries) -> PreparedMethod:
    """処理単位ごとに手法を解決し直す（要件 4.1）。

    ``sample`` にはその処理単位のデータを渡す。組込モデルの初期値をそのデータから
    推定させるためであり、設定解決時に一度だけ推定して使い回すと、ファイルごとに
    スケールの異なるデータで収束が悪化する（設計の Implementation Notes）。実測でも、
    小さいスケールのデータから推定した初期値のまま桁の異なるデータに当てると、
    当てはめは初期値からほとんど動かず中心も幅も復元されない。

    :raises UnexpectedConfigViolation: 解決が違反を返した場合。実行前ゲートを通って
        いれば起こりえない（:class:`UnexpectedConfigViolation` 参照）
    """
    prepared = resolve(spec, sample=series)
    if isinstance(prepared, tuple):
        raise UnexpectedConfigViolation(prepared)
    return prepared


def _smoother_parameter_count(method: PreparedSmoother) -> int:
    """平滑化手法が推定するパラメータの個数。

    既定値は当てはめエンジンが単独で所有するため、次数の既定は
    :data:`~curvefit.engines.smoothing.SMOOTHER_OPTION_DEFAULTS` から引く。ここに独自の
    既定値を置くと、検証を通った設定が実行時に別の値で動く。

    スプラインと移動平均は推定パラメータを持たない（``engines.smoothing``）。節点ごとの
    係数や畳み込み係数は手法の内部表現であり、利用者が比較できる推定量ではない。
    """
    if method.kind is SmootherKind.LINEAR:
        return LINEAR_DEGREE + 1
    if method.kind is SmootherKind.POLYNOMIAL:
        default = SMOOTHER_OPTION_DEFAULTS[SmootherKind.POLYNOMIAL][POLYNOMIAL_DEGREE_OPTION]
        return int(method.options.get(POLYNOMIAL_DEGREE_OPTION, default)) + 1
    return 0


def _min_points(method: PreparedMethod, spec: MethodSpec) -> int:
    """前処理に渡す最小点数を、解決済み手法の **推定対象** パラメータ数から導出する。

    要件 2.4 が点数と比べるのは推定対象パラメータの個数であり、**固定したパラメータは
    数えない**（要件 4.5）。固定した値は当てはめが動かさないため、必要な点数を増やさない。
    数に含めると、実際には当てはまる処理単位が点数不足として報告される。``sigma`` を
    固定したガウシアンは推定対象が 2 個であり、2 点のデータで当てはめられる。

    固定の指定を持つのは **解決前** の :class:`~curvefit.models.resolver.MethodSpec` で
    ある。:class:`~curvefit.models.resolver.PreparedModel` は固定の可否をパラメータ束の
    内部にしか持たず、その参照は当てはめエンジンに限られる（設計の Contracts）。同じ
    区別を :func:`_success_from_engine` は当てはめ結果の ``fixed`` から行うが、そちらは
    当てはめが済んだ後にしか使えない。

    ``parameter_names`` は推定対象パラメータの識別子であり、派生量を含まない。含めると
    本判定が狂うため、解決層が ``make_params()`` の前に確定させている。

    下限は :data:`MINIMUM_FIT_POINTS` とする。推定パラメータを持たない手法でも、
    点が 1 つも残らない系列を当てはめに渡す意味はない。

    :param method: 解決済みの手法
    :param spec: 解決前の手法指定。固定パラメータ（``fixed``）の判定に用いる
    """
    if isinstance(method, PreparedModel):
        count = sum(1 for name in method.parameter_names if name not in spec.fixed)
    else:
        count = _smoother_parameter_count(method)
    return max(count, MINIMUM_FIT_POINTS)


def _provisional_fit(
    engine: FitEngine, method: PreparedMethod
) -> Callable[[DataSeries], FloatArray | None]:
    """外れ値判定に用いる暫定当てはめを、エンジンを束ねたクロージャとして組み立てる。

    前処理層が :mod:`curvefit.engines` に依存しない構造は、この供給責任を本層に置く
    ことで成立する（設計の Implementation Notes）。

    **非収束は ``None`` で伝える。** :func:`~curvefit.preprocess.apply_preprocess` は
    例外・``None``・長さ不一致・非有限値のいずれでも非収束と解するが、当てはめ契約は
    失敗を値（:class:`~curvefit.engines.base.EngineFailure`）で返す形に統一されている。
    値で受け取れる失敗を例外として投げ直せば、前処理層は当てはめ器の実装上の誤りと
    非収束を見分ける手立てを失う。

    **資源枯渇は捕捉しない。** エンジンは :class:`MemoryError` と :class:`OSError` を
    そのまま送出し、前処理層もこの 2 つだけは捕捉せず通す。要件 10.3 の「中断した対象を
    明示する」報告は、この 2 つが呼び出し元まで届くことに依る。
    """

    def provisional(candidate: DataSeries) -> FloatArray | None:
        outcome = engine.fit(candidate, method)
        if isinstance(outcome, EngineSuccess):
            return outcome.y_fit
        return None

    return provisional


def _log_ignored_weights(
    logger: logging.Logger, series: DataSeries, method: PreparedMethod, method_name: str
) -> None:
    """重みを持つ系列に、重みを扱えない手法が当たる場合を実行ログに残す。

    :class:`~curvefit.types.FitOutcome` は重みの由来情報を持たないため、この判定が
    できるのは :class:`~curvefit.types.DataSeries` と解決済み手法を同時に持つ本層だけ
    である（設計の Implementation Notes、タスク 5.4 のレビューで担当を確定）。黙って
    無視すると、利用者は測定誤差を与えたのにそれが推定へ反映されていないことに気付けず、
    重み付きの結果として読んでしまう。

    **要件 1.10 の拒否があってもなお必要である。** 実行前ゲートが拒否するのは
    「**誤差列が指定されている**（:attr:`~curvefit.readers.ColumnSpec.weight`）かつ
    重みを扱えない手法」という設定上の組み合わせである（``preflight``）。読み込み済みの
    系列を直接渡す経路（:attr:`Job.series`、:func:`~curvefit.api.fit_series`、要件 9.1）
    では、重みは :class:`~curvefit.types.DataSeries` が既に持っており、列指定は
    当てはめに一切関与しない（``api.UNUSED_COLUMNS``）。実行前ゲートは系列を受け取らない
    ため、この経路の重みを見ることができない。したがって本記録はこの経路の唯一の告知で
    あり、到達不能な防御ではない。``tests/integration/test_api.py`` の
    `Test記録の届き先` が、``fit_series`` にこの警告が届くことを固定する。

    失敗にはしない。この経路では手法の選択も系列の重みもそれ自体は正当であり、当てはめは
    実行できる。水準は警告とし、対象・手法を必ず書く（設計の Error Categories）。

    重みを扱えるかどうかは :data:`~curvefit.engines.smoothing.SMOOTHER_USES_WEIGHTS` を
    唯一の出所とする。**本層は対象を列挙しない。** かつて独自の集合を持っており、
    スプラインが重みを扱うようになった際（タスク 11.1）に当てはめ側と本層の両方を直す
    必要があった。
    """
    if series.weights is None or not isinstance(method, PreparedSmoother):
        return
    if SMOOTHER_USES_WEIGHTS[method.kind]:
        return
    logger.warning(
        "source_id=%r method=%r status=%s "
        "測定誤差による重みが与えられているが、%s では反映できない（%s）",
        series.source_id,
        method_name,
        WEIGHTS_IGNORED_STATUS,
        method.kind.value,
        NO_WEIGHT_SUPPORT_REASONS[method.kind],
    )


def _describe_initial(initial_values: Mapping[str, float]) -> str:
    """非収束の報告に載せる初期値の記述（要件 4.7）。

    :class:`~curvefit.types.FitFailure` は初期値の欄を持たないため、説明に織り込まなければ
    「どの初期値から出発したか」が失われる。利用者の次の行動は初期値の見直しであり、
    これが無ければ初期値を変えるべきかモデルを変えるべきかを判断できない。

    並びは当てはめエンジンが控えた順序（解決済みモデルのパラメータ順）をそのまま保つ。
    パラメータ順は解決層が確定させた決定的な並びであり、要件 8.2 の再現性を損なわない。
    """
    if not initial_values:
        return ""
    rendered = ", ".join(f"{name}={value!r}" for name, value in initial_values.items())
    return f"使用した初期値: {rendered}。"


def _failure_from_engine(
    job: Job, failure: EngineFailure, report: PreprocessReport
) -> FitFailure:
    """当てはめの失敗を処理単位の失敗結果に写し替える。

    エンジンは対象がどの入力に由来するかを知らないため、識別子の付与は本層が担う
    （``engines.base``）。前処理の記録も併せて残す。何点が使われた結果の失敗なのかは、
    次の一手（区間指定の見直しか、モデルの見直しか）を分ける材料になる。
    """
    return FitFailure(
        source_id=job.source,
        method_name=job.method.name,
        reason=failure.reason,
        message=f"{failure.message}{_describe_initial(failure.initial_values)}",
        preprocess=report,
    )


def _success_from_engine(
    job: Job, series: DataSeries, report: PreprocessReport, success: EngineSuccess
) -> FitSuccess:
    """当てはめの成功を処理単位の結果に組み立てる（要件 7.1、7.2）。

    適合度は :func:`~curvefit.engines.base.compute_goodness` が残差から算出する。手法に
    よらず同一の式であることが、要件 5.3 の「同一の形式で出力する」の前提になる。
    変動パラメータ数は固定指定されていない推定値の個数である（要件 4.5）。固定した
    パラメータは推定していないため、モデルの比較に用いる数には含めない。

    残差は実測値から当てはめ値を引いた値とする。曲線データは入力の行順を保つ。並べ替えは
    描画時にのみ行われ（``plotting``）、出力される数値データの並びは入力に対応づく。
    """
    y_fit = success.y_fit
    n_varied = sum(1 for estimate in success.parameters if not estimate.fixed)
    return FitSuccess(
        source_id=job.source,
        method_name=job.method.name,
        parameters=success.parameters,
        goodness=compute_goodness(series.y, y_fit, n_varied),
        curve=CurveData(
            x=series.x,
            y_observed=series.y,
            y_fit=y_fit,
            residual=series.y - y_fit,
        ),
        preprocess=report,
    )


def _output_target(
    config: RunConfig, series: DataSeries | None, enabled: bool, *parts: str
) -> Path | None:
    """出力 1 件の書き出し先を決める。書き出さない場合は ``None`` を返す。

    **出力を書くか否かの判断は本関数だけが持つ。** 抑止には 2 つの軸がある。

    - **出力先を持たない実行かどうか**（``series``、要件 9.1）。読み込み済みの系列を
      直接受け取った実行は結果を返り値でのみ渡し、書き出す先が無い。
      :func:`~curvefit.api.fit_series` の ``output.directory`` は共有の一時領域
      （:func:`tempfile.gettempdir`）であり、書けば利用者の一時領域に痕跡が残り続ける
    - **その出力が有効かどうか**（``enabled``、要件 7.4、7.5）。既定値そのものは
      :class:`~curvefit.config.OutputSpec` が持ち、本関数は受け取った真偽値を見るだけで
      ある。前処理 CSV（要件 2.5）と実行条件の記録（要件 8.3）はオプトインの
      フラグを持たない出力であり、呼び出し側は ``True`` を渡す

    **2 軸を 1 か所で合流させるためにある。** 軸ごとに別の場所で抑止すると、ある出力は
    フラグだけ、別の出力は系列の有無だけを見る形になり、「何も書かない」の根拠が出力の
    種類ごとに分かれる。フラグを持たない出力を足した時点で、系列を直接渡す経路が
    利用者の一時領域へ書き始める（実測で確認）。書き出し先を求める経路を 1 本にすれば、
    新しい出力もその 1 本を通る。

    :param config: 実行条件。出力先の位置だけを参照する
    :param series: 直接渡された系列。``None`` でない実行は出力先を持たない
    :param enabled: その出力が有効か。フラグを持たない出力では ``True``
    :param parts: 出力先からの相対位置。省略すると出力先そのものを返す
    :return: 書き出し先。抑止されている場合は ``None``
    """
    if series is not None or not enabled:
        return None
    return config.output.directory.joinpath(*parts)


def _apply_outputs(config: RunConfig, job: Job, success: FitSuccess) -> None:
    """成功した処理単位の出力物を書き出す（要件 7.4、7.5、7.6）。

    **グラフ画像は既定で保存し**（要件 7.4）、**曲線・残差 CSV は有効化された場合にのみ
    生成する**（要件 7.5）。既定値そのものは :class:`~curvefit.config.OutputSpec` が
    持ち、本関数は判断を持たない。``writers.write_curve`` がオプトインの判断を持たない
    のと同じ理由で、有効/無効の解釈が 2 か所に分かれないようにする。書き出すか否かと
    書き出し先は :func:`_output_target` が単独で決める。

    ファイル名は :func:`~curvefit.writers.build_output_stem` がジョブから決定的に導出する。
    列の識別子（:attr:`Job.column_label`）を含むため、同一ファイルの別々の列の出力が互いを
    上書きせず、ジョブ番号を含むため、別ディレクトリの同名ファイルでも上書きしない
    （要件 7.6）。

    :raises OSError: 書き込みに失敗した場合。資源・環境の失敗は要件 10.3 の系統であり、
        値として飲み込まない。捕捉と中断の判断はバッチ制御が持つ
    """
    stem = build_output_stem(job.source, job.column_label, job.method.name, job.index)
    plot = _output_target(
        config, job.series, config.output.write_plot, PLOT_SUBDIRECTORY, f"{stem}{PLOT_SUFFIX}"
    )
    if plot is not None:
        render_fit_plot(success, plot)
    curve = _output_target(
        config, job.series, config.output.write_curve, CURVE_SUBDIRECTORY, f"{stem}{CURVE_SUFFIX}"
    )
    if curve is not None:
        write_curve(success, curve)


def _apply_preprocess_report(config: RunConfig, job: Job, outcome: FitOutcome) -> None:
    """外れ値として除外した点を書き出す（要件 2.5、9.1）。

    **成否によらず書く。これは本層で唯一、「出力物を書き出すのは成功した場合に限る」
    （:func:`run_job`）から外れる出力である。** 整合させようとして成功時に限らないこと。
    理由は出力物の種類が違うことにある。グラフ画像と曲線 CSV は **当てはめの結果** で
    あり、失敗した対象に残れば出力ディレクトリの内容とサマリ表の成否が食い違う。前処理
    CSV は **前処理が何をしたかの説明** であり、当てはめの成否とは独立に成立する。外れ値
    を除いた結果として点数不足で落ちる場合（要件 2.4）は、まさにどの点が除かれたのかを
    知りたい場面であり、そこで書かなければ要件 2.5 が最も必要な場面で満たされない
    （設計の writers / Implementation Notes）。したがって :func:`_apply_outputs` は
    使えない。あれは :class:`~curvefit.types.FitSuccess` を受け取る。

    **本出力はオプトインのフラグを持たない**（要件 2.5 は出力の有効化を条件にしていない）。
    書き出すか否かと書き出し先は :func:`_output_target` が単独で決め、``enabled`` には
    ``True`` を渡す。**系列を直接渡された処理単位で書かない**（:attr:`Job.series`、
    要件 9.1、9.3）判断もそこにある。図・曲線 CSV と同じ 1 本の経路を通すためであり、
    フラグを持つ出力と持たない出力で抑止の根拠が分かれない。

    **書くか否かの残り 2 条件は持たない。** ``outcome.preprocess`` が ``None`` の場合
    （前処理に到達する前に失敗した処理単位）と、除外した点が 1 つもない場合に何も書かない
    判断は :func:`~curvefit.writers.write_preprocess` が単独で持つ。判断材料が引数の中に
    あるためである（``writers`` の docstring）。本関数はその 2 条件を見ずに呼ぶ。判断を
    2 か所に置くと片方だけが更新される。

    ファイル名は :func:`_apply_outputs` と同じ :func:`~curvefit.writers.build_output_stem`
    から導く。前処理 CSV の名前も列の識別子を含み（要件 2.5 の「処理対象を識別できる形」）、
    同一ファイルの別々の列の出力が互いを上書きしない。ジョブ番号を含むため、別ディレクトリの
    同名ファイルでも上書きしない（要件 7.6）。

    :raises OSError: 書き込みに失敗した場合。資源・環境の失敗は要件 10.3 の系統であり、
        値として飲み込まない。捕捉と中断の判断はバッチ制御が持つ
    """
    stem = build_output_stem(job.source, job.column_label, job.method.name, job.index)
    target = _output_target(
        config,
        job.series,
        True,
        PREPROCESS_SUBDIRECTORY,
        f"{stem}{PREPROCESS_SUFFIX}",
    )
    if target is not None:
        write_preprocess(outcome, target)


@overload
def _with_column_identity(
    job: Job, outcome: FitFailure, series: DataSeries | None
) -> FitFailure: ...


@overload
def _with_column_identity(
    job: Job, outcome: FitOutcome, series: DataSeries | None
) -> FitOutcome: ...


def _with_column_identity(
    job: Job, outcome: FitOutcome, series: DataSeries | None
) -> FitOutcome:
    """処理単位の結果に、y 列の 2 つの識別子を刻む（要件 1.4、1.5、7.3、7.6）。

    **刻む規則を持つのは本関数だけである。** 返り口は 5 つあり（読み込み不能・読み込みの
    失敗・前処理の失敗・当てはめの失敗・成功）、返り口ごとに刻むと 1 つ足しただけで刻み
    忘れが生まれる。2 つの欄は既定値 ``None`` を持つため（設計の types の Invariants:
    既定値を外すと構築地点 82 か所に波及する）、**刻み忘れても型は黙って通る**。したがって
    埋まっていることは振る舞いの側でしか押さえられず、``tests/integration/`` の
    ``TestColumnIdentityOnEveryOutcome`` と ``TestColumnIdentityIsStampedInOnePlace`` が
    返り口ごとの刻印と、刻む構文が他所に現れないことを固定している。

    2 つの識別子は確定する時期が違う。**指定の綴り**（:attr:`Job.column_label`）は
    ジョブ展開の時点で決まるため、読み込みに 1 バイトも進まなかった失敗にも載る。
    **解決後の見出し名**（:attr:`~curvefit.types.DataSeries.column_name`）は読み込めた
    系列からしか分からず、列を解決できない失敗と有効データが 1 件も無い失敗では ``None``
    である。

    **綴りを持たない処理単位には何も刻まない。** 綴りが ``None`` になるのは系列を直接
    渡す経路（:func:`_series_jobs`、要件 9.1）に限り、その経路は列の概念を持たない。
    渡された系列がたまたま見出し名を持っていても載せない。見出し名だけが載る結果は型の
    不変条件（見出し名を持つなら綴りも持つ）に反し、生成時に落ちる。

    失敗だけを扱う呼び出し元（:func:`_resource_failure`）が型を失わないよう、失敗を
    渡した場合の返り型を多重定義で保つ。

    :param job: 実行した処理単位。綴りの出どころである
    :param outcome: 刻む前の結果。成功・失敗のいずれでもよい
    :param series: 読み込めた系列。読み込みに至らなかった場合は ``None``
    :return: 2 つの識別子を持つ結果
    """
    if job.column_label is None:
        return outcome
    return replace(
        outcome,
        column_label=job.column_label,
        column_name=series.column_name if series is not None else None,
    )


def _unreadable_failure(job: Job, error: OSError) -> FitFailure:
    """入力を読めなかった処理単位を、個別の失敗として表す（要件 1.8）。

    **この失敗はバッチを止めない。** 綴り誤りや共有先から消えた 1 ファイルで数百件の
    実行が終わってはならない（要件 6.4、10.1）。資源枯渇
    （:attr:`~curvefit.errors.FailureReason.RESOURCE_EXHAUSTED`）と別の理由に分けるのは、
    継続するか中断するかの判断がこの区別に載っているためである。

    次の行動が決まる報告にする。読めなかったパスと OS が返した理由の双方を載せる。
    件数だけの報告では、数百件の実行のどの指定を直せばよいかが分からない。
    """
    return FitFailure(
        source_id=job.source,
        method_name=job.method.name,
        reason=FailureReason.INPUT_UNREADABLE,
        message=(
            f"入力ファイルを読めない（{type(error).__name__}: {error}）。"
            "パスの綴りと読み取り権限を確認する。この対象のみを失敗として記録し、"
            "残りの処理は継続する"
        ),
    )


def run_job(job: Job, config: RunConfig) -> JobResult:
    """1 件の処理単位を、読み込みから出力の適用まで通す（要件 2.5、4.1、5.4、7.4、7.5）。

    段階は **読み込み → モデル解決 → 前処理 → 当てはめ → 出力の適用** の順である
    （:func:`_run_stages`）。いずれかの段階が :class:`~curvefit.types.FitFailure` を
    返した場合、以降の段階には進まず、その結果をそのまま処理単位の結果とする。当てはめの
    結果である出力物（グラフ画像・曲線 CSV）を書き出すのは成功した場合に限る。失敗した
    対象の図や曲線 CSV が残ると、出力ディレクトリの内容とサマリ表の成否が食い違う。

    **前処理 CSV だけはこの規則から外れる**（要件 2.5、:func:`_apply_preprocess_report`）。
    外れ値として除外した点の記録は当てはめの結果ではなく前処理の説明であり、成否とは
    独立に成立する。**どの返り口からも 1 度だけ通す。** 書き出しの地点は 2 つある。

    - 成功する場合は :func:`_run_stages` の中で、当てはめ結果の書き出しより **先** に
      書く。後に置くと、図や曲線 CSV の書き込みが送出する :exc:`OSError`（要件 10.3）で
      前処理の説明まで一緒に失われる（実測で再現した）
    - それ以外は本関数が書く。成功した結果をここで再び書かないよう
      :func:`~curvefit.types.FitSuccess` を除いており、この 2 地点は排他である

    前処理に到達しなかった返り口（入力を読めない・読み込みの失敗）では
    :attr:`~curvefit.types.FitOutcome.preprocess` が ``None`` であり、書くか否かを単独で
    判断する :func:`~curvefit.writers.write_preprocess` が何も書かずに戻る。

    **成功を返す返り口を新たに設ける場合は、そこでも書くこと。** 本関数の除外は
    「:func:`_run_stages` の中で既に書いた」ことを前提にしており、書かずに成功を返す
    経路を足すと、2 地点のどちらも通らない。``tests/integration/test_pipeline_job_run.py``
    が、返り口ごとに書き出しがちょうど 1 回であることを固定する。

    **処理単位が系列を伴う場合は読み込みを行わない**（:attr:`Job.series`、要件 9.1、
    :func:`_load_series`）。省くのは読み込みの 1 段だけであり、以降の段階は系列の由来に
    よらず同一の手順を通る。当てはめ専用の経路を作らないことが、要件 9.3 を構造で保つ
    形である。

    **入力を読めない場合は個別の失敗として返す**（要件 1.8、:func:`_unreadable_failure`）。
    捕捉するのは読み込みの 1 呼び出しに限る。関数全体を包むと、出力の書き込み失敗まで
    値になり、要件 10.3 の中断が成立しなくなる。

    **y 列の識別子は返り口によらずここで刻む**（要件 1.4、1.5、7.3、7.6、
    :func:`_with_column_identity`）。刻む地点を段階の側に置くと、返り口 5 つのどれかで
    刻み忘れが起き、2 つの欄が既定値 ``None`` を持つため型は黙って通る。読み込めた系列を
    本関数が持つのはこのためである。

    モデル解決は処理単位ごとに呼び直す（要件 4.1、:func:`_resolve_for_job`）。前処理に
    渡す最小点数（:func:`_min_points`）と暫定当てはめ（:func:`_provisional_fit`）は本層が
    供給する。

    **当てはめが補った既定値は :class:`JobResult` に載せて返す**（要件 5.4）。当てはめに
    到達しなかった処理単位では、補われた選択肢があっても実際には何も効いていない。
    したがって失敗した場合の ``applied_defaults`` は空である。

    **バッチ制御は行わない。** 失敗の集約・進捗通知・資源枯渇の扱いは :func:`run` の
    担当である。:class:`MemoryError` と、出力の書き込みが送出する :class:`OSError` は
    捕捉せず送出させる。

    :param job: 実行する処理単位。``series`` を伴わない場合、``source`` の読み込み可否は
        問わない（読めなければ要件 1.8 の失敗として返す）
    :param config: 実行条件。入力の列指定・前処理・出力設定を参照する。書き換えない
    :return: 当てはめ結果（成功なら :class:`~curvefit.types.FitSuccess`、いずれかの段階で
        失敗した場合はその段階の :class:`~curvefit.types.FitFailure`）と、当てはめが
        補った既定値を持つ :class:`JobResult`
    :raises UnexpectedConfigViolation: 手法の解決が違反を返した場合。実行前ゲートを
        通っていれば起こりえない（設計の Preconditions）
    :raises OSError: 出力を書けない場合。出力先の不備は対象を替えても解消しないため、
        値として飲み込まない（要件 10.3）
    :raises MemoryError: 記憶領域が尽きた場合。同上
    """
    loaded = _load_series(job, config)
    if isinstance(loaded, FitFailure):
        series = None
        result = JobResult(outcome=loaded)
    else:
        series = loaded
        result = _run_stages(job, config, series)
    # 列の識別子は読み込みの成否によらず、この 1 か所で刻む（要件 7.3、7.6）。
    result = replace(result, outcome=_with_column_identity(job, result.outcome, series))
    # 成功経路では _run_stages の中で書き終えている（当てはめ結果より先に書くため）。
    # ここに来るのは前処理まで到達して失敗した場合と、前処理に到達しなかった場合で、
    # 後者は書くか否かを単独で判断する write_preprocess が何も書かずに戻る。
    if not isinstance(result.outcome, FitSuccess):
        _apply_preprocess_report(config, job, result.outcome)
    return result


def _load_series(job: Job, config: RunConfig) -> DataSeries | FitFailure:
    """処理単位の入力を系列として得る（:func:`run_job` の第 1 段）。

    **処理単位が系列を伴う場合は読み込みを行わない**（:attr:`Job.series`、要件 9.1）。
    省くのは読み込みの 1 段だけである。

    切り出してあるのは、読み込みで止まった場合と読み込めた場合の双方を
    :func:`run_job` が同じ高さで扱えるようにするためである。列の見出し名を刻むには
    読み込めた系列が要り（:func:`_with_column_identity`）、読み込みを段階の内側に
    埋めたままでは刻印が段階ごとに分かれる。

    :return: 読み込めた系列。読めない・列を解決できない・有効なデータ点が無い場合は
        その処理単位の失敗（要件 1.4、1.5、1.8）
    """
    if job.series is not None:
        return job.series
    try:
        return read_delimited(
            Path(job.source),
            job.columns,
            config.inputs.delimiter,
            config.inputs.header,
            method_name=job.method.name,
        )
    except OSError as error:
        # 読めない入力はその対象だけの失敗である（要件 1.8）。捕捉をこの 1 呼び出しに
        # 限るのは、出力の書き込み失敗（要件 10.3）まで飲み込まないためである。
        return _unreadable_failure(job, error)


def _run_stages(job: Job, config: RunConfig, series: DataSeries) -> JobResult:
    """読み込んだ系列から当てはめまでの段階を順に通す（:func:`run_job` の本体）。

    切り出してあるのは、**前処理 CSV の書き出しをどの返り口からも 1 度だけ通す** ため
    である（:func:`run_job`）。返り口は全体で 5 つあり、そのうち本関数が持つのは 3 つ
    （前処理の失敗・当てはめの失敗・成功）で、いずれも前処理に到達している。残る 2 つは
    読み込みの段（:func:`_load_series`）にある。

    このうち成功の返り口だけは本関数の中で書く。当てはめ結果の書き出しより先に置く必要が
    あり、それは本関数の中でしか実現できないためである。残る 4 つは :func:`run_job` が
    まとめて引き受ける。
    """
    logger = logging.getLogger(LOGGER_NAME)
    method_name = job.method.name

    method = _resolve_for_job(job.method, series)
    _log_ignored_weights(logger, series, method, method_name)
    engine = select_engine(method)

    preprocessed = apply_preprocess(
        series,
        config.preprocess,
        _min_points(method, job.method),
        _provisional_fit(engine, method),
        method_name=method_name,
    )
    if isinstance(preprocessed, FitFailure):
        return JobResult(outcome=preprocessed)
    fitted_series, report = preprocessed

    fitted = engine.fit(fitted_series, method)
    if isinstance(fitted, EngineFailure):
        return JobResult(outcome=_failure_from_engine(job, fitted, report))

    success = _success_from_engine(job, fitted_series, report, fitted)
    # 前処理の記録を当てはめ結果より先に書く。図・曲線 CSV の書き込みが送出する
    # OSError（要件 10.3）で、前処理が何をしたかの記録まで一緒に失われないため。
    _apply_preprocess_report(config, job, success)
    _apply_outputs(config, job, success)
    return JobResult(outcome=success, applied_defaults=fitted.applied_defaults)


# --- バッチ制御 --------------------------------------------------------------------


class ProgressObserver(Protocol):
    """進捗の通知先（要件 6.3、設計の Contracts）。

    **総処理単位数と総入力数の双方を受け取る。** 処理単位数は入力数 × 列数 × 手法数で
    あり、利用者が把握するファイル数とは一致しない。片方だけでは「3 ファイルを指定したのに
    6 件と表示される」形になり、進捗が何に対する進捗なのか読み取れない。

    実装は :mod:`curvefit.cli` が提供する（設計の cli ブロック）。本モジュールは通知
    までを責任範囲とし、端末への描画を行わない。ライブラリ利用（要件 9.1）では通知先が
    無いことも普通であるため、:func:`run` の ``observer`` は省略できる。
    """

    def on_start(self, total_jobs: int, total_sources: int) -> None:
        """実行開始時に、総処理単位数と総入力数を受け取る。"""

    def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None:
        """処理単位 1 件の完了ごとに、完了件数・総数・結果を受け取る。

        ``done`` は 1 起点であり、``total`` は :meth:`on_start` の ``total_jobs`` に
        等しい。呼ばれる順序は処理単位の順序（要件 8.2 により決定的）に一致する。
        """

    def on_finish(self, report: BatchReport) -> None:
        """実行終了時に集計結果を受け取る。中断した場合も呼ばれる。"""


@dataclass(frozen=True)
class BatchReport:
    """バッチ 1 回分の集計結果（要件 6.6、設計の Contracts）。

    成功件数と失敗件数を持つのは、結果の並びを数え直さずに要件 6.6 のサマリを得られる
    ようにするためである。両者の和が結果の総数に一致することを不変条件として検証する。
    食い違った記録は、サマリ CSV との突き合わせを黙って壊す。
    """

    outcomes: tuple[FitOutcome, ...]
    """実行した処理単位の結果。並びは処理単位の順序に一致する（要件 8.2）。

    中断した場合はそこまでの分のみを含む（要件 10.3）。ジョブ展開の時点で中断した
    場合は空である（設計の Implementation Notes）。

    **既定では曲線データを保持しない**（要件 10.4、:func:`run` の ``retain_curve``）。
    :attr:`~curvefit.types.FitSuccess.curve` は出力の適用が済み次第 ``None`` になり、
    推定値・適合度・成否だけが残る。全件分を抱えると常駐メモリが件数に正確に比例して
    増える（1 件あたり 4 配列 × 8 バイト × 点数。2 万行なら 625 KiB、要件 10.1 の上限
    規模 500 件 × 5 万行で約 800 MB）。曲線は ``curves/*.csv`` として既にディスクにあり、
    メモリ上の保持は重複である。曲線が要る利用者は CSV を読むか
    :func:`~curvefit.api.fit_series` を使う。
    """

    n_success: int
    n_failure: int
    aborted: bool
    """fail-fast（要件 6.5）または資源枯渇（要件 10.3）で中断したか。"""

    execution: ExecutionRecord
    """実行条件の記録。適用された既定値を反映済みである（要件 5.4）。"""

    def __post_init__(self) -> None:
        object.__setattr__(self, "outcomes", tuple(self.outcomes))
        if self.n_success < 0 or self.n_failure < 0:
            raise ValueError(
                f"件数は負にできない（実際: {self.n_success} と {self.n_failure}）"
            )
        if len(self.outcomes) != self.n_success + self.n_failure:
            raise ValueError(
                "成否の件数が結果の総数と一致しない"
                f"（{len(self.outcomes)} と {self.n_success} + {self.n_failure}）"
            )


def _warn_empty_specs(logger: logging.Logger, paths: Sequence[str]) -> int:
    """0 件に解決された入力指定を警告し、総入力数を返す（要件 6.1、6.3、8.4）。

    ディレクトリ指定の拡張子絞り込み（``.dat`` は対象外）、綴り誤り、一致しない
    ワイルドカードのいずれも 0 件になる。黙って正常終了すると 1 ディレクトリ分の入力が
    無報告で消え、利用者は「処理された」と読んでしまう。**どの指定が 0 件だったかを
    書く。** 指定が複数ある実行では、件数だけでは調べる先が分からない。

    存在しないファイルの直接指定は 0 件にならない。存在確認を行わない方針
    （本モジュールの docstring）により 1 件の処理単位となり、要件 1.8 の個別失敗
    （:attr:`~curvefit.errors.FailureReason.INPUT_UNREADABLE`）として報告されるため
    である。バッチは既定どおり継続する（要件 6.4）。

    返す総入力数は :func:`expand_sources` と同じ重複排除の規則で数える。進捗通知に
    渡す値（要件 6.3）であり、処理単位数と別に数える必要がある。

    :raises OSError: 存在するディレクトリを読み取れない場合。捕捉は :func:`run` が担う
    """
    collected: set[str] = set()
    for text in paths:
        resolved = _expand_one(text)
        if not resolved:
            logger.warning(
                "input_spec=%r status=%s "
                "入力指定が 0 件に解決された。ディレクトリは %s のみを対象とし、"
                "再帰しない。綴りとワイルドカードの一致を確認する",
                text,
                EMPTY_INPUT_STATUS,
                "/".join(sorted(DIRECTORY_SUFFIXES)),
            )
        collected |= resolved
    return len(collected)


def _resource_failure(job: Job, error: BaseException) -> FitFailure:
    """資源・環境の失敗で中断した処理単位を、失敗結果として表す（要件 10.3）。

    **中断した対象を結果にも残す。** 実行ログだけに書くと、呼び出し元は
    :attr:`BatchReport.aborted` からどの対象で止まったのかを知る手段を持たず、サマリ
    CSV にも現れない。出力の書き込みが失敗した場合、当てはめ自体は成功しているが
    出力物は無い。成功として集計すると、サマリ表と出力ディレクトリの内容が食い違う
    （``writers`` の docstring）。

    **これは :func:`run_job` の外側で組み立てる唯一の処理単位の結果である。** 列の
    識別子は他の結果と同じ規則で埋める必要があるため、自前で欄を埋めずに
    :func:`_with_column_identity` を通す。読み込みの成否はここでは分からないため、
    見出し名は載らない。
    """
    return _with_column_identity(
        job,
        FitFailure(
            source_id=job.source,
            method_name=job.method.name,
            reason=FailureReason.RESOURCE_EXHAUSTED,
            message=(
                "資源または環境の制約により処理を継続できない"
                f"（{type(error).__name__}: {error}）。この対象で中断した"
            ),
        ),
        None,
    )


def _log_expansion_failure(
    logger: logging.Logger, paths: Sequence[str], error: OSError
) -> None:
    """ジョブ展開の失敗を実行ログに残す（要件 10.3）。

    この段階では処理単位が 1 件も確定していないため、結果として表せる対象が無い
    （設計の Implementation Notes: 展開時に送出された場合 ``outcomes`` は空）。
    代わりに、走査しようとした入力指定を残す。読み取れないディレクトリは利用者が
    設定で直せるものではなく、権限か環境の問題であるため、指定を書かなければ次の
    行動が決まらない。
    """
    logger.error(
        "input_paths=%r status=%s reason=%s message=%r "
        "入力の走査に失敗したため処理単位を 1 件も実行していない",
        tuple(paths),
        ABORTED_STATUS,
        FailureReason.RESOURCE_EXHAUSTED.value,
        str(error),
    )


def _release_curve(outcome: FitOutcome) -> FitOutcome:
    """出力の適用を終えた結果から曲線データを手放す（要件 10.4）。

    **手放してよいのは出力の適用が済んだ後だけである。** グラフ画像と曲線 CSV は
    :func:`run_job` の中で書き終えており（:func:`_apply_outputs`）、ここに届く結果は
    書き出し済みである。曲線は ``curves/*.csv`` として既にディスクにあり、メモリ上の
    保持は重複である。

    失敗結果は曲線を持たないためそのまま返す。手放す操作そのものは
    :meth:`~curvefit.types.FitSuccess.without_curve` が持つ（推定値・適合度・成否に
    触れないことを型の側で 1 か所に保つため）。
    """
    if isinstance(outcome, FitSuccess):
        return outcome.without_curve()
    return outcome


def _log_fail_fast(logger: logging.Logger, outcome: FitFailure) -> None:
    """fail-fast による中止を実行ログに残す（要件 6.5）。

    失敗そのものは :func:`~curvefit.logging_setup.log_outcome` が既に記録している。
    ここで残すのは「残りを実行しなかった」という事実であり、これが無いと、後からログを
    読んだ利用者は処理単位が少ないことの理由を説明できない。
    """
    logger.error(
        "source_id=%r method=%r status=%s policy=%s "
        "最初の失敗を検出したため残りの処理単位を実行しない",
        outcome.source_id,
        outcome.method_name,
        ABORTED_STATUS,
        FailurePolicy.FAIL_FAST.value,
    )


def _write_batch_outputs(
    logger: logging.Logger,
    config: RunConfig,
    series: DataSeries | None,
    outcomes: Sequence[FitOutcome],
    record: ExecutionRecord,
) -> bool:
    """バッチ終了時の出力物を書き出す。書けなければ中断として報告する。

    サマリ表（要件 7.3）は有効な場合にのみ書き出す。有効/無効の判断は
    :class:`~curvefit.config.OutputSpec` が持ち、``writers`` は判断を持たない
    （``_apply_outputs`` と同じ規則）。実行条件の記録（要件 8.3、5.4）は、適用された
    既定値が確定するのがバッチ終了時であるため、ここでしか書けない。

    **中断した実行でも書き出す。** 要件 10.3 が求めるのは「それまでに完了した対象の
    結果を保持」することであり、結果を返り値の中だけに留めると、利用者が手元で見る
    出力ディレクトリからは中断までの成果が消える。

    **2 つの出力物は独立に試みる。** 片方が書けないことは他方が書けない理由にならず、
    サマリ表だけが書けない実行で要件 8.3 の実行条件の記録まで失うのは、保持できる
    ものを捨てる振る舞いである。どちらかが失敗すれば中断として報告する点は変わらない。

    **出力先を持たない実行では 1 件も書かない**（``series``、要件 9.1）。この抑止は
    処理単位ごとの出力物と同じ :func:`_output_target` が担う。抑止の判断を本関数に
    置くと、書くか否かの根拠がバッチ出力物と処理単位の出力物で分かれる。

    :return: 書き出せなかった場合に ``True``。呼び出し元は中断として扱う
    """
    failed = False
    summary = _output_target(config, series, config.output.write_summary, SUMMARY_FILENAME)
    if summary is not None:
        failed |= _attempt_write(logger, summary, lambda path: write_summary(outcomes, path))
    execution = _output_target(config, series, True, EXECUTION_RECORD_FILENAME)
    if execution is not None:
        failed |= _attempt_write(
            logger, execution, lambda path: write_execution_record(record, path)
        )
    return failed


def _attempt_write(
    logger: logging.Logger, path: Path, write: Callable[[Path], None]
) -> bool:
    """バッチ出力物 1 件の書き出しを試み、失敗を実行ログに残す（要件 10.3）。

    :param path: 書き出し先。抑止の判断は済んでおり（:func:`_output_target`）、本関数は
        書くと決まったものだけを受け取る
    :return: 書き出せなかった場合に ``True``
    """
    try:
        write(path)
    except (MemoryError, OSError) as error:
        logger.error(
            "output_dir=%r status=%s reason=%s message=%r "
            "バッチの出力物を書き出せなかった。結果は返り値にのみ保持される",
            str(path.parent),
            ABORTED_STATUS,
            FailureReason.RESOURCE_EXHAUSTED.value,
            str(error),
        )
        return True
    return False


def _finish(
    logger: logging.Logger,
    config: RunConfig,
    outcomes: Sequence[FitOutcome],
    applied: Sequence[tuple[str, Mapping[str, float | int]]],
    execution: ExecutionRecord,
    *,
    aborted: bool,
    observer: ProgressObserver | None,
    series: DataSeries | None,
) -> BatchReport:
    """出力物を書き出し、集計結果を組み立てて通知する（要件 5.4、6.6、8.4）。

    **適用された既定値は手法ごとに畳み込んでから記録に載せる**（要件 5.4）。同じ手法
    なら既定値は常に同じであり、数百対象の記録に同一の内容が並んでも情報は増えない
    （:func:`~curvefit.execution.collect_applied_defaults`）。
    :class:`~curvefit.execution.ExecutionRecord` は生成後に変更されないため、
    :func:`dataclasses.replace` で新しい記録を作る。渡された記録は書き換えない。

    成功件数は結果の型から数える。処理の途中で数えた値を持ち回ると、中断の経路ごとに
    数え漏らしが生まれる。

    **記録の組み立ては出力の有無によらない。** 出力先を持たない実行（:func:`run` の
    ``series``）でも、返す集計結果には既定値を反映した記録を載せる。要件 5.4 の畳み込みを
    書き出しの条件に結び付けると、呼び出し元が受け取る記録が経路によって別物になる。

    :param series: 直接渡された系列。``None`` でなければ出力先を持たない実行である
        （要件 9.1）。真偽値に翻訳せずそのまま渡すのは、**書くか否かの判断を
        :func:`_output_target` の 1 か所に保つため**である。ここで真偽値に畳むと、
        処理単位ごとの出力物とは別の抑止の軸が生まれる
    """
    record = replace(execution, applied_defaults=collect_applied_defaults(applied))
    unwritable = _write_batch_outputs(logger, config, series, outcomes, record)
    stopped = unwritable or aborted
    n_success = sum(1 for outcome in outcomes if isinstance(outcome, FitSuccess))
    report = BatchReport(
        outcomes=tuple(outcomes),
        n_success=n_success,
        n_failure=len(outcomes) - n_success,
        aborted=stopped,
        execution=record,
    )
    log_summary(logger, n_success=report.n_success, n_failure=report.n_failure)
    if observer is not None:
        observer.on_finish(report)
    return report


@contextmanager
def _run_log(config: RunConfig, series: DataSeries | None) -> Iterator[logging.Logger]:
    """実行ログの記録先を用意する（要件 8.4）。

    ファイル入力の実行では ``{出力先}/run.log`` に構成し、終了時に必ず解放する。

    **メモリ上の系列を受け取った実行では構成しない**（:func:`run` の ``series``）。
    その実行は結果を返り値でのみ渡すため出力先を持たず、記録の置き場が無い。呼び出し
    ごとに一時領域へ書けば、対話環境からの当てはめが痕跡を残し続ける。その判断は出力物
    と共通の :func:`_output_target` が持ち、本関数は書き出し先の有無だけを見る。記録
    そのものは行われる。取り付け先の ``curvefit`` ロガーは常に同じであり、ハンドラを持たない
    実行では呼び出し側のログ構成に委ねられる。
    """
    directory = _output_target(config, series, True)
    if directory is None:
        yield logging.getLogger(LOGGER_NAME)
        return
    with configure_run_log(directory) as handle:
        yield handle.logger


def run(
    config: RunConfig,
    execution: ExecutionRecord,
    observer: ProgressObserver | None = None,
    *,
    series: DataSeries | None = None,
    retain_curve: bool = False,
) -> BatchReport:
    """処理単位を逐次実行し、結果を集約する（要件 6.3〜6.6、8.4、10.1、10.3）。

    段階は **実行ログの構成 → 入力の展開 → 逐次実行 → 出力物の書き出し** の順である。
    実行ログは ``{出力先}/run.log`` に構成し、終了時に必ず解放する。ファイル記述子を
    開いたままにすると、数百件規模の連続実行（要件 10.1）で資源を食い潰す。

    **個別の失敗は既定では処理を止めない**（要件 6.4）。
    :attr:`~curvefit.config.FailurePolicy.FAIL_FAST` が指定された場合のみ最初の失敗で
    中止し、その場合もそれまでの結果を保持する（要件 6.5）。

    **資源・環境の失敗は捕捉する**（要件 10.3）。ジョブ展開時の :class:`OSError`
    （読み取れないディレクトリ）はその時点で中断し、結果は空になる。処理単位の実行中の
    :class:`MemoryError` / :class:`OSError` は、その対象を
    :attr:`~curvefit.errors.FailureReason.RESOURCE_EXHAUSTED` の失敗として記録した
    うえで中断する。いずれの場合もそれまでの結果とサマリ表は保持する。

    **読めない入力ファイルはここに含まない**（設計の pipeline Implementation Notes）。
    :func:`run_job` が要件 1.8 の個別失敗として返すため、既定では残りの処理単位が続く
    （要件 6.4）。中断は「対象を替えても解消しない失敗」に限る。1 件の綴り誤りで
    数百件の実行を捨てると、要件 10.1 の運用が成立しない。

    **端末への描画は行わない**（要件 6.3）。進捗は ``observer`` に通知するのみで、
    描画は ``cli`` が持つ。

    **曲線データは既定で手放す**（要件 10.4、``retain_curve``）。出力の適用を終えた処理
    単位から :attr:`~curvefit.types.FitSuccess.curve` を外してから集計に積む。したがって
    ``observer`` と実行ログが受け取る結果も、集計結果に載るものと同一の（曲線を持たない）
    値である。通知と集計で別の値を渡すと、進捗で見た結果と後から読む結果が食い違う。

    実行条件は読むだけで書き換えない。返り値の :attr:`BatchReport.execution` は、
    適用された既定値を反映した **新しい** 記録である（要件 5.4）。

    **読み込み済みの系列を受け取った実行は、入力の走査を行わず出力先も持たない**
    （``series``、要件 9.1）。処理単位は その系列 1 件 × 手法数であり、列軸は展開
    しない（:func:`_series_jobs`）。以降の制御はファイル入力と同一である。
    実行ログ（要件 8.4）とサマリ表・実行条件の記録
    （要件 7.3、8.3）を書かないのは、結果が返り値でのみ渡る利用であり、書き出す先が
    無いためである。呼び出しごとに一時領域へ書けば痕跡が残り続ける。

    :param config: 実行条件。``preflight.validate`` が ``ok`` を返していること
        （設計の Preconditions）
    :param execution: 実行前に組み立てた実行条件の記録。書き換えない
    :param observer: 進捗の通知先。``None`` なら通知しない
    :param series: 読み込み済みの系列。``None`` なら ``config.inputs.paths`` を走査する。
        指定した場合、``config`` の入力指定（位置・列・区切り・見出し）は読み込みに
        使われない。列指定の先頭要素だけは :attr:`Job.columns` を埋めるために運ぶ
        （:func:`_series_jobs`）。実行条件は列指定を 1 件以上持つ（要件 1.11、
        設計の Preconditions）
    :param retain_curve: 集計結果に曲線データを残すか（要件 10.4）。既定の ``False`` では
        出力の適用が済み次第
        :attr:`~curvefit.types.FitSuccess.curve` を手放し、常駐メモリが処理件数に比例して
        増えないようにする。``True`` にできるのは、結果が 1 件だけで曲線が返り値そのもの
        である利用（:func:`~curvefit.api.fit_series`、要件 9.1）に限る。数百件のバッチで
        ``True`` にすると要件 10.4 が成立しない
    :return: 集計結果
    :raises UnexpectedConfigViolation: 実行前ゲートを通過していない手法指定が届いた
        場合。呼び出し側の誤りであり、データの失敗として集計しない
    """
    with _run_log(config, series) as logger:
        log_run_start(
            logger,
            config_path=execution.config_path,
            resolved_config=execution.resolved_config,
        )

        if series is not None:
            total_sources = 1
            jobs = _series_jobs(series, config.inputs.columns[0], config.methods)
        else:
            try:
                total_sources = _warn_empty_specs(logger, config.inputs.paths)
                jobs = expand_jobs(config)
            except OSError as error:
                _log_expansion_failure(logger, config.inputs.paths, error)
                return _finish(
                    logger,
                    config,
                    (),
                    (),
                    execution,
                    aborted=True,
                    observer=observer,
                    series=series,
                )

        if observer is not None:
            observer.on_start(len(jobs), total_sources)

        outcomes: list[FitOutcome] = []
        applied: list[tuple[str, Mapping[str, float | int]]] = []
        aborted = False
        for job in jobs:
            try:
                result = run_job(job, config)
            except (MemoryError, OSError) as error:
                outcome: FitOutcome = _resource_failure(job, error)
                aborted = True
            else:
                # 出力の適用は run_job の中で終えている。曲線を集計に積む前に手放す
                # （要件 10.4）。積んでから外しても実行中の常駐メモリは減らない。
                outcome = result.outcome if retain_curve else _release_curve(result.outcome)
                applied.append((job.method.name, result.applied_defaults))

            outcomes.append(outcome)
            log_outcome(logger, outcome)
            if observer is not None:
                observer.on_job_done(len(outcomes), len(jobs), outcome)

            if aborted:
                break
            if (
                isinstance(outcome, FitFailure)
                and config.failure_policy is FailurePolicy.FAIL_FAST
            ):
                _log_fail_fast(logger, outcome)
                aborted = True
                break

        return _finish(
            logger,
            config,
            outcomes,
            applied,
            execution,
            aborted=aborted,
            observer=observer,
            series=series,
        )
