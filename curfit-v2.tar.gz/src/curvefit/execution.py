"""実行条件の記録（要件 5.4、8.3、9.4）。

本モジュールが所有するのは次の 3 点である。

1. **記録の構造** — :class:`ExecutionRecord` が、実行開始時刻・ツールと基盤ライブラリの
   版・解決済みの実行条件・上書き項目・適用された既定値を 1 つの値にまとめる。入力の
   識別情報（入力パス・列指定・見出し行の扱い）は ``resolved_config`` が運ぶ。
   **列の指定は記述された並びのまま残す**（要件 8.3、設計の execution / logging_setup）。
   処理単位は入力パスと列指定の組から展開されるため、並びが崩れた記録からは同じ対象集合を
   作り直せない。写像と並びの反復順を保つ :func:`_jsonable` がこれを担保する
2. **上書きの表現** — :class:`OverrideRecord` が、CLI 引数が設定ファイルに優先した項目を
   **上書き前後の値ごと** 残す（要件 9.4）。どの項目が上書きされたかだけでは元の設定に
   戻せず、要件 9.4 が求める再現の手段にならない
3. **書き出し形式** — :func:`write_execution_record` が ``execution.json`` を書き出す

**設定は TOML で読むが記録は JSON で出す**（設計の Implementation Notes）。機械可読性と、
実行時に解決された値（既定値の適用結果を含む）を素直に表現できることが理由である。

**実行日時だけが実行ごとに変わってよい。** 要件 8.2 の再現性は「同一環境・同一設定なら
同一の出力物」であり、記録に非決定性が混じると差分の原因を切り分けられなくなる。時計は
:func:`build_execution_record` の引数として注入する。深い場所で :func:`datetime.now` を
呼ぶと、試験から固定できない。集合のような反復順の定まらない値は並びを固定して書き出す。

**版の記録は環境差を後から判別する手段である**（設計の Validation）。要件が直接求める
ものではないが、要件 8.2 の「同一結果」は同一環境を前提としており、環境が違ったことを
後から言えなければ再現の失敗を診断できない。

本モジュールは入出力のうち記録の書き出しだけを持ち、ログ出力は持たない（``logging_setup``
の責務）。自パッケージからは :mod:`curvefit.types` と :mod:`curvefit.errors` 以外を
import しない（設計の Allowed Dependencies）。実際には現時点でどちらも必要としない。

**記録に含めるのは実行条件だけである。** ``resolved_config`` に入力ファイルの絶対パスが
含まれる点は設計の Risks が運用上の注意事項として受け入れている。環境変数・利用者名・
ホスト名のように利用者が指定していない情報は、これ以上増やさない。
"""

from __future__ import annotations

import json
import math
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field, fields, is_dataclass
from datetime import UTC, datetime
from enum import Enum
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _installed_version
from pathlib import Path, PurePath
from types import MappingProxyType

TOOL_PACKAGE = "curvefit"
"""ツール自身の配布名。版はここから引く。"""

RECORDED_LIBRARIES: tuple[str, ...] = (
    "lmfit",
    "asteval",
    "scipy",
    "numpy",
    "pandas",
    "matplotlib",
)
"""版を記録する基盤ライブラリ（設計の Allowed Dependencies に挙がるもの全件）。

設計の型注釈は例として lmfit / scipy / numpy / matplotlib を挙げるが、asteval は数式
モデルの評価を、pandas は入力の読み取りを担っており、いずれも版が変われば結果が変わりうる。
記録の目的が「環境差を後から判別すること」である以上、結果に効く依存を落とす理由がない。

並びは記録の並びでもある。集合ではなくタプルで持つのは、反復順を固定するためである。
"""

UNKNOWN_VERSION = "unknown"
"""版を特定できなかった場合の記録値。項目自体は落とさない。

欠落させると「その環境に無かった」のか「記録し忘れた」のかを後から区別できない。
"""

EXECUTION_RECORD_FILENAME = "execution.json"
"""実行条件の記録のファイル名（設計の Batch / Job Contract）。"""

HEADER_KEY = "header"
"""見出し行の扱いを表す実行条件のキー（タスク 5.5、要件 1.6、1.7）。

3 状態（未指定 / あり / なし）を取り、``resolved_config`` にそのまま載る。``None``
（未指定）が ``false``（見出しなし）と同じに潰れると、読み方の記録として役に立たない。
:func:`_jsonable` が ``None`` を落とさないのはこのためである。
"""

JSON_INDENT = 2
"""書き出しの字下げ。差分を人が読めることを優先する。機械可読性はどちらでも変わらない。"""


def _package_version(name: str) -> str:
    """導入済みパッケージの版を返す。特定できなければ :data:`UNKNOWN_VERSION`。"""
    try:
        return _installed_version(name)
    except PackageNotFoundError:
        return UNKNOWN_VERSION


def utc_now() -> datetime:
    """既定の時計。UTC の現在時刻を返す。

    実行日時の取得はこの 1 か所に閉じる。記録の組み立ての奥で現在時刻を読むと、
    試験から固定できず、再現性の検証（要件 8.2）が成立しない。
    """
    return datetime.now(UTC)


def format_timestamp(moment: datetime) -> str:
    """日時を UTC の ISO 8601 表記にする（要件 8.3）。

    時刻帯を持たない日時は誤りとして拒否する。UTC と見なして受け入れると、地方時が
    UTC として静かに記録され、複数拠点の記録を突き合わせたときに実行順序が入れ替わる。
    どの時刻帯だったかは呼び出し側にしか分からない。

    :raises ValueError: ``moment`` が時刻帯を持たない場合
    """
    if moment.tzinfo is None or moment.tzinfo.utcoffset(moment) is None:
        raise ValueError(f"実行日時は時刻帯を持たなければならない（実際: {moment!r}）")
    return moment.astimezone(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")


_version_cache: dict[tuple[str, ...], Mapping[str, str]] = {}
"""集めた版を並びごとに記憶する（要件 9.1）。

導入済みパッケージの版は工程の実行中に変わらない。にもかかわらず毎回引くと、配布
メタデータの走査が単一系列の当てはめの 78%（実測 26.6 ミリ秒中 20.7 ミリ秒）を占める。
対話環境から系列ごとに呼ぶ使い方（要件 9.1）では、この費用が当てはめ本体を覆い隠す。

並びを鍵にするのは、試験が別の並びを渡したときに前の結果を返さないためである。
"""


def collect_library_versions(
    packages: Sequence[str] = RECORDED_LIBRARIES,
) -> Mapping[str, str]:
    """基盤ライブラリの版を集める（設計の Validation）。

    与えられた並びの順に記録する。導入されていないものは :data:`UNKNOWN_VERSION` とし、
    項目自体は残す。

    **工程内で一度だけ引く。** 結果は :data:`_version_cache` に記憶する。同じ並びに対して
    同じ値を返すため、記録される内容は変わらない（要件 8.3）。試験は
    :func:`_package_version` を差し替えたうえで :data:`_version_cache` を空にすれば、
    記憶を挟まない状態を作れる。

    :param packages: 版を引く配布名の並び
    :return: 配布名 → 版。書き換え不能
    """
    key = tuple(packages)
    cached = _version_cache.get(key)
    if cached is None:
        cached = MappingProxyType({name: _package_version(name) for name in key})
        _version_cache[key] = cached
    return cached


def _frozen_mapping(mapping: Mapping[str, object] | None) -> Mapping[str, object]:
    """呼び出し側の辞書から切り離した、書き換え不能な写像を返す。

    浅い複製である。入れ子の値までは凍らせない。記録の書き出しは
    :func:`record_to_mapping` が改めて変換するため、後からの書き換えが書き出し内容に
    影響するのは入れ子の値に限られる。最上位を切り離すのは、実行条件そのものを
    差し替えられると記録が実行と食い違うためである。
    """
    return MappingProxyType(dict(mapping or {}))


@dataclass(frozen=True)
class OverrideRecord:
    """CLI 引数が設定ファイルに優先した項目 1 件（要件 9.4）。

    上書き **前後の双方** を持つ。事実だけを残しても、元の設定に戻すには設定ファイルを
    別途参照するほかなく、記録が再現の手段にならない。

    ``config_value`` が ``None`` であることの意味は ``config``（タスク 6.1）が決める。
    設定ファイルに該当キーが無い場合を表すのか、空値が書かれていたのかは上書きを検出した
    側にしか分からない。本モジュールは与えられた値をそのまま記録する。
    """

    key: str
    """上書きされた項目名。設定ファイル内の位置を指す表記（``output.directory`` など）。"""

    config_value: object | None
    """上書き前の値。"""

    cli_value: object
    """実際に適用された値。"""

    def __post_init__(self) -> None:
        if not self.key:
            raise ValueError("上書き記録は項目名を持たなければならない")


@dataclass(frozen=True)
class ExecutionRecord:
    """1 回の実行の条件と環境の記録（要件 5.4、8.3、9.4）。

    フィールドの並びは書き出される JSON の並びでもある。
    """

    started_at: str
    """実行開始時刻。UTC の ISO 8601（要件 8.3）。実行ごとに正当に変わる唯一の値。"""

    tool_version: str
    library_versions: Mapping[str, str]
    """基盤ライブラリの版。環境差を後から判別する手段（設計の Validation）。"""

    config_path: str | None = None
    """設定ファイルの位置。ライブラリ呼び出し（要件 9.1）では ``None``。"""

    resolved_config: Mapping[str, object] = field(default_factory=dict)
    """解決済みの実行条件（要件 8.3）。入力の識別情報と見出し行の扱いを含む。

    列の指定は **記述された並びのまま** 載る。再実行が同じ対象集合を再構成できることが
    記録の目的であり、並びが崩れると処理単位の展開が一致しない。
    """

    cli_overrides: tuple[OverrideRecord, ...] = ()
    """CLI 引数が優先した項目（要件 9.4）。与えられた順序を保つ。"""

    applied_defaults: Mapping[str, object] = field(default_factory=dict)
    """適用された手法固有オプションの既定値（要件 5.4）。利用者の明示値は含まない。"""

    def __post_init__(self) -> None:
        started = self.started_at
        try:
            parsed = datetime.fromisoformat(started)
        except ValueError as error:
            raise ValueError(f"実行開始時刻が ISO 8601 ではない（実際: {started!r}）") from error
        if parsed.utcoffset() is None:
            raise ValueError(f"実行開始時刻は時刻帯を持たなければならない（実際: {started!r}）")
        object.__setattr__(self, "library_versions", MappingProxyType(dict(self.library_versions)))
        object.__setattr__(self, "resolved_config", _frozen_mapping(self.resolved_config))
        object.__setattr__(self, "applied_defaults", _frozen_mapping(self.applied_defaults))
        object.__setattr__(self, "cli_overrides", tuple(self.cli_overrides))


def build_execution_record(
    *,
    resolved_config: Mapping[str, object],
    config_path: str | None = None,
    cli_overrides: Sequence[OverrideRecord] = (),
    applied_defaults: Mapping[str, object] | None = None,
    clock: Callable[[], datetime] = utc_now,
    tool_version: str | None = None,
    library_versions: Mapping[str, str] | None = None,
) -> ExecutionRecord:
    """実行条件の記録を組み立てる（要件 8.3）。

    ``clock`` は試験から固定するために注入できる。既定は :func:`utc_now`。版の取得も
    差し替えられるが、既定は実行環境の実測値である。

    :param resolved_config: 解決済みの実行条件。入力の識別情報を含む
    :param config_path: 設定ファイルの位置。ライブラリ呼び出しでは ``None``
    :param cli_overrides: CLI 引数が優先した項目（要件 9.4）
    :param applied_defaults: 適用された既定値（要件 5.4）
    :param clock: 実行開始時刻を返す時計
    :param tool_version: ツール自身の版。既定は導入済みの版
    :param library_versions: 基盤ライブラリの版。既定は実行環境の実測値
    :return: 組み立てた記録
    """
    return ExecutionRecord(
        started_at=format_timestamp(clock()),
        tool_version=tool_version if tool_version is not None else _package_version(TOOL_PACKAGE),
        library_versions=(
            library_versions if library_versions is not None else collect_library_versions()
        ),
        config_path=config_path,
        resolved_config=resolved_config,
        cli_overrides=tuple(cli_overrides),
        applied_defaults=applied_defaults or {},
    )


def collect_applied_defaults(
    entries: Iterable[tuple[str, Mapping[str, float | int]]],
) -> dict[str, dict[str, float | int]]:
    """手法ごとに、適用された既定値を畳み込む（要件 5.4）。

    エンジンは処理単位ごとに ``applied_defaults`` を返す（``EngineSuccess``）。既定値は
    手法が単独で所有する定数であり、同じ手法なら常に同じ値になる。数百対象を処理した
    記録に同一の内容が数百回並んでも情報は増えないため、手法名で畳み込む。

    並びは最初に現れた順を保つ。既定値を 1 つも適用しなかった手法は記録に現れない。
    記録に載せるのは「利用者が書いていないのに効いた値」だけである。

    :param entries: ``(手法名, 適用された既定値)`` の並び
    :return: 手法名 → オプション名 → 値
    """
    collected: dict[str, dict[str, float | int]] = {}
    for method_name, defaults in entries:
        if not defaults:
            continue
        collected.setdefault(method_name, {}).update(defaults)
    return collected


def _jsonable(value: object) -> object:
    """任意の実行条件の値を JSON で表せる形に落とす。

    ``resolved_config`` は TOML と CLI に由来する任意の値を運ぶ。設定の表現（`Path`、
    列挙、凍結データクラス、タプル）をそのまま渡せることが、記録の呼び出し側に
    「記録用の辞書を別途組み立てる」手間を課さない条件である。

    落とせない値も **文字列として残す**。項目ごと落とすと「指定しなかった」と読め、
    実行条件の記録としては誤りに近い。

    非有限な浮動小数点は文字列にする。``NaN`` / ``Infinity`` は JSON の数値ではなく、
    素通しすると標準の JSON パーサで読めない記録ができる。

    集合は並べ替えてから書き出す。集合の反復順は要素の生成順に左右され、固定しないと
    同一設定の再実行で記録が揺れる（要件 8.2）。

    所属と名前（``__module__`` / ``__qualname__``）を持つ値は、その名前で書く。要件 3.3
    の利用者定義モデルは関数そのものを実行条件に載せるため、この分岐に落ちる。既定の
    :func:`str` は ``<function model at 0x1064be7a0>`` を返し、**番地は実行のたびに
    変わる**。当てはめ結果が同一でも実行条件の記録だけが毎回異なり、要件 8.2 の
    「同一設定・同一入力なら同一の出力」が関数経路でだけ成り立たなくなる。所属つきの
    名前であれば、どの関数だったかを後から言えるという記録の目的も保たれる。
    """
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if isinstance(value, Enum):
        return _jsonable(value.value)
    if isinstance(value, PurePath):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if is_dataclass(value) and not isinstance(value, type):
        return {f.name: _jsonable(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, (set, frozenset)):
        return sorted((_jsonable(item) for item in value), key=repr)
    if isinstance(value, (bytes, bytearray)):
        return str(value)
    if isinstance(value, Sequence):
        return [_jsonable(item) for item in value]
    return _stable_text(value)


def _stable_text(value: object) -> str:
    """JSON に落とせない値を、実行をまたいで変わらない文字列にする（要件 8.2）。

    所属と名前を持つ値（関数、クラス、メソッド）はその名前で表す。持たない値は
    :func:`str` に委ねる。設定の経路に現れるのは要件 3.3 の関数だけであり、それ以外に
    まで型名で代用すると、記録から元の値が読めなくなる方の害が上回る。
    """
    module = getattr(value, "__module__", None)
    qualname = getattr(value, "__qualname__", None)
    if isinstance(module, str) and isinstance(qualname, str):
        return f"{module}.{qualname}"
    return str(value)


def record_to_mapping(record: ExecutionRecord) -> dict[str, object]:
    """記録を JSON で表せる写像にする。キーの並びは定義順に固定する。

    上書き記録は ``key`` / ``config_value`` / ``cli_value`` の 3 項目を持つ写像の並びと
    する。前後の値が同じ 1 件の中に並ぶことが、要件 9.4 の記録として意味を持つ形である。
    """
    return {
        "started_at": record.started_at,
        "tool_version": record.tool_version,
        "library_versions": dict(record.library_versions),
        "config_path": record.config_path,
        "resolved_config": _jsonable(record.resolved_config),
        "cli_overrides": [
            {
                "key": override.key,
                "config_value": _jsonable(override.config_value),
                "cli_value": _jsonable(override.cli_value),
            }
            for override in record.cli_overrides
        ],
        "applied_defaults": _jsonable(record.applied_defaults),
    }


def dumps_execution_record(record: ExecutionRecord) -> str:
    """記録を JSON 文字列にする。末尾に改行を 1 つ付ける。

    ``ensure_ascii=False`` とするのは、日本語の識別子やラベルを読める形で残すためである。
    キーの並べ替えは行わない。写像の並びは呼び出し側が与えた順序であり、実行条件の
    記述順を保つ方が設定ファイルと突き合わせやすい。並びの決定性は
    :func:`_jsonable`（集合の並べ替え）と写像の挿入順で担保される。
    """
    return json.dumps(record_to_mapping(record), ensure_ascii=False, indent=JSON_INDENT) + "\n"


def write_execution_record(record: ExecutionRecord, path: Path) -> None:
    r"""実行条件の記録を ``execution.json`` として書き出す（要件 8.3）。

    行区切りは環境によらず ``\n`` に固定する。既定の ``\r\n`` では、同一設定・同一
    入力の再実行が環境をまたぐと逐字一致しなくなる（要件 8.2、``writers`` と同じ規則）。

    親ディレクトリは必要に応じて作る。

    :param record: 書き出す記録
    :param path: 出力先。通常は ``{output_dir}/execution.json``
    :raises OSError: 書き込みに失敗した場合。資源・環境の失敗は要件 10.3 の系統であり、
        値として飲み込まない
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(dumps_execution_record(record))
