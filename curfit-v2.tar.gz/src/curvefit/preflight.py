"""実行前の一括検証ゲート（要件 3.4、4.3、4.6、5.4、5.5、7.7、8.5、2.1）。

**「処理を開始せず報告する」種類の検査は、すべて本モジュールに集約する。** この集約が
設計の中心的な判断であり、要件 6.4 の「個別の失敗はスキップして継続する」との境界を
一意にする。境界が 2 か所に分かれると、ある不備がバッチを止めるのか 1 件を飛ばすだけ
なのかが、呼び出し側からは追えなくなる。

検査項目は次の 8 つである。

1. **モデル解決の可否**（要件 3.4）
2. **組込以外のモデルにおける初期値の必須性**（要件 4.3）
3. **初期値と上下限の整合**（要件 4.6）
4. **平滑化オプションの制約**（要件 5.4）、および **平滑化スプラインの平滑化パラメータの
   必須性**（要件 5.5）
5. **平滑化手法に書かれたパラメータ指定の拒否**（要件 4.4、4.5、8.5）
6. **重みを扱えない手法への誤差列指定の拒否**（要件 1.10）
7. **出力先の書き込み可否**（要件 7.7）
8. **設定構造の妥当性**（要件 8.5、および要件 2.1 のフィット区間）

1〜3 は :func:`~curvefit.models.resolver.resolve` が、7 は
:func:`~curvefit.writers.check_output_writable` が既に判定できる。本モジュールは
**それらを呼び出して結果を並べるだけであり、同じ判定を書き直さない**。検査が 2 か所に
分かれると、片方だけが更新されたときに検証を通った設定が実行時に別の規則で動く。

**最初の違反で打ち切らない。** 全項目を検査してから違反を一括で返す（設計の
Error Handling）。設定の誤りは全件に等しく影響するため、1 件ずつ直しては再実行する
往復を利用者に強いる理由がない。

**利用者が書いた内容に対して例外を送出しない。** 違反はすべて値として返る。

モデル解決とデータ
------------------

モデル解決は ``sample=None`` で試み、**データに依存しない違反だけ** を検出する（設計の
Implementation Notes）。組込モデルの初期値自動推定はジョブごとにそのジョブのデータで
行われるため、ここで推定の可否を判定しても意味がない。

**入力パスの存在確認は行わない。** ディレクトリ指定でファイルが 0 件の場合は処理対象
0 件として正常終了し、存在しないファイルの直接指定は要件 1.4/1.5 の経路で個別の失敗
として扱う。ここで存在確認を行うと、まだ書き出されていない測定データを待つ運用が
バッチごと止まる。

既定値の出所
------------

平滑化オプションの制約検証は :mod:`curvefit.engines.smoothing` が所有する定数のみを
出所とする。**本モジュールは独自の既定値を持たない。** 既定値の定義が検証側とエンジン
側の 2 か所に分かれると、検証を通った設定が実行時に別の値で動く。窓長を省いた設定に
対して次数の上限を判定できるのも、エンジンが実際に適用する既定の窓長をここで参照して
いるからである。

**手法の性質についても同じ扱いをする。** どの手法が点ごとの重みを扱えるかは
:data:`~curvefit.engines.smoothing.SMOOTHER_USES_WEIGHTS` が単独で所有し、本モジュール
は対象を独自に列挙しない（要件 1.10）。以前 ``pipeline`` が同内容の集合を別に持って
おり、スプラインが重みを扱うようになった際に両方の更新が要った。

違反の並び
----------

要件 8.2 の再現性は違反の並びにも及ぶ。走査順を次のように固定する。

- 手法は :attr:`~curvefit.config.RunConfig.methods` の記述順
- 1 つの手法の中では、モデル解決の違反 → パラメータ指定の違反 → 平滑化オプションの違反
  → 重みを扱えないことの違反
- パラメータ指定の違反は ``initial`` → ``bounds`` → ``fixed`` の順
- 未知の選択肢名とパラメータ名は名前順
- 手法をすべて見たあと、出力先、前処理の順

依存方向は ``preflight`` までであり、``pipeline`` 以降を import しない（設計の
Allowed Dependencies）。
"""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from curvefit.config import RunConfig
from curvefit.engines.smoothing import (
    MOVING_AVERAGE_POLYORDER_OPTION,
    MOVING_AVERAGE_WINDOW_OPTION,
    NO_WEIGHT_SUPPORT_REASONS,
    POLYNOMIAL_DEGREE_OPTION,
    SMOOTHER_EMITS_PARAMETERS,
    SMOOTHER_OPTION_DEFAULTS,
    SMOOTHER_OPTION_NAMES,
    SMOOTHER_USES_WEIGHTS,
    SPLINE_LAMBDA_OPTION,
)
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.resolver import (
    PARAMETER_FIELDS,
    MethodSpec,
    PreparedSmoother,
    SmootherKind,
    resolve,
)
from curvefit.preprocess import PreprocessSpec
from curvefit.readers import ColumnSpec
from curvefit.writers import check_output_writable


@dataclass(frozen=True)
class PreflightResult:
    """実行前検証の結果。

    ``ok`` が ``True`` の場合、以降の失敗はデータ個別の事由に限られる（設計の
    Postconditions）。生成後に変更されない。
    """

    violations: tuple[ConfigViolation, ...]
    """検出したすべての違反。並びは実行のたびに変わらない（要件 8.2）。"""

    @property
    def ok(self) -> bool:
        """違反が 1 件も無いか。"""
        return not self.violations


def _method_location(spec: MethodSpec, field_name: str) -> str:
    """違反の報告箇所を、手法の識別名から決定的に導出する。

    解決層と同じ表記を用いる。同じ手法についての違反が、出所によって別の書式で
    報告されると、利用者は 1 か所を直すのに 2 通りの読み方を強いられる。
    """
    return f"method[{spec.name}].{field_name}"


def _option_violation(spec: MethodSpec, message: str) -> ConfigViolation:
    """平滑化オプションの制約違反を 1 件作る（要件 5.4、5.5）。"""
    return ConfigViolation(
        kind=ViolationKind.SMOOTHER_OPTION_INVALID,
        location=_method_location(spec, "options"),
        message=message,
    )


def _config_violation(location: str, message: str) -> ConfigViolation:
    """設定構造の違反を 1 件作る（要件 8.5）。"""
    return ConfigViolation(
        kind=ViolationKind.CONFIG_INVALID, location=location, message=message
    )


def _is_integer(value: object) -> bool:
    """整数として扱える値か。真偽値は整数の仲間だが、値域の指定としては受け取らない。"""
    return isinstance(value, int) and not isinstance(value, bool)


def _is_number(value: object) -> bool:
    """有限の実数として扱える値か。"""
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


# --- 平滑化オプションの制約（要件 5.4）--------------------------------------------


def _unknown_option_violations(
    spec: MethodSpec, kind: SmootherKind
) -> tuple[tuple[ConfigViolation, ...], dict[str, float | int]]:
    """指定できない選択肢名を違反として集め、指定できた分だけを返す。

    綴り誤りを黙って捨てると、指定したはずの窓長が効かないまま結果だけが出る。要件 8 の
    再現性の意図に反する。並びを固定するため名前順に走査する。

    :return: 違反の並びと、名前の正しい選択肢だけを残した写像
    """
    allowed = SMOOTHER_OPTION_NAMES[kind]
    violations: list[ConfigViolation] = []
    known: dict[str, float | int] = {}
    for name in sorted(spec.options):
        if name in allowed:
            known[name] = spec.options[name]
            continue
        accepted = ", ".join(allowed) or "（なし）"
        violations.append(
            _option_violation(
                spec,
                f"手法 {kind.value!r} は選択肢 {name!r} を持たない。"
                f"指定できる選択肢: {accepted}",
            )
        )
    return tuple(violations), known


def _polynomial_violations(
    spec: MethodSpec, effective: Mapping[str, float | int]
) -> tuple[ConfigViolation, ...]:
    """多項式回帰の次数を検証する。"""
    degree = effective.get(POLYNOMIAL_DEGREE_OPTION)
    if degree is None:
        return ()
    if not _is_integer(degree):
        return (
            _option_violation(
                spec,
                f"選択肢 {POLYNOMIAL_DEGREE_OPTION!r} は整数で指定する（実際: {degree!r}）。",
            ),
        )
    if degree < 0:
        return (
            _option_violation(
                spec,
                f"選択肢 {POLYNOMIAL_DEGREE_OPTION!r} は 0 以上で指定する（実際: {degree}）。",
            ),
        )
    return ()


def _moving_average_violations(
    spec: MethodSpec, effective: Mapping[str, float | int]
) -> tuple[ConfigViolation, ...]:
    """移動平均の窓長と多項式次数を検証する。

    窓長を先に見る。窓長が定まらなければ「次数が窓長より小さいか」も定まらないため、
    その比較だけを見送る。次数そのものの検査は続ける（全項目を検査してから返す）。

    窓長には既定値があるため、利用者が次数だけを指定した場合も実際に適用される窓長と
    比較できる。
    """
    violations: list[ConfigViolation] = []
    window = effective.get(MOVING_AVERAGE_WINDOW_OPTION)
    window_valid = False
    if window is not None:
        if not _is_integer(window):
            violations.append(
                _option_violation(
                    spec,
                    f"選択肢 {MOVING_AVERAGE_WINDOW_OPTION!r} は整数で指定する"
                    f"（実際: {window!r}）。",
                )
            )
        elif window <= 0:
            violations.append(
                _option_violation(
                    spec,
                    f"選択肢 {MOVING_AVERAGE_WINDOW_OPTION!r} は正の値で指定する"
                    f"（実際: {window}）。",
                )
            )
        elif window % 2 == 0:
            violations.append(
                _option_violation(
                    spec,
                    f"選択肢 {MOVING_AVERAGE_WINDOW_OPTION!r} は奇数で指定する"
                    f"（実際: {window}）。偶数では窓の中心が定まらない。",
                )
            )
        else:
            window_valid = True

    polyorder = effective.get(MOVING_AVERAGE_POLYORDER_OPTION)
    if polyorder is None:
        return tuple(violations)
    if not _is_integer(polyorder):
        violations.append(
            _option_violation(
                spec,
                f"選択肢 {MOVING_AVERAGE_POLYORDER_OPTION!r} は整数で指定する"
                f"（実際: {polyorder!r}）。",
            )
        )
    elif polyorder < 0:
        violations.append(
            _option_violation(
                spec,
                f"選択肢 {MOVING_AVERAGE_POLYORDER_OPTION!r} は 0 以上で指定する"
                f"（実際: {polyorder}）。",
            )
        )
    elif window is not None and window_valid and polyorder >= window:
        violations.append(
            _option_violation(
                spec,
                f"選択肢 {MOVING_AVERAGE_POLYORDER_OPTION!r} は "
                f"{MOVING_AVERAGE_WINDOW_OPTION!r} より小さく指定する"
                f"（実際: {polyorder} >= {window}）。",
            )
        )
    return tuple(violations)


def _spline_violations(
    spec: MethodSpec, effective: Mapping[str, float | int]
) -> tuple[ConfigViolation, ...]:
    """平滑化スプラインの平滑化パラメータを検証する（要件 5.5）。

    **未指定を拒否する。** 既定値を置かないのは、この選択肢に「適用したことにできる
    値」が無いからである（:data:`~curvefit.engines.smoothing.SPLINE_LAMBDA_OPTION`）。
    未指定を基盤ライブラリの自動選択（GCV 探索）に委ねる道は要件 5.5 で塞いだ。自動選択
    は同一の設定と同一の入力でも当てはめ値が呼び出しごとに揺れ、要件 8.2 が成立しない。
    サマリ CSV の丸めはこれを解決しない。丸めの境界付近の値は、揺れが最終桁の刻みより
    小さくても表記が変わる（設計の Validation）。本検証がこの経路の唯一の入口であり、
    ここを通れば当てはめ層に平滑化パラメータのない指定は届かない。

    報告は「不正」で終えない。何を書けばよいのかと、なぜ省略できないのかを伝える。
    利用者から見れば、これまで書かずに動いていた指定が拒否されるようになった変更で
    あり、理由の分からない拒否は設定の書き直しではなく手法の乗り換えを招く。
    """
    lam = effective.get(SPLINE_LAMBDA_OPTION)
    if lam is None:
        return (
            _option_violation(
                spec,
                f"手法 {SmootherKind.SPLINE.value!r} は選択肢 "
                f"{SPLINE_LAMBDA_OPTION!r}（平滑化の強さ）の指定を必須とする。"
                "省略すると平滑化の強さが実行のたびに選び直され、同一の設定と同一の"
                "入力でも当てはめ値が変わる（再現性が損なわれる）。"
                f"正の数値を指定する（例: {SPLINE_LAMBDA_OPTION} = 0.01。"
                "大きいほど滑らかになる）。",
            ),
        )
    if not _is_number(lam) or lam <= 0:
        return (
            _option_violation(
                spec,
                f"選択肢 {SPLINE_LAMBDA_OPTION!r} は正の有限な数値で指定する"
                f"（実際: {lam!r}）。",
            ),
        )
    return ()


def _smoother_option_violations(
    spec: MethodSpec, kind: SmootherKind
) -> tuple[ConfigViolation, ...]:
    """手法固有の選択肢の制約を検証する（要件 5.4、5.5）。

    既定値は当てはめエンジンが所有する定数をそのまま用いる。**実行時に適用される値**
    を検証するため、利用者の指定に既定値を重ねた写像に対して判定する。
    """
    violations, known = _unknown_option_violations(spec, kind)
    effective: dict[str, float | int] = {**SMOOTHER_OPTION_DEFAULTS[kind], **known}
    if kind is SmootherKind.POLYNOMIAL:
        return violations + _polynomial_violations(spec, effective)
    if kind is SmootherKind.MOVING_AVERAGE:
        return violations + _moving_average_violations(spec, effective)
    if kind is SmootherKind.SPLINE:
        return violations + _spline_violations(spec, effective)
    return violations


# --- 平滑化手法へのパラメータ指定（要件 4.4、4.5、8.5）-----------------------------



_PARAMETER_FIELD_LABELS: Mapping[str, str] = {
    "initial": "初期値",
    "bounds": "上下限",
    "fixed": "固定値",
}
"""報告に添える場の意味。設定ファイルのキー名は要件の語をそのまま使う。"""


def _why_not_applicable(kind: SmootherKind, label: str) -> str:
    """指定が効かない理由を、手法が返すものに合わせて述べる（要件 5.3）。

    ``linear`` と ``polynomial`` は名前付きパラメータを**返す**ため、利用者は
    サマリ表でその名前を目にする。「持たない」と説明すると出力と食い違う。
    ``spline`` と ``moving_average`` はパラメータを 1 つも返さないため、
    「結果として得られる」と説明すると存在しない出力を探させることになる。
    """
    if SMOOTHER_EMITS_PARAMETERS[kind]:
        return f"パラメータは推定の結果として得られるものであり、{label}を与える対象ではない"
    return "この手法は名前付きパラメータを持たず、当てはめ後の系列のみを返す"


def _parameter_violation(
    spec: MethodSpec, field_name: str, kind: SmootherKind
) -> ConfigViolation:
    """平滑化手法に書かれたパラメータ指定 1 件分の違反を作る（要件 4.4、4.5、8.5）。

    報告に載せる名前は、写像の走査順に左右されないよう名前順に並べる（要件 8.2）。

    **「パラメータを持たない」とは言わない。** 平滑化手法も推定結果として名前付きの
    パラメータを返す（要件 5.3。``linear`` なら ``slope`` / ``intercept``、
    ``polynomial`` なら ``c0`` 以降）。利用者はそれをサマリ表で見た直後にこの違反を
    受け取りうる。持たないと言えば、目の前の出力と食い違う説明になる。
    実際の理由は解き方の側にある。平滑化は閉形式で解くため、パラメータは
    **結果として出てくるもの**であって、探索の出発点や範囲として与えられるものではない。
    """
    specified: Mapping[str, object] = getattr(spec, field_name)
    names = ", ".join(repr(name) for name in sorted(specified))
    label = _PARAMETER_FIELD_LABELS[field_name]
    return ConfigViolation(
        kind=ViolationKind.CONFIG_INVALID,
        location=_method_location(spec, field_name),
        message=(
            f"平滑化手法 {kind.value!r} は閉形式で解くため、"
            f"{field_name} に書かれた {names} の{label}を当てはめに反映できない"
            f"（{_why_not_applicable(kind, label)}）。該当の指定を削除する。"
            f"{label}を指定したい場合は、モデル関数フィット（builtin / expression）で"
            "当てはめる形に変える。"
        ),
    )


def _smoother_parameter_violations(
    spec: MethodSpec, kind: SmootherKind
) -> tuple[ConfigViolation, ...]:
    """平滑化手法に書かれた ``initial`` / ``bounds`` / ``fixed`` を違反として集める。

    **黙って捨てない。** 平滑化は閉形式で解くため、これらの指定に効く先が無い
    （パラメータは推定の結果として得られる。要件 5.3）。捨てると、上下限を書いた
    設定が範囲外の推定値を返したまま正常終了し、
    しかもその上下限が実行条件の記録に「適用した条件」として残る（要件 8.5）。同じ指定を
    組込モデルに書けば実行前に拒否されるため、同一の意図が手法の書き方だけで正反対の
    結果になる。

    タスク 6.3 が数式モデルに添えた選択肢を拒否したのと同じ扱いである（要件 8.5）
    （``models.resolver._unaccepted_option_violations``）。指定が空であることは既定で
    あり、「何も指定していない」を意味するため違反ではない。

    本検査を解決層ではなく実行前ゲートに置くのは、平滑化手法についての制約の検証が
    既にここに集まっているためである（:func:`~curvefit.models.resolver._resolve_smoother`
    は選択肢の検証も行わない）。解決層に置くと、パラメータ指定の違反を返した時点で
    選択肢の検査に進めず、「全項目を検査してから返す」という本モジュールの契約が
    手法 1 件の内側で崩れる。
    """
    return tuple(
        _parameter_violation(spec, field_name, kind)
        for field_name in PARAMETER_FIELDS
        if getattr(spec, field_name)
    )


# --- 重みを扱えない手法への誤差列指定（要件 1.10）----------------------------------


WEIGHT_COLUMN_LOCATION_TEMPLATE = "input.columns[{index}].weight"
"""誤差列を指定する設定キーの書き表し方（:attr:`~curvefit.readers.ColumnSpec.weight`）。

報告に載せる。利用者が消すべき指定の位置を書かなければ、拒否だけを受け取った利用者は
どこを直せばよいか分からない。

**添字を伴う。** 列指定は y 列ごとの並びであり（要件 1.11、1.12）、誤差列は同じ位置の
y 列に対応する。添字が無ければ、複数列の設定で「どの列に書いた誤差列を消せばよいか」が
利用者に伝わらない。
"""


def weight_column_locations(columns: Sequence[ColumnSpec]) -> tuple[str, ...]:
    """誤差列が対応付けられている y 列の位置を、報告に載せる形で並べる（要件 1.10、1.12）。

    **`0` は位置指定として正当な値である。** 真偽値ではなく ``None`` との比較で
    「指定の有無」を見る。

    :param columns: y 列ごとの列指定の並び（:attr:`~curvefit.config.InputSpec.columns`）
    :return: 誤差列を持つ要素の位置表記。1 件も無ければ空の並び
    """
    return tuple(
        WEIGHT_COLUMN_LOCATION_TEMPLATE.format(index=index)
        for index, spec in enumerate(columns)
        if spec.weight is not None
    )


_NO_WEIGHT_SUPPORT_REASONS = NO_WEIGHT_SUPPORT_REASONS
"""重みを扱えない手法について、扱えない理由。

:data:`~curvefit.engines.smoothing.SMOOTHER_USES_WEIGHTS` が偽とする手法をすべて
覆う。**所有は :mod:`curvefit.engines.smoothing` にある**（宣言と同じ場所）。
本モジュールは別名で参照するだけであり、文言をここに書き写さない。

**一般的な言い換えで済ませない**（:func:`_why_not_applicable` と同じ理由）。「重みを
扱えない」だけでは、利用者には設定の書き方の問題なのか手法の性質なのかが分からない。
理由が分からない拒否は、設定の見直しではなく手法の乗り換えを招く。
"""

_GENERIC_NO_WEIGHT_REASON = "この手法には点ごとの重みが効く場所が無い"
"""理由が個別に書かれていない場合の説明。

宣言に新しい手法が加わり :data:`_NO_WEIGHT_SUPPORT_REASONS` の更新が漏れた場合に
用いる。**ここで :exc:`KeyError` を送出しない。** 本モジュールは利用者が書いた内容に
対して例外を送出しない約束であり、宣言の更新漏れという実装側の不備を利用者の設定の
異常として噴出させると、その約束が実装の都合で破れる。漏れそのものは統合テストが
検出する。
"""


def _weight_capable_methods() -> str:
    """重みを扱える平滑化手法の名前を、報告に載せる形で並べる。

    **一覧は宣言から導く。** ここに手書きの並びを置くと、宣言と食い違った案内を
    利用者に示すことになる（タスク 11.1 でスプラインが重みを扱うようになった際、
    ``pipeline`` の独自の集合が同じ形でずれた）。並びは
    :class:`~curvefit.models.resolver.SmootherKind` の定義順であり、実行のたびに
    変わらない（要件 8.2）。
    """
    return " / ".join(kind.value for kind in SmootherKind if SMOOTHER_USES_WEIGHTS[kind])


def _weight_support_violations(
    spec: MethodSpec, kind: SmootherKind, weight_locations: Sequence[str]
) -> tuple[ConfigViolation, ...]:
    """誤差列を指定したうえで重みを扱えない手法を選んだ設定を拒否する（要件 1.10）。

    **黙って無視しない。** 無視すると、測定誤差を指定した利用者がそれを反映した結果
    として当てはめを読む。実行ログには従来から警告を出していたが、要件 7.3 のサマリ表
    だけを読む利用者には届かない。実行前に止めて設定を直させる方が、誤読の代償より
    小さい。平滑化手法に書かれたパラメータ指定を拒否するのと同じ扱いである
    （:func:`_smoother_parameter_violations`、要件 4.4、4.5）。

    **対象はモデル式を前提としない手法に限る。** モデル関数フィット（組込・数式・
    利用者定義関数）はいずれも重み付き最小二乗であり、重みが効かない経路が無い
    （要件 1.3）。

    報告する位置は手法の側とする。誤差列そのものは正しい指定であり、他の手法では
    そのまま効く。どの手法との組み合わせが成立しなかったのかは、違反の位置に手法名が
    無ければ複数手法の設定で特定できない。消すべき誤差列の位置
    （:func:`weight_column_locations`）は説明の側に載せる。**誤差列を持つ y 列が
    複数あればそのすべてを挙げる。** 1 つだけ消しても拒否は解けないため、部分的な
    案内は利用者を無駄な往復に導く。

    :param weight_locations: 誤差列が対応付けられている y 列の位置表記（要件 1.10、
        1.12）。空なら「いずれの y 列にも誤差列が無い」であり、検査対象にならない。
        データではなく **設定** に由来する事実であり、``sample=None`` の方針と矛盾しない
    """
    if not weight_locations or SMOOTHER_USES_WEIGHTS[kind]:
        return ()
    reason = _NO_WEIGHT_SUPPORT_REASONS.get(kind, _GENERIC_NO_WEIGHT_REASON)
    where = " / ".join(weight_locations)
    return (
        ConfigViolation(
            kind=ViolationKind.CONFIG_INVALID,
            location=_method_location(spec, "smoother"),
            message=(
                f"手法 {kind.value!r} は点ごとの重みを扱えないため、"
                f"{where} に指定された測定誤差の列を当てはめに"
                f"反映できない（{reason}）。"
                f"測定誤差を反映しなくてよい場合は {where} の指定を"
                "削除する。反映したい場合は、重みを扱う手法"
                f"（{_weight_capable_methods()}、またはモデル関数フィットの "
                "builtin / expression）に変える。"
            ),
        ),
    )


# --- 手法 1 件の検査 ---------------------------------------------------------------


def _method_violations(
    spec: MethodSpec, weight_locations: Sequence[str]
) -> tuple[ConfigViolation, ...]:
    """手法 1 件を検査する（要件 1.10、3.4、4.3、4.4、4.5、4.6、5.4）。

    モデル解決は ``sample=None`` で試みる。解決層はモデル解決の可否、初期値の必須性、
    初期値と上下限の整合（モデル固有の上下限を含む）、組込モデルの選択肢を既に判定
    するため、本モジュールはその結果をそのまま並べる。

    解決できなかった手法のパラメータ指定と選択肢は検査しない。手法が定まらなければ
    指定できる内容も定まらず、利用者に無関係な違反を増やすだけになる。重みを扱えるか
    どうかも同様で、手法が定まらなければ判定できない。

    :param weight_locations: いずれかの y 列に誤差列が対応付けられているか（要件 1.10）。
        空でなければ対応付けがある。データではなく **設定** に由来する事実であり、
        ``sample=None`` の方針と矛盾しない
    """
    resolved = resolve(spec, None)
    if isinstance(resolved, tuple):
        return resolved
    if isinstance(resolved, PreparedSmoother):
        return (
            _smoother_parameter_violations(spec, resolved.kind)
            + _smoother_option_violations(spec, resolved.kind)
            + _weight_support_violations(spec, resolved.kind, weight_locations)
        )
    return ()


# --- 設定構造の妥当性（要件 8.5、2.1）----------------------------------------------


def _preprocess_violations(spec: PreprocessSpec) -> tuple[ConfigViolation, ...]:
    """前処理の指定のうち、データに依存しない不備を検査する（要件 8.5）。

    前処理層はこれらを検証しない。区間の逆転を通すと点が 1 つも残らず「点数不足」に
    化け（要件 2.1 の指定誤りが要件 2.4 の失敗として報告される）、``sigma <= 0`` を
    通すと残差が 0 でない全点が外れ値になる。いずれも実行を止めて指定を直させるべき
    不備であり、データ個別の失敗ではない。
    """
    violations: list[ConfigViolation] = []
    # 数値であることを先に確かめる。設定ファイル経由なら config が弾くが、ライブラリを
    # 直接使う経路（要件 9.1）では任意の値が届きうる。素で比較すると TypeError が漏れ、
    # 「利用者が書いた内容に対して例外を送出しない」という本モジュールの約束が破れる。
    for name, value in (("x_min", spec.x_min), ("x_max", spec.x_max)):
        if value is not None and not _is_number(value):
            violations.append(
                _config_violation(
                    f"preprocess.{name}",
                    f"フィット区間の {name} が有限の数値でない: {value!r}",
                )
            )
    if (
        _is_number(spec.x_min)
        and _is_number(spec.x_max)
        and spec.x_min > spec.x_max  # type: ignore[operator]
    ):
        violations.append(
            _config_violation(
                "preprocess.x_min",
                f"フィット区間の下限 {spec.x_min} が上限 {spec.x_max} を上回っている。"
                "この指定では対象となる点が 1 つも残らない。",
            )
        )
    outlier = spec.outlier
    if outlier is None:
        return tuple(violations)
    if not _is_number(outlier.sigma) or outlier.sigma <= 0:
        violations.append(
            _config_violation(
                "preprocess.outlier.sigma",
                f"外れ値判定の閾値は正の有限な数値で指定する（実際: {outlier.sigma!r}）。"
                "0 以下では残差が 0 でない点がすべて外れ値になる。",
            )
        )
    if not _is_integer(outlier.max_iterations) or outlier.max_iterations < 0:
        violations.append(
            _config_violation(
                "preprocess.outlier.max_iterations",
                "外れ値除去の反復上限は 0 以上の整数で指定する"
                f"（実際: {outlier.max_iterations!r}）。",
            )
        )
    return tuple(violations)


# --- ゲート本体 --------------------------------------------------------------------


def validate(config: RunConfig) -> PreflightResult:
    """ジョブを 1 件も実行する前に、実行条件の全違反を一括収集する。

    **最初の違反で打ち切らない。** 全項目を検査してから返す。

    :param config: 検証する実行条件
    :return: 検出したすべての違反。1 件も無ければ :attr:`PreflightResult.ok` が ``True``
    """
    violations: list[ConfigViolation] = []
    # 誤差列の指定は入力の読み方であって手法ごとの指定ではないため、走査の外で 1 度だけ
    # 判定して各手法に渡す（要件 1.10）。列指定は y 列ごとの並びであり、判定は
    # 「いずれかの y 列に誤差列が対応付けられているか」で行う（要件 1.11、1.12）。
    #
    # **個数一致は検査しない。** 要件 1.13 は `config` が所有する（design.md の
    # `#### preflight` / `#### config`）。`RunConfig` に届く時点で並びは対応付け済みで
    # あり、元の個数は復元できない。
    weight_locations = weight_column_locations(config.inputs.columns)
    for spec in config.methods:
        violations.extend(_method_violations(spec, weight_locations))
    violations.extend(check_output_writable(config.output.directory))
    violations.extend(_preprocess_violations(config.preprocess))
    return PreflightResult(violations=tuple(violations))
