"""組込モデル名とモデル実体の対応表（要件 3.1、3.4）。

本モジュールが所有するのは「名前 → モデル実体の作り方」と「そのモデルがデータから
初期値を自動推定できるか」の 2 点のみである。初期値・上下限・固定の束縛は
:mod:`curvefit.models.resolver` が担う。

lmfit はここでモデル実体を組み立てるためだけに使う。公開シグネチャの注釈には
lmfit の型を一切現さない（設計の Allowed Dependencies）。生成したモデル実体は
:class:`object` として扱い、実際に読むのは :mod:`curvefit.engines.least_squares` と
:mod:`curvefit.models.resolver` に限る。

未知のモデル名は例外ではなく :class:`~curvefit.errors.ConfigViolation` として返す。
実行前ゲートが違反を最初の 1 件で打ち切らずに全件収集できるようにするためである。
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType

from lmfit.models import (
    ExponentialModel,
    GaussianModel,
    LinearModel,
    PolynomialModel,
)

from curvefit.errors import ConfigViolation, ViolationKind

POLYNOMIAL_DEGREE_OPTION = "degree"
"""多項式モデルの次数を指定するオプション名。"""

DEFAULT_POLYNOMIAL_DEGREE = 2
"""多項式モデルの既定次数。

次数はモデルの生成時に必須であり、既定値がなければ名前だけでの選択（要件 3.1）が
成立しない。既定値をレジストリが単独で所有し、実行条件として記録できるようにする。
"""

MAX_POLYNOMIAL_DEGREE: int = PolynomialModel.MAX_DEGREE
"""多項式モデルに指定できる次数の上限。

上限を超える指定は基盤ライブラリが :class:`TypeError` を送出する。値域の検証は
:mod:`curvefit.models.resolver` が行うが、上限そのものは対応表の一部であるため
ここで公開する。lmfit の値をそのまま参照するのは、定数と実体の乖離を防ぐためである。
"""

MIN_POLYNOMIAL_DEGREE: int = 0
"""多項式モデルに指定できる次数の下限。

負の次数は基盤ライブラリでは例外にならず、パラメータを 1 つも持たない退化した
モデルを黙って生成する。名前だけでの選択（要件 3.1）が成立しなくなるため拒否する。
"""

DEFAULT_LOCATION = "method.builtin"
"""解決失敗を報告する既定の箇所。呼び出し側が設定ファイル内の位置を渡して上書きする。"""


@dataclass(frozen=True)
class BuiltinModelSpec:
    """組込モデル 1 件の登録内容。"""

    name: str
    """設定ファイルおよび実行時引数で指定する名前。"""

    supports_auto_initial: bool
    """データからの初期値自動推定が可能か（要件 4.1 の可否判定に用いる）。"""

    default_options: Mapping[str, int]
    """モデル生成に必要な選択肢の既定値。多項式の次数のように、名前だけでは
    決まらない項目をここで補う。選択肢を持たないモデルでは空。"""

    _factory: Callable[..., object] = field(repr=False)
    """モデル実体を組み立てる関数。lmfit のモデルクラスを指す。"""

    def create(self, options: Mapping[str, int] | None = None) -> object:
        """モデル実体を新たに 1 つ組み立てて返す。

        :param options: 既定値を上書きする選択肢。``None`` なら既定値のみを用いる
        :return: 当てはめエンジンが利用するモデル実体（lmfit のモデル）
        :raises ValueError: 当該モデルが持たない選択肢名が渡されたとき
        """
        resolved = dict(self.default_options)
        for key, value in (options or {}).items():
            if key not in resolved:
                accepted = ", ".join(sorted(resolved)) or "（なし）"
                raise ValueError(
                    f"モデル {self.name!r} は選択肢 {key!r} を持たない。"
                    f"指定できる選択肢: {accepted}"
                )
            resolved[key] = value
        return self._factory(**resolved)

    def applied_defaults(
        self, options: Mapping[str, int] | None = None
    ) -> Mapping[str, int]:
        """:meth:`create` が既定値で補うことになる選択肢を返す（要件 5.4）。

        指定のあった選択肢は含まない。実行条件として記録するのは「利用者が書いて
        いないのに効いた値」であり、明示値と混ぜると記録から区別できなくなる。

        値を返すのは登録内容そのものであり、既定値の所有はここに留まる。補われた
        事実を知る必要があるのは解決層と当てはめ層だが、どちらも値を持たない
        （設計の Implementation Notes: 既定値の所有を 2 か所に分けない）。

        :param options: 利用者が明示した選択肢。``None`` なら既定値がすべて効く
        :return: 選択肢名 → 適用される既定値。補うものが無ければ空
        """
        specified = frozenset(options or {})
        return MappingProxyType(
            {key: value for key, value in self.default_options.items() if key not in specified}
        )


def _spec(
    name: str,
    factory: Callable[..., object],
    *,
    supports_auto_initial: bool,
    default_options: Mapping[str, int] | None = None,
) -> BuiltinModelSpec:
    return BuiltinModelSpec(
        name=name,
        supports_auto_initial=supports_auto_initial,
        default_options=MappingProxyType(dict(default_options or {})),
        _factory=factory,
    )


BUILTIN_MODELS: Mapping[str, BuiltinModelSpec] = MappingProxyType(
    {
        # lmfit の組込モデルはいずれも guess() を実装しており、データからの初期値
        # 自動推定が可能。可否をここに保持するのは、推定できないモデルを将来
        # 追加した場合に、要件 4.3（初期値必須）の判定が破綻しないようにするため。
        "linear": _spec("linear", LinearModel, supports_auto_initial=True),
        "polynomial": _spec(
            "polynomial",
            PolynomialModel,
            supports_auto_initial=True,
            default_options={POLYNOMIAL_DEGREE_OPTION: DEFAULT_POLYNOMIAL_DEGREE},
        ),
        "gaussian": _spec("gaussian", GaussianModel, supports_auto_initial=True),
        "exponential": _spec("exponential", ExponentialModel, supports_auto_initial=True),
    }
)
"""組込モデル名 → 登録内容（要件 3.1）。実行中に変更されない。"""


def resolve_builtin(
    name: str, location: str = DEFAULT_LOCATION
) -> BuiltinModelSpec | ConfigViolation:
    """組込モデル名を登録内容に解決する。

    名前は完全一致で照合する。綴りや大小の揺れを黙って受け入れると、設定ファイルの
    記述と実際に適用されたモデルの対応が崩れ、要件 8 の再現性の意図に反する。

    :param name: 設定で指定された組込モデル名
    :param location: 違反を報告する際に示す箇所（設定ファイル内の位置または引数名）
    :return: 解決できた場合は :class:`BuiltinModelSpec`、
        できなかった場合は :class:`~curvefit.errors.ConfigViolation`（要件 3.4）
    """
    spec = BUILTIN_MODELS.get(name)
    if spec is not None:
        return spec
    return ConfigViolation(
        kind=ViolationKind.MODEL_UNRESOLVED,
        location=location,
        message=(
            f"組込モデル名 {name!r} は存在しない。"
            f"選択できる名前: {', '.join(BUILTIN_MODELS)}"
        ),
    )
