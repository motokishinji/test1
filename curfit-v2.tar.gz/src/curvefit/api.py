"""ライブラリ利用者に対する公開ファサード（要件 1.2、9.1、9.3）。

本モジュールが所有するのは次の 3 点である。

1. **公開する入口の形** — 単一系列の当てはめ（:func:`fit_series`）、実行条件からの一括
   処理（:func:`run_batch`）、設定ファイルからの一括処理（:func:`run_from_config`）の
   3 つ。加えて、利用者がこれらを呼ぶために必要な型と入力の正規化関数を再エクスポート
   する
2. **実行前ゲートと実行の連結** — 検証（``preflight``）を通ってから実行（``pipeline``）
   へ進む順序。違反があれば処理単位を 1 件も実行せず、違反一覧をそのまま返す
3. **実行条件の記録の組み立て** — ``pipeline`` が要求する
   :class:`~curvefit.execution.ExecutionRecord` を、解決済みの実行条件から作る

**専用の実行経路を作らない。** 3 つの入口はいずれも :func:`_execute` を通り、そこから
:func:`curvefit.pipeline.run` に入る。要件 9.3 の「CLI とライブラリで同一結果」は、
テストの比較ではなく **この構造** によって保証される（設計の Key decisions）。比較で
保証しようとすると、経路が分かれていること自体は検出できず、片方だけが更新されたときに
黙って結果が食い違う。

単一系列も一括処理と同じ経路を通る
----------------------------------

:func:`fit_series` は、受け取った系列を **そのまま** 1 件の処理単位に載せ、1 対象 1 手法
の実行条件とともに :func:`_execute` に渡す。**当てはめ専用の近道を持たない。**

差込口は ``pipeline`` の側にある（:class:`~curvefit.pipeline.Job` の ``series``）。
読み込み・前処理・当てはめ・出力の順序は :func:`~curvefit.pipeline.run_job` の 1 か所に
あり、メモリ上の系列を渡した実行が省くのは読み込みの 1 段だけである。本モジュールに
順序を持たせないことが、要件 9.3 を規律ではなく構造で保つ形である。差込口を設けずに
「入力の位置」だけで処理単位を表すと、呼び出し元は系列を一時ファイルに書き出して読み
直すほかなく、対話環境からの利用（要件 9.1）が系列 1 件ごとにテキスト往復と作業領域の
生成破棄を伴う。

**したがって同一の数値データを与えた 2 経路は厳密に一致する**
（``tests/integration/test_api.py`` の :class:`Test経路の違いが値を変えないこと`）。
一致は往復の丸めに依存せず、当てはめに渡る系列が同一のオブジェクトであることによる。
ファイル経由との一致は、読み込み側が値を保つこと（``pandas`` の
``float_precision="round_trip"``、``readers`` の Postconditions）に依る。

誤差列も変換を挟まずに渡る。:class:`~curvefit.types.DataSeries` が保持するのは重み
``1/σ`` であり（``readers`` が σ → 1/σ を行う唯一の場所）、当てはめエンジンが受け取る
のもその値である。

出力先を持たない実行である
--------------------------

:func:`fit_series` は表も図も曲線 CSV も生成しない。結果は返り値で受け取る用途であり、
利用者が指定していない場所に出力を残す理由がない。実行ログと実行条件の記録も同様で、
``pipeline`` は読み込み済みの系列を受け取った実行ではこれらを書き出さない
（:func:`~curvefit.pipeline.run`）。**この経路は出力物を 1 つも残さない。**
（実行前検証が書き込み可否を確かめる際に探査用の一時ファイルを 1 つ作って即座に消すが、
呼び出しの後に残るものは無い）

曲線データの保持について
------------------------

一括処理（:func:`run_batch` / :func:`run_from_config`）が返す結果は **曲線データを保持
しない**（要件 10.4）。全件分を抱えると常駐メモリが処理件数に正確に比例して増え、要件 10
の「手元の PC で処理し切る」が成立しない。曲線は ``curves/*.csv`` として既にディスクに
ある（要件 7.5）ため、メモリ上の保持は重複である。

**:func:`fit_series` だけが保持したまま返す。** この経路は曲線 CSV を書かないため、手放せば
各点の当てはめ値と残差を受け取る手段が無くなる。結果が 1 件である以上、保持しても件数に
比例した増加は生じない。この違いは :func:`_execute` の ``retain_curve`` として **呼び出しに
書く**。``series`` の有無から推し量ると、出力先を持たないことと曲線を返すことが同じ真偽値
に相乗りし、片方だけを変えたい要求が出た時点で意味が割れる。

入力の 3 経路について
---------------------

要件 1.2 の 3 経路（CSV・NumPy 配列・pandas DataFrame）は ``readers`` が
:class:`~curvefit.types.DataSeries` に収束させる。本モジュールはその入口
（:func:`~curvefit.readers.read_delimited` / :func:`~curvefit.readers.read_frame` /
:func:`~curvefit.readers.read_arrays`）を再エクスポートするに留め、**経路ごとの当てはめ
関数を持たない**。:func:`fit_series` が受け取るのは正規化済みの
:class:`~curvefit.types.DataSeries` だけであり、3 経路が同一手順に載ることが署名の水準で
現れる。表形式の型を受け取るのは ``readers`` の 1 か所だけになり、本モジュールは
:mod:`pandas` を取り込まない。

依存方向は ``api`` までであり、``cli`` を import しない（設計の Allowed Dependencies）。
"""

from __future__ import annotations

import tempfile
from collections.abc import Mapping, Sequence
from dataclasses import replace
from pathlib import Path

from curvefit import pipeline, preflight
from curvefit.config import (
    FailurePolicy,
    InputSpec,
    OutputSpec,
    RunConfig,
    load_config,
)
from curvefit.errors import ConfigViolation, FailureReason, ViolationKind
from curvefit.execution import (
    HEADER_KEY,
    ExecutionRecord,
    OverrideRecord,
    build_execution_record,
)
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.pipeline import BatchReport, ProgressObserver, UnexpectedConfigViolation
from curvefit.plotting import PLOT_FONT_KEY, selected_japanese_font
from curvefit.preflight import PreflightResult
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec, read_arrays, read_delimited, read_frame
from curvefit.types import (
    CurveData,
    DataSeries,
    FitFailure,
    FitOutcome,
    FitSuccess,
    FloatArray,
    GoodnessOfFit,
    OutlierPoint,
    ParameterEstimate,
    PreprocessReport,
)

__all__ = [
    "BatchReport",
    "ColumnSpec",
    "ConfigViolation",
    "CurveData",
    "DataSeries",
    "ExecutionRecord",
    "FailurePolicy",
    "FailureReason",
    "FitFailure",
    "FitOutcome",
    "FitSuccess",
    "FloatArray",
    "GoodnessOfFit",
    "InputSpec",
    "MethodSpec",
    "OutlierPoint",
    "OutlierSpec",
    "OutputSpec",
    "OverrideRecord",
    "ParameterEstimate",
    "PreflightAborted",
    "PreflightResult",
    "PreprocessReport",
    "PreprocessSpec",
    "ProgressObserver",
    "RunConfig",
    "SmootherKind",
    "UnexpectedConfigViolation",
    "ViolationKind",
    "fit_series",
    "read_arrays",
    "read_delimited",
    "read_frame",
    "run_batch",
    "run_from_config",
]

UNUSED_COLUMNS = (ColumnSpec(x="x", y="y"),)
"""単一系列の実行条件が持つ、参照されない列指定。

:func:`fit_series` の経路は読み込みを行わないため、列・区切り文字・見出し行の指定は
当てはめに一切影響しない。それでも値が要るのは
:class:`~curvefit.config.InputSpec` が入力を「位置と読み方」で表すためである。
実際に読む経路と取り違えないよう、名前で参照されない旨を示す。

**並びとして持つ**（要件 1.11）。:attr:`~curvefit.config.InputSpec.columns` は y 列
ごとの並びであり、1 件でも並びである。当てはめる系列は 1 つなので要素も 1 つとする。
**誤差列は持たない。** 重みは :class:`~curvefit.types.DataSeries` が既に保持しており、
ここに誤差列を書くと実行前ゲートの要件 1.10 の検査が、読みもしない列指定を根拠に
当てはめを拒否する。
"""

def _unwritten_output_directory() -> Path:
    """単一系列の実行条件が持つ、何も書き出されない出力先。

    :func:`fit_series` は出力物を 1 つも書かず、``pipeline`` も読み込み済みの系列を
    受け取った実行では実行ログと実行条件の記録を書かない。この値を見るのは実行前ゲートの
    書き込み可否検査（``writers.check_output_writable``、要件 7.7）だけである。

    **一時領域を指すのは、その検査の結論を変えないためである。** 検査は存在する最も近い
    祖先に実際に書けるかを試す。作業用の一時ディレクトリを作っていた頃の判定先も同じ
    一時領域であり、判定の結果はそのときと変わらない。現在位置を指すと、書き込めない
    作業ディレクトリからの当てはめが手法の指定の誤りとして拒否される。

    呼び出しのたびに解決する。一時領域の位置は :mod:`tempfile` の設定で実行中に変わり
    うるため、取り込み時に固定すると、既に無い位置を検査して当てはめが拒否されうる。
    """
    return Path(tempfile.gettempdir())


class PreflightAborted(RuntimeError):  # noqa: N818 - 公開名。改名は利用者の import を壊す
    """実行前ゲートで違反が見つかり、処理単位を 1 件も実行せずに中止したことを表す。

    :func:`run_batch` と :func:`run_from_config` は違反を **値** として返す
    （:class:`~curvefit.preflight.PreflightResult`）。設計のフロー図が
    ``Api-->>Cli: PreflightAborted`` と記す中止は、この返り値で表される。

    本例外が要るのは :func:`fit_series` だけである。返す型が
    :class:`~curvefit.types.FitOutcome` に限られており、違反を値として返す欄が無い。
    :class:`~curvefit.types.FitFailure` に化けさせることはできない。
    :class:`~curvefit.errors.FailureReason` は実行中の失敗（データ個別の事由）の分類で
    あって設定の違反を表す語を持たず、無理に当てはめれば「実行前に停止すべき設定の誤り」
    が「1 件のデータが処理できなかった」と読める形で返る（``errors`` の
    Responsibilities）。

    :class:`~curvefit.pipeline.UnexpectedConfigViolation` とは別物である。あちらは
    実行前ゲートを **通していない** という呼び出し側の誤りを表す。こちらはゲートが正しく
    働いた結果であり、利用者が直すのは手法の指定である。
    """

    def __init__(self, result: PreflightResult) -> None:
        self.result: PreflightResult = result
        self.violations: tuple[ConfigViolation, ...] = result.violations
        rendered = "; ".join(
            f"[{violation.kind.value}] {violation.location}: {violation.message}"
            for violation in result.violations
        )
        super().__init__(
            f"実行前検証で違反が見つかったため何も実行していない"
            f"（違反 {len(result.violations)} 件）: {rendered}"
        )


def _resolved_config(config: RunConfig) -> dict[str, object]:
    """実行条件を、記録に載せる写像に写す（要件 8.3）。

    値は解決済みの表現をそのまま渡す。:mod:`curvefit.execution` の書き出しは ``Path``・
    列挙・凍結データクラス・タプルを扱えるため、記録用の別表現を組み立てる必要はない
    （``execution`` の Implementation Notes）。二重に表現を持つと、片方だけが実行条件の
    変更に追従しない。

    見出し行の扱いだけは :data:`~curvefit.execution.HEADER_KEY` の名前で最上位に置く
    （要件 1.6、1.7、8.3）。3 状態（未指定 / あり / なし）のどれで読んだかは、後から
    同じ結果を得られるかを左右する。

    グラフの表題に使ったフォントも同じ扱いで載せる（要件 7.4）。端末に導入されている
    日本語対応フォントから選ぶため、同じ設定でも端末によって字形が変わる。どのフォントで
    描いたかを後から判別できなければ、図の見た目の違いが設定の違いなのか環境の違いなのか
    切り分けられない。値は :func:`~curvefit.plotting.selected_japanese_font` が描画前でも
    確定させるため、記録の組み立て時点で読める。

    並びは固定する。同一の実行条件なら記録も同一になる（要件 8.2）。
    """
    return {
        "paths": config.inputs.paths,
        "columns": config.inputs.columns,
        "delimiter": config.inputs.delimiter,
        HEADER_KEY: config.inputs.header,
        "methods": config.methods,
        "preprocess": config.preprocess,
        "output": config.output,
        "failure_policy": config.failure_policy,
        PLOT_FONT_KEY: selected_japanese_font(),
    }


def _execute(
    config: RunConfig,
    observer: ProgressObserver | None,
    *,
    config_path: str | None,
    overrides: Sequence[OverrideRecord],
    series: DataSeries | None = None,
    retain_curve: bool = False,
) -> BatchReport | PreflightResult:
    """実行前ゲートを通してから一括処理を実行する。

    **本関数が唯一の実行経路である。** 公開する 3 つの入口はいずれもここを通り、
    :func:`curvefit.pipeline.run` に入る（要件 9.3）。

    実行条件の記録は実行の **前** に組み立てる。``pipeline`` はこれを要求し、適用された
    既定値（要件 5.4）を反映した新しい記録を返す。

    :param config: 実行条件
    :param observer: 進捗の通知先。``None`` なら通知しない
    :param config_path: 設定ファイルの位置。ライブラリ呼び出しでは ``None``（要件 8.3）
    :param overrides: 実行時引数が優先した項目の記録（要件 9.4）
    :param series: 読み込み済みの系列（要件 9.1）。``None`` なら実行条件の入力指定を
        走査する。指定した場合も通る経路は同一であり、``pipeline`` が読み込みの 1 段を
        省くだけである
    :param retain_curve: 結果に曲線データを残すか（要件 10.4）。既定の ``False`` では
        ``pipeline`` が出力の適用後に手放す。``True`` を渡してよいのは
        :func:`fit_series` だけであり、その理由はそこに書く
    :return: 違反があれば検証結果、無ければ集計結果
    """
    result = preflight.validate(config)
    if not result.ok:
        return result
    record = build_execution_record(
        resolved_config=_resolved_config(config),
        config_path=config_path,
        cli_overrides=tuple(overrides),
    )
    return pipeline.run(config, record, observer, series=series, retain_curve=retain_curve)


def run_batch(
    config: RunConfig,
    observer: ProgressObserver | None = None,
) -> BatchReport | PreflightResult:
    """実行条件に従って一括処理を実行する（要件 9.1）。

    **違反があれば処理単位を 1 件も実行しない。** 返り値が
    :class:`~curvefit.preflight.PreflightResult` であることが、何も実行されなかったこと
    を表す。設定の誤りは全件に等しく影響するため、部分的に進めてから失敗するより、何も
    書き出さずに全違反を提示するほうが利用者の修正コストが低い（設計の System Flows）。

    ::

        result = run_batch(config)
        if isinstance(result, BatchReport):
            ...  # 成功失敗サマリを読む
        else:
            for violation in result.violations:
                ...  # 設定を直す

    **集計結果は曲線データを保持しない**（要件 10.4）。
    :attr:`~curvefit.types.FitSuccess.curve` は出力の適用後に手放され ``None`` になる。
    各点の当てはめ値と残差が要る場合は、曲線 CSV の出力を有効にして読むか（要件 7.5）、
    系列 1 件ごとに :func:`fit_series` を使う。推定値・適合度・成否は従来どおり残る。

    :param config: 実行条件。設定ファイルを経由せず組み立ててもよい
    :param observer: 進捗の通知先（要件 6.3）。端末への描画は行わない
    :return: 集計結果、または実行前検証の違反一覧
    """
    return _execute(config, observer, config_path=None, overrides=())


def run_from_config(
    path: Path,
    overrides: Mapping[str, object] | None = None,
    observer: ProgressObserver | None = None,
) -> BatchReport | PreflightResult:
    """設定ファイルの読み込みから実行までを 1 回の呼び出しで行う（要件 8.1、9.1、9.4）。

    段階は **設定の読み込み → 実行前検証 → 実行** の順である。設定ファイルを読めない
    場合・解釈できない場合も、例外ではなく違反として返る（``config`` の
    :func:`~curvefit.config.load_config`）。実行前に停止する経路を値 1 本に保つことで、
    呼び出し側が同じ判断を値と例外の 2 通りで持たずに済む。

    **集計結果は曲線データを保持しない**（要件 10.4、:func:`run_batch` と同じ）。

    ``overrides`` は設定ファイルの内容に優先する（要件 9.4）。優先順位を判断するのは
    ``config`` だけであり、本モジュールは受け取った指定をそのまま渡す。上書きした項目は
    実行条件の記録に前後の値ごと残る。

    :param path: 設定ファイルの位置
    :param overrides: 設定ファイルに優先する指定。キーは ``output.directory`` のように
        設定ファイル内の位置を表す表記
    :param observer: 進捗の通知先（要件 6.3）
    :return: 集計結果、または実行前検証の違反一覧
    """
    loaded = load_config(Path(path), dict(overrides) if overrides else {})
    if not isinstance(loaded[0], RunConfig):
        # 失敗時の返り値は違反の並びであり、必ず 1 件以上を含む（``config.load_config``）。
        # 実行前に停止する経路を値 1 本に保つため、ここでも値として返す。
        return PreflightResult(violations=loaded)
    config, records = loaded
    return _execute(config, observer, config_path=str(path), overrides=records)


def _single_config(method: MethodSpec) -> RunConfig:
    """1 対象 1 手法の実行条件を組み立てる。

    **入力の位置は空である。** 当てはめる系列は :func:`_execute` に直接渡り、``pipeline``
    は走査も読み込みも行わない。列・区切り・出力先の指定は参照されない
    （:data:`UNUSED_COLUMNS`、:func:`_unwritten_output_directory`）。

    出力物はいずれも切る。単一系列の当てはめは結果を返り値で受け取る用途であり、利用者が
    指定していない場所に表や図を残す理由がない。
    """
    return RunConfig(
        inputs=InputSpec(paths=(), columns=UNUSED_COLUMNS),
        methods=(method,),
        preprocess=PreprocessSpec(),
        output=OutputSpec(
            directory=_unwritten_output_directory(),
            write_summary=False,
            write_plot=False,
            write_curve=False,
        ),
        failure_policy=FailurePolicy.SKIP,
    )


def fit_series(
    series: DataSeries,
    method: MethodSpec,
    preprocess: PreprocessSpec | None = None,
) -> FitOutcome:
    """メモリ上の 1 系列に手法を当てはめる（要件 9.1、9.3）。

    **一括処理と同一の実行経路を通る。** 系列をそのまま 1 件の処理単位に載せ、1 対象
    1 手法の実行条件とともに :func:`_execute` に渡す。当てはめ専用の近道を持たないため、
    要件 9.3 の「CLI とライブラリで同一結果」が構造として成立する（本モジュールの
    docstring 参照）。**出力物を残さない。**（実行前検証の書き込み可否の探査を除く。下記参照）

    結果の識別子は呼び出し元が :class:`~curvefit.types.DataSeries` に付けた ``source_id``
    である。処理単位の対象名としてそのまま渡るため、成功・失敗のいずれの結果にも現れる。

    **曲線データを保持したまま返す**（``retain_curve=True``、要件 7.5、10.4）。一括処理は
    出力の適用を終えた時点で曲線を手放すが（要件 10.4）、本関数はその適用を行わない
    （表も図も曲線 CSV も書かない）。手放せば、各点の当てはめ値と残差を受け取る手段が
    利用者から失われる。**保持してよいのは結果が 1 件だからである。** 常駐メモリは呼び出し
    1 回分の系列に留まり、処理件数に比例して増える形にはならない。この指定は
    :func:`_execute` への引数として明示する。``series`` の有無から推し量ると、出力先を
    持たないことと曲線を返すことという別々の要求が同じ真偽値に相乗りする。

    :param series: 当てはめる系列。3 つの読み込み関数のいずれかで得る（要件 1.2）
    :param method: 当てはめる手法の指定
    :param preprocess: 前処理の指定。``None`` なら既定（欠損除去のみ）
    :return: 当てはめ結果。成功なら :attr:`~curvefit.types.FitSuccess.curve` を伴う。
        いずれかの段階で失敗した場合はその段階の :class:`~curvefit.types.FitFailure`
    :raises PreflightAborted: 手法や前処理の指定に違反があった場合。当てはめは試みない
    """
    config = _single_config(method)
    if preprocess is not None:
        config = replace(config, preprocess=preprocess)

    report = _execute(
        config, None, config_path=None, overrides=(), series=series, retain_curve=True
    )
    if isinstance(report, PreflightResult):
        raise PreflightAborted(report)
    # 処理単位は 1 対象 1 手法のちょうど 1 件であり、``pipeline`` は処理単位ごとに
    # 結果を 1 件返す（中断した処理単位も :attr:`BatchReport.outcomes` に載る）。
    return report.outcomes[0]
