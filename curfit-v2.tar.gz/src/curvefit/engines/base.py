"""当てはめの単一契約と、手法によらない適合度算出（要件 5.2、7.2）。

本モジュールが所有するのは次の 2 点である。

1. **当てはめ契約** — :class:`FitEngine` は「系列と解決済み手法を受け取り、成功か失敗を
   値として返す」という 1 つの形を定める。モデル関数フィット（最小二乗）と回帰・
   スムージングはいずれもこの契約の実装として並置される。要件 5.2 の「モデル関数フィット
   と同一の手順で実行する」を、呼び出し側の分岐ではなく構造として実現する手段である
2. **適合度の算出** — 決定係数と RMSE は :func:`compute_goodness` に集約する。算出は
   残差だけに依存し、手法を引数に取らない。手法ごとに別の式を持つと、要件 5.3 の
   「モデル関数フィットと同一の形式で出力する」が指標の意味の水準で崩れる

本モジュールは具体エンジンを import しない。契約と実装の依存を一方向（実装 → 契約）に
保つためである。手法から実装への振り分けは本モジュールの責務ではない。

想定内の失敗は :class:`EngineFailure` として値で返す。例外は送出しない。バッチは既定で
個別の失敗をスキップして継続するため、ここで例外を投げるとバッチ全体が落ちる（設計の
Error Strategy）。例外を送出するのは呼び出し側の誤り（配列の形が契約に合わない）に限る。

入出力を一切持たない純粋計算として保つ。ファイル・端末・ログに触れない。基盤ライブラリ
（lmfit / SciPy）固有の型は公開シグネチャにも実装にも現れない。正規化は各エンジンの
内部で完結させる（設計の Allowed Dependencies）。
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Protocol, TypeAlias, runtime_checkable

import numpy as np

from curvefit.errors import FailureReason
from curvefit.models.resolver import PreparedMethod
from curvefit.types import DataSeries, FloatArray, GoodnessOfFit, ParameterEstimate


def _require_fit_array(name: str, array: FloatArray) -> None:
    """当てはめ値の配列が一次元の倍精度浮動小数点であることを検める。

    :class:`~curvefit.types.CurveData` が同じ制約を課しており、成立しない配列は結果の
    組み立て時に必ず失敗する。エンジンの出力地点で検めることで、原因のある場所で
    止まる。
    """
    if array.ndim != 1:
        raise ValueError(f"{name} は一次元配列でなければならない（実際: {array.ndim} 次元）")
    if array.dtype != np.float64:
        raise ValueError(f"{name} は float64 でなければならない（実際: {array.dtype}）")


def _frozen(mapping: Mapping[str, float | int] | None) -> Mapping[str, float | int]:
    """呼び出し側の辞書から切り離した、書き換え不能な写像を返す。"""
    return MappingProxyType(dict(mapping or {}))


@dataclass(frozen=True)
class EngineSuccess:
    """当てはめが成立した場合のエンジンの出力。

    処理単位の結果（:class:`~curvefit.types.FitSuccess`）ではない。識別子・前処理の記録・
    適合度の組み立ては呼び出し側が行う。エンジンが知るのは系列と手法だけであり、
    それ以上を持たせると、同じ当てはめを別の文脈から呼べなくなる。
    """

    parameters: tuple[ParameterEstimate, ...]
    """推定パラメータ。移動平均のようにパラメータを持たない手法では空（要件 5.3）。"""

    y_fit: FloatArray
    """各データ点の当てはめ値。入力系列と同一長であること（設計の Postconditions）。

    長さの一致は系列を知る呼び出し側でしか検められないため、ここでは配列の形のみを
    検める。
    """

    applied_defaults: Mapping[str, float | int] = field(default_factory=dict)
    """既定値を適用した手法固有の選択肢（要件 5.4）。

    利用者が明示した値は含まない。実行条件の記録に載せるのは「利用者が書いていないのに
    効いた値」であり、明示値と混ぜると記録から区別できなくなる。
    """

    def __post_init__(self) -> None:
        _require_fit_array("y_fit", self.y_fit)
        object.__setattr__(self, "applied_defaults", _frozen(self.applied_defaults))


@dataclass(frozen=True)
class EngineFailure:
    """当てはめが成立しなかった場合のエンジンの出力。

    例外ではなく値として運ぶ。既定ではバッチを止めずに集約されるため、握りつぶしが
    起きない形で表現する必要がある（:class:`~curvefit.types.FitFailure` と同じ理由）。

    識別子（``source_id`` / ``method_name``）は持たない。エンジンは対象がどの入力に
    由来するかを知らないため、報告の組み立ては呼び出し側が担う。
    """

    reason: FailureReason
    """失敗の分類。非収束は :attr:`~curvefit.errors.FailureReason.NOT_CONVERGED`（要件 4.7）。"""

    message: str
    """何が起きたかの説明。空にはできない。

    数百件のバッチでは、理由の分類だけでは次の一手が決まらない。反復が尽きたのか
    残差が発散したのかは分類に現れないため、説明を必須とする（設計の Error Categories）。
    """

    initial_values: Mapping[str, float] = field(default_factory=dict)
    """当てはめに用いた初期値（要件 4.7）。

    非収束の報告は「収束しなかった」だけでは再実行の指針にならない。どの初期値から
    出発したかが分かって初めて、初期値を変えるべきかモデルを変えるべきかを判断できる。
    """

    def __post_init__(self) -> None:
        if not self.message:
            raise ValueError(f"失敗 {self.reason} に説明が与えられていない")
        object.__setattr__(self, "initial_values", MappingProxyType(dict(self.initial_values)))


EngineOutcome: TypeAlias = EngineSuccess | EngineFailure
"""エンジンの出力。成功と失敗をひとつの戻り値として表す。"""


@runtime_checkable
class FitEngine(Protocol):
    """当てはめの単一契約（要件 5.2）。

    最小二乗も回帰・スムージングもこの契約の実装であり、呼び出し側は手法の種類で
    分岐せずに当てはめを実行できる。
    """

    def fit(self, series: DataSeries, method: PreparedMethod) -> EngineOutcome:
        """前処理済みの系列に、解決済みの手法を当てはめる。

        :param series: 前処理済みの系列。欠損を含まない（設計の Preconditions）
        :param method: 解決済みの手法。モデル指定の由来は残っていない
        :return: 成功なら :class:`EngineSuccess`、失敗なら :class:`EngineFailure`。
            想定内の失敗で例外を送出しない
        """
        ...


def compute_goodness(
    y_observed: FloatArray, y_fit: FloatArray, n_varied_params: int
) -> GoodnessOfFit:
    """残差から適合度指標を算出する（要件 7.2）。

    手法を引数に取らない。決定係数も RMSE も残差だけで決まり、最小二乗と回帰・
    スムージングで意味が変わらないことが、要件 5.3 の「同一の形式で出力する」の前提に
    なる。重みは用いない。重み付き残差で測ると、同じ当てはめでも入力に誤差列があるか
    否かで指標が変わり、対象間の比較が成立しなくなる。

    決定係数は ``1 - 残差平方和 / 全変動`` とする。境界の扱いは次の 2 点である。
    いずれも利用者が目にする値であり、規約として固定する。

    - **全変動が 0（実測値が一定、単一点を含む）で残差も 0** — ``1.0`` を返す。当てはめは
      実測値を完全に再現しており、これを不定とするのは実態に合わない
    - **全変動が 0 で残差が残る** — ``0.0`` を返す。除算は行わない。無限大や NaN を
      返すとサマリ CSV とグラフの軸に伝播し、他の対象の集計まで読めなくなる

    平均より当てはまりが悪い場合の負値は、そのまま返す。0 に切り上げると「平均を返す
    方がましである」という利用者が知るべき状態が、無害な値に化ける。

    当てはめ値に有限でない値が含まれる場合、その値はそのまま算出に通り、指標も有限でない
    値になる。実測 ``[1, 2, 3, 4]`` に対し当てはめ値の 1 点を ``NaN`` にすると
    ``r_squared`` も ``rmse`` も ``nan`` になり、``inf`` にすると ``r_squared`` は
    ``-inf``、``rmse`` は ``inf`` になる。ここでは有限性を判定しない。発散の検出は各
    エンジンの責任であり、有限でない当てはめ値を得たエンジン（実装は 4.2 / 4.3）は
    :class:`EngineFailure` を返すこと。本関数を防波堤として当てにすると、非収束の扱いが
    2 か所に分かれ、失敗の理由と初期値（要件 4.7）を報告できる地点を通らずに指標だけが
    出力される。

    :param y_observed: 実測値
    :param y_fit: 当てはめ値。``y_observed`` と同一長であること
    :param n_varied_params: 変動させたパラメータ数。決定係数の自由度調整には用いず、
        利用者がモデルを比較する際の参照用に保持する（設計の Validation）
    :return: 決定係数・RMSE・点数・変動パラメータ数
    :raises ValueError: 配列の形が揃わない場合、点が 1 つもない場合
    """
    _require_fit_array("y_observed", y_observed)
    _require_fit_array("y_fit", y_fit)
    if len(y_observed) != len(y_fit):
        raise ValueError(
            f"実測値と当てはめ値の長さが一致しない（{len(y_observed)} と {len(y_fit)}）"
        )
    if len(y_observed) == 0:
        raise ValueError("適合度指標は 1 点以上の実測値を必要とする")

    residual = y_observed - y_fit
    sum_squared_residual = float(np.sum(np.square(residual)))
    deviation = y_observed - float(np.mean(y_observed))
    total_variation = float(np.sum(np.square(deviation)))

    if total_variation == 0.0:
        r_squared = 1.0 if sum_squared_residual == 0.0 else 0.0
    else:
        r_squared = 1.0 - sum_squared_residual / total_variation

    return GoodnessOfFit(
        r_squared=r_squared,
        rmse=float(np.sqrt(sum_squared_residual / len(y_observed))),
        n_points=len(y_observed),
        n_varied_params=n_varied_params,
    )
