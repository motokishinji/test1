"""当てはめエンジン。

当てはめの単一契約（:class:`~curvefit.engines.base.FitEngine`）と、その実装を置く層。
モデル関数フィットと回帰・スムージングは同じ契約の実装として並置され、呼び出し側は
手法の種類で分岐せずに当てはめを実行できる（要件 5.2）。

本パッケージの入口は、解決済み手法から実装への**振り分け**（:func:`select_engine`）も
所有する。契約を定める :mod:`curvefit.engines.base` に置かないのは、契約と実装の依存を
一方向（実装 → 契約）に保つためである。

基盤ライブラリ（lmfit / SciPy / NumPy）は各エンジンの内部に閉じ、公開シグネチャには
現れない。入出力を一切持たない純粋計算として保つ。
"""

from __future__ import annotations

from curvefit.engines.base import (
    EngineFailure,
    EngineOutcome,
    EngineSuccess,
    FitEngine,
    compute_goodness,
)
from curvefit.engines.least_squares import LeastSquaresEngine
from curvefit.engines.smoothing import SmoothingEngine
from curvefit.models.resolver import PreparedMethod, PreparedModel, PreparedSmoother

__all__ = [
    "EngineFailure",
    "EngineOutcome",
    "EngineSuccess",
    "FitEngine",
    "compute_goodness",
    "select_engine",
]


def select_engine(method: PreparedMethod) -> FitEngine:
    """解決済み手法に対応する当てはめエンジンを返す（要件 5.2）。

    呼び出し側はこの関数を通すことで、モデル関数フィットと回帰・スムージングを同一の
    手順で実行できる。手法の種類による分岐は、呼び出し側ではなくここに 1 か所だけ置く。

    **登録簿を持たない。** 具体エンジンは静的に import し、対応は解決済み手法の型で
    決める。実行時に差し替えられる対応表を持つと、同一設定・同一データでも import の
    状態によって別のエンジンが選ばれうる。要件 8.2 の再現性は、この関数が引数だけの
    関数であること、すなわち書き換え可能なモジュール状態を持たないことに依る。

    **エンジンは呼び出しごとに作る。** 両エンジンは属性を持たない凍結データクラスで
    あり、共有しても計算結果は変わらない。それでも使い回さないのは、モジュールに保持
    した実体が呼び出し側から到達可能な書き換え対象になるためである。生成費用は属性の
    ない実体 1 個であり、当てはめ 1 回の計算量に対して無視できる。

    :param method: 解決済みの手法（:class:`~curvefit.models.resolver.PreparedModel`
        または :class:`~curvefit.models.resolver.PreparedSmoother`）
    :return: その手法を当てはめられる :class:`~curvefit.engines.base.FitEngine`
    :raises TypeError: 対応するエンジンがない型を渡された場合。利用者由来のデータや
        設定に起因する失敗ではなく呼び出し側の誤りであるため、値ではなく例外で知らせる。
        :class:`~curvefit.engines.base.EngineFailure` として集約すると、プログラムの
        誤りがバッチのスキップ件数に紛れる（各エンジンが誤った解決済み型を拒む扱いと
        同じである）
    """
    if isinstance(method, PreparedModel):
        return LeastSquaresEngine()
    if isinstance(method, PreparedSmoother):
        return SmoothingEngine()
    raise TypeError(
        f"当てはめエンジンを選べない手法である（実際: {type(method).__name__}）。"
        f"{PreparedModel.__name__} または {PreparedSmoother.__name__} を渡す。"
    )
