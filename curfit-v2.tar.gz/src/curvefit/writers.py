"""出力物の形式・命名規則・出力先検証を所有する（要件 2.5、7.3、7.5、7.6、7.7）。

本モジュールが所有するのは次の 5 点である。

1. **サマリ CSV の列構成** — 1 行 = ``(source_id, column_label, method_name,
   parameter_name)`` の long 形式であり、適合度指標は行内で繰り返す。詳細は
   :func:`write_summary`
2. **曲線・残差 CSV の形式** — 各データ点の x・実測値・当てはめ値・残差。オプトイン
   出力であり、生成するかどうかの判断は呼び出し側にある（要件 7.5）
3. **前処理 CSV の形式と、書くか否かの判断** — 外れ値として除外した各点の x・実測値・
   反復回数（要件 2.5）。オプトインではなく、成否も条件にしない。除外が 0 件の場合と
   前処理に到達していない場合は **ファイルを作らない**。詳細は :func:`write_preprocess`
4. **出力ファイル名の一意性** — :func:`build_output_stem` が対象・列・手法から決定的に
   導出する。複数対象の出力と、同一ファイルの別々の列の出力が互いを上書きしない
   （要件 7.6）
5. **出力先の検証** — :func:`check_output_writable` が書き込み可否を判定し、違反を
   **値として** 返す（要件 7.7）。作るのは最終要素 1 階層だけで、親の連なりごと
   存在しない指定は打ち間違いとして拒否する

**丸めはサマリ表に限る。** サマリ CSV の数値は有効数字
:data:`SUMMARY_SIGNIFICANT_DIGITS` 桁で書き出し、曲線・残差 CSV と前処理 CSV は全精度で
書き出す。理由は :func:`_format_summary_number` に記す。

**想定内の失敗は値として返す。** 出力先が書けないことは利用者の設定誤りであり、
:class:`~curvefit.errors.ConfigViolation` として返す。実行前ゲート（``preflight``）が
全違反を一括収集するため、ここで例外を送出すると 1 件目で収集が打ち切られる
（設計の Error Strategy）。

**書き込み中の :class:`OSError` は握り潰さない。** ディスク枯渇のような資源・環境の
失敗は要件 10.3 の系統であり、``pipeline`` が ``RESOURCE_EXHAUSTED`` として扱う。
ここで飲み込むと、書けなかった対象が成功として集計される。

pandas の型は外に出さない。書き出しは標準ライブラリの :mod:`csv` で行う。数値の
文字列表現をこのモジュールが完全に決めることが、逐字比較（要件 8.2）の前提である。
matplotlib は import しない。描画は ``plotting`` に閉じる（設計の Allowed Dependencies）。
"""

from __future__ import annotations

import csv
import os
import tempfile
from collections.abc import Sequence
from pathlib import Path, PurePosixPath

from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.types import FitFailure, FitOutcome, FitSuccess, PreprocessReport

SUMMARY_COLUMNS: tuple[str, ...] = (
    "source_id",
    "column_label",
    "column_name",
    "method_name",
    "status",
    "parameter_name",
    "value",
    "stderr",
    "fixed",
    "r_squared",
    "rmse",
    "n_points",
    "n_dropped_invalid",
    "n_dropped_out_of_range",
    "n_dropped_outlier",
    "failure_reason",
    "message",
)
"""サマリ CSV の列（設計の「サマリ CSV の列」表）。並び順まで含めて本モジュールが所有する。

列を位置で読む後段があるため、追加は表のとおりの位置に入れる。``column_label`` と
``column_name`` が ``source_id`` と ``method_name`` の間に入るのはそのためである
（:func:`_column_identity_cells`）。
"""

CURVE_COLUMNS: tuple[str, ...] = ("x", "y_observed", "y_fit", "residual")
"""曲線・残差 CSV の列（要件 7.5）。:class:`~curvefit.types.CurveData` の並びに一致させる。"""

PREPROCESS_COLUMNS: tuple[str, ...] = ("x", "y_observed", "iteration")
"""前処理 CSV の列（要件 2.5、設計の「前処理 CSV の列」表）。

:class:`~curvefit.types.OutlierPoint` の並びに一致させる。``y_observed`` は曲線 CSV と
同じ語であり、当てはめ値ではなく **実測値** であることを名前で示す。
"""

SUMMARY_SIGNIFICANT_DIGITS = 10
"""サマリ CSV の数値を丸める有効数字の桁数（設計の Validation）。

報告物として意味のある桁に揃えるための丸めであり、再現性の担保が目的ではない
（:func:`_format_summary_number`）。
"""

SUCCESS_STATUS = "success"
FAILURE_STATUS = "failure"

OUTPUT_DIRECTORY_LOCATION = "output_dir"
"""出力先違反の ``location``。実行前ゲートが報告に用いる設定項目名。"""

STEM_SEPARATOR = "__"
"""出力名の各部を繋ぐ区切り。単一の ``_`` は対象名の一部として現れうるため 2 文字とする。"""

MAX_STEM_COMPONENT = 80
"""出力名 1 部分の最大文字数。ファイル名長の上限に対して余裕を持たせる。"""

JOB_INDEX_WIDTH = 4
"""ジョブ番号の桁数。数百件規模（要件 10.1）では 4 桁で辞書順と数値順が一致する。"""

FALLBACK_SOURCE_NAME = "input"
"""対象名として使える文字が 1 つも残らない場合の代替（``".."`` や空文字など）。"""

FALLBACK_COLUMN_NAME = "column"
"""列の識別子として使える文字が 1 つも残らない場合の代替。

系列を直接渡された経路（``column_label`` が ``None``）でも同じ語を置き、出力名の形を
1 通りに保つ（:func:`build_output_stem`）。
"""

FALLBACK_METHOD_NAME = "method"
"""手法名として使える文字が 1 つも残らない場合の代替。"""

_SAFE_EXTRA_CHARS = frozenset({"-", "_"})
"""英数字以外で出力名に残す文字。パス区切り・親ディレクトリ参照を作らない文字に限る。"""

_PROBE_PREFIX = ".curvefit-write-probe-"
"""書き込み可否の実測に用いる一時ファイルの接頭辞。検査後に必ず削除する。"""


def _format_summary_number(value: float | None) -> str:
    """サマリ用に数値を有効数字 10 桁で表す。``None`` は空欄（設計の Validation）。

    丸めるのは **報告物の桁を揃えるため** である。サマリ表は読んで比較するための出力物で
    あり、測定データの解析で意味を持つ桁は 10 桁に収まる。それを超える桁は計算過程の
    産物であって、並べても読み手の判断を助けない。

    **丸めは再現性の担保ではない。** 値が丸めの境界付近にあれば、最終桁の刻みより小さい
    揺れでも表記は変わる。丸めは必要条件であって十分条件ではなく、桁数を減らしても
    一致しない確率が下がるだけである（実測: 462 データ中 5 件が境界をまたいだ）。要件 8.2
    が求める再現性は、揺れを生む経路そのものを断つことで成立させている。唯一の経路で
    あった平滑化パラメータの自動選択は、パラメータを必須にすることで到達不能になった
    （要件 5.5、:mod:`curvefit.engines.smoothing`）。

    丸めるのはサマリ表だけである。曲線・残差 CSV とグラフは全精度で出力する
    （:func:`_format_full_number`）。丸めた値を数値データとして再利用されると、
    ここで意図した「比較のための表示」が「加工されたデータ」に変わる。

    ``None`` を空欄にするのは、標準誤差が算出できない場合（ヤコビアンがフルランクで
    ない、固定パラメータ）を ``nan`` や ``0`` と区別するためである。``0`` は「誤差が
    ない」と読め、``nan`` は「計算が壊れた」と読める。どちらも実際とは違う。
    """
    if value is None:
        return ""
    return f"{value:.{SUMMARY_SIGNIFICANT_DIGITS}g}"


def _format_full_number(value: float) -> str:
    """曲線・残差 CSV 用に数値を全精度で表す（設計の Validation）。

    :func:`repr` は往復して同じ値に戻る最短の表現を返す。曲線データは数値として
    再利用される出力物であり、丸めると残差の再計算が合わなくなる。

    NumPy のスカラを受け取っても NumPy 固有の表現（``np.float64(...)``）を出さないよう、
    :class:`float` に落としてから表す。基盤ライブラリの型を出力物に漏らさない。
    """
    return repr(float(value))


def _column_identity_cells(outcome: FitOutcome) -> list[str]:
    """対象の y 列を識別する 2 列を作る（要件 7.3、設計の writers Responsibilities）。

    **2 列あるのは役割が違うためである。** ``column_label`` は利用者が書いた
    **指定の綴り**（列名または位置）であり、ファイルを読む前に確定して出力ファイル名にも
    入る（:func:`build_output_stem`）。``column_name`` は **解決後の見出し名** であり、
    読み込み後にしか埋まらない代わりに、位置で指定した場合でもどのチャネルかが分かる。
    実データでは列名がファイルごとに変わるため位置指定が主経路になり、``column_label``
    だけでは ``1`` / ``2`` という綴りしか残らない。

    ``None`` は空欄にする。``column_name`` が ``None`` になるのは見出しを持たない入力と、
    読み込みに至らずに失敗した対象である。どちらも「見出し名が無い」のであって、空文字の
    見出しがあるわけではない。``column_label`` が ``None`` になるのは系列を直接渡された
    経路だけであり（設計の types の Postconditions）、その経路はサマリを書かない。
    """
    return [outcome.column_label or "", outcome.column_name or ""]


def _preprocess_cells(report: PreprocessReport | None) -> list[str]:
    """前処理の除去件数 3 列を作る（要件 2.2、2.3）。

    ``None`` は前処理に到達する前の失敗（列が解決できない、有効データが 0 件）を表す。
    この場合の除去件数は 0 件ではなく **未計測** であり、空欄とする。0 と書くと
    「前処理は動いたが 1 件も落ちなかった」と読め、失敗した段階を誤らせる。
    """
    if report is None:
        return ["", "", ""]
    return [
        str(report.n_dropped_invalid),
        str(report.n_dropped_out_of_range),
        str(report.n_dropped_outlier),
    ]


def _success_rows(success: FitSuccess) -> list[list[str]]:
    """成功 1 件を long 形式の行に展開する（要件 7.1、7.2、7.3、3.5）。

    行の先頭には対象と y 列の識別子が並ぶ（:func:`_column_identity_cells`）。

    パラメータ 1 個につき 1 行とし、適合度指標と前処理の件数は各行で繰り返す。
    モデルごとにパラメータの数と名前が異なるため、パラメータを列に展開する wide 形式では
    複数モデルを 1 つの表に収めた時点で列が破綻する（設計の Integration）。

    パラメータを持たない手法（平滑化スプライン、移動平均）は ``parameters`` が空だが、
    行を 1 つ出す。適合度指標は手法によらず算出されており（要件 5.3、7.2）、行を
    省くと成功したはずの対象がサマリから消え、要件 6.6 の成否集計と突き合わせられなく
    なる。この行の ``parameter_name`` は空とする。
    """
    goodness = success.goodness
    head = [
        success.source_id,
        *_column_identity_cells(success),
        success.method_name,
        SUCCESS_STATUS,
    ]
    tail = [
        _format_summary_number(goodness.r_squared),
        _format_summary_number(goodness.rmse),
        str(goodness.n_points),
        *_preprocess_cells(success.preprocess),
        "",
        "",
    ]

    if not success.parameters:
        return [[*head, "", "", "", "", *tail]]

    return [
        [
            *head,
            parameter.name,
            _format_summary_number(parameter.value),
            _format_summary_number(parameter.stderr),
            str(parameter.fixed),
            *tail,
        ]
        for parameter in success.parameters
    ]


def _failure_rows(failure: FitFailure) -> list[list[str]]:
    """失敗 1 件を行にする（要件 6.4、6.6）。

    失敗もサマリ表に載せる。要件 6.6 の成功/失敗件数はこの表と突き合わせられる必要が
    あり、失敗を落とすと「処理したはずの対象がどこにもない」状態になる。推定値と
    適合度の列は空欄とし、代わりに理由と説明を載せる。
    """
    return [
        [
            failure.source_id,
            *_column_identity_cells(failure),
            failure.method_name,
            FAILURE_STATUS,
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            *_preprocess_cells(failure.preprocess),
            failure.reason.value,
            failure.message,
        ]
    ]


def _summary_rows(outcome: FitOutcome) -> list[list[str]]:
    """結果 1 件を行の並びにする。成功と失敗の双方が同じ列構成を共有する。"""
    if isinstance(outcome, FitSuccess):
        return _success_rows(outcome)
    return _failure_rows(outcome)


def _write_csv(path: Path, header: Sequence[str], rows: Sequence[Sequence[str]]) -> None:
    r"""CSV を書き出す。既存の内容は上書きする（設計の Idempotency & recovery）。

    行区切りは環境によらず ``\n`` に固定する。既定の ``\r\n`` では、同一設定・同一
    入力の再実行が環境をまたぐと逐字一致しなくなる（要件 8.2）。

    親ディレクトリは必要に応じて作る。曲線 CSV の出力先は ``{output_dir}/curves/``、
    前処理 CSV は ``{output_dir}/preprocess/`` であり（設計の Batch / Job Contract）、
    この階層を作るのは出力側の責務である。**書くと決めた後にだけ呼ぶこと。** 書かない
    対象のために階層を作ると、除外のあった対象を探す手掛かりが消える
    （:func:`write_preprocess`）。

    :raises OSError: 書き込みに失敗した場合。資源・環境の失敗は要件 10.3 の系統であり、
        値として飲み込まない
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(list(header))
        writer.writerows([list(row) for row in rows])


def write_summary(outcomes: Sequence[FitOutcome], path: Path) -> None:
    """全処理対象の結果を 1 つのサマリ表として書き出す（要件 7.3）。

    列は :data:`SUMMARY_COLUMNS`、1 行 = ``(source_id, column_label, method_name,
    parameter_name)`` の long 形式である。適合度指標と前処理の除去件数は行内で繰り返す。
    成功も失敗も同じ表に載る（要件 6.6）。

    各行がどの入力のどの y 列かは ``column_label``（指定の綴り）と ``column_name``
    （解決後の見出し名）の 2 列で識別する（:func:`_column_identity_cells`）。刻印は
    ``pipeline`` が行い、本関数に届く結果は刻印済みである。

    行の順序は与えられた順序をそのまま保つ。ジョブ順序は ``pipeline`` が決定的に定める
    （要件 8.2）ため、ここで並べ替えると順序の所有者が 2 か所に分かれる。

    数値は有効数字 :data:`SUMMARY_SIGNIFICANT_DIGITS` 桁で書き出す
    （:func:`_format_summary_number`）。

    :param outcomes: 書き出す結果。成功と失敗が混在してよい
    :param path: 出力先のファイルパス。親ディレクトリは必要に応じて作る
    :raises OSError: 書き込みに失敗した場合
    """
    rows = [row for outcome in outcomes for row in _summary_rows(outcome)]
    _write_csv(path, SUMMARY_COLUMNS, rows)


def write_curve(success: FitSuccess, path: Path) -> None:
    """各データ点の実測値・当てはめ値・残差を書き出す（要件 7.5）。

    この出力は既定では生成しない。数百件規模でファイル数とサイズが膨れ上がるため、
    有効化された場合にのみ呼ぶ（steering ``tech.md`` の Key Technical Decisions）。
    有効かどうかを判断するのは呼び出し側であり、本関数は判断しない。

    数値は丸めずに全精度で書き出す（:func:`_format_full_number`）。サマリ表と違い、
    これは表示ではなく数値データそのものである。

    :param success: 書き出す成功結果。曲線データを保持していること
    :param path: 出力先のファイルパス。親ディレクトリは必要に応じて作る
    :raises ValueError: 曲線データが解放済み（``success.curve`` が ``None``）の場合。
        書き出しは解放より前に行われる（``pipeline`` の ``run_job`` → ``run``）ため、
        ここに解放済みの結果が届くのは呼び出し側の誤りである（要件 10.4）
    :raises OSError: 書き込みに失敗した場合
    """
    curve = success.curve
    if curve is None:
        # 空のファイルを書くと、出力ディレクトリの内容とサマリ表の成否が食い違う。
        # 値として飲み込まず、呼び出し側の誤りとして送出する（本プロジェクトの規約）。
        raise ValueError(
            f"曲線データが解放済みの結果は書き出せない"
            f"（source_id={success.source_id!r} method={success.method_name!r}）"
        )
    rows = [
        [
            _format_full_number(x),
            _format_full_number(y_observed),
            _format_full_number(y_fit),
            _format_full_number(residual),
        ]
        for x, y_observed, y_fit, residual in zip(
            curve.x.tolist(),
            curve.y_observed.tolist(),
            curve.y_fit.tolist(),
            curve.residual.tolist(),
            strict=True,
        )
    ]
    _write_csv(path, CURVE_COLUMNS, rows)


def write_preprocess(outcome: FitOutcome, path: Path) -> None:
    """外れ値として除外した各点を書き出す（要件 2.5）。

    列は :data:`PREPROCESS_COLUMNS`、1 行 = 除外した 1 点である。並びは
    :attr:`~curvefit.types.PreprocessReport.outlier_points` の並び、すなわち **除去順**
    （反復順、反復内では入力の並び順）をそのまま保つ。並べ替えると、どちらの点が先に
    外れたのかが読めなくなる。順序は入力だけで決まるため、同一入力・同一設定の再実行は
    同一の並びになる（要件 8.2）。

    **成功も失敗も受け取る。** 前処理 CSV は当てはめの結果ではなく **前処理が何をしたかの
    説明** であり、当てはめの成否とは独立に成立する。外れ値を除いた結果として点数不足で
    落ちる場合は、まさにどの点が除かれたのかを知りたい場面である（設計の Integration）。

    **オプトインの判断は持たない。** 要件 2.5 は出力の有効化を条件にしていない。除外された
    点だけを並べるため、曲線 CSV のような規模の問題も生じない。

    **書くか否かの判断は本関数が単独で持つ。** 次の 2 つの場合はファイルを作らずに戻る。

    1. ``outcome.preprocess`` が ``None`` — 前処理に到達する前に失敗した処理単位
    2. 除外した点が 1 つもない場合

    呼び出し側（``pipeline``）は**この 2 条件**を見ずに呼ぶ（系列を直接渡された処理単位では
    書かないという別軸の抑止は ``pipeline`` が持つ）。判断を 2 か所に置くと片方だけが
    更新される（本プロジェクトで実際に起きた。タスク 9.1 の欠陥）。

    :func:`write_curve` がオプトインの判断を **呼び出し側に** 置いているのと逆に見えるが、
    不整合ではない。判断の材料がどこにあるかが違う。曲線 CSV の有効化は ``RunConfig`` に
    あり、本モジュールは ``config`` を import しない（設計の Allowed Dependencies）ため
    判断できない。除外点の有無は引数 ``outcome`` の中にあり、本関数だけで判断できる。
    判断材料を持つ側が判断を持つ、が両者に共通する規則である。

    **空のファイルは作らない。** 対象ごとに空ファイルが並ぶと、外れ値があった対象を探すのに
    ファイルを開く必要が生じる。存在そのものが「この対象には除外があった」を意味する形に
    する（設計の Integration）。書かない場合は親ディレクトリも作らない。

    数値は丸めずに全精度で書き出す（:func:`_format_full_number`）。曲線 CSV と同じく、
    これは表示ではなく数値データそのものである。``iteration`` は 1 起点の整数であり、
    実数として書くと「3.0 回目」と読ませることになるため整数のまま出す。

    :param outcome: 書き出す結果。成功と失敗のどちらでもよい
    :param path: 出力先のファイルパス。**書く場合にのみ** 親ディレクトリを必要に応じて作る
    :raises OSError: 書き込みに失敗した場合
    """
    report = outcome.preprocess
    if report is None or not report.outlier_points:
        return

    rows = [
        [
            _format_full_number(point.x),
            _format_full_number(point.y),
            str(point.iteration),
        ]
        for point in report.outlier_points
    ]
    _write_csv(path, PREPROCESS_COLUMNS, rows)


def _last_path_component(source_id: str) -> str:
    r"""識別子の最後の要素を取り出す。パス区切りと親ディレクトリ参照を除去する。

    ``source_id`` は利用者が与えた任意の文字列であり、``../../etc/passwd`` や絶対パスも
    ありうる（設計の Security Considerations）。区切りで分解して最後の要素だけを採る
    ことで、出力が指定ディレクトリの外に出る経路を断つ。

    ``..`` は 1 つ前の要素を打ち消す。単に読み飛ばすと ``data/subdir/..`` が ``subdir``
    という名前になり、実際に指している ``data`` と食い違う。打ち消す相手がない場合
    （``../../etc``）は無視する。出力先の外を指す指定を、外を指さない名前へ潰す。

    ``\`` も区切りとして扱う。Windows 形式のパスを識別子に持つ入力で ``..\..\x`` が
    1 つの要素として通ると、除去したはずの親ディレクトリ参照が名前に残る。
    """
    parts: list[str] = []
    for part in source_id.replace("\\", "/").split("/"):
        if part in ("", "."):
            continue
        if part == "..":
            if parts:
                parts.pop()
            continue
        parts.append(part)
    return parts[-1] if parts else ""


def _safe_component(text: str, fallback: str) -> str:
    """出力名に使える文字だけを残す。残らなければ ``fallback`` を返す。

    英数字（日本語を含む）と ``-`` ``_`` を残し、それ以外は ``_`` に置き換える。置換に
    より別々の入力が同じ名前に潰れうるが、名前の末尾に付くジョブ番号が一意性を保証する
    （:func:`build_output_stem`）。

    先頭・末尾の ``_`` は落とす。先頭の ``.`` が ``_`` に置き換わった結果として現れる
    ものであり、残しても意味を持たない。長さは :data:`MAX_STEM_COMPONENT` で切る。
    ファイル名長の上限は環境によって異なり、長い識別子で書き出しだけが失敗するのを防ぐ。
    """
    replaced = "".join(
        character if character.isalnum() or character in _SAFE_EXTRA_CHARS else "_"
        for character in text
    )
    trimmed = replaced[:MAX_STEM_COMPONENT].strip("_")
    return trimmed if trimmed else fallback


def build_output_stem(
    source_id: str, column_label: str | None, method_name: str, index: int
) -> str:
    """対象・列・手法・ジョブ番号から出力ファイル名の幹を決定的に導出する（要件 7.6）。

    形は ``{対象名}__{列}__{手法名}__{ジョブ番号}`` である。対象名は ``source_id`` の
    最後のパス要素から拡張子を除いたもので、パス区切りと親ディレクトリ参照は除去する
    （設計の Security Considerations）。

    **列は固定の位置に入る。** 位置による列指定（``"1"`` など）は数字の綴りになるため、
    位置が動くとジョブ番号と見分けが付かなくなる。列を対象と手法の間に固定し、番号を
    常に末尾に置くことで、名前を読む側は要素の位置だけで区別できる。

    **y 列が 1 つだけでも同じ規則で組み立てる**（要件 7.6）。件数によって形が変わると
    出力名の読み取り規則が 2 通りになり、利用者側の後処理が y 列の数に依存する。

    **列の識別子にも対象名と同じ置換規則を適用する。** 安全でない文字の置換規則を
    所有するのは本モジュールだけであり、:func:`~curvefit.readers.column_label` は素の
    文字列を返す（設計の readers の Postconditions）。2 か所で置換すると規則が分岐する。

    ``column_label`` が ``None`` になるのは系列を直接渡された経路だけであり、その経路は
    出力物を書かない（設計の types の Postconditions）。名前の形を 1 通りに保つため、
    その場合も :data:`FALLBACK_COLUMN_NAME` を同じ位置に置く。

    **ジョブ番号は常に付ける。** 設計は「異なる入力が同一の stem に正規化される場合に
    付与する」と書いているが、本関数は 1 ジョブ分の情報しか受け取らないため、他の
    ジョブと衝突するかどうかをここでは判定できない。判定できない条件で付与を省くと、
    別ディレクトリの同名ファイル（``run1/sample.csv`` と ``run2/sample.csv``）や、
    安全でない文字の置換で同じ名前に潰れた 2 入力が、互いの出力を黙って上書きする。
    要件 7.6 が防ごうとしているのはまさにこれであり、上書きの代償（解析結果の消失）は
    名前が長くなる代償と釣り合わない。付与を条件付きにするなら、衝突の検出はジョブ
    一覧を持つ ``pipeline`` の責務として設計を改める必要がある。

    ジョブ順序は ``pipeline`` が決定的に定める（要件 8.2）ため、番号を含めても同一設定・
    同一入力の再実行は同一の名前になる。ハッシュや実行時刻は用いない。

    :param source_id: 入力の識別子。ファイルパスでも呼び出し元のラベルでもよい
    :param column_label: y 列の識別子（指定の綴り）。系列を直接渡された経路では ``None``
    :param method_name: 適用した手法の識別名
    :param index: ジョブ番号。0 起点
    :return: 拡張子を含まないファイル名。パス区切りと親ディレクトリ参照を含まない
    :raises ValueError: ``index`` が負の場合。ジョブ番号は 0 起点であり、負の値は
        呼び出し側の誤りである
    """
    if index < 0:
        raise ValueError(f"ジョブ番号は 0 以上でなければならない（実際: {index}）")

    source = _safe_component(
        PurePosixPath(_last_path_component(source_id)).stem, FALLBACK_SOURCE_NAME
    )
    column = _safe_component(column_label or "", FALLBACK_COLUMN_NAME)
    method = _safe_component(method_name, FALLBACK_METHOD_NAME)
    return STEM_SEPARATOR.join((source, column, method, f"{index:0{JOB_INDEX_WIDTH}d}"))


def _output_not_writable(directory: Path, detail: str) -> ConfigViolation:
    """出力先が使えないことを表す違反を組み立てる（要件 7.7）。

    どの出力先が、なぜ使えないかを両方載せる。次の行動は出力先の変更か権限の修正で
    あり、どちらであるかは理由が分からないと決められない。
    """
    return ConfigViolation(
        kind=ViolationKind.OUTPUT_NOT_WRITABLE,
        location=OUTPUT_DIRECTORY_LOCATION,
        message=f"出力先 {directory} に書き込めない: {detail}",
    )


def _is_present(path: Path) -> bool:
    """その名前が既に何かに使われているかを返す。

    壊れた symlink は :meth:`Path.exists` では偽になるが、名前としては塞がっている。
    「存在しない」と扱うと作成できるかのように見えるため、存在する側に数える。
    """
    return path.exists() or path.is_symlink()


def _nearest_existing(directory: Path) -> Path:
    """存在する最も近い祖先を返す。出力先が未作成の場合の判定対象になる。

    出力先そのものが存在しないことは失敗ではない。実際に作る階層
    （``{output_dir}/curves/`` など）は書き出し時に作られるため、判定すべきは
    「そこに作れるか」である。
    """
    candidate = directory
    while not candidate.exists() and not candidate.is_symlink():
        parent = candidate.parent
        if parent == candidate:
            return candidate
        candidate = parent
    return candidate


def _probe_writable(directory: Path) -> str | None:
    """ディレクトリに実際に書けるかを試す。書ければ ``None``、書けなければ理由。

    権限ビットの読み取り（``os.access``）ではなく実書き込みで判定する。読み取り専用で
    マウントされた領域や ACL による拒否は権限ビットに現れず、判定が通ってから書き込みで
    初めて失敗する。要件 7.7 は「処理を開始せず」報告することを求めており、数百件の
    当てはめを終えてから書けないと分かるのでは意味がない。

    試験用のファイルは必ず削除する。検査が出力先に痕跡を残すと、再実行のたびに内容の
    異なるファイルが増え、出力ディレクトリの同一性（要件 8.2）が崩れる。
    """
    try:
        descriptor, name = tempfile.mkstemp(prefix=_PROBE_PREFIX, dir=directory)
    except OSError as error:
        return str(error)
    os.close(descriptor)
    try:
        Path(name).unlink()
    except OSError as error:  # pragma: no cover - 作成できて削除できない環境は想定外
        return str(error)
    return None


def check_output_writable(directory: Path) -> tuple[ConfigViolation, ...]:
    """出力先が書き込み可能かを検証する（要件 7.7）。

    違反は **値として** 返す。実行前ゲートは全違反を一括収集して一度に提示するため
    （設計の Error Strategy）、ここで例外を送出すると収集が 1 件目で打ち切られ、利用者は
    修正の往復を強いられる。書けない出力先は利用者の設定誤りであって、資源の枯渇では
    ない。

    **作るのは最終要素 1 階層だけである。** 親が存在すれば出力先そのものが未作成でも
    違反にしない（書き出し時に作る）。親の連なりごと存在しない指定は違反として実行前に
    拒否する（設計の「出力ディレクトリの作成方針」）。``--output-dir ./a/very/deep/typo``
    のような打ち間違いを黙って作ってしまうと、処理は成功で終わるのに利用者が見に行った
    場所には何も無い。1 階層の新規作成は打ち間違いと正当な新規指定を区別できないため
    許容し、2 階層以上の欠落は打ち間違いとして扱う。``{output_dir}/curves/``
    ``{output_dir}/plots/`` の下位ディレクトリは本モジュールが作るため、この規則の
    対象外である。

    親が存在する場合は、存在する最も近い祖先に実際に書けるかで判定する。

    :param directory: 検証する出力ディレクトリ
    :return: 違反の並び。書き込み可能なら空のタプル
    """
    parent = directory.parent
    if not _is_present(parent):
        return (
            _output_not_writable(
                directory,
                f"親ディレクトリ {parent} が存在しない"
                "（作成するのは最終要素 1 階層のみ）。"
                "出力先の綴りを確認するか、親ディレクトリを先に作成する",
            ),
        )

    existing = _nearest_existing(directory)

    if not existing.is_dir():
        detail = (
            f"{existing} はディレクトリではない"
            if existing == directory
            else f"経路上の {existing} がディレクトリではない"
        )
        return (_output_not_writable(directory, detail),)

    reason = _probe_writable(existing)
    if reason is not None:
        detail = reason if existing == directory else f"作成先の {existing} に書けない（{reason}）"
        return (_output_not_writable(directory, detail),)

    return ()
