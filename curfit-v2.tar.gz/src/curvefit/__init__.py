"""入力データに対するフィッティングを一括かつ再現可能に実行するライブラリ。

公開 API は :mod:`curvefit.api` と :mod:`curvefit.types` からのみ再エクスポートする
（設計の File Structure Plan）。基盤ライブラリ（lmfit / SciPy / matplotlib）固有の型を
ここから露出させてはならない。

::

    import curvefit

    series = curvefit.read_arrays(x, y, source_id="実験A", method_name="gauss")
    outcome = curvefit.fit_series(series, curvefit.MethodSpec(
        name="gauss", kind="builtin", builtin="gaussian"
    ))

    report = curvefit.run_from_config(Path("run.toml"))

**内部の実装は再エクスポートしない。** ジョブ展開・モデル解決・当てはめエンジン・
出力の書き出しは、実行経路（``pipeline``）の内側にある。ここから露出させると、
実行前ゲートを迂回した呼び出しが書けるようになり、要件 8.5 の「設定の不備では処理を
開始しない」が保証でなくなる。

**取り込みはプロセス大域の状態を変えない。** とくに描画バックエンドを書き換えない
（``plotting``）。要件 9.1 が想定する対話環境からの利用では、``import curvefit`` が
利用者の表示設定を壊さないことが前提になる。
"""

from __future__ import annotations

from curvefit.api import (
    BatchReport,
    ColumnSpec,
    ConfigViolation,
    ExecutionRecord,
    FailurePolicy,
    FailureReason,
    InputSpec,
    MethodSpec,
    OutlierSpec,
    OutputSpec,
    OverrideRecord,
    PreflightAborted,
    PreflightResult,
    PreprocessSpec,
    ProgressObserver,
    RunConfig,
    SmootherKind,
    UnexpectedConfigViolation,
    ViolationKind,
    fit_series,
    read_arrays,
    read_delimited,
    read_frame,
    run_batch,
    run_from_config,
)
from curvefit.types import (
    CurveData,
    DataSeries,
    FitFailure,
    FitOutcome,
    FitSuccess,
    FloatArray,
    GoodnessOfFit,
    OutlierPoint,
    ParameterEstimate,
    PreprocessReport,
)

__version__ = "0.1.0"

__all__ = [
    "BatchReport",
    "ColumnSpec",
    "ConfigViolation",
    "CurveData",
    "DataSeries",
    "ExecutionRecord",
    "FailurePolicy",
    "FailureReason",
    "FitFailure",
    "FitOutcome",
    "FitSuccess",
    "FloatArray",
    "GoodnessOfFit",
    "InputSpec",
    "MethodSpec",
    "OutlierPoint",
    "OutlierSpec",
    "OutputSpec",
    "OverrideRecord",
    "ParameterEstimate",
    "PreflightAborted",
    "PreflightResult",
    "PreprocessReport",
    "PreprocessSpec",
    "ProgressObserver",
    "RunConfig",
    "SmootherKind",
    "UnexpectedConfigViolation",
    "ViolationKind",
    "__version__",
    "fit_series",
    "read_arrays",
    "read_delimited",
    "read_frame",
    "run_batch",
    "run_from_config",
]
