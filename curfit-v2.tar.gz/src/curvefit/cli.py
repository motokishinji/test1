"""コマンドライン入口（要件 6.3、9.2、9.4、9.5）。

本モジュールが所有するのは次の 3 点である。

1. **引数の配線** — 設定ファイル・入力指定・出力先などの実行時引数を集め、
   :func:`~curvefit.api.run_from_config` の ``overrides`` として **そのまま** 渡す
2. **進捗の描画**（要件 6.3） — :class:`~curvefit.pipeline.ProgressObserver` の端末実装。
   ``pipeline`` は通知までを責任範囲とし、描画を持たない
3. **終了コードの決定**（要件 9.5） — 全件成功・1 件以上の失敗または中断・実行前検証での
   停止の 3 状態を :class:`ExitCode` に写す

**優先順位を判断しない**（要件 9.4）。設定ファイルと実行時引数で同じ項目が指定された
場合に実行時引数を優先する規則は ``config`` の :func:`~curvefit.config._apply_overrides`
だけが実装する。本モジュールは設定ファイルを読まず（:mod:`tomllib` を取り込まない）、
:func:`~curvefit.config.load_config` も呼ばない。**比較する材料を持たない** ことが、
実装箇所が 1 か所であることの構造的な裏づけである。上書きできる項目の表記も
:data:`~curvefit.config.OVERRIDABLE_KEYS` が権威であり、本モジュールは引数と表記の
対応（:data:`OVERRIDE_ARGUMENTS`）を持つに留める。

**違反は値として受け取る。** :func:`~curvefit.api.run_from_config` は違反を
:class:`~curvefit.preflight.PreflightResult` として返す（例外ではない）。
:class:`~curvefit.api.PreflightAborted` は :func:`~curvefit.api.fit_series` 専用であり、
本モジュールの経路には現れない。

出力先について
--------------

**人が読む出力はすべて標準エラー出力へ書く。** 進捗も集計も違反も同じである。本コマンドの
成果は出力ディレクトリのファイルと終了コードであり、標準出力はどの実行状態でも空に保つ。
進捗を標準出力に混ぜると ``curvefit run.toml > result.txt`` のような単純な取り回しが
壊れ、後から機械可読な出力を標準出力に足す余地も失われる。``--help`` と ``--version``
だけは :mod:`argparse` の規約どおり標準出力に出る（利用者が明示的に要求した内容であり、
実行の副産物ではない）。

依存方向は ``cli`` が終端であり、**ライブラリ側のどのモジュールからも import されない**
（設計の Allowed Dependencies）。取り込むのは公開ファサード :mod:`curvefit.api` だけで
あり、``pipeline`` や ``config`` の内部には触れない。
"""

from __future__ import annotations

import argparse
import codecs
import sys
from collections.abc import Mapping, Sequence
from enum import IntEnum
from pathlib import Path
from typing import TextIO

from curvefit import __version__
from curvefit.api import (
    BatchReport,
    ConfigViolation,
    FailurePolicy,
    FitOutcome,
    FitSuccess,
    PreflightResult,
    ViolationKind,
    run_from_config,
)

__all__ = ["ExitCode", "TerminalProgress", "build_parser", "main"]


class ExitCode(IntEnum):
    """コマンドの終了状態（要件 9.5、設計の cli ブロック）。

    3 状態を区別できることが要件である。利用者は「失敗が出た」と「そもそも実行して
    いない」を取り違えると、次に見る場所を間違える。前者は入力データを、後者は設定を
    見ることになる。
    """

    SUCCESS = 0
    """全処理単位が成功した。"""

    PARTIAL_FAILURE = 1
    """1 件以上の失敗、または中断（要件 6.5、10.3）。出力物はそこまでの分が残る。"""

    CONFIG_ERROR = 2
    """実行前検証で停止した（要件 8.5）。処理単位を 1 件も実行していない。

    :mod:`argparse` が引数の誤りに対して用いる終了コードと同じ値である。どちらも
    「利用者の指定を直すまで実行できない」状態であり、区別する意味がない。
    """


OVERRIDE_ARGUMENTS: tuple[tuple[str, str], ...] = (
    ("failure_policy", "failure_policy"),
    ("input.columns.weight", "weight_column"),
    ("input.columns.x", "x_column"),
    ("input.columns.y", "y_column"),
    ("input.delimiter", "delimiter"),
    ("input.header", "header"),
    ("input.paths", "input_paths"),
    ("output.directory", "output_directory"),
    ("output.write_curve", "write_curve"),
    ("output.write_plot", "write_plot"),
    ("output.write_summary", "write_summary"),
)
"""設定ファイル内の位置を表す表記と、対応する引数の格納先。

**表記の権威は :data:`~curvefit.config.OVERRIDABLE_KEYS` にある。** ここにあるのは
コマンドライン引数との対応だけであり、上書きできるかどうかの判断ではない。表記に
無いものを渡せば ``config`` が違反として返す。

並びは表記順に固定する。上書きの適用順は ``config`` が
:data:`~curvefit.config.OVERRIDABLE_KEYS` の順で決めるため結果には影響しないが、
指定の与え方によって本モジュールの振る舞いが変わる余地を残さない。
"""

BOM = codecs.BOM_UTF8
"""UTF-8 の BOM。TOML はこれを認めない（:func:`_bom_violation`）。"""

EPILOG = """\
セキュリティ上の注意:
  設定ファイルの expression に書いた数式文字列は評価される。第三者から受け取った設定
  ファイルをそのまま実行することは、任意の Python コードを実行することと同等のリスクを
  持つ。実行前に中身を読むこと。

CSV の読み取り精度:
  本コマンドは CSV を float_precision="round_trip" で読み、値を最終ビットまで保つ。
  pandas.read_csv を自分で呼んだ表をライブラリに渡す場合は、同じ指定を行うこと。既定の
  解釈器は値の約 46% の最下位ビットを変え、劣化した値はライブラリ側では回復できない。

終了コード:
  0  全処理単位が成功した
  1  1 件以上が失敗した、または中断した
  2  実行前検証で停止した。処理単位を 1 件も実行していない
"""


def _bom_violation(path: Path) -> ConfigViolation | None:
    """設定ファイル先頭の UTF-8 BOM を違反として名指しする。

    BOM 付きの設定ファイルは :mod:`tomllib` に届くと ``Invalid statement (at line 1,
    column 1)`` という一般的な構文誤りになる。利用者の画面には正しく見える 1 行目が
    指されるため、原因に到達できない。Windows のメモ帳が既定でこの保存を行うため、
    現実に踏む経路である。

    **読めないこと自体は本関数の担当ではない。** 不存在・ディレクトリ・権限は
    ``config`` が違反として報告する（実行前に停止する経路を値 1 本に保つ）。ここで
    別の報告を作ると同じ状況が 2 通りの書式で出る。

    :param path: 設定ファイルの位置
    :return: BOM があれば違反 1 件、無ければ（読めない場合も）``None``
    """
    try:
        with path.open("rb") as handle:
            prefix = handle.read(len(BOM))
    except OSError:
        return None
    if prefix != BOM:
        return None
    return ConfigViolation(
        kind=ViolationKind.CONFIG_INVALID,
        location=str(path),
        message=(
            "設定ファイルの先頭に UTF-8 の BOM（EF BB BF）がある。TOML は BOM を認めない"
            "ため、以降の記述は 1 行目から構文誤りとして扱われる。Windows のメモ帳が既定で"
            "付けるものが該当する。編集器で「UTF-8（BOM 無し）」として保存し直す"
        ),
    )


def _job_target(outcome: FitOutcome) -> str:
    """進捗 1 行が指す対象の表記（要件 6.3）。

    **対象と手法の間に列を挟む。** 1 つのファイルに測定チャネルが複数ある場合
    （要件 1.11）、対象と手法だけでは複数の行が完全に同一の文字列になり、どのチャネルの
    進捗なのかが読み取れない。実行ログが同じ理由で列を併記している（要件 8.4）。

    列の綴りを持たないのは系列を直接渡す経路だけであり（``column_label`` が ``None``）、
    その場合は対象と手法だけを出す。この経路は :func:`~curvefit.api.fit_series` 専用で
    本モジュールからは到達しないが、綴りの有無で場合分けする側を 1 か所に閉じておく。
    """
    if outcome.column_label is None:
        return f"{outcome.source_id} / {outcome.method_name}"
    return f"{outcome.source_id} / {outcome.column_label} / {outcome.method_name}"


class TerminalProgress:
    """進捗の端末表示（要件 6.3、設計の cli ブロックの Postconditions）。

    ``pipeline`` は :class:`~curvefit.pipeline.ProgressObserver` へ通知するところまでを
    責任範囲とし、描画を持たない。本クラスがその実装である。

    **総処理単位数と総入力数の双方を出す。** 処理単位数は入力数 × 列数 × 手法数であり、
    利用者が数えるファイル数と一致しない（要件 1.11、6.8）。片方だけを出すと
    「3 ファイルを指定したのに 6 件と表示される」形になり、進捗が何に対する進捗なのか
    読み取れない。

    端末に直結している場合は 1 行を上書きして更新し、リダイレクト先では 1 件 1 行で
    残す。数百件のバッチ（要件 10.1）でログに流し込むと上書き用の制御文字だけが増え、
    後から読む側の役に立たない。上書きの詰め物は文字数で数えるため、全角を含む行では
    見た目の余白が残ることがある。消え残りを作らないことを優先する。
    """

    def __init__(self, stream: TextIO) -> None:
        self._stream: TextIO = stream
        self._interactive: bool = bool(getattr(stream, "isatty", lambda: False)())
        self._pending: int = 0
        """上書き待ちの行の文字数。0 なら上書き待ちの行は無い。"""

    def _write(self, text: str, *, transient: bool) -> None:
        """1 行を書く。``transient`` は端末直結時に上書きしてよい行を表す。"""
        if transient and self._interactive:
            self._stream.write(f"\r{text.ljust(self._pending)}")
            self._pending = len(text)
        else:
            if self._pending:
                self._stream.write("\n")
                self._pending = 0
            self._stream.write(f"{text}\n")
        self._stream.flush()

    def on_start(self, total_jobs: int, total_sources: int) -> None:
        """実行開始を示す（要件 6.3）。"""
        self._write(
            f"開始: 入力 {total_sources} 件 / 処理単位 {total_jobs} 件（入力 × 列 × 手法）",
            transient=False,
        )

    def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None:
        """処理単位 1 件の完了を示す（要件 6.3）。

        対象・列・手法を併記する（:func:`_job_target`）。数百件のバッチでは、件数だけの
        進捗は止まっている箇所を指せない。
        """
        state = "成功" if isinstance(outcome, FitSuccess) else "失敗"
        self._write(f"[{done}/{total}] {state} {_job_target(outcome)}", transient=True)

    def on_finish(self, report: BatchReport) -> None:
        """集計を示す（要件 6.6）。中断した場合はその旨を添える。"""
        suffix = "（中断した。残りの処理単位は実行していない）" if report.aborted else ""
        self._write(
            f"完了: 成功 {report.n_success} 件 / 失敗 {report.n_failure} 件{suffix}",
            transient=False,
        )


class FailureOnlyProgress(TerminalProgress):
    """個別の失敗のみを報告する（``--quiet`` 用。要件 6.4、6.5）。

    ``--quiet`` は「進捗と集計を表示しない。**違反と失敗の報告は表示する**」と約束して
    いる。観測者を丸ごと外すとこの約束が破れ、失敗を含むバッチが終了コードだけを残して
    黙る。数百件のバッチで何が落ちたのかを知るために実行ログを開かせるのは、
    「失敗した対象と失敗理由を記録する」（要件 6.4）を端末の側で放棄することにあたる。

    進捗（``on_start`` / 成功の各行 / ``on_finish``）は抑止し、失敗した処理単位のみを
    出す。上書きは使わない。消えてよい行ではないためである。
    """

    def on_start(self, total_jobs: int, total_sources: int) -> None:
        """表示しない。"""

    def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None:
        """失敗した処理単位のみを報告する。"""
        if isinstance(outcome, FitSuccess):
            return
        self._write(
            f"[{done}/{total}] 失敗 {_job_target(outcome)}: {outcome.message}",
            transient=False,
        )

    def on_finish(self, report: BatchReport) -> None:
        """集計は表示しない。中断したことだけは伝える（要件 6.5）。"""
        if report.aborted:
            self._write(
                "中断した。残りの処理単位は実行していない", transient=False
            )


def build_parser() -> argparse.ArgumentParser:
    """引数の定義を組み立てる（要件 9.2、9.4）。

    実行に要るのは **設定ファイル・入力指定・出力先** の 3 つだけである（要件 9.2）。
    残りの引数は設定ファイルの項目を実行時に差し替えるためのものであり、いずれも
    :data:`~curvefit.config.OVERRIDABLE_KEYS` の表記に 1 対 1 で対応する。

    真偽の指定は ``--plot`` / ``--no-plot`` の対で受け取り、既定を ``None`` に置く。
    「指定しなかった」と「false を指定した」は別物である。前者は設定ファイルの値を
    そのまま使い、後者は上書きとして記録される（要件 9.4）。見出し行の指定
    （要件 1.6）に至っては、未指定・あり・なしの 3 状態が読み取り結果を変える。

    **列を受け取る引数は、設定ファイルの列の並びを 1 件に置き換える**（設計の cli
    ブロック）。要件 9.2 が求めているのは設定ファイルに記述できるすべての実行条件を
    コマンドから実行できることであり、引数の側に並び（要件 1.11）の表現力を持たせる
    ことではない。並びを引数で書けるようにすると、上書きの単位が並び全体なのか
    1 要素なのかが曖昧になる。複数列と位置指定は設定ファイルが担う。
    """
    parser = argparse.ArgumentParser(
        prog="curvefit",
        description="入力データに対するフィッティングを一括して実行する",
        epilog=EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"curvefit {__version__}")
    parser.add_argument(
        "config",
        nargs="?",
        type=Path,
        help="設定ファイル（TOML）。省略すると使い方を表示して終了する",
    )
    parser.add_argument(
        "-i",
        "--input",
        dest="input_paths",
        action="append",
        metavar="PATH",
        help="入力の位置。ファイル・ディレクトリ・ワイルドカードを指定できる。"
        "複数回指定できる（設定ファイルの input.paths を置き換える）",
    )
    parser.add_argument(
        "-o",
        "--output",
        dest="output_directory",
        metavar="DIR",
        help="出力先ディレクトリ（設定ファイルの output.directory を置き換える）",
    )
    parser.add_argument(
        "--delimiter",
        metavar="SEP",
        help=(
            "区切り文字。省略時は設定ファイルの指定、それも無ければ拡張子から決める。"
            "2 文字以上は正規表現として解釈する。桁揃えの空白で区切られた装置出力には "
            r"'\s+' を指定する（' ' 1 文字では読めない）"
        ),
    )
    parser.add_argument(
        "--header",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="先頭行を見出しとして扱うか。指定しない場合は設定ファイルに従う",
    )
    parser.add_argument(
        "--x-column",
        dest="x_column",
        metavar="NAME",
        help="x 軸の列名。位置（整数）での指定は設定ファイルで行う",
    )
    parser.add_argument(
        "--y-column",
        dest="y_column",
        metavar="NAME",
        help="y 軸の列名。設定ファイルの列の並びを、この 1 件に置き換える。"
        "複数列と位置（整数）での指定は設定ファイルで行う",
    )
    parser.add_argument(
        "--weight-column",
        dest="weight_column",
        metavar="NAME",
        help="測定誤差 σ の列名。y 列と同じく、並びをこの 1 件に置き換える。"
        "複数列と位置（整数）での指定は設定ファイルで行う",
    )
    parser.add_argument(
        "--summary",
        dest="write_summary",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="サマリ CSV を書き出すか",
    )
    parser.add_argument(
        "--plot",
        dest="write_plot",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="グラフ画像を書き出すか",
    )
    parser.add_argument(
        "--curve",
        dest="write_curve",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="当てはめ曲線と残差の CSV を書き出すか",
    )
    parser.add_argument(
        "--failure-policy",
        dest="failure_policy",
        choices=[policy.value for policy in FailurePolicy],
        help="個別の失敗が出たときに継続するか最初の失敗で止めるか",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="進捗と集計を表示しない。違反と失敗の報告は表示する",
    )
    return parser


def collect_overrides(args: argparse.Namespace) -> dict[str, object]:
    """指定された実行時引数を、設定ファイル内の位置を表す表記の写像にする（要件 9.4）。

    **値は解釈せずそのまま載せる。** 文字列は文字列のまま、真偽は真偽のまま渡す。
    型の妥当性も上書きの可否も ``config`` が判断する。ここで値を作り替えると、
    設定ファイル経由と実行時引数経由で同じ項目が別の規則で解釈されうる。

    指定されなかった引数（``None``）は写像に載せない。載せると「未指定」が
    「``None`` の指定」として上書き記録に現れ、設定ファイルの値を消してしまう。

    :param args: 解析済みの引数
    :return: 表記 → 値 の写像。:func:`~curvefit.api.run_from_config` にそのまま渡す
    """
    overrides: dict[str, object] = {}
    for key, destination in OVERRIDE_ARGUMENTS:
        value = getattr(args, destination)
        if value is not None:
            overrides[key] = value
    return overrides


def _report_violations(violations: Sequence[ConfigViolation], stream: TextIO) -> None:
    """検出した違反を **全件** 提示する（設計の Error Handling）。

    1 件ずつ直しては実行し直す往復を強いないために ``preflight`` と ``config`` は全違反を
    集めて返す。提示側で先頭の 1 件に絞ると、その配慮が失われる。

    **各行に位置を書く。** 数百件のバッチでは、どこが原因かを示さない報告は実質的に
    無価値である（steering ``tech.md``）。並びは受け取った順のままにする。``config`` と
    ``preflight`` が要件 8.2 のために固定した順序であり、並べ替える理由がない。
    """
    stream.write(
        f"実行前検証で {len(violations)} 件の違反が見つかった。"
        "処理単位を 1 件も実行していない\n"
    )
    for violation in violations:
        stream.write(f"  [{violation.kind.value}] {violation.location}: {violation.message}\n")
    stream.flush()


def _exit_code(result: BatchReport) -> ExitCode:
    """集計結果を終了コードに写す（要件 9.5）。

    中断（要件 6.5、10.3）も失敗として扱う。中断した実行では残りの処理単位が実行されて
    おらず、成功として返すと呼び出し元の自動化が次の段階へ進んでしまう。
    """
    if result.n_failure > 0 or result.aborted:
        return ExitCode.PARTIAL_FAILURE
    return ExitCode.SUCCESS


def main(argv: Sequence[str] | None = None) -> int:
    """コマンドの入口（要件 9.2、9.5）。

    段階は **引数の解析 → 設定ファイルの下読み → 実行 → 終了コードの決定** の順である。
    実行そのものは公開ファサード :func:`~curvefit.api.run_from_config` に委ね、本関数は
    読み込みも検証も当てはめも行わない。要件 9.3 の「CLI とライブラリで同一結果」は、
    この委譲によって構造的に成立する。

    引数を 1 つも与えなかった場合は使い方を表示して正常終了する。実行対象が無いことは
    失敗ではなく、また実行前に停止した設定の誤り（:attr:`ExitCode.CONFIG_ERROR`）でも
    ない。

    :param argv: コマンドライン引数。``None`` なら :data:`sys.argv` から取る
    :return: :class:`ExitCode` のいずれか
    """
    parser = build_parser()
    args = parser.parse_args(argv)
    stream: TextIO = sys.stderr

    if args.config is None:
        parser.print_help()
        return ExitCode.SUCCESS

    bom = _bom_violation(args.config)
    if bom is not None:
        _report_violations((bom,), stream)
        return ExitCode.CONFIG_ERROR

    observer = FailureOnlyProgress(stream) if args.quiet else TerminalProgress(stream)
    overrides: Mapping[str, object] = collect_overrides(args)
    result = run_from_config(args.config, overrides, observer)

    if isinstance(result, PreflightResult):
        _report_violations(result.violations, stream)
        return ExitCode.CONFIG_ERROR
    return _exit_code(result)


if __name__ == "__main__":
    raise SystemExit(main())
