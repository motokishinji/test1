"""ユーザーマニュアルが実装から取り残されないことを検査する。

ドキュメントは実装より静かに古くなる。誰も落ちないからである。ここでは 2 方向を
固定し、古くなった時点で検査を落とす。

1. `docs/manual_facts.py` の宣言と、実装が持つ値が一致すること
2. 宣言に現れるすべての名前が、生成スクリプトの本文に literal として現れること

1 だけでは「宣言を直したがドキュメント本文を直していない」状態を通してしまい、
2 だけでは「実装に項目が増えたが宣言にもドキュメントにも無い」状態を通してしまう。
両方あって初めて、実装の変更がドキュメントの更新を強制する。

生成物（.pptx / .docx）そのものは検査しない。ZIP の内部に生成時刻が入るため、
中身が同じでもバイト列が毎回変わり、比較が意味を持たないためである。代わりに
「生成スクリプトが最新の事実を含み、かつ実行できること」を検査する。
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path
from types import ModuleType

import pytest

from curvefit import config, errors, writers
from curvefit.engines import smoothing
from curvefit.execution import ExecutionRecord
from curvefit.models import registry

DOCS = Path(__file__).resolve().parents[2] / "docs"
"""生成スクリプトと宣言の置き場所。"""


def _load_manual_facts() -> ModuleType:
    """docs/manual_facts.py を読み込む。

    docs はパッケージではないため、通常の import 経路には乗らない。位置を指定して
    読み込むことで、リポジトリのどこから pytest を起動しても同じものを指す。
    """
    path = DOCS / "manual_facts.py"
    spec = importlib.util.spec_from_file_location("manual_facts", path)
    assert spec is not None and spec.loader is not None, f"読み込めない: {path}"
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


facts = _load_manual_facts()


class TestTheDeclaredFactsMatchTheImplementation:
    """宣言と実装の一致。実装に項目を足す・消す・綴りを変えると落ちる。"""

    @pytest.mark.parametrize(
        ("declared", "actual", "where"),
        [
            (facts.TOP_LEVEL_KEYS, config.TOP_LEVEL_KEYS, "config.TOP_LEVEL_KEYS"),
            (facts.INPUT_KEYS, config.INPUT_KEYS, "config.INPUT_KEYS"),
            (facts.COLUMNS_KEYS, config.COLUMNS_KEYS, "config.COLUMNS_KEYS"),
            (facts.METHOD_KEYS, config.METHOD_KEYS, "config.METHOD_KEYS"),
            (facts.BOUND_KEYS, config.BOUND_KEYS, "config.BOUND_KEYS"),
            (facts.PREPROCESS_KEYS, config.PREPROCESS_KEYS, "config.PREPROCESS_KEYS"),
            (facts.OUTLIER_KEYS, config.OUTLIER_KEYS, "config.OUTLIER_KEYS"),
            (facts.OUTPUT_KEYS, config.OUTPUT_KEYS, "config.OUTPUT_KEYS"),
            (facts.OVERRIDABLE_KEYS, config.OVERRIDABLE_KEYS, "config.OVERRIDABLE_KEYS"),
            (facts.SUMMARY_COLUMNS, writers.SUMMARY_COLUMNS, "writers.SUMMARY_COLUMNS"),
            (facts.CURVE_COLUMNS, writers.CURVE_COLUMNS, "writers.CURVE_COLUMNS"),
            (
                facts.PREPROCESS_COLUMNS,
                writers.PREPROCESS_COLUMNS,
                "writers.PREPROCESS_COLUMNS",
            ),
        ],
    )
    def test_key_and_column_lists_agree(
        self, declared: tuple[str, ...], actual: tuple[str, ...], where: str
    ) -> None:
        assert tuple(declared) == tuple(actual), (
            f"{where} が docs/manual_facts.py の宣言と食い違う。"
            f"実装を変えたなら、宣言と 4 つの生成スクリプトの本文も直すこと"
        )

    def test_the_number_of_significant_digits_agrees(self) -> None:
        assert facts.SUMMARY_SIGNIFICANT_DIGITS == writers.SUMMARY_SIGNIFICANT_DIGITS

    def test_the_violation_kinds_agree(self) -> None:
        assert tuple(facts.VIOLATION_KINDS) == tuple(kind.value for kind in errors.ViolationKind)

    def test_the_failure_reasons_agree(self) -> None:
        assert tuple(facts.FAILURE_REASONS) == tuple(
            reason.value for reason in errors.FailureReason
        )

    def test_the_builtin_model_names_agree(self) -> None:
        assert tuple(facts.BUILTIN_MODELS) == tuple(registry.BUILTIN_MODELS)

    def test_the_smoothers_and_their_options_agree(self) -> None:
        actual = {
            kind.value: tuple(options)
            for kind, options in smoothing.SMOOTHER_OPTION_NAMES.items()
        }
        assert {name: tuple(opts) for name, opts in facts.SMOOTHERS.items()} == actual

    def test_the_execution_record_keys_agree(self) -> None:
        # 実行記録は dataclass であり、書き出される JSON の鍵は場の名前に一致する。
        actual = tuple(ExecutionRecord.__dataclass_fields__)
        assert tuple(facts.EXECUTION_RECORD_KEYS) == actual


class TestEveryDeclaredNameAppearsInTheManuals:
    """宣言だけ直してドキュメント本文を直し忘れた状態を落とす。"""

    @staticmethod
    def _source(script: str) -> str:
        path = DOCS / script
        assert path.exists(), f"生成スクリプトが無い: {path}"
        return path.read_text(encoding="utf-8")

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_generator_exists_and_names_its_output(self, script: str) -> None:
        source = self._source(script)
        assert facts.GENERATORS[script] in source, (
            f"{script} が {facts.GENERATORS[script]} を書き出していない"
        )

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_names_common_to_every_manual_appear(self, script: str) -> None:
        """スライドと詳細版の双方が触れる事実。"""
        source = self._source(script)
        common = (
            *facts.TOP_LEVEL_KEYS,
            *facts.INPUT_KEYS,
            *facts.COLUMNS_KEYS,
            *facts.PREPROCESS_KEYS,
            *facts.OUTPUT_KEYS,
            *facts.SMOOTHERS,
        )
        missing = sorted({name for name in common if name not in source})
        assert not missing, f"{script} に現れない名前がある: {missing}"

    @pytest.mark.parametrize(
        "script", sorted(s for s in facts.GENERATORS if "docx" in s)
    )
    def test_the_names_only_the_detailed_manual_carries_appear(self, script: str) -> None:
        """詳細版（Word）だけが列挙する事実。スライドには課さない。"""
        source = self._source(script)
        detailed: list[str] = []
        for group in facts.DETAILED_ONLY:
            detailed.extend(getattr(facts, group))
        missing = sorted({name for name in detailed if name not in source})
        assert not missing, f"{script} に現れない名前がある: {missing}"


class TestTheGeneratorsStillRun:
    """本文を直したつもりでスクリプトを壊した状態を落とす。"""

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_generator_compiles(self, script: str) -> None:
        # 実行には python-pptx / python-docx が要る。開発依存に含めていないため、
        # ここでは構文と名前解決の手前までを見る。生成そのものは docs/README.md の
        # 手順で人が回す。
        source = (DOCS / script).read_text(encoding="utf-8")
        compile(source, str(DOCS / script), "exec")

    def test_the_generators_are_the_only_python_files_under_docs(self) -> None:
        # 置き忘れた実験用スクリプトが「マニュアルの一部」に見えないようにする。
        found = {path.name for path in DOCS.glob("*.py")}
        expected = set(facts.GENERATORS) | {"manual_facts.py"}
        assert found == expected, f"docs/ の Python ファイルが想定と違う: {found ^ expected}"


class TestTheGeneratedDocumentsArePresent:
    """生成物そのものが版管理から落ちていないことを見る。"""

    @pytest.mark.parametrize("script", sorted(facts.GENERATORS))
    def test_the_document_exists(self, script: str) -> None:
        document = DOCS / facts.GENERATORS[script]
        assert document.exists(), (
            f"{document.name} が無い。docs/README.md の手順で生成すること"
        )
        assert document.stat().st_size > 10_000, f"{document.name} が小さすぎる"


def test_the_repository_has_no_stray_manual_outside_docs() -> None:
    """マニュアルの置き場所を docs/ の 1 か所に保つ。"""
    root = DOCS.parent
    stray = sorted(
        path.name
        for pattern in ("*.pptx", "*.docx")
        for path in root.glob(pattern)
    )
    assert not stray, f"docs/ の外にマニュアルがある: {stray}"


def test_the_python_used_to_run_pytest_can_import_the_facts() -> None:
    # 読み込み経路そのものの検査。ここが壊れると上の検査すべてが空振りする。
    result = subprocess.run(
        [sys.executable, "-c", "import importlib.util, sys; sys.exit(0)"],
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0
    assert facts.GENERATORS, "宣言が空になっている"
