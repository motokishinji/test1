"""入力 3 経路の正規化を検証する。

対応要件: 1.1（CSV / TSV の列指定読み込み）、1.2（配列・DataFrame も同一手順・同一構造）、
1.3（誤差列を 1/σ として重みに反映）、1.4（列が存在しない場合の報告）、
1.5（有効データ 0 件の報告）、1.6（見出し行の有無の指定に従う）、
1.7（見出し行が曖昧な入力の報告）。

設計の readers ブロックが定める Responsibilities & Constraints（3 経路が同一の
``DataSeries`` に収束する、数値変換できない値は ``NaN`` として通し除去は ``preprocess``
が担う、列の欠損と有効データ 0 件は ``FitFailure`` として返し例外を送出しない）、
Postconditions（``delimiter`` が ``None`` なら拡張子から決定する）、Invariants
（3 関数はいずれも同一の ``DataSeries`` 不変条件を満たす）、および Allowed Dependencies
（``readers`` は pandas を使ってよいが下流の層に依存しない）を対象とする。

要件 1.2 の「同一手順・同一構造」は、配列の値が一致することだけでは確かめられない。
3 経路の系列を実際に当てはめエンジンに通し、推定値まで一致することを見る。読み込みが
経路ごとに違う正規化を行えば、そこで初めて差が出る。

要件 1.3 の重みは σ ではなく 1/σ である。この向きは値の比較だけでは固定できない
（どちらの向きでも「重みが設定されている」ことは成り立つ）。誤差の大きい点を含む
データを実際に当てはめ、その点の寄与が小さくなる向きであることまで見る。
"""

from __future__ import annotations

import ast
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from curvefit.engines.least_squares import LeastSquaresEngine
from curvefit.errors import FailureReason
from curvefit.models.resolver import MethodSpec, PreparedModel, resolve
from curvefit.preprocess import PreprocessSpec, apply_preprocess
from curvefit.readers import (
    ColumnSpec,
    column_label,
    read_arrays,
    read_delimited,
    read_frame,
)
from curvefit.types import DataSeries, FitFailure, FloatArray

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

METHOD = "linear"
"""失敗の報告に載る手法の識別名。読み込み層は値による分岐を行わない。"""

TRUE_SLOPE = 2.0
TRUE_INTERCEPT = 1.0


def _array(values: list[float]) -> FloatArray:
    return np.array(values, dtype=np.float64)


def _write(path: Path, text: str) -> Path:
    path.write_text(text, encoding="utf-8")
    return path


def _series_of(outcome: DataSeries | FitFailure) -> DataSeries:
    """成功であることを主張したうえで系列を取り出す。"""
    assert isinstance(outcome, DataSeries), f"読み込みに失敗した: {outcome}"
    return outcome


def _failure_of(outcome: DataSeries | FitFailure) -> FitFailure:
    """失敗であることを主張したうえで失敗を取り出す。"""
    assert isinstance(outcome, FitFailure), f"失敗するはずが成功した: {outcome}"
    return outcome


def _fit_slope(series: DataSeries) -> float:
    """組込 linear モデルを当てはめ、傾きを返す。

    重みの向きは当てはめを通して初めて観測できる。読み込み層の出力を実際に
    エンジンへ渡すことが、要件 1.3 の検証手段である。
    """
    method = resolve(MethodSpec(name=METHOD, kind="builtin", builtin="linear"), series)
    assert isinstance(method, PreparedModel), f"モデルを解決できない: {method}"
    outcome = LeastSquaresEngine().fit(series, method)
    parameters = {p.name: p.value for p in outcome.parameters}
    return parameters["slope"]


class TestDelimiterDetermination:
    """設計の Postconditions: ``delimiter`` が ``None`` なら拡張子から決定する。"""

    def test_a_csv_extension_is_read_as_comma_separated(self, tmp_path: Path) -> None:
        """拡張子が csv ならカンマ区切りとして読む。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n2,20\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.x.tolist() == [1.0, 2.0]
        assert series.y.tolist() == [10.0, 20.0]

    def test_a_tsv_extension_is_read_as_tab_separated(self, tmp_path: Path) -> None:
        """拡張子が tsv ならタブ区切りとして読む。"""
        path = _write(tmp_path / "data.tsv", "x\ty\n1\t10\n2\t20\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.x.tolist() == [1.0, 2.0]
        assert series.y.tolist() == [10.0, 20.0]

    def test_any_extension_other_than_tsv_is_read_as_comma_separated(self, tmp_path: Path) -> None:
        """設計は ``.tsv`` を tab、それ以外を comma とだけ定める。``.txt`` も comma。"""
        path = _write(tmp_path / "data.txt", "x,y\n1,10\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.x.tolist() == [1.0]

    def test_the_extension_is_matched_case_insensitively(self, tmp_path: Path) -> None:
        """拡張子の大文字小文字を区別しない。"""
        path = _write(tmp_path / "data.TSV", "x\ty\n1\t10\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.x.tolist() == [1.0]

    def test_an_explicit_delimiter_wins_over_the_extension(self, tmp_path: Path) -> None:
        """拡張子と中身が食い違う入力は現実に存在する。指定は常に優先する。"""
        path = _write(tmp_path / "data.csv", "x\ty\n1\t10\n2\t20\n")
        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y"), delimiter="\t", method_name=METHOD)
        )

        assert series.x.tolist() == [1.0, 2.0]


HEADERLESS = "1,10\n2,20\n3,30\n"
"""見出しを持たない 3 点の入力。先頭行 ``1,10`` は測定点である。"""

WITH_HEADER = "x,y\n1,10\n2,20\n3,30\n"
"""同じ 3 点を見出しつきで表した入力。"""


class TestHeaderRowHandling:
    """要件 1.6 / 1.7: 見出し行の有無は実行条件として指定でき、未指定は 3 状態の 1 つ。

    ``header`` は ``None``（未指定）・``True``（あり）・``False``（なし）の 3 状態を取る
    （設計の readers Postconditions）。未指定は見出しありとして読むが、位置による列指定で
    先頭行のすべての値が数値として解釈できる場合だけは読まずに失敗を返す。この組み合わせ
    でそのまま読むと先頭の測定点が見出しとして消費され、失敗にも警告にもならないまま
    最初の 1 点が消えるためである。静かな誤りを、直せる失敗に変えることがここの目的である。

    ``True`` を明示した場合は検査を行わない。明示指定が推測に優先するという規約
    （初期値の明示が ``guess()`` に優先し、CLI 引数が設定ファイルに優先するのと同じ）に
    従い、数値に見える見出しを持つ入力の逃げ道になる。
    """

    def test_reading_a_headerless_input_by_position_fails(self, tmp_path: Path) -> None:
        """要件 1.7: 先頭行の全値が数値なら読まずに報告する。

        黙って 2 点だけ読むことは、利用者が気づけない誤りになる。
        """
        path = _write(tmp_path / "headerless.csv", HEADERLESS)
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS
        assert failure.source_id == str(path)
        assert failure.method_name == METHOD

    def test_the_failure_names_the_input_and_the_next_action(self, tmp_path: Path) -> None:
        """steering tech.md: エラーは「どの対象が」「何が原因か」を含み、行動可能であること。"""
        path = _write(tmp_path / "headerless.csv", HEADERLESS)
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert str(path) in failure.message, "数百件のバッチでは対象を特定できない失敗は無価値"
        assert "header" in failure.message, "次の行動は header の明示である"

    def test_explicit_no_header_reads_the_first_row_as_data(self, tmp_path: Path) -> None:
        """要件 1.6: ``header=False`` は先頭行をデータとして解釈する。"""
        path = _write(tmp_path / "headerless.csv", HEADERLESS)
        series = _series_of(
            read_delimited(path, ColumnSpec(x=0, y=1), header=False, method_name=METHOD)
        )

        assert len(series) == 3, "先頭の測定点が失われてはならない"
        assert series.x.tolist() == [1.0, 2.0, 3.0]
        assert series.y.tolist() == [10.0, 20.0, 30.0]

    def test_an_explicitly_headerless_input_cannot_be_addressed_by_column_name(
        self, tmp_path: Path
    ) -> None:
        """見出しがない以上、列名は解決できない。静かに別の列を読まず要件 1.4 の失敗にする。"""
        path = _write(tmp_path / "headerless.csv", HEADERLESS)
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x="x", y="y"), header=False, method_name=METHOD)
        )

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND

    def test_an_input_with_a_header_reads_by_position_even_when_unspecified(
        self, tmp_path: Path
    ) -> None:
        """先頭行が数値として解釈できない入力で検査は作動しない（誤検出しない）。"""
        path = _write(tmp_path / "with_header.csv", WITH_HEADER)
        series = _series_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert series.x.tolist() == [1.0, 2.0, 3.0]
        assert series.y.tolist() == [10.0, 20.0, 30.0]

    def test_explicit_header_yields_the_same_result(self, tmp_path: Path) -> None:
        """要件 1.6: ``header=True`` は既定の解釈と一致する。"""
        path = _write(tmp_path / "with_header.csv", WITH_HEADER)
        explicit = _series_of(
            read_delimited(path, ColumnSpec(x=0, y=1), header=True, method_name=METHOD)
        )
        implicit = _series_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert explicit.x.tolist() == implicit.x.tolist()
        assert explicit.y.tolist() == implicit.y.tolist()

    def test_the_check_stays_silent_for_a_numeric_looking_header_when_explicit(
        self, tmp_path: Path
    ) -> None:
        """明示指定が推測に優先する。誤検出された入力の逃げ道がこれである。

        見出しが ``1,10`` という数値に見える文字列であっても、``header=True`` を与えた
        入力は見出しありとして読む。読める点数は先頭行を除いた 2 点になる。
        """
        path = _write(tmp_path / "numeric_header.csv", HEADERLESS)
        series = _series_of(
            read_delimited(path, ColumnSpec(x=0, y=1), header=True, method_name=METHOD)
        )

        assert len(series) == 2, "先頭行は明示指定に従って見出しとして消費される"
        assert series.x.tolist() == [2.0, 3.0]
        assert series.y.tolist() == [20.0, 30.0]

    def test_a_headerless_input_cannot_be_addressed_by_column_name(self, tmp_path: Path) -> None:
        """要件 1.4 の失敗になる経路は変えない（未指定は見出しありとして読むため）。

        位置指定を使うべき入力に名前指定を与えた場合は、静かに別の列を読むのではなく
        要件 1.4 の失敗になる。存在する列として先頭行の値が並ぶことが、先頭行が
        見出しとして解釈された証拠である。名前指定では先頭の測定点が黙って消えることが
        ないため、要件 1.7 の検査は作動しない。
        """
        path = _write(tmp_path / "headerless.csv", HEADERLESS)
        failure = _failure_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert "'1'" in failure.message and "'10'" in failure.message

    def test_the_check_fires_when_any_column_is_given_by_position(self, tmp_path: Path) -> None:
        """名前と位置が混在する指定も「位置による列指定」として扱う（要件 1.7）。

        位置指定が 1 つでもあれば、その列は先頭行を消費した表から読まれる。名前側が
        たまたま先頭行の値に一致すれば読み込みは成功してしまい、最初の測定点は
        黙って失われる。検査を全指定が位置の場合に限ると、この経路が漏れる。
        """
        path = _write(tmp_path / "headerless.csv", HEADERLESS)
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y="10"), method_name=METHOD))

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS

    def test_the_check_fires_for_a_positional_error_column_too(self, tmp_path: Path) -> None:
        """誤差列の位置指定でも検査は作動する。"""
        path = _write(tmp_path / "headerless.csv", "1,10,0.5\n2,20,1\n3,30,2\n")
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x="1", y="10", weight=2), method_name=METHOD)
        )

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS

    def test_the_check_stays_silent_when_the_first_row_holds_a_non_numeric_value(
        self, tmp_path: Path
    ) -> None:
        """「すべての値が数値」が条件である。1 つでも数値でなければ見出しとみなす。"""
        path = _write(tmp_path / "mixed.csv", "1,y\n2,20\n3,30\n")
        series = _series_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert series.x.tolist() == [2.0, 3.0]

    def test_the_check_still_fires_with_a_label_column_present(self, tmp_path: Path) -> None:
        """要件 1.7: 判定の対象は先頭行全体ではなく、位置で指定された列である。

        試料名などのラベル列は装置出力として最も普通の形である。先頭行全体を見ると
        ラベル列があるだけで検査が素通りし、指定された x・y は数値のままなので
        先頭の測定点が黙って消える。この形を見逃すなら検査を置く意味がない。
        """
        path = _write(tmp_path / "label.csv", "1,10,sampleA\n2,20,sampleB\n3,30,sampleC\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS

    def test_the_check_still_fires_with_a_unit_column_present(self, tmp_path: Path) -> None:
        """単位を各行に持つ出力もラベル列と同じ形である。"""
        path = _write(tmp_path / "unit.csv", "0.0,1.2,mV\n1.0,2.4,mV\n2.0,3.6,mV\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS

    def test_the_check_still_fires_with_a_trailing_comma(self, tmp_path: Path) -> None:
        """末尾の区切り文字が生む空欄は、指定された列の外にある。"""
        path = _write(tmp_path / "trailing.csv", "1,10,\n2,20,\n3,30,\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS

    def test_the_check_still_fires_with_a_leading_time_column(self, tmp_path: Path) -> None:
        """指定された列が先頭にない場合も、その列だけを見て判定する。"""
        path = _write(
            tmp_path / "timestamp.csv",
            "2024-01-01,1,10\n2024-01-02,2,20\n2024-01-03,3,30\n",
        )
        failure = _failure_of(read_delimited(path, ColumnSpec(x=1, y=2), method_name=METHOD))

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS

    def test_the_check_still_fires_with_an_error_column_beside_a_label_column(
        self, tmp_path: Path
    ) -> None:
        """誤差列を含む指定でも、判定の対象は指定された 3 列だけである。"""
        path = _write(tmp_path / "sigma_label.csv", "1,10,0.5,A\n2,20,1.0,A\n3,30,2.0,A\n")
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x=0, y=1, weight=2), method_name=METHOD)
        )

        assert failure.reason is FailureReason.HEADER_AMBIGUOUS

    def test_the_failure_names_the_column_positions_it_examined(self, tmp_path: Path) -> None:
        """判定の根拠は報告から追えなければならない（steering tech.md）。

        先頭行に数値でない値が見えている入力では、行全体を挙げるだけでは
        「なぜ曖昧なのか」が伝わらない。判定した列の位置を併記する。
        """
        path = _write(tmp_path / "timestamp.csv", "2024-01-01,1,10\n2024-01-02,2,20\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x=1, y=2), method_name=METHOD))

        assert "位置 1, 2" in failure.message
        assert "2024-01-01" in failure.message, "判定材料である先頭行そのものも示す"

    def test_the_check_stays_silent_when_a_selected_column_holds_a_non_numeric_value(
        self, tmp_path: Path
    ) -> None:
        """指定された列の側が数値でなければ、その行は見出しである（誤検出しない）。

        指定の外にある通番列が数値であっても判定は変わらない。判定の対象が先頭行全体
        ではなく指定された列であることは、この向きでも成り立たなければならない。
        """
        path = _write(tmp_path / "index_header.csv", "0,x,y\n1,1,10\n2,2,20\n")
        series = _series_of(read_delimited(path, ColumnSpec(x=1, y=2), method_name=METHOD))

        assert series.x.tolist() == [1.0, 2.0]
        assert series.y.tolist() == [10.0, 20.0]

    def test_an_input_with_a_header_and_a_label_column_is_not_misdetected(
        self, tmp_path: Path
    ) -> None:
        """本物の見出しを持つ入力は、ラベル列があっても従来どおり読める。"""
        path = _write(tmp_path / "header_label.csv", "x,y,name\n1,10,a\n2,20,b\n3,30,c\n")
        series = _series_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert series.x.tolist() == [1.0, 2.0, 3.0]

    def test_a_blank_in_a_selected_column_does_not_count_as_numeric(self, tmp_path: Path) -> None:
        """空欄を含む先頭行は、そもそも測定点として成立しない（見出しとして読んでよい）。"""
        path = _write(tmp_path / "blank.csv", "1,,note\n2,20,note\n3,30,note\n")
        series = _series_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert series.y.tolist() == [20.0, 30.0]

    def test_an_out_of_range_position_is_reported_as_a_missing_column_before_header_ambiguity(
        self, tmp_path: Path
    ) -> None:
        """要件 1.4 / 1.7: 解決できない位置指定は判定の対象にならない。

        指定された列を先頭行の位置に対応づけられない以上、見出しの有無は判定できない。
        先に ``HEADER_AMBIGUOUS`` を返すと、利用者は ``header`` を明示してから改めて
        列の誤りを知ることになり、往復が 2 度になる。
        """
        path = _write(tmp_path / "headerless.csv", HEADERLESS)
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=5), method_name=METHOD))

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert "5" in failure.message

    def test_a_boolean_looking_first_row_is_not_treated_as_numeric(self, tmp_path: Path) -> None:
        """``bool`` を位置として受け付けない規約（要件 1.4）と同じ扱いを先頭行にも適用する。

        ``TRUE`` / ``FALSE`` は利用者にとって数値ではない。これを数値と数えると、
        真偽値の見出しを持つ入力が誤って失敗になる。
        """
        path = _write(tmp_path / "flags.csv", "TRUE,FALSE\n1,10\n2,20\n")
        series = _series_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert series.x.tolist() == [1.0, 2.0]

    def test_an_empty_file_is_reported_as_no_valid_data_not_header_ambiguity(
        self, tmp_path: Path
    ) -> None:
        """先頭行そのものが存在しない入力は要件 1.5 の系統である。"""
        path = _write(tmp_path / "empty.csv", "")
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD))

        assert failure.reason is FailureReason.NO_VALID_DATA

    def test_the_decision_is_the_same_for_the_same_content(self, tmp_path: Path) -> None:
        """要件 8.2: 判定はファイル内容だけに依存し、実行のたびに揺れない。"""
        first = _write(tmp_path / "a.csv", HEADERLESS)
        second = _write(tmp_path / "b.csv", HEADERLESS)

        reasons = [
            _failure_of(read_delimited(path, ColumnSpec(x=0, y=1), method_name=METHOD)).reason
            for path in (first, second, first)
        ]

        assert reasons == [FailureReason.HEADER_AMBIGUOUS] * 3

    def test_the_frame_path_has_no_notion_of_a_header(self) -> None:
        """``read_frame`` / ``read_arrays`` に先頭行の解釈という問題は存在しない。

        すべての値が数値の表を位置指定で読んでも、1 行目は測定点として残る。
        """
        frame = pd.DataFrame([[1.0, 10.0], [2.0, 20.0], [3.0, 30.0]])
        series = _series_of(
            read_frame(frame, ColumnSpec(x=0, y=1), source_id="frame", method_name=METHOD)
        )

        assert series.x.tolist() == [1.0, 2.0, 3.0]

    def test_the_array_path_has_no_notion_of_a_header(self) -> None:
        """配列経路は見出しの概念を持たない。"""
        series = _series_of(
            read_arrays(
                _array([1.0, 2.0, 3.0]),
                _array([10.0, 20.0, 30.0]),
                source_id="mem",
                method_name=METHOD,
            )
        )

        assert series.x.tolist() == [1.0, 2.0, 3.0]


class TestAgreementOfTheThreePaths:
    """要件 1.2: 配列・DataFrame もファイル入力と同一手順・同一構造。"""

    def _three_paths(self, tmp_path: Path) -> tuple[DataSeries, DataSeries, DataSeries]:
        x = [1.0, 2.0, 3.0, 4.0]
        y = [3.2, 5.1, 6.9, 9.2]
        sigma = [0.5, 2.0, 4.0, 1.0]

        rows = "".join(f"{a},{b},{c}\n" for a, b, c in zip(x, y, sigma, strict=True))
        path = _write(tmp_path / "same.csv", "x,y,err\n" + rows)
        columns = ColumnSpec(x="x", y="y", weight="err")

        from_file = _series_of(read_delimited(path, columns, method_name=METHOD))
        from_frame = _series_of(
            read_frame(
                pd.DataFrame({"x": x, "y": y, "err": sigma}),
                columns,
                source_id="same",
                method_name=METHOD,
            )
        )
        from_arrays = _series_of(
            read_arrays(
                np.array(x),
                np.array(y),
                source_id="same",
                sigma=np.array(sigma),
                method_name=METHOD,
            )
        )
        return from_file, from_frame, from_arrays

    def test_the_three_paths_yield_the_same_series(self, tmp_path: Path) -> None:
        """三経路が同一の系列になる。"""
        from_file, from_frame, from_arrays = self._three_paths(tmp_path)

        for other in (from_frame, from_arrays):
            assert other.x.tolist() == from_file.x.tolist()
            assert other.y.tolist() == from_file.y.tolist()
            assert other.weights is not None and from_file.weights is not None
            assert other.weights.tolist() == from_file.weights.tolist()

    def test_the_three_paths_yield_the_same_estimates(self, tmp_path: Path) -> None:
        """配列が一致しても後続処理が経路ごとに違えば結果は割れる。推定値まで見る。"""
        from_file, from_frame, from_arrays = self._three_paths(tmp_path)
        slopes = [_fit_slope(series) for series in (from_file, from_frame, from_arrays)]

        assert slopes[1] == slopes[0]
        assert slopes[2] == slopes[0]

    def test_column_name_and_column_index_yield_the_same_series(self, tmp_path: Path) -> None:
        """要件 1.1 の列指定は名前と位置の双方を受け付ける。"""
        path = _write(tmp_path / "data.csv", "x,y,err\n1,10,0.5\n2,20,2\n")

        by_name = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )
        by_position = _series_of(
            read_delimited(path, ColumnSpec(x=0, y=1, weight=2), method_name=METHOD)
        )

        assert by_position.x.tolist() == by_name.x.tolist()
        assert by_position.y.tolist() == by_name.y.tolist()
        assert by_position.weights is not None and by_name.weights is not None
        assert by_position.weights.tolist() == by_name.weights.tolist()

    def test_the_selected_columns_are_taken_regardless_of_column_order(
        self, tmp_path: Path
    ) -> None:
        """列の並びによらず指定した列が選ばれる。"""
        path = _write(tmp_path / "data.csv", "y,other,x\n10,-1,1\n20,-2,2\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.x.tolist() == [1.0, 2.0]
        assert series.y.tolist() == [10.0, 20.0]

    def test_the_input_identifier_stays_on_the_series(self, tmp_path: Path) -> None:
        """入力の識別子が系列に残る。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.source_id == str(path)


class TestRecoveryFromDecimalNotation:
    """要件 1.9: 記載された値を最終ビットまで復元し、読み込みで値が変わらないこと。

    設計の readers Postconditions: 十進表記を float64 に戻す変換は最近接に丸める。

    ``pandas`` の既定の解釈器は正しく丸められておらず、float64 を往復できる最短表記
    （``repr``）で書かれた値を読み直しても元のビット列に戻らない。実測では一様乱数の
    36%、対数正規乱数の 41% が変化し、最大 7370 ulp ずれる。本プロジェクトは出力の
    有効数字 10 桁を約束しており（``writers``、要件 8.2）、この誤りは条件の悪い
    当てはめでその水準を上回る差を生む。

    試験データに 2 の冪を用いてはならない。2 の冪は短い十進表記を持ち、既定の解釈器でも
    たまたま正しく戻るため、検査が素通りする。
    """

    def _full_precision_values(self, count: int = 500) -> list[float]:
        """短い十進表記を持たない値を作る。``repr`` は 17 桁前後になる。"""
        rng = np.random.default_rng(20260811)
        return rng.lognormal(0.0, 8.0, count).tolist()

    def test_full_precision_decimal_notation_is_recovered_to_the_last_bit(
        self, tmp_path: Path
    ) -> None:
        """全桁の十進表記が最終ビットまで復元される。"""
        values = self._full_precision_values()
        rows = "".join(f"{v!r},{-v!r}\n" for v in values)
        path = _write(tmp_path / "full.csv", "x,y\n" + rows)

        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.x.tolist() == values
        assert series.y.tolist() == [-v for v in values]

    def test_the_error_column_is_also_recovered_to_the_last_bit(self, tmp_path: Path) -> None:
        """重みは σ の逆数として作られる。σ が 1 ulp 違えば重みも違う。"""
        sigma = self._full_precision_values(count=200)
        rows = "".join(f"{i},{i},{s!r}\n" for i, s in enumerate(sigma))
        path = _write(tmp_path / "sigma.csv", "x,y,err\n" + rows)

        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        assert series.weights is not None
        assert series.weights.tolist() == [1.0 / s for s in sigma]


class TestStringToFloatConversion:
    """設計の readers Postconditions: 文字列から実数への変換全般を往復厳密にする。

    ``float_precision="round_trip"`` が守るのは区切り文字つきファイルの読み込みだけで
    ある。列に欠測として認識されない文字列（機器のエラーコードなど）が **1 つ** 混ざると、
    その列は文字列のまま渡され、全経路が通る数値化で改めて解釈し直される。既定の解釈は
    正しく丸められていないため、エラーコードとは無関係な正常値までまとめて劣化する。
    実測（pandas 3.0.5、2000 点中 1 セルが ``OVERFLOW``）では他の 39.2% が変化し、
    最大 7275 ulp ずれた。

    要件 2.2 は数値として解釈できない行の混在を想定内としている。想定内の入力が、
    それ自身ではなく **周囲の正常なデータ** を壊してはならない。

    ``N/A`` のように pandas が欠測として認識する文字列ではこの巻き添えは起きない
    （列が float64 のまま届く）。試験には認識されない文字列を用いる。

    試験データに 2 の冪を用いてはならない。2 の冪は短い十進表記を持ち、既定の解釈器でも
    たまたま正しく戻るため、検査が素通りする。
    """

    ERROR_CODE = "OVERFLOW"
    """欠測として認識されない文字列。装置が測定不能を報告する形の一例である。"""

    def _full_precision_values(self, count: int = 500) -> list[float]:
        """短い十進表記を持たない値を作る。``repr`` は 17 桁前後になる。"""
        rng = np.random.default_rng(20260812)
        return rng.lognormal(0.0, 8.0, count).tolist()

    def test_one_error_code_does_not_degrade_the_other_points(self, tmp_path: Path) -> None:
        """エラーコードが 1 つ混ざっても他の点は最終ビットまで復元される。"""
        values = self._full_precision_values()
        bad = 7
        rows = "".join(
            f"{i},{self.ERROR_CODE if i == bad else repr(v)}\n" for i, v in enumerate(values)
        )
        path = _write(tmp_path / "code.csv", "x,y\n" + rows)

        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert math.isnan(series.y[bad]), "エラーコード自身は NaN として通る"
        restored = [series.y[i] for i in range(len(values)) if i != bad]
        assert restored == [v for i, v in enumerate(values) if i != bad], (
            "1 セルのエラーコードが列全体を文字列にし、無関係な正常値まで劣化させている"
        )

    @pytest.mark.parametrize("code", ["OVERFLOW", "測定不能", "---", "N/A"])
    def test_the_other_points_survive_whatever_the_error_code_spelling(
        self, tmp_path: Path, code: str
    ) -> None:
        """欠測として認識される綴り（``N/A``）とされない綴りで結果が変わってはならない。

        認識される綴りでは列が float64 のまま届くため巻き添えが起きない。この差が
        「どの文字列を書いたか」で残りのデータの精度を決めてしまう状態そのものである。
        """
        values = self._full_precision_values(count=200)
        rows = "".join(f"{i},{code if i == 3 else repr(v)}\n" for i, v in enumerate(values))
        path = _write(tmp_path / "code.csv", "x,y\n" + rows)

        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert math.isnan(series.y[3])
        assert [series.y[i] for i in range(len(values)) if i != 3] == [
            v for i, v in enumerate(values) if i != 3
        ]

    def test_an_error_code_in_the_error_column_leaves_the_other_weights_unchanged(
        self, tmp_path: Path
    ) -> None:
        """重みは σ の逆数である。σ が 1 ulp 違えば重みも違い、推定値まで届く。"""
        sigma = self._full_precision_values(count=200)
        bad = 11
        rows = "".join(
            f"{i},{i},{self.ERROR_CODE if i == bad else repr(s)}\n" for i, s in enumerate(sigma)
        )
        path = _write(tmp_path / "sigma.csv", "x,y,err\n" + rows)

        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        assert series.weights is not None
        assert math.isnan(series.weights[bad]), "重みを定義できない点は NaN として通る"
        assert [series.weights[i] for i in range(len(sigma)) if i != bad] == [
            1.0 / s for i, s in enumerate(sigma) if i != bad
        ]

    def test_a_string_column_on_the_frame_path_is_also_recovered_to_the_last_bit(self) -> None:
        """要件 1.2: 3 経路は同一の数値化を通る。表形式経路に文字列で数値が届く場合も同じ。"""
        values = self._full_precision_values(count=300)
        frame = pd.DataFrame(
            {"x": [repr(float(i)) for i in range(len(values))], "y": [repr(v) for v in values]}
        )

        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )

        assert series.y.tolist() == values
        assert series.x.tolist() == [float(i) for i in range(len(values))]

    def test_strings_on_the_array_path_are_also_recovered_to_the_last_bit(self) -> None:
        """配列経路の文字列も最終ビットまで復元される。"""
        values = self._full_precision_values(count=300)
        series = _series_of(
            read_arrays(
                np.array([repr(float(i)) for i in range(len(values))], dtype=object),
                np.array([repr(v) for v in values], dtype=object),
                source_id="mem",
                method_name=METHOD,
            )
        )

        assert series.y.tolist() == values

    def test_removal_of_error_coded_rows_belongs_to_the_preprocess_layer(self) -> None:
        """要件 2.2: 読み込み層は ``NaN`` として通すだけであり、件数を数えるのは前処理層。"""
        frame = pd.DataFrame({"x": ["1.5", "2.5", "3.5"], "y": ["10.5", self.ERROR_CODE, "30.5"]})
        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )

        assert len(series) == 3, "読み込み層で除去すると件数記録が分散する"

        outcome = apply_preprocess(series, PreprocessSpec(), min_points=1, method_name=METHOD)
        assert not isinstance(outcome, FitFailure), outcome
        _, report = outcome
        assert (report.n_input, report.n_dropped_invalid) == (3, 1)

    def test_a_boolean_column_becomes_ones_and_zeros(self) -> None:
        """真偽・整数・float64 の列は再解釈を必要としない。既存の扱いを変えない。"""
        frame = pd.DataFrame({"x": [True, False, True], "y": [1, 2, 3]})
        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )

        assert series.x.tolist() == [1.0, 0.0, 1.0]
        assert series.y.tolist() == [1.0, 2.0, 3.0]

    def test_the_result_is_a_contiguous_1d_float64_array(self) -> None:
        """結果は連続した 1 次元の float64 配列になる。"""
        frame = pd.DataFrame({"x": ["1.5", "2.5"], "y": ["10.5", self.ERROR_CODE]})
        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )

        for array in (series.x, series.y):
            assert array.dtype == np.float64
            assert array.ndim == 1
            assert array.flags["C_CONTIGUOUS"]

    def test_numeric_conversion_of_a_string_column_finishes_in_practical_time(self) -> None:
        """要件 10.2: 数百件を数分以内。1 件あたりの数値化がその制約を脅かさないこと。

        これは性能の測定ではなく、要素ごとの解釈が二次的な費用に化けていないことを見る
        歩哨である。実測は 10,000 行あたり数ミリ秒であり、閾値はその 3 桁上に置く。
        負荷のかかった実行環境でも偽陽性にならない水準を選んでいる。
        """
        count = 10_000
        rng = np.random.default_rng(20260813)
        texts = [repr(v) for v in rng.lognormal(0.0, 8.0, count).tolist()]
        frame = pd.DataFrame({"x": texts, "y": texts})

        started = time.perf_counter()
        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )
        elapsed = time.perf_counter() - started

        assert len(series) == count
        assert elapsed < 5.0, f"10,000 行の文字列列の数値化に {elapsed:.3f} 秒かかった"


class TestErrorColumnToWeightConversion:
    """要件 1.3: 誤差列 σ の逆数 1/σ を重みとする。変換はこの層だけが行う。"""

    def test_the_reciprocal_of_the_error_becomes_the_weight(self, tmp_path: Path) -> None:
        """誤差列の逆数が重みになる。"""
        path = _write(tmp_path / "data.csv", "x,y,err\n1,10,0.5\n2,20,2\n3,30,4\n")
        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        assert series.weights is not None
        assert series.weights.tolist() == [2.0, 0.5, 0.25]

    def test_no_weights_without_an_error_column(self, tmp_path: Path) -> None:
        """誤差列を指定しなければ重みを持たない。"""
        path = _write(tmp_path / "data.csv", "x,y,err\n1,10,0.5\n2,20,2\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert series.weights is None

    def test_the_array_path_also_uses_the_reciprocal_as_the_weight(self) -> None:
        """配列経路の第 3 系列も誤差 σ であり、逆数への変換はここで行う。"""
        series = _series_of(
            read_arrays(
                _array([1.0, 2.0]),
                _array([10.0, 20.0]),
                source_id="mem",
                sigma=_array([0.5, 4.0]),
                method_name=METHOD,
            )
        )

        assert series.weights is not None
        assert series.weights.tolist() == [2.0, 0.25]

    def test_points_with_larger_error_contribute_less_to_the_estimate(self, tmp_path: Path) -> None:
        """要件 1.3 の向きを当てはめで固定する。

        σ をそのまま重みにすると誤差の大きい点ほど強く効き、推定が静かに誤る。
        真値から大きく外れた点にだけ大きな σ を与え、その点が無視される向きで
        あることを、σ をそのまま重みにした場合との差として見る。
        """
        x = np.arange(10, dtype=np.float64)
        y = TRUE_SLOPE * x + TRUE_INTERCEPT
        y[-1] += 20.0
        sigma = np.full(10, 0.1)
        sigma[-1] = 10.0

        rows = "".join(f"{a},{b},{c}\n" for a, b, c in zip(x, y, sigma, strict=True))
        path = _write(tmp_path / "noisy.csv", "x,y,err\n" + rows)
        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        weighted = _fit_slope(series)
        inverted = _fit_slope(
            DataSeries(source_id=series.source_id, x=series.x, y=series.y, weights=sigma)
        )

        assert weighted == pytest.approx(TRUE_SLOPE, abs=0.05)
        assert abs(weighted - TRUE_SLOPE) < abs(inverted - TRUE_SLOPE)

    def test_a_non_positive_or_non_finite_error_yields_nan_for_the_weight(
        self, tmp_path: Path
    ) -> None:
        """σ <= 0 と非有限の σ に 1/σ は存在しない。行は除去せず ``NaN`` として通す。"""
        path = _write(
            tmp_path / "data.csv",
            "x,y,err\n1,10,0\n2,20,-1\n3,30,nan\n4,40,inf\n5,50,2\n",
        )
        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        assert series.weights is not None
        assert len(series) == 5, "重みを定義できない行もこの層では除去しない"
        assert [math.isnan(w) for w in series.weights.tolist()] == [
            True,
            True,
            True,
            True,
            False,
        ]
        assert series.weights[4] == 0.5

    @pytest.mark.filterwarnings("ignore:overflow encountered in divide:RuntimeWarning")
    def test_a_weight_beyond_the_finite_range_becomes_nan_not_infinity(
        self, tmp_path: Path
    ) -> None:
        """極端に小さい σ の逆数は有限にならない。無限大を通さず ``NaN`` とする。

        無限大の重みを通すと、その 1 点だけで残差の総和が無限大になり当てはめが黙って
        壊れる。重みを定めたことにならない点は、σ <= 0 の場合と同じく ``NaN`` として
        通し、除去と件数の記録は前処理層に委ねる（要件 2.2）。
        """
        path = _write(tmp_path / "tiny.csv", "x,y,err\n1,10,1e-320\n2,20,2\n3,30,4\n")
        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        assert series.weights is not None
        assert not math.isinf(series.weights[0]), "無限大の重みは当てはめを静かに壊す"
        assert math.isnan(series.weights[0])
        assert series.weights[1:].tolist() == [0.5, 0.25]

        outcome = apply_preprocess(series, PreprocessSpec(), min_points=1, method_name=METHOD)
        assert not isinstance(outcome, FitFailure), outcome
        kept, report = outcome

        assert (report.n_input, report.n_dropped_invalid) == (3, 1)
        assert kept.x.tolist() == [2.0, 3.0]

    def test_points_without_a_definable_weight_are_removed_and_counted_by_preprocessing(
        self, tmp_path: Path
    ) -> None:
        """除去と件数記録は前処理層の責任である（要件 2.2）。"""
        path = _write(tmp_path / "data.csv", "x,y,err\n1,10,0\n2,20,2\n3,30,4\n")
        series = _series_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        outcome = apply_preprocess(series, PreprocessSpec(), min_points=1, method_name=METHOD)
        assert not isinstance(outcome, FitFailure), outcome
        kept, report = outcome

        assert report.n_input == 3
        assert report.n_dropped_invalid == 1
        assert kept.x.tolist() == [2.0, 3.0]

    def test_all_errors_invalid_fails_as_no_valid_data(self, tmp_path: Path) -> None:
        """要件 1.5: 重みを定義できない点しか残らない入力に有効なデータ点はない。"""
        path = _write(tmp_path / "data.csv", "x,y,err\n1,10,0\n2,20,-3\n")
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        assert failure.reason is FailureReason.NO_VALID_DATA


class TestHandlingOfNonNumericValues:
    """設計: 数値変換できない値は ``NaN`` として通し、除去は ``preprocess`` が担う。"""

    def test_non_numeric_values_pass_through_as_nan_rather_than_being_removed(
        self, tmp_path: Path
    ) -> None:
        """数値にできない値を除去せず NaN として通す。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n2,broken\n,30\n4,40\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert len(series) == 4, "読み込み層で除去すると件数記録が分散する"
        assert math.isnan(series.y[1])
        assert math.isnan(series.x[2])

    def test_the_passed_through_nan_is_counted_by_preprocessing(self, tmp_path: Path) -> None:
        """通した NaN を前処理が件数として数える。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n2,broken\n,30\n4,40\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        outcome = apply_preprocess(series, PreprocessSpec(), min_points=1, method_name=METHOD)
        assert not isinstance(outcome, FitFailure), outcome
        _, report = outcome

        assert (report.n_input, report.n_dropped_invalid) == (4, 2)

    def test_the_array_path_also_passes_non_numeric_values_as_nan(self) -> None:
        """配列経路でも数値にできない値を NaN として通す。"""
        series = _series_of(
            read_arrays(
                np.array([1.0, 2.0], dtype=object),
                np.array(["10", "broken"], dtype=object),
                source_id="mem",
                method_name=METHOD,
            )
        )

        assert len(series) == 2
        assert series.y[0] == 10.0
        assert math.isnan(series.y[1])

    def test_the_frame_path_also_passes_non_numeric_values_as_nan(self) -> None:
        """表形式経路でも数値にできない値を NaN として通す。"""
        frame = pd.DataFrame({"x": [1, 2], "y": ["10", "broken"]})
        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )

        assert series.y[0] == 10.0
        assert math.isnan(series.y[1])

    def test_a_complex_column_on_the_frame_path_becomes_nan_not_its_real_part(self) -> None:
        """複素数は :class:`float` へ落とせない値であり、実部で代用しない。

        pandas は複素数列を数値と認めるため、そのまま float64 へ変換すると虚部を捨てた
        実部が観測値として通り、利用者が渡していない値で当てはめが進む。全行が複素数の
        列に有効な点はなく、要件 1.5 の失敗になる。
        """
        frame = pd.DataFrame({"x": [1.0, 2.0], "y": pd.Series([1 + 2j, 3 + 4j])})
        failure = _failure_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="complex", method_name=METHOD)
        )

        assert failure.reason is FailureReason.NO_VALID_DATA, "実部 1.0・3.0 を採ってはならない"
        assert failure.source_id == "complex"

    def test_complex_values_on_the_array_path_also_become_nan_not_their_real_part(self) -> None:
        """実数と複素数が混在する配列でも、実部への読み替えは起こらない。

        pandas は混在した列を複素数列に揃えるため、実部を採る実装では複素数でない値まで
        巻き込んで「有効な点がある」ことになってしまう。ここでも有効な点はない。
        """
        failure = _failure_of(
            read_arrays(
                np.array([1.0, 2.0]),
                np.array([1 + 2j, 5.0], dtype=object),
                source_id="mem",
                method_name=METHOD,
            )
        )

        assert failure.reason is FailureReason.NO_VALID_DATA


class TestWhenAColumnIsAbsent:
    """要件 1.4: 入力名と解決できなかった列指定を含む失敗を、例外ではなく値で返す。"""

    def test_reports_a_missing_column_name(self, tmp_path: Path) -> None:
        """存在しない列名を報告する。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n")
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x="x", y="missing"), method_name=METHOD)
        )

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert failure.source_id == str(path)
        assert "missing" in failure.message

    def test_reports_an_out_of_range_column_index(self, tmp_path: Path) -> None:
        """範囲外の列番号を報告する。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=7), method_name=METHOD))

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert "7" in failure.message

    def test_reports_a_negative_column_index(self, tmp_path: Path) -> None:
        """末尾からの参照は列指定として受け付けない。位置は 0 起点の前方参照に固定する。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x=0, y=-1), method_name=METHOD))

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND

    def test_reports_every_column_that_could_not_be_resolved(self, tmp_path: Path) -> None:
        """1 件ずつ直す往復を避けるため、解決できなかった指定を一度に提示する。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n")
        failure = _failure_of(
            read_delimited(
                path, ColumnSpec(x="no_x", y="no_y", weight="no_err"), method_name=METHOD
            )
        )

        for missing in ("no_x", "no_y", "no_err"):
            assert missing in failure.message

    def test_reports_when_only_the_error_column_is_missing(self, tmp_path: Path) -> None:
        """誤差列だけが存在しない場合も報告する。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n")
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x="x", y="y", weight="err"), method_name=METHOD)
        )

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert "err" in failure.message

    def test_lists_the_columns_that_do_exist(self, tmp_path: Path) -> None:
        """次の行動は列名の確認である。入力側に何があるかを併記する。"""
        path = _write(tmp_path / "data.csv", "alpha,beta\n1,10\n")
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x="alpha", y="gamma"), method_name=METHOD)
        )

        assert "beta" in failure.message

    def test_the_frame_path_also_reports_a_missing_column(self) -> None:
        """表形式経路でも列の欠損を報告する。"""
        frame = pd.DataFrame({"x": [1.0], "y": [10.0]})
        failure = _failure_of(
            read_frame(frame, ColumnSpec(x="x", y="z"), source_id="frame", method_name=METHOD)
        )

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert failure.source_id == "frame"

    def test_duplicate_column_names_resolve_to_the_first(self) -> None:
        """重複した列名でも解決結果が入力の並び順だけで決まる（要件 8.2）。"""
        frame = pd.DataFrame([[1.0, 99.0, 10.0]], columns=["x", "x", "y"])
        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="dup", method_name=METHOD)
        )

        assert series.x.tolist() == [1.0]

    def test_a_boolean_column_spec_is_not_accepted_as_a_position(self) -> None:
        """``bool`` は ``int`` の派生型だが、列の位置としては解決しない。

        ``True`` を位置 1 として黙って受け入れると、真偽値が紛れ込んだ列指定が
        エラーにならずに隣の列を読む。指定の誤りは要件 1.4 の失敗として返す。
        """
        frame = pd.DataFrame({"a": [1.0, 2.0], "b": [10.0, 20.0]})
        failure = _failure_of(
            read_frame(frame, ColumnSpec(x=True, y=1), source_id="bool", method_name=METHOD)
        )

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND, "True を位置 1 に解決しない"
        assert "True" in failure.message

    def test_a_column_index_is_always_interpreted_as_a_position(self) -> None:
        """整数の列ラベルを持つ表でも、整数指定は位置であって名前ではない。"""
        frame = pd.DataFrame({5: [1.0, 2.0], 3: [10.0, 20.0]})
        series = _series_of(
            read_frame(frame, ColumnSpec(x=0, y=1), source_id="ints", method_name=METHOD)
        )

        assert series.x.tolist() == [1.0, 2.0]
        assert series.y.tolist() == [10.0, 20.0]


class TestWhenThereAreNoValidDataPoints:
    """要件 1.5: 有効なデータ点が 1 件もない入力を失敗として報告する。"""

    def test_an_empty_file(self, tmp_path: Path) -> None:
        """空のファイル。"""
        path = _write(tmp_path / "empty.csv", "")
        failure = _failure_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert failure.reason is FailureReason.NO_VALID_DATA

    def test_a_file_with_only_a_header(self, tmp_path: Path) -> None:
        """見出しだけのファイル。"""
        path = _write(tmp_path / "header.csv", "x,y\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert failure.reason is FailureReason.NO_VALID_DATA

    def test_a_file_whose_every_row_is_non_numeric(self, tmp_path: Path) -> None:
        """全行が数値として解釈できないファイル。"""
        path = _write(tmp_path / "text.csv", "x,y\na,b\nc,d\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert failure.reason is FailureReason.NO_VALID_DATA
        assert failure.source_id == str(path)

    def test_missing_x_and_y_on_different_rows_also_leaves_no_valid_point(
        self, tmp_path: Path
    ) -> None:
        """有効なのは x と y が揃っている点である。列ごとに数えると取り違える。"""
        path = _write(tmp_path / "sparse.csv", "x,y\n1,\n,20\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert failure.reason is FailureReason.NO_VALID_DATA

    def test_an_empty_array(self) -> None:
        """空の配列。"""
        failure = _failure_of(
            read_arrays(_array([]), _array([]), source_id="mem", method_name=METHOD)
        )

        assert failure.reason is FailureReason.NO_VALID_DATA

    def test_an_empty_frame(self) -> None:
        """空の表。"""
        frame = pd.DataFrame({"x": [], "y": []})
        failure = _failure_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )

        assert failure.reason is FailureReason.NO_VALID_DATA

    def test_a_single_valid_point_is_enough_to_avoid_failure(self, tmp_path: Path) -> None:
        """有効な点が 1 件でもあれば失敗しない。"""
        path = _write(tmp_path / "one.csv", "x,y\n1,10\n,\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert len(series) == 2, "無効な行もこの層では通す"


class TestHowFailuresAreCarried:
    """設計の Error Strategy: 想定内の失敗は値として返し、例外を送出しない。"""

    @pytest.mark.parametrize(
        ("columns", "expected"),
        [
            (ColumnSpec(x="x", y="missing"), FailureReason.COLUMN_NOT_FOUND),
            (ColumnSpec(x="x", y="y"), FailureReason.NO_VALID_DATA),
        ],
    )
    def test_the_failure_carries_the_method_name(
        self, tmp_path: Path, columns: ColumnSpec, expected: FailureReason
    ) -> None:
        """``FitFailure`` は手法名を必須とする。読み込み層は呼び出し側から受け取る。"""
        path = _write(tmp_path / "text.csv", "x,y\na,b\n")
        failure = _failure_of(read_delimited(path, columns, method_name="polynomial"))

        assert failure.reason is expected
        assert failure.method_name == "polynomial"

    def test_the_failure_carries_no_preprocess_report(self, tmp_path: Path) -> None:
        """前処理に到達する前の失敗である。"""
        path = _write(tmp_path / "text.csv", "x,y\na,b\n")
        failure = _failure_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert failure.preprocess is None

    def test_an_uninterpretable_file_does_not_raise(self, tmp_path: Path) -> None:
        """列数が行ごとに食い違う入力でもバッチを止めない（要件 6.4）。"""
        path = _write(tmp_path / "ragged.csv", "x,y\n1,10\n2,20,30,40\n")
        outcome = read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD)

        assert isinstance(outcome, (DataSeries, FitFailure))

    def test_a_missing_file_is_propagated_to_the_caller(self, tmp_path: Path) -> None:
        """入力の存在確認は実行前ゲートの担当。資源系の例外は握り潰さない。"""
        with pytest.raises(OSError):
            read_delimited(tmp_path / "absent.csv", ColumnSpec(x="x", y="y"), method_name=METHOD)

    def test_arrays_of_unequal_length_raise_as_a_caller_error(self) -> None:
        """データ由来の失敗ではなく、``DataSeries`` の不変条件違反である。"""
        with pytest.raises(ValueError):
            read_arrays(_array([1.0, 2.0]), _array([10.0]), source_id="mem", method_name=METHOD)

    def test_a_2d_array_raises_as_a_caller_error(self) -> None:
        """二次元の配列は呼び出し側の誤りとして例外になる。"""
        with pytest.raises(ValueError):
            read_arrays(np.zeros((2, 2)), np.zeros((2, 2)), source_id="mem", method_name=METHOD)


class TestDependencyDirection:
    """設計の Allowed Dependencies と Architecture の依存方向。"""

    def test_does_not_depend_on_downstream_layers(self) -> None:
        """``readers`` が参照してよいのは ``types`` / ``errors`` までである。"""
        tree = ast.parse((SRC / "readers.py").read_text(encoding="utf-8"))
        own = {
            node.module
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.startswith("curvefit")
        }
        own |= {
            alias.name
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
            if alias.name.startswith("curvefit")
        }

        assert own <= {"curvefit.types", "curvefit.errors"}, f"想定外の依存: {own}"

    def test_the_reader_layer_returns_only_normalized_types(self, tmp_path: Path) -> None:
        """pandas の型を外へ出さない（Allowed Dependencies）。"""
        path = _write(tmp_path / "data.csv", "x,y\n1,10\n")
        series = _series_of(read_delimited(path, ColumnSpec(x="x", y="y"), method_name=METHOD))

        assert isinstance(series.x, np.ndarray)
        assert series.x.dtype == np.float64
        assert series.y.dtype == np.float64


class TestColumnLabelDerivation:
    """設計の Postconditions: ``column_label`` は ``ColumnSpec.y`` の綴りを文字列にする。

    対応要件: 7.6（出力ファイル名に y 列を識別できる情報を含める）。

    ラベルは出力名に載る。出力名はファイルを読む前に確定していなければならず
    （要件 7.7 の出力先検証、要件 8.2 の決定性）、この関数が受け取るのは列指定だけである。
    ファイルを引数に取らないことが「見出し行から読み直さない」の構造的な保証である。
    """

    def test_a_column_name_becomes_the_label_as_written(self) -> None:
        """列名で指定した場合はその名前がそのままラベルになる。"""
        assert column_label(ColumnSpec(x="time", y="signal")) == "signal"

    def test_a_position_becomes_the_digits_of_that_position(self) -> None:
        """位置で指定した場合はその位置の数字がラベルになる。"""
        assert column_label(ColumnSpec(x=0, y=1)) == "1"

    def test_the_label_comes_from_the_y_column_not_from_x_or_the_error_column(self) -> None:
        """ラベルの出どころは y 列の指定だけである。"""
        columns = ColumnSpec(x="time", y="signal", weight="sigma")

        assert column_label(columns) == "signal"

    def test_the_same_specification_always_yields_the_same_label(self) -> None:
        """同一の指定に対して常に同一の値になる（要件 8.2）。"""
        labels = {column_label(ColumnSpec(x=0, y=2)) for _ in range(5)}

        assert labels == {"2"}

    def test_the_label_does_not_depend_on_the_header_row_of_the_input(
        self, tmp_path: Path
    ) -> None:
        """見出し名が違うファイルを読んでも、同じ位置指定なら同じラベルである。

        実データでは列名がファイルごとに変わる（``research.md`` の G2）。見出しから
        採ると同じ設定でもファイルごとに別のラベルになり、出力名が入力に依存する。
        """
        columns = ColumnSpec(x=0, y=1)
        first = _write(tmp_path / "run1.csv", "t,ch_a\n1,10\n2,20\n")
        second = _write(tmp_path / "run2.csv", "t,ch_b\n1,10\n2,20\n")
        _series_of(read_delimited(first, columns, header=True, method_name=METHOD))
        _series_of(read_delimited(second, columns, header=True, method_name=METHOD))

        assert column_label(columns) == "1"

    def test_the_label_is_available_before_any_input_is_read(self) -> None:
        """存在しない入力しか持たない段階でもラベルは確定する（要件 7.7、8.2）。"""
        assert column_label(ColumnSpec(x="x", y="y")) == "y"

    def test_the_label_is_the_raw_spelling_without_substitution(self) -> None:
        """ファイル名として安全でない文字の置換は ``writers`` が所有する。"""
        assert column_label(ColumnSpec(x="x", y="a/b c")) == "a/b c"


class TestTheResolvedHeaderNameOnTheSeries:
    """設計の Postconditions: 解決した y 列の見出し名を ``DataSeries.column_name`` に載せる。

    対応要件: 7.3（各行がどの入力のどの y 列の結果かを識別できるようにする）。

    綴り（``column_label``）と見出し名（``column_name``）は役割が違う。綴りは読む前に
    確定して出力名に入り、見出し名は読んだ後にしか分からない代わりに、位置で指定した
    場合でもどのチャネルかが分かる。
    """

    def test_a_column_name_specification_carries_that_header_name(self, tmp_path: Path) -> None:
        """列名で指定した場合、その見出し名が系列に載る。"""
        path = _write(tmp_path / "data.csv", "time,signal\n1,10\n2,20\n")
        series = _series_of(
            read_delimited(path, ColumnSpec(x="time", y="signal"), method_name=METHOD)
        )

        assert series.column_name == "signal"

    def test_a_positional_specification_carries_the_resolved_header_name(
        self, tmp_path: Path
    ) -> None:
        """位置で指定した場合も、解決した列の見出し名が載る。

        位置指定が主経路になる実データで、``column_label`` の ``1`` という綴りだけでは
        どのチャネルかが分からない。この場が情報量の側を担う。
        """
        path = _write(tmp_path / "data.csv", "time,ch_a,ch_b\n1,10,100\n2,20,200\n")
        series = _series_of(
            read_delimited(path, ColumnSpec(x=0, y=2), header=True, method_name=METHOD)
        )

        assert series.column_name == "ch_b"

    def test_an_input_without_a_header_carries_no_header_name(self, tmp_path: Path) -> None:
        """``header=False`` の入力は見出しを持たないため空である。"""
        path = _write(tmp_path / "data.csv", "1,10\n2,20\n")
        series = _series_of(
            read_delimited(path, ColumnSpec(x=0, y=1), header=False, method_name=METHOD)
        )

        assert series.column_name is None

    def test_a_failure_to_resolve_the_column_carries_no_header_name(self, tmp_path: Path) -> None:
        """列を解決できなかった場合は見出し名を持たない（要件 1.4）。"""
        path = _write(tmp_path / "data.csv", "time,signal\n1,10\n")
        failure = _failure_of(
            read_delimited(path, ColumnSpec(x="time", y="absent"), method_name=METHOD)
        )

        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert failure.column_name is None

    def test_the_array_path_carries_no_header_name(self) -> None:
        """配列経路は列の概念を持たないため空である。"""
        series = _series_of(
            read_arrays(
                _array([1.0, 2.0]), _array([10.0, 20.0]), source_id="mem", method_name=METHOD
            )
        )

        assert series.column_name is None

    def test_the_frame_path_carries_the_label_of_the_resolved_column(self) -> None:
        """表形式経路でも、解決した列の見出し名が載る。"""
        frame = pd.DataFrame({"time": [1.0, 2.0], "signal": [10.0, 20.0]})
        series = _series_of(
            read_frame(frame, ColumnSpec(x=0, y=1), source_id="frame", method_name=METHOD)
        )

        assert series.column_name == "signal"

    def test_a_frame_without_column_names_carries_no_header_name(self) -> None:
        """既定の整数ラベルしか持たない表は見出しを持たない入力である。"""
        frame = pd.DataFrame([[1.0, 10.0], [2.0, 20.0]])
        series = _series_of(
            read_frame(frame, ColumnSpec(x=0, y=1), source_id="frame", method_name=METHOD)
        )

        assert series.column_name is None

    def test_duplicate_header_names_carry_the_name_of_the_first_column(self) -> None:
        """同名の列は最初の列を採る既存規則に従う。"""
        frame = pd.DataFrame([[1.0, 10.0, 99.0]], columns=["x", "y", "y"])
        series = _series_of(
            read_frame(frame, ColumnSpec(x="x", y="y"), source_id="frame", method_name=METHOD)
        )

        assert series.column_name == "y"
        assert series.y.tolist() == [10.0]

    def test_the_same_input_always_yields_the_same_header_name(self, tmp_path: Path) -> None:
        """同一入力の再読み込みは同一の見出し名になる（要件 8.2）。"""
        path = _write(tmp_path / "data.csv", "time,signal\n1,10\n2,20\n")
        names = {
            _series_of(
                read_delimited(path, ColumnSpec(x=0, y=1), header=True, method_name=METHOD)
            ).column_name
            for _ in range(3)
        }

        assert names == {"signal"}

    def test_the_header_name_does_not_replace_the_written_label(self, tmp_path: Path) -> None:
        """見出し名を載せても、綴りの側は指定のままである。"""
        path = _write(tmp_path / "data.csv", "time,signal\n1,10\n2,20\n")
        columns = ColumnSpec(x=0, y=1)
        series = _series_of(read_delimited(path, columns, header=True, method_name=METHOD))

        assert (column_label(columns), series.column_name) == ("1", "signal")
