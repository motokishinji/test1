"""3 経路のモデル指定を単一表現に解決する処理を検証する。

対応要件: 3.1（組込モデルを名前で選択）、3.2（数式文字列をモデルとして解釈）、
3.3（利用者定義 Python 関数をモデルとして受け入れ）、3.4（解決失敗を指定内容とともに
報告し、最初の 1 件で打ち切らない）、3.5（パラメータ名を結果出力の識別子として確定）、
4.1（組込モデルの初期値自動推定）、4.2（明示指定が自動推定に優先）、
4.4（上下限の反映）、4.5（固定指定の反映）。

設計の Invariants / Postconditions に由来する 4.3（数式・関数モデルでの初期値必須）と
4.6（初期値が上下限の範囲外）も本モジュールが実装するため、あわせて検証する。
"""

from __future__ import annotations

import ast
import dataclasses
import math
from collections.abc import Mapping
from dataclasses import FrozenInstanceError
from pathlib import Path

import numpy as np
import pytest

from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.models.registry import (
    DEFAULT_POLYNOMIAL_DEGREE,
    MAX_POLYNOMIAL_DEGREE,
    POLYNOMIAL_DEGREE_OPTION,
)
from curvefit.models.resolver import (
    PARAMETER_FIELDS,
    MethodSpec,
    PreparedModel,
    PreparedSmoother,
    SmootherKind,
    resolve,
)
from curvefit.types import DataSeries, FloatArray

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


def _linear_series(source_id: str = "sample") -> DataSeries:
    """傾き 2.0・切片 1.0 の直線。組込モデルの初期値推定が素直に効く。"""
    x = np.linspace(0.0, 10.0, 51)
    return DataSeries(source_id=source_id, x=x, y=2.0 * x + 1.0)


def _gaussian_series() -> DataSeries:
    x = np.linspace(-5.0, 5.0, 101)
    return DataSeries(source_id="gauss", x=x, y=3.0 * np.exp(-((x - 0.5) ** 2) / (2.0 * 1.2**2)))


def _user_linear(x: FloatArray, slope: float, intercept: float) -> FloatArray:
    """要件 3.3 の利用者定義モデル。"""
    return slope * x + intercept


def _violations(result: object) -> tuple[ConfigViolation, ...]:
    """解決結果が違反の集合であることを確かめ、その集合を返す。"""
    assert isinstance(result, tuple), f"違反の集合が返るはずが {type(result).__name__} だった"
    assert result, "違反が 1 件も含まれていない"
    assert all(isinstance(item, ConfigViolation) for item in result)
    return result


def _kinds(result: object) -> set[ViolationKind]:
    return {violation.kind for violation in _violations(result)}


def _values(prepared: PreparedModel) -> Mapping[str, float]:
    """解決済み表現が保持する初期値を、パラメータ名で引ける形にして返す。"""
    parameters = prepared._parameters
    return {name: parameters[name].value for name in prepared.parameter_names}


class TestResolutionOfTheThreeRoutes:
    """組込名・数式・関数のいずれからも同一の表現が得られること（要件 3.1、3.2、3.3）。"""

    def test_resolves_from_a_builtin_model_name(self) -> None:
        """組込モデル名から解決できる。"""
        result = resolve(MethodSpec(name="line", kind="builtin", builtin="linear"), None)
        assert isinstance(result, PreparedModel)
        assert result.display_name == "line"

    def test_resolves_from_an_expression_string(self) -> None:
        """数式文字列から解決できる。"""
        spec = MethodSpec(
            name="expr",
            kind="expression",
            expression="a * x + b",
            initial={"a": 1.0, "b": 0.0},
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)

    def test_resolves_from_a_user_function(self) -> None:
        """利用者定義関数から解決できる。"""
        spec = MethodSpec(
            name="user",
            kind="callable",
            function=_user_linear,
            initial={"slope": 1.0, "intercept": 0.0},
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)

    def test_all_three_routes_converge_on_the_same_representation(self) -> None:
        """以降の層がモデル指定の由来を知らずに済むことを、型として確認する。"""
        results = [
            resolve(MethodSpec(name="a", kind="builtin", builtin="linear"), None),
            resolve(
                MethodSpec(
                    name="b",
                    kind="expression",
                    expression="a * x + b",
                    initial={"a": 1.0, "b": 0.0},
                ),
                None,
            ),
            resolve(
                MethodSpec(
                    name="c",
                    kind="callable",
                    function=_user_linear,
                    initial={"slope": 1.0, "intercept": 0.0},
                ),
                None,
            ),
        ]
        assert {type(result) for result in results} == {PreparedModel}

    def test_returns_an_independent_instance_per_call(self) -> None:
        """ジョブごとに解決を呼び直す設計のため、実体を共有すると状態が漏れる。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear")
        first = resolve(spec, None)
        second = resolve(spec, None)
        assert isinstance(first, PreparedModel)
        assert isinstance(second, PreparedModel)
        assert first._model is not second._model
        assert first._parameters is not second._parameters


class TestFixingTheParameterNames:
    """抽出したパラメータ名が結果出力の識別子になること（要件 3.5）。"""

    def test_keeps_the_builtin_model_parameter_names(self) -> None:
        """組込モデルのパラメータ名を保持する。"""
        result = resolve(MethodSpec(name="line", kind="builtin", builtin="linear"), None)
        assert isinstance(result, PreparedModel)
        assert result.parameter_names == ("slope", "intercept")

    def test_keeps_expression_parameter_names_in_order_of_appearance(self) -> None:
        """数式のパラメータ名を出現順で保持する。"""
        spec = MethodSpec(
            name="expr",
            kind="expression",
            expression="amp * exp(-x / tau) + offset",
            initial={"amp": 1.0, "tau": 1.0, "offset": 0.0},
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert result.parameter_names == ("amp", "tau", "offset")

    def test_uses_the_user_function_argument_names_as_parameter_names(self) -> None:
        """利用者定義関数の引数名をパラメータ名にする。"""
        spec = MethodSpec(
            name="user",
            kind="callable",
            function=_user_linear,
            initial={"slope": 1.0, "intercept": 0.0},
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert result.parameter_names == ("slope", "intercept")

    def test_dependent_derived_quantities_are_not_parameters(self) -> None:
        """ガウシアンの fwhm / height は他のパラメータから決まる派生量であり、
        推定対象ではない。含めると要件 2.4 の点数判定も狂う。"""
        result = resolve(MethodSpec(name="g", kind="builtin", builtin="gaussian"), None)
        assert isinstance(result, PreparedModel)
        assert result.parameter_names == ("amplitude", "center", "sigma")

    def test_parameter_name_order_is_constant_across_calls(self) -> None:
        """要件 8.2 の再現性は、ここで確定した順序が出力に伝わることに依存する。"""
        spec = MethodSpec(
            name="expr",
            kind="expression",
            expression="c * x**2 + b * x + a",
            initial={"a": 0.0, "b": 0.0, "c": 0.0},
        )
        orders = set()
        for _ in range(3):
            result = resolve(spec, None)
            assert isinstance(result, PreparedModel)
            orders.add(result.parameter_names)
        assert len(orders) == 1


class TestReportingAnUnresolvableSpec:
    """解決失敗を例外ではなく値として、原因となった指定内容とともに返す（要件 3.4）。"""

    def test_an_unknown_builtin_model_name_returns_a_violation(self) -> None:
        """未知の組込モデル名で違反を返す。"""
        result = resolve(MethodSpec(name="m", kind="builtin", builtin="gausian"), None)
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(result)

    def test_the_violation_includes_the_offending_builtin_name(self) -> None:
        """違反は原因となった組込モデル名を含む。"""
        result = resolve(MethodSpec(name="m", kind="builtin", builtin="gausian"), None)
        assert any("gausian" in violation.message for violation in _violations(result))

    def test_an_uninterpretable_expression_returns_a_violation(self) -> None:
        """解釈できない数式で違反を返す。"""
        spec = MethodSpec(
            name="m", kind="expression", expression="a * x +", initial={"a": 1.0}
        )
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(resolve(spec, None))

    def test_the_violation_includes_the_offending_expression(self) -> None:
        """違反は原因となった数式を含む。"""
        spec = MethodSpec(
            name="m", kind="expression", expression="a * x +", initial={"a": 1.0}
        )
        assert any("a * x +" in v.message for v in _violations(resolve(spec, None)))

    @pytest.mark.parametrize("reserved", ["eval", "exec", "__import__", "__package__"])
    def test_an_expression_with_a_reserved_word_as_a_parameter_returns_a_violation(
        self, reserved: str
    ) -> None:
        """式の解釈は通るがパラメータとして束縛できない名前がある。素通しすると
        当てはめ層で未捕捉の例外になり、バッチ全体が落ちる（要件 3.4）。"""
        expression = f"a * x + {reserved}"
        spec = MethodSpec(
            name="m",
            kind="expression",
            expression=expression,
            initial={"a": 1.0, reserved: 1.0},
        )
        result = resolve(spec, None)
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(result)
        assert any(expression in violation.message for violation in _violations(result))

    def test_a_function_without_the_independent_variable_returns_a_violation(self) -> None:
        """独立変数を取らない関数を違反として返す。"""

        def no_x(t: FloatArray, a: float) -> FloatArray:
            return a * t

        spec = MethodSpec(name="m", kind="callable", function=no_x, initial={"a": 1.0})
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(resolve(spec, None))

    def test_a_function_without_estimable_parameters_returns_a_violation(self) -> None:
        """推定対象を持たない関数を違反として返す。"""

        def no_params(x: FloatArray) -> FloatArray:
            return x

        spec = MethodSpec(name="m", kind="callable", function=no_params, initial={"a": 1.0})
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(resolve(spec, None))

    @pytest.mark.parametrize(
        "spec",
        [
            MethodSpec(name="m", kind="builtin"),
            MethodSpec(name="m", kind="expression", initial={"a": 1.0}),
            MethodSpec(name="m", kind="callable", initial={"a": 1.0}),
            MethodSpec(name="m", kind="smoother"),
        ],
        ids=["builtin", "expression", "callable", "smoother"],
    )
    def test_a_missing_spec_for_the_route_returns_a_violation(self, spec: MethodSpec) -> None:
        """経路に対応する指定が欠けていれば違反を返す。"""
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(resolve(spec, None))

    def test_an_unknown_route_kind_returns_a_violation(self) -> None:
        """未知の経路種別で違反を返す。"""
        spec = MethodSpec(name="m", kind="unknown")  # type: ignore[arg-type]
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(resolve(spec, None))

    def test_the_violation_names_the_location(self) -> None:
        """違反は指定箇所を示す。"""
        result = resolve(MethodSpec(name="m1", kind="builtin", builtin="gausian"), None)
        assert all("m1" in violation.location for violation in _violations(result))

    def test_a_resolution_failure_is_not_raised_as_an_exception(self) -> None:
        """実行前ゲートが違反を集められるよう、想定内の失敗はすべて値で返す。"""
        for spec in (
            MethodSpec(name="m", kind="builtin", builtin="nope"),
            MethodSpec(name="m", kind="expression", expression="((("),
            MethodSpec(name="m", kind="callable", function=None),
        ):
            assert isinstance(resolve(spec, None), tuple)


class TestInitialValuePrecedence:
    """明示指定が自動推定に優先すること（要件 4.1、4.2）。"""

    def test_a_builtin_model_guesses_initials_from_the_data(self) -> None:
        """組込モデルはデータから初期値を推定する。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear")
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        assert _values(result)["slope"] == pytest.approx(2.0, rel=1e-6)

    def test_explicit_initials_win_over_the_auto_guess(self) -> None:
        """明示された初期値が自動推定より優先される。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            initial={"slope": 99.0, "intercept": -7.0},
        )
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        assert _values(result) == {"slope": 99.0, "intercept": -7.0}

    def test_partially_explicit_initials_are_completed_by_the_auto_guess(self) -> None:
        """一部だけ明示した場合は残りを自動推定で補う。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear", initial={"slope": 99.0})
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        values = _values(result)
        assert values["slope"] == 99.0
        assert values["intercept"] == pytest.approx(1.0, abs=1e-6)

    def test_no_auto_guess_without_data(self) -> None:
        """実行前ゲートは sample=None で解決し、データに依存しない違反のみを見る。

        推定を行わなかったことは出発点で見る。データを与えた場合の値（傾き 2.0）に
        ならないことが、推定が働いていないことの観測可能な現れである。
        """
        spec = MethodSpec(name="line", kind="builtin", builtin="linear")
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert _values(result)["slope"] != pytest.approx(2.0, rel=1e-6)

    def test_different_data_gives_different_guessed_initials(self) -> None:
        """ジョブごとに解決を呼び直す設計が意味を持つことの確認。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear")
        first = resolve(spec, _linear_series())
        x = np.linspace(0.0, 10.0, 51)
        second = resolve(spec, DataSeries(source_id="other", x=x, y=-5.0 * x + 3.0))
        assert isinstance(first, PreparedModel)
        assert isinstance(second, PreparedModel)
        assert _values(first)["slope"] != pytest.approx(_values(second)["slope"])

    def test_the_auto_guess_also_works_for_the_gaussian(self) -> None:
        """ガウシアンでも自動推定が働く。"""
        result = resolve(
            MethodSpec(name="g", kind="builtin", builtin="gaussian"), _gaussian_series()
        )
        assert isinstance(result, PreparedModel)
        assert _values(result)["center"] == pytest.approx(0.5, abs=0.2)


class TestRoutesRequiringExplicitInitials:
    """数式・関数モデルで初期値が与えられていない場合の報告（要件 4.3）。"""

    def test_an_expression_model_without_initials_returns_a_violation(self) -> None:
        """数式モデルで初期値がなければ違反を返す。"""
        spec = MethodSpec(name="m", kind="expression", expression="a * x + b")
        assert ViolationKind.INITIAL_REQUIRED in _kinds(resolve(spec, None))

    def test_a_function_model_without_initials_returns_a_violation(self) -> None:
        """関数モデルで初期値がなければ違反を返す。"""
        spec = MethodSpec(name="m", kind="callable", function=_user_linear)
        assert ViolationKind.INITIAL_REQUIRED in _kinds(resolve(spec, None))

    def test_partially_given_initials_return_a_violation(self) -> None:
        """初期値が一部しか与えられていなければ違反を返す。"""
        spec = MethodSpec(name="m", kind="expression", expression="a * x + b", initial={"a": 1.0})
        result = resolve(spec, None)
        assert ViolationKind.INITIAL_REQUIRED in _kinds(result)
        assert any("b" in violation.message for violation in _violations(result))

    def test_a_fixed_spec_stands_in_for_an_initial(self) -> None:
        """固定指定は初期値の代わりになる。"""
        spec = MethodSpec(
            name="m",
            kind="expression",
            expression="a * x + b",
            initial={"a": 1.0},
            fixed={"b": 3.0},
        )
        assert isinstance(resolve(spec, None), PreparedModel)

    def test_builtin_models_do_not_require_initials(self) -> None:
        """要件 4.1 により組込モデルは自動推定できるため、必須にすると経路が塞がる。"""
        result = resolve(MethodSpec(name="line", kind="builtin", builtin="linear"), None)
        assert isinstance(result, PreparedModel)


class TestApplyingTheBounds:
    """指定された上下限が解決後の表現に反映されること（要件 4.4）。"""

    def test_the_bounds_enter_the_resolved_representation(self) -> None:
        """上下限が解決後の表現に入る。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            bounds={"slope": (0.0, 5.0)},
        )
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        parameter = result._parameters["slope"]
        assert (parameter.min, parameter.max) == (0.0, 5.0)

    def test_a_one_sided_spec_is_accepted(self) -> None:
        """片側のみの指定を受け付ける。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            bounds={"slope": (0.0, None), "intercept": (None, 10.0)},
        )
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        assert result._parameters["slope"].min == 0.0
        assert math.isinf(result._parameters["slope"].max)
        assert result._parameters["intercept"].max == 10.0
        assert math.isinf(result._parameters["intercept"].min)

    def test_the_guessed_value_is_clamped_into_the_given_range(self) -> None:
        """推定値が範囲外になる指定でも、自動推定は利用者指定ではないため違反にしない。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            bounds={"slope": (None, 0.5)},
        )
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        assert _values(result)["slope"] <= 0.5

    def test_a_lower_bound_above_the_upper_bound_returns_a_violation(self) -> None:
        """下限が上限を上回る指定を違反として返す。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            bounds={"slope": (5.0, 1.0)},
            initial={"slope": 3.0},
        )
        assert ViolationKind.CONFIG_INVALID in _kinds(resolve(spec, None))


class TestApplyingTheFixedSpec:
    """固定されたパラメータが変化しない形で表現されること（要件 4.5）。"""

    def test_a_fixed_parameter_is_set_not_to_vary(self) -> None:
        """固定パラメータは変動しない設定になる。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear", fixed={"intercept": 1.5})
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        assert result._parameters["intercept"].vary is False
        assert result._parameters["intercept"].value == 1.5

    def test_an_unfixed_parameter_still_varies(self) -> None:
        """固定していないパラメータは変動する。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear", fixed={"intercept": 1.5})
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        assert result._parameters["slope"].vary is True

    def test_a_fixed_value_wins_over_the_auto_guess(self) -> None:
        """固定値は自動推定に優先する。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear", fixed={"slope": 42.0})
        result = resolve(spec, _linear_series())
        assert isinstance(result, PreparedModel)
        assert _values(result)["slope"] == 42.0

    def test_giving_both_an_initial_and_a_fixed_value_for_one_parameter_returns_a_violation(
        self,
    ) -> None:
        """どちらが効いたかが記録から追えなくなるため、黙って一方を採らない。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            initial={"slope": 1.0},
            fixed={"slope": 2.0},
        )
        assert ViolationKind.CONFIG_INVALID in _kinds(resolve(spec, None))


class TestConflictBetweenInitialsAndBounds:
    """指定された初期値が範囲外の場合の報告（要件 4.6）。"""

    def test_an_initial_outside_the_range_returns_a_violation(self) -> None:
        """範囲外の初期値を違反として返す。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            initial={"slope": 10.0},
            bounds={"slope": (0.0, 5.0)},
        )
        assert ViolationKind.INITIAL_OUT_OF_BOUNDS in _kinds(resolve(spec, None))

    def test_an_initial_below_the_lower_bound_returns_a_violation(self) -> None:
        """下限を下回る初期値を違反として返す。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            initial={"slope": -1.0},
            bounds={"slope": (0.0, None)},
        )
        assert ViolationKind.INITIAL_OUT_OF_BOUNDS in _kinds(resolve(spec, None))

    def test_an_initial_inside_the_range_is_not_a_violation(self) -> None:
        """範囲内の初期値は違反にならない。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            initial={"slope": 2.0},
            bounds={"slope": (0.0, 5.0)},
        )
        assert isinstance(resolve(spec, None), PreparedModel)

    def test_a_fixed_value_outside_the_range_returns_a_violation(self) -> None:
        """範囲外の固定値を違反として返す。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            fixed={"slope": 10.0},
            bounds={"slope": (0.0, 5.0)},
        )
        assert ViolationKind.INITIAL_OUT_OF_BOUNDS in _kinds(resolve(spec, None))

    def test_an_initial_violating_the_intrinsic_lower_bound_returns_a_violation(self) -> None:
        """基盤ライブラリは範囲外の初期値を黙って丸める。丸めを許すと、要件 4.2 が
        求める「指定された初期値を使用する」が成立しない。"""
        spec = MethodSpec(name="g", kind="builtin", builtin="gaussian", initial={"sigma": -1.0})
        assert ViolationKind.INITIAL_OUT_OF_BOUNDS in _kinds(resolve(spec, None))

    def test_on_violation_no_representation_with_a_clamped_initial_is_returned(self) -> None:
        """違反時は指定した初期値が丸められた表現を返さない。"""
        spec = MethodSpec(name="g", kind="builtin", builtin="gaussian", initial={"sigma": -1.0})
        assert not isinstance(resolve(spec, None), PreparedModel)


class TestUnknownParameterNames:
    """モデルが持たないパラメータへの指定を黙って捨てない。"""

    @pytest.mark.parametrize("field", ["initial", "bounds", "fixed"])
    def test_a_spec_for_a_name_absent_from_the_model_returns_a_violation(self, field: str) -> None:
        """モデルにない名前への指定を違反として返す。"""
        payload: dict[str, object] = {
            "initial": {"slop": 1.0},
            "bounds": {"slop": (0.0, 1.0)},
            "fixed": {"slop": 1.0},
        }
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            **{field: payload[field]},  # type: ignore[arg-type]
        )
        result = resolve(spec, _linear_series())
        assert ViolationKind.CONFIG_INVALID in _kinds(result)
        assert any("slop" in violation.message for violation in _violations(result))

    def test_a_spec_for_a_derived_quantity_is_also_treated_as_unknown(self) -> None:
        """派生量への指定も未知として扱う。"""
        spec = MethodSpec(name="g", kind="builtin", builtin="gaussian", initial={"fwhm": 1.0})
        assert ViolationKind.CONFIG_INVALID in _kinds(resolve(spec, _gaussian_series()))


class TestMethodSpecificOptions:
    """利用者由来のオプションを素通しさせない（carry-over: registry は例外を送出する）。"""

    def test_resolves_with_the_default_degree(self) -> None:
        """既定の次数で解決できる。"""
        result = resolve(MethodSpec(name="p", kind="builtin", builtin="polynomial"), None)
        assert isinstance(result, PreparedModel)
        assert result.parameter_names == ("c0", "c1", "c2")

    def test_the_given_degree_takes_effect(self) -> None:
        """指定した次数が反映される。"""
        spec = MethodSpec(
            name="p", kind="builtin", builtin="polynomial", options={POLYNOMIAL_DEGREE_OPTION: 3}
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert result.parameter_names == ("c0", "c1", "c2", "c3")

    def test_an_unknown_option_name_returns_a_violation_not_an_exception(self) -> None:
        """綴り誤りが例外になるとバッチ全体が落ちる。要件 3.4 は全違反の収集を求める。"""
        spec = MethodSpec(name="p", kind="builtin", builtin="polynomial", options={"degrees": 3})
        result = resolve(spec, None)
        assert ViolationKind.CONFIG_INVALID in _kinds(result)
        assert any("degrees" in violation.message for violation in _violations(result))

    def test_options_given_to_a_model_that_has_none_return_a_violation(self) -> None:
        """オプションを持たないモデルへの指定を違反として返す。"""
        spec = MethodSpec(name="g", kind="builtin", builtin="gaussian", options={"degree": 3})
        assert ViolationKind.CONFIG_INVALID in _kinds(resolve(spec, None))

    def test_a_negative_degree_returns_a_violation(self) -> None:
        """負の次数はパラメータ 0 個の退化したモデルを黙って作る。"""
        spec = MethodSpec(
            name="p", kind="builtin", builtin="polynomial", options={POLYNOMIAL_DEGREE_OPTION: -1}
        )
        assert ViolationKind.CONFIG_INVALID in _kinds(resolve(spec, None))

    def test_a_degree_above_the_maximum_returns_a_violation(self) -> None:
        """上限を超える次数を違反として返す。"""
        spec = MethodSpec(
            name="p",
            kind="builtin",
            builtin="polynomial",
            options={POLYNOMIAL_DEGREE_OPTION: MAX_POLYNOMIAL_DEGREE + 1},
        )
        result = resolve(spec, None)
        assert ViolationKind.CONFIG_INVALID in _kinds(result)
        assert any(str(MAX_POLYNOMIAL_DEGREE) in v.message for v in _violations(result))

    def test_a_non_integer_degree_returns_a_violation(self) -> None:
        """整数でない次数を違反として返す。"""
        spec = MethodSpec(
            name="p", kind="builtin", builtin="polynomial", options={POLYNOMIAL_DEGREE_OPTION: 2.5}
        )
        assert ViolationKind.CONFIG_INVALID in _kinds(resolve(spec, None))

    def test_the_maximum_constant_matches_the_underlying_library_limit(self) -> None:
        """定数だけを直しても、ここで実体との乖離が落ちる。"""
        from lmfit.models import PolynomialModel

        assert MAX_POLYNOMIAL_DEGREE == PolynomialModel.MAX_DEGREE

    @pytest.mark.parametrize("degree", [0, MAX_POLYNOMIAL_DEGREE])
    def test_degrees_at_the_edges_of_the_allowed_range_resolve(self, degree: int) -> None:
        """許容範囲の端の次数は解決できる。"""
        spec = MethodSpec(
            name="p",
            kind="builtin",
            builtin="polynomial",
            options={POLYNOMIAL_DEGREE_OPTION: degree},
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert len(result.parameter_names) == degree + 1


class TestKeepingTheFilledInDefaults:
    """要件 5.4: 既定値で補った選択肢を、当てはめ層へ渡せる形で保持する。

    組込モデルの選択肢はモデル実体の組み立てに要る。次数が決まらなければパラメータ
    すら定まらないため、既定値は解決の時点で消費される。当てはめ層は補われた事実を
    観測できず、解決層が運ばなければ記録の材料がどこにも残らない（平滑化手法とは
    既定値が確定する時点が違う）。

    期待値は登録簿の定数から読む。試験に書き写すと既定値の所有が 2 か所に分かれる。
    """

    def test_an_unspecified_degree_is_kept_as_a_filled_in_default(self) -> None:
        """未指定の次数は補った既定値として保持される。"""
        result = resolve(MethodSpec(name="p", kind="builtin", builtin="polynomial"), None)
        assert isinstance(result, PreparedModel)
        assert dict(result.applied_defaults) == {
            POLYNOMIAL_DEGREE_OPTION: DEFAULT_POLYNOMIAL_DEGREE
        }

    def test_an_explicit_degree_is_not_among_the_filled_in_defaults(self) -> None:
        """明示した次数は補った既定値に含めない。"""
        spec = MethodSpec(
            name="p", kind="builtin", builtin="polynomial", options={POLYNOMIAL_DEGREE_OPTION: 3}
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert dict(result.applied_defaults) == {}

    def test_a_builtin_model_without_options_yields_nothing(self) -> None:
        """選択肢を持たない組込モデルは空である。"""
        result = resolve(MethodSpec(name="g", kind="builtin", builtin="gaussian"), None)
        assert isinstance(result, PreparedModel)
        assert dict(result.applied_defaults) == {}

    @pytest.mark.parametrize(
        "spec",
        [
            MethodSpec(
                name="e", kind="expression", expression="a * x + b", initial={"a": 1.0, "b": 0.0}
            ),
            MethodSpec(
                name="c",
                kind="callable",
                function=_user_linear,
                initial={"slope": 1.0, "intercept": 0.0},
            ),
        ],
        ids=["expression", "callable"],
    )
    def test_a_route_without_options_yields_nothing(self, spec: MethodSpec) -> None:
        """選択肢を持たない経路は空である。"""
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert dict(result.applied_defaults) == {}

    def test_the_kept_defaults_are_immutable(self) -> None:
        """保持した既定値は書き換えられない。"""
        result = resolve(MethodSpec(name="p", kind="builtin", builtin="polynomial"), None)
        assert isinstance(result, PreparedModel)
        with pytest.raises(TypeError):
            result.applied_defaults[POLYNOMIAL_DEGREE_OPTION] = 9  # type: ignore[index]


class TestRoutesThatAcceptNoOptions:
    """数式・利用者定義関数の経路に書かれた選択肢を違反として報告する（要件 8.5）。

    この 2 経路に手法固有の選択肢の意味はない。黙って捨てると、設定ファイルの記述と
    実際の実行条件が食い違ったまま当てはめが成功する。組込モデルと平滑化が既に未知の
    選択肢を拒否している方針に揃える。
    """

    def test_options_attached_to_an_expression_model_return_a_violation(self) -> None:
        """数式モデルに添えた選択肢を違反として返す。"""
        spec = MethodSpec(
            name="decay",
            kind="expression",
            expression="a * exp(-b * x) + c",
            initial={"a": 1.0, "b": 0.1, "c": 0.0},
            options={"degree": 3},
        )
        result = resolve(spec, None)
        violations = _violations(result)
        assert ViolationKind.CONFIG_INVALID in _kinds(result)
        assert any("degree" in violation.message for violation in violations)
        assert any(violation.location == "method[decay].options" for violation in violations)

    def test_options_attached_to_a_user_function_return_a_violation(self) -> None:
        """利用者定義関数に添えた選択肢を違反として返す。"""
        spec = MethodSpec(
            name="user",
            kind="callable",
            function=_user_linear,
            initial={"slope": 1.0, "intercept": 0.0},
            options={"window": 7},
        )
        result = resolve(spec, None)
        assert ViolationKind.CONFIG_INVALID in _kinds(result)
        assert any("window" in violation.message for violation in _violations(result))

    def test_empty_options_are_not_a_violation(self) -> None:
        """既定は空の写像であり、「何も指定していない」を意味する。"""
        spec = MethodSpec(
            name="decay",
            kind="expression",
            expression="a * x + b",
            initial={"a": 1.0, "b": 0.0},
            options={},
        )
        assert isinstance(resolve(spec, None), PreparedModel)

    def test_the_report_states_that_the_route_has_no_options(self) -> None:
        """利用者の次の行動が「その指定を消す」であるため、理由を明示する。"""
        spec = MethodSpec(
            name="decay",
            kind="expression",
            expression="a * x + b",
            initial={"a": 1.0, "b": 0.0},
            options={"degree": 3},
        )
        message = _violations(resolve(spec, None))[0].message
        assert "選択肢" in message

    def test_option_names_are_listed_in_name_order(self) -> None:
        """要件 8.2 の決定性: 写像の走査順に報告内容が左右されない。"""
        spec = MethodSpec(
            name="decay",
            kind="expression",
            expression="a * x + b",
            initial={"a": 1.0, "b": 0.0},
            options={"window": 7, "degree": 3, "alpha": 1},
        )
        messages = [v.message for v in _violations(resolve(spec, None))]
        joined = "\n".join(messages)
        assert joined.index("alpha") < joined.index("degree") < joined.index("window")

    def test_comes_back_together_with_other_violations(self) -> None:
        """最初の 1 件で打ち切らない（要件 3.4、設計の Postconditions）。"""
        spec = MethodSpec(
            name="decay",
            kind="expression",
            expression="a * x + b",
            options={"degree": 3},
        )
        kinds = _kinds(resolve(spec, None))
        assert ViolationKind.CONFIG_INVALID in kinds
        assert ViolationKind.INITIAL_REQUIRED in kinds

    def test_comes_back_together_even_when_the_model_cannot_be_resolved(self) -> None:
        """モデルを解決できない場合も同時に返る。"""
        spec = MethodSpec(
            name="decay",
            kind="expression",
            expression="a * x +",
            initial={"a": 1.0},
            options={"degree": 3},
        )
        kinds = _kinds(resolve(spec, None))
        assert ViolationKind.CONFIG_INVALID in kinds
        assert ViolationKind.MODEL_UNRESOLVED in kinds

    def test_builtin_model_options_are_still_accepted(self) -> None:
        """組込モデルの選択肢は引き続き受け付ける。"""
        spec = MethodSpec(
            name="p", kind="builtin", builtin="polynomial", options={POLYNOMIAL_DEGREE_OPTION: 3}
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert result.parameter_names == ("c0", "c1", "c2", "c3")

    def test_smoother_options_are_still_accepted(self) -> None:
        """平滑化手法の選択肢は引き続き受け付ける。"""
        spec = MethodSpec(
            name="s",
            kind="smoother",
            smoother=SmootherKind.MOVING_AVERAGE,
            options={"window": 5},
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedSmoother)
        assert dict(result.options) == {"window": 5}


class TestCollectingEveryViolation:
    """最初の 1 件で打ち切らないこと（要件 3.4、設計の Postconditions）。"""

    def test_several_violations_come_back_together(self) -> None:
        """複数の違反が一度に返る。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            initial={"slope": 10.0, "nope": 1.0},
            bounds={"slope": (0.0, 5.0)},
        )
        kinds = _kinds(resolve(spec, None))
        assert ViolationKind.INITIAL_OUT_OF_BOUNDS in kinds
        assert ViolationKind.CONFIG_INVALID in kinds

    def test_a_resolution_failure_and_a_missing_initial_come_back_together(self) -> None:
        """モデル解決の失敗と初期値必須が同時に返る。"""
        spec = MethodSpec(name="m", kind="expression", expression="a * x +")
        kinds = _kinds(resolve(spec, None))
        assert ViolationKind.MODEL_UNRESOLVED in kinds
        assert ViolationKind.INITIAL_REQUIRED in kinds

    def test_the_violation_order_is_constant_across_calls(self) -> None:
        """違反の並びは呼び出しによらず一定である。"""
        spec = MethodSpec(
            name="line",
            kind="builtin",
            builtin="linear",
            initial={"slope": 10.0, "zz": 1.0, "aa": 2.0},
            bounds={"slope": (0.0, 5.0), "intercept": (5.0, 1.0)},
        )
        orders = {
            tuple((v.kind, v.location, v.message) for v in _violations(resolve(spec, None)))
            for _ in range(3)
        }
        assert len(orders) == 1


class TestSmootherResolution:
    """モデル式を前提としない手法も同一入口で解決できること（要件 5.1 への接続）。"""

    @pytest.mark.parametrize("kind", list(SmootherKind))
    def test_every_method_resolves(self, kind: SmootherKind) -> None:
        """各手法を解決できる。"""
        result = resolve(MethodSpec(name="s", kind="smoother", smoother=kind), None)
        assert isinstance(result, PreparedSmoother)
        assert result.kind is kind

    def test_keeps_the_given_options(self) -> None:
        """指定したオプションを保持する。"""
        spec = MethodSpec(
            name="s",
            kind="smoother",
            smoother=SmootherKind.MOVING_AVERAGE,
            options={"window": 5},
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedSmoother)
        assert dict(result.options) == {"window": 5}

    def test_applying_the_defaults_is_left_to_the_fitting_engine(self) -> None:
        """既定値の定義が 2 か所に分かれると、検証を通った設定が別の値で動く。

        解決済み表現は利用者の指定をそのまま保つだけで、補われた選択肢を置く場を
        持たない。場があると、常に空のまま記録経路に載らない写しが残る。
        """
        result = resolve(
            MethodSpec(name="s", kind="smoother", smoother=SmootherKind.POLYNOMIAL), None
        )
        assert isinstance(result, PreparedSmoother)
        assert dict(result.options) == {}
        assert not hasattr(result, "applied_defaults")

    def test_an_unknown_method_name_returns_a_violation(self) -> None:
        """未知の手法名を違反として返す。"""
        spec = MethodSpec(name="s", kind="smoother", smoother="lowess")  # type: ignore[arg-type]
        assert ViolationKind.MODEL_UNRESOLVED in _kinds(resolve(spec, None))

    def test_the_kept_options_are_immutable(self) -> None:
        """保持したオプションは書き換えられない。"""
        spec = MethodSpec(
            name="s", kind="smoother", smoother=SmootherKind.MOVING_AVERAGE, options={"window": 5}
        )
        result = resolve(spec, None)
        assert isinstance(result, PreparedSmoother)
        with pytest.raises(TypeError):
            result.options["window"] = 7  # type: ignore[index]


class TestSpecImmutability:
    """解決前後のいずれの表現も、生成後に書き換えられないこと。"""

    def test_the_spec_is_frozen(self) -> None:
        """指定は凍結されている。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear")
        with pytest.raises(FrozenInstanceError):
            spec.name = "other"  # type: ignore[misc]

    def test_the_spec_mappings_are_immutable(self) -> None:
        """指定の対応表は書き換えられない。"""
        spec = MethodSpec(name="line", kind="builtin", builtin="linear", initial={"slope": 1.0})
        with pytest.raises(TypeError):
            spec.initial["slope"] = 2.0  # type: ignore[index]

    def test_the_resolution_result_is_frozen(self) -> None:
        """解決結果は凍結されている。"""
        result = resolve(MethodSpec(name="line", kind="builtin", builtin="linear"), None)
        assert isinstance(result, PreparedModel)
        with pytest.raises(FrozenInstanceError):
            result.display_name = "other"  # type: ignore[misc]

    def test_passing_a_spec_does_not_affect_the_caller_dict(self) -> None:
        """指定を渡しても呼び出し側の辞書に影響しない。"""
        initial = {"slope": 1.0, "intercept": 0.0}
        spec = MethodSpec(name="line", kind="builtin", builtin="linear", initial=initial)
        initial["slope"] = 99.0
        result = resolve(spec, None)
        assert isinstance(result, PreparedModel)
        assert _values(result)["slope"] == 1.0


def _module_source() -> str:
    return (SRC / "models" / "resolver.py").read_text(encoding="utf-8")


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse(_module_source())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


def _names_bound_from(prefixes: set[str]) -> set[str]:
    """指定モジュール群から束縛された識別子（別名を含む）を集める。"""
    tree = ast.parse(_module_source())
    bound: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in prefixes:
                    bound.add(alias.asname or alias.name.split(".")[0])
        elif (
            isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.split(".")[0] in prefixes
        ):
            bound.update(alias.asname or alias.name for alias in node.names)
    return bound


def _public_annotations() -> list[str]:
    """公開シグネチャ（非私有の関数引数・戻り値・属性）の注釈を文字列で返す。"""
    tree = ast.parse(_module_source())
    annotations: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            if node.name.startswith("_") and node.name != "__init__":
                continue
            args = node.args
            for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs):
                if arg.annotation is not None and not arg.arg.startswith("_"):
                    annotations.append(ast.unparse(arg.annotation))
            if node.returns is not None:
                annotations.append(ast.unparse(node.returns))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if not node.target.id.startswith("_"):
                annotations.append(ast.unparse(node.annotation))
    return annotations


class TestDependencyExposure:
    """依存の露出。"""

    def test_does_not_import_upper_layers_or_libraries_of_other_areas(self) -> None:
        """設計の依存方向: models は types / errors までしか参照しない。
        SciPy は engines、matplotlib は plotting、pandas は readers/writers に閉じる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"scipy", "matplotlib", "pandas"}, (
                f"resolver.py が {imported} を import している"
            )
            assert imported not in {
                "curvefit.engines",
                "curvefit.preprocess",
                "curvefit.config",
                "curvefit.preflight",
                "curvefit.pipeline",
                "curvefit.api",
                "curvefit.cli",
            }, f"resolver.py が上位層の {imported} を import している"

    def test_public_signatures_expose_no_underlying_library_types(self) -> None:
        """内部で lmfit を使うことは前提。外向きの注釈に漏らさないことを検証する。"""
        leaked = _names_bound_from({"lmfit", "asteval"})
        assert leaked, "lmfit を import していない場合、この検証は無意味になる"
        for annotation in _public_annotations():
            used = {
                node.id for node in ast.walk(ast.parse(annotation)) if isinstance(node, ast.Name)
            }
            assert not (used & leaked), f"公開注釈 {annotation!r} が {used & leaked} を露出している"

    def test_public_attributes_of_the_resolved_representation_expose_no_library_types(self) -> None:
        """モデル実体は object として保持し、参照するのは当てはめエンジンに限る。"""
        annotations = {
            name: str(annotation)
            for name, annotation in PreparedModel.__annotations__.items()
            if not name.startswith("_")
        }
        for annotation in annotations.values():
            assert "lmfit" not in annotation and "Model" not in annotation


class TestOwnershipOfPerParameterFields:
    """`PARAMETER_FIELDS` が `MethodSpec` の実物から取り残されないこと。

    この並びは実行前ゲートと解決層の双方が使う。かつて実行前ゲート側が独自に同じ
    並びを持っており、平滑化手法へのパラメータ指定を検査する場が片方にしか無い
    状態が生まれた（タスク 9.1 の欠陥）。場が増えたときに片方だけが更新される形を
    構造として無くしたうえで、増えたこと自体に気づけるようにする。
    """

    def test_every_mapping_field_is_classified_as_per_parameter_or_as_options(self) -> None:
        """`MethodSpec` の写像型の場が、既知の 2 分類を漏れなく覆うこと。

        新しい写像型の場が加わると落ちる。落ちたときに問うべきは
        「その場はパラメータ名で引くのか、選択肢名で引くのか」であり、
        前者なら `PARAMETER_FIELDS` に加え、実行前ゲートの検査対象にも入る。
        """
        mapping_fields = {
            f.name for f in dataclasses.fields(MethodSpec) if "Mapping" in str(f.type)
        }
        assert mapping_fields == {*PARAMETER_FIELDS, "options"}, (
            "MethodSpec の写像型の場が増減した。パラメータ名で引く場なら "
            "PARAMETER_FIELDS に加える（実行前ゲートの検査対象にもなる）。"
            "選択肢名で引く場なら options 側の系統に加える"
        )

    def test_the_order_does_not_change_between_runs(self) -> None:
        """報告の順序が固定であること（要件 8.2）。"""
        assert PARAMETER_FIELDS == ("initial", "bounds", "fixed")

    def test_options_are_excluded(self) -> None:
        """`options` は選択肢名で引くものであり、対象がパラメータではない。"""
        assert "options" not in PARAMETER_FIELDS
