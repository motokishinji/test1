"""宣言した最低 Python バージョンで実際にソースが解釈できることを検証する。

パッケージ定義の `requires-python` は利用者への約束である。約束したバージョンで
import すらできない状態は、テストが全て通っていても出荷できない欠陥になる。
新しい構文を使った時点で気付けるよう、宣言値そのものを検査の入力にする。

対応要件: 8.1（設定ファイル形式を標準ライブラリで読める下限の宣言）
"""

from __future__ import annotations

import ast
import re
import tomllib
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SRC = PROJECT_ROOT / "src"


def _declared_minimum() -> tuple[int, int]:
    """`pyproject.toml` の `requires-python` から下限の (major, minor) を取り出す。"""
    manifest = tomllib.loads((PROJECT_ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    spec = manifest["project"]["requires-python"]
    match = re.fullmatch(r">=\s*(\d+)\.(\d+)", spec.strip())
    assert match, f"requires-python の書式が想定外: {spec!r}"
    return int(match.group(1)), int(match.group(2))


def _source_files() -> list[Path]:
    return sorted(SRC.rglob("*.py"))


def test_source_files_exist() -> None:
    """ソースファイルが存在する。"""
    assert _source_files(), "検査対象のソースが見つからない"


@pytest.mark.parametrize("path", _source_files(), ids=lambda p: str(p.relative_to(SRC)))
def test_parses_under_declared_minimum_version(path: Path) -> None:
    """宣言下限より新しい構文を使っていないことを、宣言値から導いて検査する。

    `ast.parse(feature_version=...)` は指定バージョンで未対応の構文を SyntaxError にする。
    たとえば PEP 695 の `type X = ...` 文は 3.12 以降であり、下限が 3.11 のまま使うと
    3.11 環境で import が失敗する。
    """
    minimum = _declared_minimum()
    try:
        ast.parse(path.read_text(encoding="utf-8"), feature_version=minimum)
    except SyntaxError as error:  # pragma: no cover - 失敗時のみ通る
        pytest.fail(
            f"{path.relative_to(PROJECT_ROOT)}:{error.lineno} は "
            f"Python {minimum[0]}.{minimum[1]} で解釈できない: {error.msg}\n"
            "構文を下限に合わせるか、pyproject.toml の requires-python を引き上げること。"
        )
