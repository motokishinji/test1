"""実測値とフィット曲線を重ねたグラフ画像の生成を検証する。

対応要件: 7.4（実測値とフィット曲線を重ねたプロットを対象ごとに画像ファイルとして
既定で保存する）、9.1（対話環境を含む他の Python コードから呼び出せる）、10.2（数百件
規模のバッチを一般的な作業用 PC で数分以内に完了する）。

設計の writers / plotting ブロック（Responsibilities & Constraints の「``plotting`` は
``Figure`` に ``FigureCanvasAgg`` を直接結び付けて描画を画面非依存にし、``Figure`` を
1 つ再利用する。**プロセス大域のバックエンドは変更しない**。他モジュールから matplotlib
を import してはならない」、Batch / Job Contract の ``{output_dir}/plots/{stem}.png``、
Implementation Notes の「``render_fit_plot`` は ``Figure`` を再利用し、描画のたびに
``Axes`` をクリアする」）、Performance & Scalability（支配的コストは描画であり、対策は
Agg キャンバスの直結・``Figure`` 再利用・``Axes`` クリアによる再描画・``pyplot`` の
不使用）、および Allowed Dependencies（matplotlib は ``plotting`` でのみ使用）を対象とする。

``Figure`` を対象ごとに生成するとメモリが線形に増加することは `research.md` に実測付きで
記録されている（夜間バッチが 60GB を消費した事例）。したがって **画像が出来ていること
だけでは足りず、1 つの ``Figure`` が使い回されていること自体を主張する**。単体テストで
プロセスの実メモリを測るのは環境差で揺れるため、代理指標として **生存している
``Figure`` の個数** が対象数に比例しないことを見る。これが線形増加を捕まえられる
最小の観測量である。

要件 8.2 の再現性は画像にも及ぶ。matplotlib は既定で PNG に ``Software``
（バージョン文字列）を埋め込むため、これを明示的に落としているかを **チャンク単位で**
検査する。バイト一致の主張だけでは、同一プロセス内では通り環境をまたぐと破れる欠陥を
見逃す。
"""

from __future__ import annotations

import ast
import copy
import gc
import os
import subprocess
import sys
import warnings
from collections.abc import Iterator
from pathlib import Path

import numpy as np
import pytest
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.lines import Line2D

from curvefit import plotting
from curvefit.plotting import (
    FIT_LABEL,
    JAPANESE_FONT_CANDIDATES,
    OBSERVED_LABEL,
    _shared_canvas,
    render_fit_plot,
    selected_japanese_font,
)
from curvefit.types import (
    CurveData,
    FitSuccess,
    FloatArray,
    GoodnessOfFit,
    ParameterEstimate,
    PreprocessReport,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SRC = PROJECT_ROOT / "src" / "curvefit"

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"

MIN_PNG_BYTES = 1000
"""画像として意味のある最小サイズ。空の ``Figure`` でも数 KB になるため下限は緩く採る。"""

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
"""root は権限ビットを無視して書き込めるため、書き込み不能の検証が成立しない。"""

requires_permission_bits = pytest.mark.skipif(
    IS_ROOT, reason="root では権限ビットによる書き込み不能を再現できない"
)


def _array(values: list[float]) -> FloatArray:
    return np.array(values, dtype=np.float64)


def _curve(n: int = 8) -> CurveData:
    x = _array([float(i) for i in range(n)])
    y_observed = _array([float(i) * 2.0 + (1.0 if i % 2 else -1.0) for i in range(n)])
    y_fit = _array([float(i) * 2.0 for i in range(n)])
    residual = _array(
        [float(observed - fit) for observed, fit in zip(y_observed, y_fit, strict=True)]
    )
    return CurveData(x=x, y_observed=y_observed, y_fit=y_fit, residual=residual)


UNSORTED_X = [5.0, 1.0, 3.0, 2.0, 4.0]
"""x について単調でない行順。入力ファイルの行順がそのまま届く状況を再現する。

``readers`` / ``preprocess`` / 各エンジンのいずれも x を並べ替えず、``CurveData`` は
入力の行順を保つ。したがって並びの崩れた x は実運用で描画まで到達する。
"""

UNSORTED_Y_FIT = [9.0, 10.0, 12.0, 7.0, 6.0]
"""``UNSORTED_X`` に対応する当てはめ値。**x の単調関数にしない**。

y_fit を x の単調関数に採ると、x と y_fit を別々に昇順へ並べ替えても対応が偶然一致して
しまい、対応を壊す並べ替えを検出できなくなる。
"""


def _unsorted_curve() -> CurveData:
    """x が昇順でない曲線データ。当てはめ曲線の並べ替えを検証するために使う。"""
    x = _array(UNSORTED_X)
    y_fit = _array(UNSORTED_Y_FIT)
    y_observed = y_fit + _array([0.5, -0.5, 0.25, -0.25, 0.75])
    return CurveData(x=x, y_observed=y_observed, y_fit=y_fit, residual=y_observed - y_fit)


def _success(
    source_id: str = "sample.csv",
    method_name: str = "linear",
    curve: CurveData | None = None,
) -> FitSuccess:
    resolved = curve if curve is not None else _curve()
    return FitSuccess(
        source_id=source_id,
        method_name=method_name,
        parameters=(ParameterEstimate(name="slope", value=2.0, stderr=0.1, fixed=False),),
        goodness=GoodnessOfFit(
            r_squared=0.99,
            rmse=1.0,
            n_points=len(resolved),
            n_varied_params=1,
        ),
        curve=resolved,
        preprocess=PreprocessReport(
            n_input=len(resolved),
            n_dropped_invalid=0,
            n_dropped_out_of_range=0,
            n_dropped_outlier=0,
            outlier_points=(),
        ),
    )


def _png_chunks(data: bytes) -> list[tuple[str, bytes]]:
    """PNG をチャンクに分解する。埋め込みメタデータの有無を型で判定するために使う。"""
    assert data[:8] == PNG_MAGIC, "PNG の署名がない"
    chunks: list[tuple[str, bytes]] = []
    offset = 8
    while offset < len(data):
        length = int.from_bytes(data[offset : offset + 4], "big")
        kind = data[offset + 4 : offset + 8].decode("ascii")
        chunks.append((kind, data[offset + 8 : offset + 8 + length]))
        offset += 12 + length
    return chunks


def _live_figure_count() -> int:
    """生存している ``Figure`` の個数。``Figure`` 再利用の破れを捕まえる代理指標。"""
    gc.collect()
    return sum(1 for obj in gc.get_objects() if isinstance(obj, Figure))


def _rendered_axes() -> Axes:
    """描画に使われている ``Axes``。図の中身を直接検査するために取り出す。

    描画資源を持つ :func:`~curvefit.plotting._shared_canvas` から直接取り出す。
    検査のためだけの取り出し口を production 側に置くと、本番経路から呼ばれない
    関数が残る。
    """
    return _shared_canvas()[1]


def _line_labelled(label: str) -> Line2D:
    """指定した凡例名を持つ線を 1 本だけ取り出す。系列の識別は凡例名で行う。

    描画順の添字で取り出すと、系列を足したときに黙って別の系列を検査し始める。
    """
    matched = [line for line in _rendered_axes().get_lines() if line.get_label() == label]
    assert len(matched) == 1, f"凡例名 {label!r} の線が 1 本ではない: {len(matched)} 本"
    return matched[0]


def _pairs(line: Line2D) -> set[tuple[float, float]]:
    """線が結んでいる (x, y) の組の集合。並べ替えで対応が入れ替わったかを見るために使う。"""
    x = np.asarray(line.get_xdata(), dtype=np.float64).tolist()
    y = np.asarray(line.get_ydata(), dtype=np.float64).tolist()
    return set(zip(x, y, strict=True))


def _rendered_figure() -> Figure:
    """描画に使われている ``Figure``。再利用の主張はこの実体の同一性で行う。"""
    figure = _shared_canvas()[0]
    assert isinstance(figure, Figure)
    return figure


_RENDER_PROGRAM = '''\
{preamble}
import hashlib
import sys
from pathlib import Path

import matplotlib
import numpy as np

from curvefit.plotting import render_fit_plot
from curvefit.types import (
    CurveData,
    FitSuccess,
    GoodnessOfFit,
    ParameterEstimate,
    PreprocessReport,
)

x = np.array({x}, dtype=np.float64)
y_fit = np.array({y_fit}, dtype=np.float64)
y_observed = y_fit + 0.5
curve = CurveData(x=x, y_observed=y_observed, y_fit=y_fit, residual=y_observed - y_fit)
success = FitSuccess(
    source_id="sample.csv",
    method_name="linear",
    parameters=(ParameterEstimate(name="slope", value=2.0, stderr=0.1, fixed=False),),
    goodness=GoodnessOfFit(r_squared=0.99, rmse=1.0, n_points=len(curve), n_varied_params=1),
    curve=curve,
    preprocess=PreprocessReport(
        n_input=len(curve),
        n_dropped_invalid=0,
        n_dropped_out_of_range=0,
        n_dropped_outlier=0,
        outlier_points=(),
    ),
)
path = Path(sys.argv[1])
render_fit_plot(success, path)
print(matplotlib.get_backend())
print(hashlib.sha256(path.read_bytes()).hexdigest())
'''
"""別プロセスで 1 枚描き、プロセスのバックエンド名と画像の SHA256 を出力する台本。

バックエンドの主張は同一プロセス内では立てられない。``curvefit.plotting`` は
テスト収集の時点で既に取り込まれており、import による副作用の有無を後から観測できない
ためである。
"""

_SVG_PREAMBLE = "import matplotlib\nmatplotlib.use('svg')\nimport matplotlib.pyplot\n"
"""``curvefit.plotting`` より先に別バックエンドを確定させる前置き。

import 順を作為的に不利にする。
"""

_NO_PREAMBLE = ""
"""前置きなし。既定バックエンドのまま描かせる対照。"""


def _environment(**overrides: str) -> dict[str, str]:
    """子プロセスの環境。``MPLBACKEND`` は明示指定した場合だけ渡す。

    親の環境に ``MPLBACKEND`` が残っていると、対照であるはずの既定バックエンド実行が
    汚染される。
    """
    environment = dict(os.environ, PYTHONPATH=str(PROJECT_ROOT / "src"))
    environment.pop("MPLBACKEND", None)
    environment.update(overrides)
    return environment


def _render_in_subprocess(
    preamble: str, path: Path, environment: dict[str, str]
) -> tuple[str, str]:
    """別プロセスで 1 枚描かせ、(プロセスのバックエンド名, 画像の SHA256) を返す。"""
    program = _RENDER_PROGRAM.format(preamble=preamble, x=UNSORTED_X, y_fit=UNSORTED_Y_FIT)

    completed = subprocess.run(
        [sys.executable, "-c", program, str(path)],
        capture_output=True,
        text=True,
        env=environment,
        timeout=180,
        check=False,
    )

    assert completed.returncode == 0, f"子プロセスが失敗した:\n{completed.stderr}"
    backend, digest = completed.stdout.split()
    return backend, digest


def _imported_roots(path: Path) -> set[str]:
    """ソースが import しているトップレベルのモジュール名を構文木から集める。

    文字列 grep では docstring 内のライブラリ名に反応する。本モジュール群は docstring で
    matplotlib に繰り返し言及するため、構文木で判定しなければ検査が成立しない
    （tasks.md の Implementation Notes）。
    """
    tree = ast.parse(path.read_text(encoding="utf-8"))
    roots = {
        alias.name.split(".")[0]
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
        for alias in node.names
    }
    roots |= {
        node.module.split(".")[0]
        for node in ast.walk(tree)
        if isinstance(node, ast.ImportFrom) and node.module
    }
    return roots


class TestImageGeneration:
    """要件 7.4: 対象ごとに画像ファイルとして保存する。"""

    def test_png_image_is_written(self, tmp_path: Path) -> None:
        """PNG画像が生成される。"""
        path = tmp_path / "plots" / "sample__linear__0000.png"

        render_fit_plot(_success(), path)

        data = path.read_bytes()
        assert data[:8] == PNG_MAGIC, "PNG の署名がない"
        assert len(data) > MIN_PNG_BYTES, f"画像が小さすぎる: {len(data)} バイト"

    def test_creates_the_parent_directory(self, tmp_path: Path) -> None:
        """出力先は ``{output_dir}/plots/{stem}.png``（Batch / Job Contract）。

        ``plots/`` 階層を作るのは出力側の責務である（``writers`` の曲線 CSV と同じ規約）。
        """
        path = tmp_path / "out" / "plots" / "a__linear__0000.png"

        render_fit_plot(_success(), path)

        assert path.is_file()

    def test_overwrites_an_existing_image(self, tmp_path: Path) -> None:
        """同一設定での再実行は同一パスを上書きする（Idempotency & recovery）。"""
        path = tmp_path / "a.png"
        path.write_bytes(b"stale")

        render_fit_plot(_success(), path)

        assert path.read_bytes()[:8] == PNG_MAGIC

    def test_both_observations_and_the_fitted_curve_are_drawn(self, tmp_path: Path) -> None:
        """要件 7.4 は「重ねたプロット」を求める。ファイルの有無では確かめられない。"""
        curve = _curve()
        render_fit_plot(_success(curve=curve), tmp_path / "a.png")

        axes = _rendered_axes()
        drawn = [line.get_ydata() for line in axes.get_lines()]
        drawn += [collection.get_offsets()[:, 1] for collection in axes.collections]

        assert any(np.array_equal(np.asarray(values), curve.y_observed) for values in drawn), (
            "実測値が描かれていない"
        )
        assert any(np.array_equal(np.asarray(values), curve.y_fit) for values in drawn), (
            "当てはめ曲線が描かれていない"
        )

    def test_source_identification_appears_in_the_figure(self, tmp_path: Path) -> None:
        """複数対象の画像が後から区別できること（要件 7.4 の「処理対象ごとに」）。"""
        render_fit_plot(
            _success(source_id="run1/a.csv", method_name="gaussian"), tmp_path / "a.png"
        )

        title = _rendered_axes().get_title()

        assert "run1/a.csv" in title
        assert "gaussian" in title

    def test_an_image_is_produced_for_each_consecutively_drawn_source(self, tmp_path: Path) -> None:
        """要件 7.4 は対象ごとの保存を求める。再利用が内容の取り違えを招かないことを見る。"""
        paths = [tmp_path / f"target_{i}.png" for i in range(5)]

        for index, path in enumerate(paths):
            curve = _curve(n=4 + index)
            render_fit_plot(_success(source_id=f"s{index}.csv", curve=curve), path)

        assert all(path.read_bytes()[:8] == PNG_MAGIC for path in paths)
        assert len({path.read_bytes() for path in paths}) == len(paths), (
            "異なるデータが同一の画像になっている"
        )


class TestFittedCurveOrdering:
    """当てはめ曲線は x の昇順に結ぶ（Implementation Notes の ``render_fit_plot``）。

    ``CurveData`` の並び順は入力ファイルの行順であり、x について単調とは限らない。
    並べ替えずに結ぶと、モデルは滑らかなのに図だけが往復する折れ線になり、要件 7.4 の
    「重ねたプロット」が読めなくなる。

    **値の集合だけを見る検査ではこの欠陥を素通りさせる**。並べ替えの有無は y の集合を
    変えないためである。したがって観測量は線の **x 座標そのもの** と **(x, y_fit) の
    対応** に採る。
    """

    def test_fitted_curve_is_connected_in_ascending_x(self, tmp_path: Path) -> None:
        """当てはめ曲線はxの昇順に結ばれる。"""
        render_fit_plot(_success(curve=_unsorted_curve()), tmp_path / "a.png")

        drawn_x = np.asarray(_line_labelled(FIT_LABEL).get_xdata(), dtype=np.float64)

        assert np.all(np.diff(drawn_x) >= 0.0), (
            f"当てはめ曲線が x の昇順で結ばれていない: {drawn_x}"
        )

    def test_sorting_preserves_the_pairing_of_x_and_fitted_values(self, tmp_path: Path) -> None:
        """x と y_fit を別々に並べ替えると、昇順にはなるが点の対応が入れ替わる。

        昇順であることだけを主張すると、この壊し方を見逃す。
        """
        curve = _unsorted_curve()
        render_fit_plot(_success(curve=curve), tmp_path / "a.png")

        drawn = _pairs(_line_labelled(FIT_LABEL))
        expected = set(zip(curve.x.tolist(), curve.y_fit.tolist(), strict=True))

        assert drawn == expected, f"(x, y_fit) の対応が並べ替えで壊れている: {sorted(drawn)}"

    def test_observations_are_drawn_in_input_order(self, tmp_path: Path) -> None:
        """点は結ばないため並び順を要しない。不要な並べ替えを持ち込んでいないことを見る。"""
        curve = _unsorted_curve()
        render_fit_plot(_success(curve=curve), tmp_path / "a.png")

        line = _line_labelled(OBSERVED_LABEL)

        assert np.array_equal(np.asarray(line.get_xdata()), curve.x), "実測値の並びが変えられている"
        assert np.array_equal(np.asarray(line.get_ydata()), curve.y_observed)

    def test_sorting_does_not_touch_the_passed_outcome(self, tmp_path: Path) -> None:
        """並べ替えは新しい配列を作る。入力の並びが昇順に書き換わってはならない。"""
        success = _success(curve=_unsorted_curve())

        render_fit_plot(success, tmp_path / "a.png")

        assert np.array_equal(success.curve.x, _array(UNSORTED_X)), "入力の x が並べ替えられている"
        assert np.array_equal(success.curve.y_fit, _array(UNSORTED_Y_FIT))


class TestFigureReuse:
    """要件 10.2 と Performance & Scalability: ``Figure`` を 1 つ再利用する。"""

    def test_the_drawing_target_is_the_same_instance_every_time(self, tmp_path: Path) -> None:
        """描画対象は毎回同じ実体である。"""
        render_fit_plot(_success(), tmp_path / "a.png")
        first = _rendered_figure()

        for index in range(10):
            render_fit_plot(_success(source_id=f"s{index}.csv"), tmp_path / f"b{index}.png")

        assert _rendered_figure() is first, "対象ごとに Figure が作り直されている"

    def test_figure_count_does_not_grow_with_the_number_of_sources(self, tmp_path: Path) -> None:
        """``Figure`` の個数が対象数に比例しないことを見る（線形増加の直接の代理）。

        単体テストでプロセスの実メモリ（RSS）を主張すると、GC・アロケータ・並走する
        テストの影響で揺れる。`research.md` が記録する線形増加の原因は対象ごとの
        ``Figure`` 生成そのものであるため、**生存 ``Figure`` の個数** を観測量に採る。
        個数が一定なら、描画に伴うメモリは対象数に依存しない。
        """
        baseline = _live_figure_count()

        for index in range(50):
            render_fit_plot(_success(source_id=f"s{index}.csv"), tmp_path / f"p{index}.png")

        assert _live_figure_count() <= baseline + 1, "対象ごとに Figure が積み上がっている"

    def test_the_previous_source_drawing_does_not_remain(self, tmp_path: Path) -> None:
        """再利用は ``Axes`` のクリアと対である。クリアを怠ると前の対象が重なって残る。"""
        first = _curve(n=8)
        render_fit_plot(_success(source_id="first.csv", curve=first), tmp_path / "first.png")
        artists_after_first = len(_rendered_axes().get_lines()) + len(_rendered_axes().collections)

        second = _curve(n=5)
        render_fit_plot(_success(source_id="second.csv", curve=second), tmp_path / "second.png")

        axes = _rendered_axes()
        assert len(axes.get_lines()) + len(axes.collections) == artists_after_first, (
            "前の対象の描画がクリアされていない"
        )
        drawn = [np.asarray(line.get_ydata()) for line in axes.get_lines()]
        drawn += [np.asarray(c.get_offsets()[:, 1]) for c in axes.collections]
        assert all(len(values) == len(second) for values in drawn), "前の対象の点数が残っている"

    def test_the_figure_is_not_registered_with_pyplot(self, tmp_path: Path) -> None:
        """pyplot の図管理簿は参照を保持し続ける。`research.md` の線形増加の経路そのもの。"""
        render_fit_plot(_success(), tmp_path / "a.png")

        pyplot = sys.modules.get("matplotlib.pyplot")
        if pyplot is None:
            return
        assert pyplot.get_fignums() == [], "pyplot に Figure が登録されている"


class TestDrawingBackend:
    """Responsibilities & Constraints: Agg キャンバスを直結し、大域設定は変更しない。

    描画を画面非依存にする手段は 2 つあり、採否が分かれる。

    - **``Figure`` への ``FigureCanvasAgg`` の直結** — 採る。その図の描画だけが Agg になる
    - **``matplotlib.use("Agg", force=True)``** — 採らない。プロセス全体を書き換えるため、
      要件 7.4 により画像出力が既定である以上 ``pipeline`` は必ず ``plotting`` を取り込み、
      ``from curvefit import run_batch`` と書いただけで対話環境の表示設定が黙って壊れる
      （要件 9.1）

    大域を変えないことと、出力が環境に依存しないこと（要件 8.2）は両立しなければならない。
    本クラスは **両方** を主張する。片方だけでは、壊れ方の異なる欠陥をそれぞれ見逃す。
    """

    def test_contains_no_call_that_switches_the_global_backend(self) -> None:
        """切り替えの呼び出しがソースに無いことを構文木で直接見る。

        ``matplotlib.use`` は import 順にも環境変数にも依存せず効いてしまう。混入は
        別プロセスでの振る舞い検査より手前、ソースの形の段階で止める。
        """
        tree = ast.parse((SRC / "plotting.py").read_text(encoding="utf-8"))
        switches = [
            ast.unparse(node)
            for node in ast.walk(tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr in {"use", "switch_backend"}
        ]

        assert switches == [], f"プロセス大域のバックエンドを切り替えている: {switches}"

    def test_the_figure_canvas_is_agg(self, tmp_path: Path) -> None:
        """大域設定が何であれ、描画そのものは Agg で行われること。"""
        from matplotlib.backends.backend_agg import FigureCanvasAgg

        render_fit_plot(_success(), tmp_path / "a.png")

        assert isinstance(_rendered_figure().canvas, FigureCanvasAgg)

    def test_produces_the_same_image_without_changing_a_foreign_global_backend(
        self, tmp_path: Path
    ) -> None:
        """要件 9.1: 取り込んでも利用者のバックエンド設定を奪わない。

        pyplot を先に別バックエンドで取り込み、環境変数でも別バックエンドを指定した状態で
        ``curvefit.plotting`` を import する。import 後もプロセスのバックエンドは ``svg``
        のままでなければならない。

        同時に、その環境で描いた画像が既定バックエンドで描いた画像とバイト単位で一致する
        ことを見る。大域を変えない代わりに出力が環境依存になったのでは、要件 8.2 の
        再現性を失って要件 9.1 を買ったことになる。
        """
        under_svg = tmp_path / "svg.png"
        under_default = tmp_path / "default.png"

        svg_backend, svg_digest = _render_in_subprocess(
            _SVG_PREAMBLE, under_svg, _environment(MPLBACKEND="svg")
        )
        _, default_digest = _render_in_subprocess(_NO_PREAMBLE, under_default, _environment())

        assert svg_backend.lower() == "svg", (
            f"取り込んだだけでプロセス大域のバックエンドを書き換えている: {svg_backend}"
        )
        assert under_svg.read_bytes()[:8] == PNG_MAGIC, "別バックエンド下で PNG になっていない"
        assert svg_digest == default_digest, (
            f"バックエンド次第で画像が変わる: {svg_digest} と {default_digest}"
        )


class TestDependencyDirection:
    """設計の Allowed Dependencies: matplotlib は ``plotting`` でのみ使用する。"""

    def test_only_plotting_imports_the_drawing_library(self) -> None:
        """描画ライブラリを取り込むのはplottingだけである。"""
        importers = sorted(
            path.relative_to(SRC).as_posix()
            for path in SRC.rglob("*.py")
            if "matplotlib" in _imported_roots(path)
        )

        assert importers == ["plotting.py"], f"描画ライブラリの取り込みが漏れている: {importers}"

    def test_does_not_depend_on_downstream_layers(self) -> None:
        """``plotting`` が参照してよい自パッケージは ``types`` / ``errors`` までである。"""
        tree = ast.parse((SRC / "plotting.py").read_text(encoding="utf-8"))
        own = {
            node.module
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.startswith("curvefit")
        }
        own |= {
            alias.name
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
            if alias.name.startswith("curvefit")
        }

        assert own <= {"curvefit.types", "curvefit.errors"}, f"想定外の依存: {own}"


class TestReproducibility:
    """要件 8.2: 同一の入力に対して同一の出力物を返す。"""

    def test_the_same_outcome_yields_the_same_image(self, tmp_path: Path) -> None:
        """同じ結果からは同じ画像が得られる。"""
        success = _success()
        first = tmp_path / "first.png"
        second = tmp_path / "second.png"

        render_fit_plot(success, first)
        render_fit_plot(success, second)

        assert first.read_bytes() == second.read_bytes()

    def test_no_environment_dependent_metadata_is_embedded(self, tmp_path: Path) -> None:
        """既定では ``Software`` にバージョン文字列が入り、環境をまたぐと一致が破れる。"""
        path = tmp_path / "a.png"
        render_fit_plot(_success(), path)

        kinds = {kind for kind, _ in _png_chunks(path.read_bytes())}

        assert kinds & {"tEXt", "iTXt", "zTXt", "tIME"} == set(), (
            f"文字列・時刻のメタデータが埋め込まれている: {sorted(kinds)}"
        )


class TestInputImmutability:
    """当てはめ結果は凍結データである。描画は読むだけで、書き換えてはならない。"""

    def test_does_not_mutate_the_passed_outcome(self, tmp_path: Path) -> None:
        """渡された結果を書き換えない。"""
        success = _success()
        before = copy.deepcopy(success.curve)

        render_fit_plot(success, tmp_path / "a.png")

        assert np.array_equal(success.curve.x, before.x)
        assert np.array_equal(success.curve.y_observed, before.y_observed)
        assert np.array_equal(success.curve.y_fit, before.y_fit)
        assert np.array_equal(success.curve.residual, before.residual)

    def test_does_not_replace_the_passed_arrays(self, tmp_path: Path) -> None:
        """渡された配列を別の実体に差し替えない。"""
        success = _success()
        arrays = (success.curve.x, success.curve.y_observed, success.curve.y_fit)

        render_fit_plot(success, tmp_path / "a.png")

        assert (success.curve.x, success.curve.y_observed, success.curve.y_fit) == arrays


class TestReleasedOutcome:
    """要件 10.4: 曲線データを手放した結果は描画できない。

    描画はバッチが曲線を手放す **前** に行われる（``pipeline`` の ``run_job`` → ``run``）
    ため、ここに解放済みの結果が届くのは呼び出し側の誤りである。点の無い図を黙って書くと、
    出力ディレクトリの内容とサマリ表の成否が食い違う。
    """

    def test_raises_when_the_curve_data_is_absent(self, tmp_path: Path) -> None:
        """曲線データが無ければ例外を送出する。"""
        path = tmp_path / "a.png"

        with pytest.raises(ValueError, match="解放済み"):
            render_fit_plot(_success().without_curve(), path)

        assert not path.exists(), "描けない結果に対して空の画像が残っている"

    def test_the_exception_message_names_the_source_and_the_method(self) -> None:
        """数百件のバッチでは、対象を特定できないエラーは実質的に無価値である。"""
        success = _success(source_id="a.csv", method_name="linear").without_curve()

        with pytest.raises(ValueError) as caught:
            render_fit_plot(success, Path("unused.png"))

        assert "a.csv" in str(caught.value) and "linear" in str(caught.value)


class TestWriteFailure:
    """要件 10.3 の系統: 資源・環境の失敗は値として飲み込まず送出する。"""

    def test_raises_when_the_destination_is_a_directory(self, tmp_path: Path) -> None:
        """出力先がディレクトリなら例外を送出する。"""
        path = tmp_path / "a.png"
        path.mkdir()

        with pytest.raises(OSError):
            render_fit_plot(_success(), path)

    @requires_permission_bits
    def test_raises_when_the_destination_is_not_writable(self, tmp_path: Path) -> None:
        """書き込めない出力先では例外を送出する。"""
        directory = tmp_path / "readonly"
        directory.mkdir()
        directory.chmod(0o500)
        try:
            with pytest.raises(OSError):
                render_fit_plot(_success(), directory / "a.png")
        finally:
            directory.chmod(0o700)


JAPANESE_SOURCE_ID = "測定データ_2024年.csv"
"""日本語を含む対象識別子。測定データのファイル名に日本語を使うのは普通のことである。"""

JAPANESE_METHOD_NAME = "ガウシアン"
"""日本語を含む手法名。表題は対象名と手法名の両方を載せるため、両方を日本語にする。"""

MISSING_GLYPH_MARKER = "missing from font"
"""欠落グリフ警告の識別語。matplotlib は 1 文字ごとに 1 件の警告を出す。"""


def _missing_glyph_warnings(records: list[warnings.WarningMessage]) -> list[str]:
    """捕えた警告のうち、欠落グリフに関するものだけを取り出す。"""
    return [
        str(record.message) for record in records if MISSING_GLYPH_MARKER in str(record.message)
    ]


def _render_capturing_warnings(success: FitSuccess, path: Path) -> list[str]:
    """1 枚描き、その間に出た欠落グリフ警告の本文を返す。

    ``simplefilter("always")`` を置くのは、同一の警告が既に一度出ていると既定のフィルタが
    2 度目以降を握り潰し、検査が無条件に成立してしまうためである。
    """
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        render_fit_plot(success, path)
    return _missing_glyph_warnings(caught)


@pytest.fixture
def font_selection_reset() -> Iterator[None]:
    """フォント選択の記憶を退避し、テスト後に戻す。

    選択は初回に一度だけ決めて記憶する。記憶を戻さないと、環境を差し替えたテストの結果が
    後続のテストへ漏れる。
    """
    saved = plotting._font_choice
    try:
        yield
    finally:
        plotting._font_choice = saved


class TestJapaneseTitle:
    """要件 7.4: 対象ごとのプロットは、対象を識別できる表題を伴って読める状態で保存する。

    matplotlib の既定フォント DejaVu Sans は CJK のグリフを持たない。日本語を含む対象名を
    そのまま描くと、表題が豆腐（□）になり **1 文字ごとに欠落グリフ警告が出る**（実測 11 件）。
    利用者は日本語話者であり、測定データのファイル名に日本語を使うことは普通である。

    **画像が出来ていることだけでは足りない**。豆腐でも画像は書き出されるためである。
    したがって観測量は **欠落グリフ警告の件数** に採る。
    """

    def test_no_missing_glyph_warning_for_a_japanese_source_name(self, tmp_path: Path) -> None:
        """日本語の対象名で欠落グリフの警告が出ない。"""
        if selected_japanese_font() is None:
            pytest.skip("この環境には日本語対応フォントが導入されていない")

        emitted = _render_capturing_warnings(
            _success(source_id=JAPANESE_SOURCE_ID, method_name=JAPANESE_METHOD_NAME),
            tmp_path / "ja.png",
        )

        assert emitted == [], f"表題が豆腐になっている: {emitted}"

    def test_an_image_is_still_produced_for_a_japanese_title(self, tmp_path: Path) -> None:
        """日本語の表題でも画像は生成される。"""
        path = tmp_path / "ja.png"

        render_fit_plot(
            _success(source_id=JAPANESE_SOURCE_ID, method_name=JAPANESE_METHOD_NAME), path
        )

        assert path.read_bytes()[:8] == PNG_MAGIC

    def test_the_title_string_itself_is_unchanged(self, tmp_path: Path) -> None:
        """読めるようにするのはフォントの選択であって、文字の置換ではない。

        非 ASCII を捨てる・音訳するといった手当ては、対象の識別という表題の役目を壊す。
        """
        render_fit_plot(
            _success(source_id=JAPANESE_SOURCE_ID, method_name=JAPANESE_METHOD_NAME),
            tmp_path / "ja.png",
        )

        title = _rendered_axes().get_title()

        assert JAPANESE_SOURCE_ID in title
        assert JAPANESE_METHOD_NAME in title

    def test_the_selected_font_is_applied_to_the_title(self, tmp_path: Path) -> None:
        """選ばれたフォントが表題に適用される。"""
        chosen = selected_japanese_font()
        if chosen is None:
            pytest.skip("この環境には日本語対応フォントが導入されていない")

        render_fit_plot(_success(source_id=JAPANESE_SOURCE_ID), tmp_path / "ja.png")

        families = list(_rendered_axes().title.get_fontfamily())

        assert chosen in families, f"選ばれたフォントが表題に効いていない: {families}"

    def test_no_warning_for_an_ascii_title(self, tmp_path: Path) -> None:
        """日本語対応への切り替えが従来の描画を壊していないことの対照。"""
        emitted = _render_capturing_warnings(_success(), tmp_path / "ascii.png")

        assert emitted == []


class TestEnvironmentWithoutTheFont:
    """特定のフォントの存在を前提にしない。無い環境では従来どおりの描画に退く。

    導入されているフォントは端末ごとに違う。日本語対応フォントを 1 つも持たない環境
    （素の Linux コンテナなど）で描画が失敗すると、日本語を含まない対象まで巻き添えで
    出力を失う。**無い場合は従来どおり描いて処理を続ける** ことが要件 7.4 の既定出力を守る。
    """

    def test_drawing_does_not_fail_without_a_japanese_font(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, font_selection_reset: None
    ) -> None:
        """日本語フォントが無くても描画は失敗しない。"""
        monkeypatch.setattr(plotting, "_installed_font_names", frozenset)
        plotting._font_choice = None
        path = tmp_path / "ja.png"

        emitted = _render_capturing_warnings(
            _success(source_id=JAPANESE_SOURCE_ID, method_name=JAPANESE_METHOD_NAME), path
        )

        assert path.read_bytes()[:8] == PNG_MAGIC
        assert selected_japanese_font() is None
        assert emitted != [], "退避先では従来どおり豆腐になる。この前提が崩れたら検査が空振りする"

    def test_no_font_is_given_to_the_title_when_none_is_available(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, font_selection_reset: None
    ) -> None:
        """存在しない名前を渡すと matplotlib が ``findfont`` の警告を出し続ける。

        退避先は「指定しない」であって「候補の 1 つ目を渡す」ではない。
        """
        monkeypatch.setattr(plotting, "_installed_font_names", frozenset)
        plotting._font_choice = None

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            render_fit_plot(_success(source_id=JAPANESE_SOURCE_ID), tmp_path / "ja.png")

        findfont = [str(record.message) for record in caught if "findfont" in str(record.message)]
        assert findfont == [], f"存在しないフォント名を渡している: {findfont}"

    def test_non_japanese_sources_still_draw_as_before(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, font_selection_reset: None
    ) -> None:
        """日本語を含まない対象は無いときも従来どおり描ける。"""
        monkeypatch.setattr(plotting, "_installed_font_names", frozenset)
        plotting._font_choice = None

        emitted = _render_capturing_warnings(_success(), tmp_path / "ascii.png")

        assert emitted == []


class TestFontSelectionDeterminism:
    """要件 8.2: 同一環境での再実行は同一の出力物を返す。

    選択が導入済みフォントの列挙順に依存すると、同じ端末でも実行ごとに字形が変わりうる。
    列挙は集合であり順序を持たないため、**順序は候補表の側だけが決める** 構造にする。
    """

    def test_repeated_calls_return_the_same_font(self) -> None:
        """繰り返し呼んでも同じフォントを返す。"""
        chosen = [selected_japanese_font() for _ in range(5)]

        assert len(set(chosen)) == 1, f"呼ぶたびに選択が変わる: {chosen}"

    def test_the_candidate_table_order_decides_the_selection(
        self, monkeypatch: pytest.MonkeyPatch, font_selection_reset: None
    ) -> None:
        """導入済みが複数あるとき、候補表で先に並ぶ方が選ばれる。

        導入済みの側を **候補表と逆の並び** で与える。集合で与えると、導入済みを走査する
        実装でも偶然一致してしまい、順序の所有者を取り違えた実装を素通りさせる。
        """
        pair = JAPANESE_FONT_CANDIDATES[:2]
        monkeypatch.setattr(plotting, "_installed_font_names", lambda: list(reversed(pair)))
        plotting._font_choice = None

        assert selected_japanese_font() == pair[0], "導入済みの並べ方で選択が変わる"

        plotting._font_choice = None
        monkeypatch.setattr(plotting, "_installed_font_names", lambda: list(pair))

        assert selected_japanese_font() == pair[0]

    def test_a_typeface_absent_from_the_candidate_table_is_not_selected(
        self, monkeypatch: pytest.MonkeyPatch, font_selection_reset: None
    ) -> None:
        """候補表にない書体は選ばない。"""
        monkeypatch.setattr(
            plotting, "_installed_font_names", lambda: frozenset({"DejaVu Sans", "Arial"})
        )
        plotting._font_choice = None

        assert selected_japanese_font() is None

    def test_the_selected_font_is_actually_installed(self) -> None:
        """選ばれたフォントは実際に導入されている。"""
        chosen = selected_japanese_font()
        if chosen is None:
            pytest.skip("この環境には日本語対応フォントが導入されていない")

        assert chosen in plotting._installed_font_names()

    def test_the_candidate_table_has_no_duplicates(self) -> None:
        """候補表に重複がない。"""
        assert len(set(JAPANESE_FONT_CANDIDATES)) == len(JAPANESE_FONT_CANDIDATES)

    def test_the_same_font_is_selected_in_another_process(self) -> None:
        """プロセスをまたいだ決定性。フォント一覧の走査順はプロセスごとに保証されない。"""
        chosen = [_selected_font_in_subprocess() for _ in range(2)]

        assert len(set(chosen)) == 1, f"プロセスごとに選択が変わる: {chosen}"
        assert chosen[0] == repr(selected_japanese_font()), (
            f"別プロセスの選択が本プロセスと違う: {chosen[0]}"
        )


_FONT_PROGRAM = """\
from curvefit.plotting import selected_japanese_font

print(repr(selected_japanese_font()))
"""
"""別プロセスで選択されたフォント名を出力する台本。"""

_RCPARAMS_PROGRAM = """\
import matplotlib
import numpy as np

before = (
    list(matplotlib.rcParams["font.family"]),
    list(matplotlib.rcParams["font.sans-serif"]),
)

from curvefit.plotting import render_fit_plot
from curvefit.types import (
    CurveData,
    FitSuccess,
    GoodnessOfFit,
    ParameterEstimate,
    PreprocessReport,
)

x = np.arange(5.0)
y_fit = x * 2.0
y_observed = y_fit + 0.5
curve = CurveData(x=x, y_observed=y_observed, y_fit=y_fit, residual=y_observed - y_fit)
success = FitSuccess(
    source_id="{source_id}",
    method_name="{method_name}",
    parameters=(ParameterEstimate(name="slope", value=2.0, stderr=0.1, fixed=False),),
    goodness=GoodnessOfFit(r_squared=0.99, rmse=1.0, n_points=len(curve), n_varied_params=1),
    curve=curve,
    preprocess=PreprocessReport(
        n_input=len(curve),
        n_dropped_invalid=0,
        n_dropped_out_of_range=0,
        n_dropped_outlier=0,
        outlier_points=(),
    ),
)
import sys
from pathlib import Path

render_fit_plot(success, Path(sys.argv[1]))

after = (
    list(matplotlib.rcParams["font.family"]),
    list(matplotlib.rcParams["font.sans-serif"]),
)
print("SAME" if before == after else "CHANGED")
print(before)
print(after)
"""
"""取り込みと描画の前後で大域の rcParams が変わらないことを別プロセスで確かめる台本。

同一プロセス内では主張できない。``curvefit.plotting`` はテスト収集の時点で既に取り込まれて
おり、取り込みの副作用を後から観測できないためである。
"""


def _run_program(program: str, *arguments: str) -> str:
    completed = subprocess.run(
        [sys.executable, "-c", program, *arguments],
        capture_output=True,
        text=True,
        env=_environment(),
        timeout=180,
        check=False,
    )
    assert completed.returncode == 0, f"子プロセスが失敗した:\n{completed.stderr}"
    return completed.stdout


def _selected_font_in_subprocess() -> str:
    return _run_program(_FONT_PROGRAM).strip()


class TestGlobalSettingsImmutability:
    """大域の rcParams は変更しない。バックエンドを大域で強制しないのと同じ理由である。

    ``rcParams["font.family"]`` を書き換えれば日本語は出るが、要件 7.4 により画像出力は
    既定であり ``pipeline`` は本モジュールを必ず取り込む。したがって
    ``import curvefit`` と書いただけで利用者の matplotlib 設定が黙って書き換わり、
    要件 9.1 が求めるライブラリ・対話環境からの利用を壊す。フォントは **本モジュールが
    描く文字の側** に閉じて指定する。
    """

    def test_contains_no_call_that_rewrites_the_global_settings(self) -> None:
        """書き換えの形がソースに無いことを構文木で直接見る。

        ``rcParams`` への代入・更新は import 順にも環境変数にも依存せず効いてしまう。
        混入は別プロセスでの振る舞い検査より手前、ソースの形の段階で止める。
        """
        tree = ast.parse((SRC / "plotting.py").read_text(encoding="utf-8"))
        writes = [
            ast.unparse(node)
            for node in ast.walk(tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr in {"rc", "rcdefaults", "rc_context", "rc_file"}
        ]
        writes += [
            ast.unparse(node)
            for node in ast.walk(tree)
            if isinstance(node, (ast.Assign, ast.AugAssign, ast.AnnAssign))
            and "rcParams" in ast.unparse(node)
        ]
        writes += [
            ast.unparse(node)
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and "rcParams" in ast.unparse(node)
        ]

        assert writes == [], f"大域の rcParams を書き換えている: {writes}"

    def test_import_and_drawing_leave_the_global_font_settings_unchanged(
        self, tmp_path: Path
    ) -> None:
        """取り込みと描画で大域のフォント設定が変わらない。"""
        program = _RCPARAMS_PROGRAM.format(
            source_id=JAPANESE_SOURCE_ID, method_name=JAPANESE_METHOD_NAME
        )

        output = _run_program(program, str(tmp_path / "ja.png")).splitlines()

        assert output[0] == "SAME", f"大域のフォント設定が書き換えられている: {output[1:]}"

    def test_does_not_touch_the_global_settings_even_within_one_process(
        self, tmp_path: Path
    ) -> None:
        """同一プロセス内でも大域設定に触れない。"""
        import matplotlib

        before = (
            list(matplotlib.rcParams["font.family"]),
            list(matplotlib.rcParams["font.sans-serif"]),
        )

        render_fit_plot(_success(source_id=JAPANESE_SOURCE_ID), tmp_path / "ja.png")

        after = (
            list(matplotlib.rcParams["font.family"]),
            list(matplotlib.rcParams["font.sans-serif"]),
        )
        assert before == after


class TestFontSelectionRecording:
    """選択結果を実行条件として記録できる状態にする。

    同じ設定でも端末によって字形が変わりうるため、どのフォントで描いたかを後から判別
    できなければならない。``plotting`` は ``execution`` と同じレイヤ 2 にあり、
    ``build_execution_record`` は描画より前に呼ばれる。したがって **本モジュールは
    読み取れる値を出すところまで** を担い、記録への差し込みは呼び出し側が行う。
    """

    def test_the_selection_is_readable_from_outside(self) -> None:
        """選択結果を外から読み取れる。"""
        chosen = selected_japanese_font()

        assert chosen is None or isinstance(chosen, str)

    def test_readable_even_before_drawing(self) -> None:
        """記録の組み立ては描画より前に走る。描いてからでないと決まらない値では使えない。"""
        output = _run_program(_FONT_PROGRAM).strip()

        assert output != ""

    def test_is_in_a_form_that_can_be_recorded(self) -> None:
        """``execution.json`` は JSON で書き出す。値はそのまま直列化できなければならない。"""
        import json

        assert json.loads(json.dumps({"plot_font": selected_japanese_font()})) == {
            "plot_font": selected_japanese_font()
        }
