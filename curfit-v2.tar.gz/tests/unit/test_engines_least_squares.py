"""最小二乗による当てはめエンジンの契約を検証する。

対応要件: 1.3（誤差列を重みに反映）、4.1（組込モデルの初期値自動推定）、
4.4（上下限の適用）、4.5（特定パラメータの固定）、4.7（非収束の記録と初期値の報告）、
7.1（パラメータ推定値と標準誤差）。

設計の engines.base / engines.least_squares / engines.smoothing ブロックが定める
Postconditions（重み付き最小化、固定値の厳密一致）、Invariants（上下限の内側）、
Risks（標準誤差が算出できない場合は失敗にしない）、および Allowed Dependencies
（lmfit の型を外へ出さない）を対象とする。

推定値の検証は steering `tech.md` に従い、既知パラメータから生成した合成データを
当てはめ、許容誤差内で復元されることを見る。浮動小数点の完全一致比較を行うのは、
固定パラメータの不変性（要件 4.5）と再現性の確認に限る。ここだけは「ほぼ等しい」では
要件を満たしたことにならない。

非収束・非有限といった正規化の分岐のうち、実データで再現できないものは、解決済み
モデルが保持する実体（:class:`~curvefit.models.resolver.PreparedModel` の ``_model`` /
``_parameters`` は :class:`object` 型）を差し替えて検証する。基盤ライブラリが送出も
返却もしない結果を実データで作ることはできず、差し替えなければ分岐が未検証のまま残る。
"""

from __future__ import annotations

import ast
import inspect
import math
from pathlib import Path
from typing import Any

import numpy as np
import pytest

from curvefit.engines.base import EngineFailure, EngineSuccess, FitEngine
from curvefit.engines.least_squares import LeastSquaresEngine
from curvefit.errors import FailureReason
from curvefit.models.registry import (
    BUILTIN_MODELS,
    DEFAULT_POLYNOMIAL_DEGREE,
    POLYNOMIAL_DEGREE_OPTION,
)
from curvefit.models.resolver import (
    MethodSpec,
    PreparedModel,
    PreparedSmoother,
    SmootherKind,
    resolve,
)
from curvefit.types import DataSeries, FloatArray, ParameterEstimate

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

TRUE_AMPLITUDE = 3.0
TRUE_CENTER = 0.5
TRUE_SIGMA = 1.2


def _array(values: list[float]) -> FloatArray:
    return np.array(values, dtype=np.float64)


def _gaussian_series(source_id: str = "gaussian.csv") -> DataSeries:
    """既知パラメータから生成したガウシアンの系列。

    lmfit の ``GaussianModel`` は ``amplitude`` を面積として扱うため、同じ定義で
    生成する。定義が食い違うと、復元の許容誤差を通らない理由が実装の欠陥なのか
    生成側の誤りなのか区別できなくなる。
    """
    x = np.linspace(-4.0, 5.0, 61)
    y = (
        TRUE_AMPLITUDE
        / (TRUE_SIGMA * math.sqrt(2.0 * math.pi))
        * np.exp(-((x - TRUE_CENTER) ** 2) / (2.0 * TRUE_SIGMA**2))
    )
    return DataSeries(source_id=source_id, x=x, y=y)


def _line_series(slope: float = 2.0, intercept: float = 1.0, n: int = 11) -> DataSeries:
    x = np.linspace(0.0, 10.0, n)
    return DataSeries(source_id="line.csv", x=x, y=slope * x + intercept)


def _quadratic_series(source_id: str = "quadratic.csv") -> DataSeries:
    """2 次多項式の系列。既定次数（2）の多項式が完全に当てはまる。"""
    x = np.linspace(-3.0, 3.0, 21)
    return DataSeries(source_id=source_id, x=x, y=1.0 + 2.0 * x + 0.5 * x**2)


def _exponential_series(source_id: str = "exponential.csv") -> DataSeries:
    """指数減衰の系列。lmfit の ``ExponentialModel`` と同じ定義で生成する。"""
    x = np.linspace(0.0, 6.0, 31)
    return DataSeries(source_id=source_id, x=x, y=3.0 * np.exp(-x / 2.0))


def _resolved(spec: MethodSpec, sample: DataSeries | None) -> PreparedModel:
    prepared = resolve(spec, sample)
    assert isinstance(prepared, PreparedModel), f"解決に失敗した: {prepared}"
    return prepared


def _gaussian_spec(**overrides: Any) -> MethodSpec:
    return MethodSpec(name="gaussian", kind="builtin", builtin="gaussian", **overrides)


def _linear_spec(**overrides: Any) -> MethodSpec:
    return MethodSpec(name="linear", kind="builtin", builtin="linear", **overrides)


def _polynomial_spec(**overrides: Any) -> MethodSpec:
    return MethodSpec(name="polynomial", kind="builtin", builtin="polynomial", **overrides)


def _initial(prepared: PreparedModel) -> dict[str, float]:
    """解決済みモデルが保持する出発点。当てはめ前のパラメータ束から読む。"""
    parameters = prepared._parameters
    return {name: float(parameters[name].value) for name in prepared.parameter_names}


def _estimates(success: EngineSuccess) -> dict[str, ParameterEstimate]:
    return {estimate.name: estimate for estimate in success.parameters}


def _fit(spec: MethodSpec, series: DataSeries, sample: DataSeries | None = None):
    """指定を解決してから当てはめる。解決は当てはめのたびに呼び直す。"""
    return LeastSquaresEngine().fit(series, _resolved(spec, series if sample is None else sample))


def _succeeded(spec: MethodSpec, series: DataSeries) -> EngineSuccess:
    outcome = _fit(spec, series)
    assert isinstance(outcome, EngineSuccess), f"成功しなかった: {outcome}"
    return outcome


# --- 実体を差し替えるための最小限の代役 ------------------------------------------


class _StubParameter:
    """解決済みパラメータ 1 個の代役。エンジンが読む属性のみを持つ。"""

    def __init__(self, value: float, *, vary: bool = True, stderr: float | None = None) -> None:
        self.value = value
        self.vary = vary
        self.stderr = stderr


class _StubResult:
    """当てはめ結果の代役。"""

    def __init__(
        self,
        params: dict[str, _StubParameter],
        best_fit: object,
        *,
        success: bool = True,
        errorbars: bool = True,
        message: str = "Fit succeeded.",
    ) -> None:
        self.params = params
        self.best_fit = best_fit
        self.success = success
        self.errorbars = errorbars
        self.message = message


class _StubModel:
    """モデル実体の代役。当てはめ時の引数を記録する。"""

    def __init__(self, result: _StubResult) -> None:
        self._result = result
        self.calls: list[dict[str, Any]] = []

    def fit(self, data: object, params: object = None, **kwargs: Any) -> _StubResult:
        self.calls.append({"data": data, "params": params, **kwargs})
        return self._result


def _stub_prepared(
    result: _StubResult, initial: dict[str, _StubParameter] | None = None
) -> tuple[PreparedModel, _StubModel]:
    model = _StubModel(result)
    parameters = initial or {
        name: _StubParameter(value=1.0) for name in result.params
    }
    prepared = PreparedModel(
        display_name="stub",
        parameter_names=tuple(result.params),
        applied_defaults={},
        _model=model,
        _parameters=parameters,
    )
    return prepared, model


class TestRecoveryOfEstimatesFromSyntheticData:
    """要件 7.1 / 4.1: 推定値と標準誤差を返し、初期値は自動推定から出発する。"""

    def test_recovers_known_parameters_within_tolerance(self) -> None:
        """既知パラメータを許容誤差内で復元する。"""
        series = _gaussian_series()
        success = _succeeded(_gaussian_spec(), series)

        estimates = _estimates(success)
        assert estimates["amplitude"].value == pytest.approx(TRUE_AMPLITUDE, rel=1e-6)
        assert estimates["center"].value == pytest.approx(TRUE_CENTER, rel=1e-6, abs=1e-9)
        assert estimates["sigma"].value == pytest.approx(TRUE_SIGMA, rel=1e-6)

    def test_builtin_model_without_explicit_initials_converges_from_auto_guess(self) -> None:
        """要件 4.1: 初期値が明示されていない組込モデルは自動推定で開始する。

        自動推定が働いたことは、出発点そのもので見る。データを与えずに解決した場合の
        出発点（基盤ライブラリの既定初期値）と食い違えば、データから決めたことになる。
        """
        series = _gaussian_series()
        prepared = _resolved(_gaussian_spec(), series)
        without_data = _resolved(_gaussian_spec(), None)
        assert _initial(prepared) != _initial(without_data), (
            "出発点がデータに依存していないため要件 4.1 を検証できない"
        )

        outcome = LeastSquaresEngine().fit(series, prepared)

        assert isinstance(outcome, EngineSuccess)
        assert _estimates(outcome)["center"].value == pytest.approx(TRUE_CENTER, abs=1e-6)

    def test_explicit_initials_reach_the_same_solution(self) -> None:
        """明示した初期値からも同じ解に到達する。"""
        series = _gaussian_series()
        success = _succeeded(
            _gaussian_spec(initial={"amplitude": 1.0, "center": 0.0, "sigma": 1.0}), series
        )
        assert _estimates(success)["sigma"].value == pytest.approx(TRUE_SIGMA, rel=1e-6)

    def test_standard_errors_come_back_finite(self) -> None:
        """要件 7.1: 推定値とともに標準誤差を返す。"""
        success = _succeeded(_gaussian_spec(), _gaussian_series())
        for estimate in success.parameters:
            assert estimate.stderr is not None
            assert math.isfinite(estimate.stderr)
            assert estimate.stderr >= 0.0

    def test_returns_only_varied_parameters_in_the_resolved_order(self) -> None:
        """要件 3.5 の識別子は解決済みモデルが確定させたもの。派生量は含まない。"""
        series = _gaussian_series()
        prepared = _resolved(_gaussian_spec(), series)
        outcome = LeastSquaresEngine().fit(series, prepared)

        assert isinstance(outcome, EngineSuccess)
        names = tuple(estimate.name for estimate in outcome.parameters)
        assert names == prepared.parameter_names
        assert "fwhm" not in names and "height" not in names

    def test_fitted_values_have_the_same_length_as_the_input_series(self) -> None:
        """当てはめ値が入力系列と同一長になる。"""
        series = _gaussian_series()
        success = _succeeded(_gaussian_spec(), series)
        assert len(success.y_fit) == len(series)
        assert success.y_fit == pytest.approx(series.y, abs=1e-6)

    def test_satisfies_the_fit_contract(self) -> None:
        """要件 5.2: 平滑化と同一の契約の実装として並置される。"""
        assert isinstance(LeastSquaresEngine(), FitEngine)


class TestAppliedDefaultsRecording:
    """要件 5.4、8.5: 利用者が書いていないのに効いた選択肢の値を記録する。

    多項式の次数は、名前だけでモデルを選べるようにするために既定値を持つ
    （:data:`~curvefit.models.registry.DEFAULT_POLYNOMIAL_DEGREE`）。記録しなければ、
    同じ利用者入力に対する記録が手法の書き方（``builtin`` と ``smoother``）で食い違い、
    実行条件の記録が実行を説明しないものになる。

    期待値は登録簿の定数から読む。試験に値を書き写すと、既定値の所有が登録簿と試験の
    2 か所に分かれる。
    """

    def test_records_the_default_polynomial_degree(self) -> None:
        """多項式の次数の既定値を記録する。"""
        success = _succeeded(_polynomial_spec(), _quadratic_series())
        assert dict(success.applied_defaults) == {
            POLYNOMIAL_DEGREE_OPTION: DEFAULT_POLYNOMIAL_DEGREE
        }

    def test_the_recorded_degree_really_affects_the_fit(self) -> None:
        """記録が「効いた値」であることの裏取り。推定対象は次数 + 1 個になる。"""
        success = _succeeded(_polynomial_spec(), _quadratic_series())
        names = tuple(estimate.name for estimate in success.parameters)
        assert len(names) == DEFAULT_POLYNOMIAL_DEGREE + 1
        assert names == tuple(f"c{index}" for index in range(len(names)))

    def test_an_explicit_degree_is_not_recorded_as_a_default(self) -> None:
        """記録に載せるのは「書いていないのに効いた値」だけである。"""
        spec = _polynomial_spec(options={POLYNOMIAL_DEGREE_OPTION: 3})
        success = _succeeded(spec, _quadratic_series())
        assert dict(success.applied_defaults) == {}
        assert len(success.parameters) == 4

    @pytest.mark.parametrize(
        ("name", "series"),
        [
            ("linear", _line_series()),
            ("gaussian", _gaussian_series()),
            ("exponential", _exponential_series()),
        ],
    )
    def test_builtin_models_without_options_record_no_defaults(
        self, name: str, series: DataSeries
    ) -> None:
        """選択肢を持たない組込モデルは既定値を記録しない。"""
        assert dict(BUILTIN_MODELS[name].default_options) == {}, "既定値を持つモデルである"
        spec = MethodSpec(name=name, kind="builtin", builtin=name)
        assert dict(_succeeded(spec, series).applied_defaults) == {}

    def test_covers_every_builtin_model_that_has_a_default(self) -> None:
        """既定値を持つモデルが増えたとき、この検査群の不足に気付けるようにする。"""
        with_defaults = sorted(
            name for name, spec in BUILTIN_MODELS.items() if spec.default_options
        )
        assert with_defaults == ["polynomial"]

    def test_the_record_is_immutable(self) -> None:
        """記録が実行と食い違わないよう、返した写像は凍結する。"""
        success = _succeeded(_polynomial_spec(), _quadratic_series())
        with pytest.raises(TypeError):
            success.applied_defaults[POLYNOMIAL_DEGREE_OPTION] = 9  # type: ignore[index]


class TestWeighting:
    """要件 1.3: 重みが与えられた場合、重み付きで残差を最小化する。"""

    def _corrupted(self, weight_on_outlier: float | None) -> DataSeries:
        x = np.linspace(0.0, 4.0, 5)
        y = 2.0 * x + 1.0
        y[-1] = 100.0
        weights = (
            None
            if weight_on_outlier is None
            else _array([1.0, 1.0, 1.0, 1.0, weight_on_outlier])
        )
        return DataSeries(source_id="weighted.csv", x=x, y=y, weights=weights)

    def test_points_with_smaller_weight_contribute_less(self) -> None:
        """重みの小さい点は当てはめへの寄与が小さくなる。"""
        series = self._corrupted(weight_on_outlier=1e-4)
        estimates = _estimates(_succeeded(_linear_spec(), series))
        assert estimates["slope"].value == pytest.approx(2.0, abs=1e-3)
        assert estimates["intercept"].value == pytest.approx(1.0, abs=1e-3)

    def test_all_points_contribute_equally_without_weights(self) -> None:
        """重みを与えない場合は全点が等しく寄与する。"""
        series = self._corrupted(weight_on_outlier=None)
        estimates = _estimates(_succeeded(_linear_spec(), series))
        assert estimates["slope"].value > 5.0, "重みなしでは外れ値に引きずられるはず"

    def test_uniform_weights_match_the_unweighted_result(self) -> None:
        """重みの意味を残差への乗数として固定する。定数倍は解を動かさない。"""
        x = np.linspace(0.0, 4.0, 5)
        y = 2.0 * x + 1.0
        y[-1] = 100.0
        without = _estimates(
            _succeeded(_linear_spec(), DataSeries(source_id="w.csv", x=x, y=y))
        )
        uniform = _estimates(
            _succeeded(
                _linear_spec(),
                DataSeries(source_id="w.csv", x=x, y=y, weights=np.full(5, 4.0)),
            )
        )
        assert uniform["slope"].value == pytest.approx(without["slope"].value, rel=1e-9)

    def test_weights_do_not_rescale_the_fitted_values(self) -> None:
        """重みは残差の最小化にのみ効き、当てはめ値は実測値と同じ尺度に留まる。"""
        series = self._corrupted(weight_on_outlier=1e-4)
        success = _succeeded(_linear_spec(), series)
        assert success.y_fit[0] == pytest.approx(1.0, abs=1e-2)


class TestBoundsApplication:
    """要件 4.4: 上下限が指定されたパラメータの推定値は必ず範囲内に収まる。"""

    def test_estimates_never_exceed_the_given_upper_bound(self) -> None:
        """推定値が指定した上限を超えない。"""
        series = _line_series(slope=2.0, intercept=1.0)
        success = _succeeded(_linear_spec(bounds={"slope": (None, 0.5)}), series)
        slope = _estimates(success)["slope"].value
        assert slope <= 0.5, f"上限 0.5 を超えている: {slope}"

    def test_estimates_never_fall_below_the_given_lower_bound(self) -> None:
        """推定値が指定した下限を下回らない。"""
        series = _line_series(slope=2.0, intercept=1.0)
        success = _succeeded(_linear_spec(bounds={"slope": (5.0, None)}), series)
        slope = _estimates(success)["slope"].value
        assert slope >= 5.0, f"下限 5.0 を下回っている: {slope}"

    def test_reaches_the_true_value_without_bounds(self) -> None:
        """上限の効果が、制約なしの結果との差として現れることを示す。"""
        series = _line_series(slope=2.0, intercept=1.0)
        success = _succeeded(_linear_spec(), series)
        assert _estimates(success)["slope"].value == pytest.approx(2.0, rel=1e-9)

    def test_estimates_are_recovered_inside_a_range_containing_the_true_value(self) -> None:
        """真値を含む範囲では推定値が範囲内で復元される。"""
        series = _line_series(slope=2.0, intercept=1.0)
        success = _succeeded(_linear_spec(bounds={"slope": (1.0, 3.0)}), series)
        slope = _estimates(success)["slope"].value
        assert 1.0 <= slope <= 3.0
        assert slope == pytest.approx(2.0, rel=1e-6)


class TestFixedParameters:
    """要件 4.5: 固定指定されたパラメータは変化せず、標準誤差を持たない。"""

    def test_the_fixed_value_stays_exactly_unchanged(self) -> None:
        """固定値が厳密に不変である。"""
        series = _line_series(slope=2.0, intercept=1.0)
        success = _succeeded(_linear_spec(fixed={"intercept": 0.25}), series)
        intercept = _estimates(success)["intercept"]
        assert intercept.value == 0.25, "固定値が動いている"
        assert intercept.fixed is True

    def test_a_fixed_parameter_has_no_standard_error(self) -> None:
        """固定パラメータの標準誤差は空になる。"""
        series = _line_series(slope=2.0, intercept=1.0)
        success = _succeeded(_linear_spec(fixed={"intercept": 0.25}), series)
        assert _estimates(success)["intercept"].stderr is None

    def test_unfixed_parameters_are_still_estimated(self) -> None:
        # 残差が厳密に 0 の系列では共分散が求まらず標準誤差が空になる。固定していない
        # パラメータに標準誤差が付くことを見るため、わずかなずれを与える。
        """固定していないパラメータは推定される。"""
        series = _line_series(slope=2.0, intercept=1.0)
        y = series.y + _array([0.01, -0.02, 0.03, 0.0, -0.01, 0.02, -0.03, 0.01, 0.0, -0.02, 0.01])
        series = DataSeries(source_id=series.source_id, x=series.x, y=y)
        success = _succeeded(_linear_spec(fixed={"intercept": 1.0}), series)
        slope = _estimates(success)["slope"]
        assert slope.fixed is False
        assert slope.value == pytest.approx(2.0, abs=1e-3)
        assert slope.stderr is not None
        assert math.isfinite(slope.stderr) and slope.stderr > 0.0

    def test_fixing_is_reflected_in_the_fitted_values(self) -> None:
        """固定した切片が当てはめ値に現れることで、固定が実行に効いたと言える。"""
        series = _line_series(slope=2.0, intercept=1.0)
        success = _succeeded(_linear_spec(fixed={"intercept": 0.25}), series)
        assert float(success.y_fit[0]) == pytest.approx(0.25, abs=1e-9)


class TestNonConvergence:
    """要件 4.7: 非収束は失敗として記録し、使用した初期値を報告する。"""

    def test_a_spec_leaving_no_varied_parameter_is_reported_as_non_convergence(self) -> None:
        """全パラメータの固定は基盤ライブラリが当てはめ不能として拒む。

        例外にすると 1 件の指定でバッチ全体が落ちるため、値として返す。
        """
        series = _line_series()
        outcome = _fit(_linear_spec(fixed={"slope": 2.0, "intercept": 1.0}), series)

        assert isinstance(outcome, EngineFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert outcome.message
        assert dict(outcome.initial_values) == {"slope": 2.0, "intercept": 1.0}

    def test_a_broken_fit_also_returns_failure_as_a_value(self) -> None:
        """モデルが有限でない値を生む場合、基盤ライブラリは例外を送出する。"""

        def diverging(x: FloatArray, a: float) -> FloatArray:
            with np.errstate(over="ignore"):
                return np.exp(a * x)

        series = _line_series(n=5)
        spec = MethodSpec(
            name="diverging", kind="callable", function=diverging, initial={"a": 500.0}
        )
        outcome = _fit(spec, series)

        assert isinstance(outcome, EngineFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert dict(outcome.initial_values) == {"a": 500.0}

    def test_failure_is_carried_as_a_return_value_not_an_exception(self) -> None:
        """失敗は例外ではなく戻り値として運ばれる。"""
        outcome = _fit(_linear_spec(fixed={"slope": 1.0, "intercept": 0.0}), _line_series())
        assert not isinstance(outcome, BaseException)

    def test_the_reported_initials_are_the_values_actually_used(self) -> None:
        """要件 4.7: 明示指定した初期値がそのまま報告される。"""
        result = _StubResult(
            params={"a": _StubParameter(1.0)},
            best_fit=np.zeros(3, dtype=np.float64),
            success=False,
            message="Fit did not converge.",
        )
        prepared, _ = _stub_prepared(result, initial={"a": _StubParameter(7.5)})
        series = DataSeries(source_id="s.csv", x=np.arange(3.0), y=np.arange(3.0))

        outcome = LeastSquaresEngine().fit(series, prepared)

        assert isinstance(outcome, EngineFailure)
        assert dict(outcome.initial_values) == {"a": 7.5}
        assert "Fit did not converge." in outcome.message


class TestWhenTheStandardErrorCannotBeComputed:
    """要件 7.1: 標準誤差が算出できないことは失敗ではない。"""

    def _degenerate(self) -> tuple[MethodSpec, DataSeries]:
        def unaffected(x: FloatArray, offset: float, unused: float) -> FloatArray:
            """``unused`` は当てはめに影響しない。ヤコビアンがフルランクにならない。"""
            return np.full_like(x, offset)

        series = DataSeries(
            source_id="flat.csv",
            x=np.linspace(0.0, 4.0, 5),
            y=np.full(5, 2.0, dtype=np.float64),
        )
        spec = MethodSpec(
            name="unaffected",
            kind="callable",
            function=unaffected,
            initial={"offset": 0.0, "unused": 1.0},
        )
        return spec, series

    def test_an_uncomputable_standard_error_becomes_none_not_a_failure(self) -> None:
        """算出できない標準誤差は空として扱い失敗にしない。"""
        spec, series = self._degenerate()
        outcome = _fit(spec, series)

        assert isinstance(outcome, EngineSuccess), f"失敗として扱われた: {outcome}"
        for estimate in outcome.parameters:
            assert estimate.stderr is None

    def test_estimates_and_fitted_values_are_returned_even_without_standard_errors(self) -> None:
        """標準誤差が空でも推定値と当てはめ値は返る。"""
        spec, series = self._degenerate()
        outcome = _fit(spec, series)

        assert isinstance(outcome, EngineSuccess)
        assert _estimates(outcome)["offset"].value == pytest.approx(2.0, abs=1e-6)
        assert len(outcome.y_fit) == len(series)

    def test_a_zero_standard_error_becomes_none_when_no_covariance_is_available(self) -> None:
        """残差が厳密に 0 の系列では共分散が求まらず、基盤ライブラリは標準誤差に 0.0 を残す。

        そのまま出すと「誤差 0 の完璧な推定」に見える。算出できなかったことと、
        算出した結果が 0 であることは区別されなければならない。
        """
        series = _line_series(slope=2.0, intercept=1.0)
        outcome = _fit(_linear_spec(fixed={"intercept": 1.0}), series)

        assert isinstance(outcome, EngineSuccess)
        slope = _estimates(outcome)["slope"]
        assert slope.value == pytest.approx(2.0, rel=1e-9)
        assert slope.fixed is False
        assert slope.stderr is None

    def test_a_non_finite_standard_error_also_becomes_none(self) -> None:
        """有限でない標準誤差も空として扱う。"""
        result = _StubResult(
            params={"a": _StubParameter(1.0, stderr=math.inf)},
            best_fit=np.zeros(3, dtype=np.float64),
        )
        prepared, _ = _stub_prepared(result)
        series = DataSeries(source_id="s.csv", x=np.arange(3.0), y=np.zeros(3))

        outcome = LeastSquaresEngine().fit(series, prepared)

        assert isinstance(outcome, EngineSuccess)
        assert outcome.parameters[0].stderr is None


class TestNonFiniteResults:
    """当てはめ値が有限でない場合は失敗として返す（tasks.md の申し送り）。

    :func:`~curvefit.engines.base.compute_goodness` は有限でない値を素通しするため、
    ここで止めなければ NaN / inf がサマリ CSV に流入する。
    """

    def _series(self) -> DataSeries:
        return DataSeries(source_id="s.csv", x=np.arange(3.0), y=np.zeros(3))

    def test_non_finite_fitted_values_return_a_failure(self) -> None:
        """当てはめ値に非有限な値があれば失敗を返す。"""
        result = _StubResult(
            params={"a": _StubParameter(1.0, stderr=0.1)},
            best_fit=_array([0.0, math.nan, 0.0]),
        )
        prepared, _ = _stub_prepared(result, initial={"a": _StubParameter(0.5)})

        outcome = LeastSquaresEngine().fit(self._series(), prepared)

        assert isinstance(outcome, EngineFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert dict(outcome.initial_values) == {"a": 0.5}

    def test_infinite_fitted_values_are_also_a_failure(self) -> None:
        """無限大の当てはめ値も失敗として扱う。"""
        result = _StubResult(
            params={"a": _StubParameter(1.0, stderr=0.1)},
            best_fit=_array([0.0, math.inf, 0.0]),
        )
        prepared, _ = _stub_prepared(result)

        outcome = LeastSquaresEngine().fit(self._series(), prepared)

        assert isinstance(outcome, EngineFailure)

    def test_non_finite_estimates_return_a_failure(self) -> None:
        """推定値が非有限なら失敗を返す。"""
        result = _StubResult(
            params={"a": _StubParameter(math.nan, stderr=0.1)},
            best_fit=np.zeros(3, dtype=np.float64),
        )
        prepared, _ = _stub_prepared(result)

        outcome = LeastSquaresEngine().fit(self._series(), prepared)

        assert isinstance(outcome, EngineFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED


class TestResultNormalization:
    """設計の Allowed Dependencies: 基盤ライブラリ固有の結果型を露出させない。"""

    def test_returns_only_shared_types(self) -> None:
        """共有型のみを返す。"""
        success = _succeeded(_gaussian_spec(), _gaussian_series())
        assert type(success).__module__.startswith("curvefit.")
        for estimate in success.parameters:
            assert isinstance(estimate, ParameterEstimate)
            assert type(estimate.value) is float
            assert estimate.stderr is None or type(estimate.stderr) is float

    def test_fitted_values_are_a_1d_float64_array(self) -> None:
        """当てはめ値が一次元の倍精度配列である。"""
        success = _succeeded(_gaussian_spec(), _gaussian_series())
        assert isinstance(success.y_fit, np.ndarray)
        assert success.y_fit.dtype == np.float64
        assert success.y_fit.ndim == 1

    def test_a_scalar_returning_model_still_yields_per_point_values(self) -> None:
        """定数モデルでは基盤ライブラリの当てはめ値がスカラになりうる。"""
        result = _StubResult(
            params={"a": _StubParameter(2.0, stderr=0.1)}, best_fit=2.0
        )
        prepared, _ = _stub_prepared(result)
        series = DataSeries(source_id="s.csv", x=np.arange(4.0), y=np.full(4, 2.0))

        outcome = LeastSquaresEngine().fit(series, prepared)

        assert isinstance(outcome, EngineSuccess)
        assert outcome.y_fit == pytest.approx(np.full(4, 2.0))

    def test_a_fitted_value_count_disagreeing_with_the_series_returns_a_failure_value(self) -> None:
        """要件 6.4: 例外を送出すると 1 件の指定でバッチ全体が落ちる。"""
        result = _StubResult(
            params={"a": _StubParameter(1.0, stderr=0.1)},
            best_fit=np.zeros(2, dtype=np.float64),
        )
        prepared, _ = _stub_prepared(result, initial={"a": _StubParameter(3.5)})
        series = DataSeries(source_id="s.csv", x=np.arange(5.0), y=np.zeros(5))

        outcome = LeastSquaresEngine().fit(series, prepared)

        assert isinstance(outcome, EngineFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert outcome.message
        assert dict(outcome.initial_values) == {"a": 3.5}


class TestUserFunctionNotReturningPerPointValues:
    """要件 3.3 / 6.4: 1 点 1 値を返さない関数も、例外ではなく失敗として値で返す。

    利用者定義関数は任意の Python 関数であり、各データ点に対応する配列を返す保証は
    ない。代役ではなく実際の関数を解決して当てはめることで、この分岐が実運用の経路
    から到達することを示す。設計の Error Strategy は、資源枯渇以外の想定内の失敗を
    すべて値として返すことを定める。
    """

    def _series(self) -> DataSeries:
        return DataSeries(
            source_id="user.csv",
            x=np.linspace(0.0, 4.0, 5),
            y=np.full(5, 2.0, dtype=np.float64),
        )

    def _spec(self, function: Any) -> MethodSpec:
        return MethodSpec(
            name="user", kind="callable", function=function, initial={"a": 1.0}
        )

    def test_a_function_returning_a_length_1_array_is_reported_as_a_failure(self) -> None:
        """長さ 1 の配列を返す関数は失敗として報告される。"""
        series = self._series()
        outcome = _fit(self._spec(lambda x, a: np.array([a])), series)

        assert isinstance(outcome, EngineFailure), f"例外が漏れたか成功した: {outcome}"
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert "(1,)" in outcome.message and "(5,)" in outcome.message
        assert dict(outcome.initial_values) == {"a": 1.0}

    def test_a_function_returning_a_column_vector_is_also_a_failure(self) -> None:
        """形が ``(n, 1)`` の場合、要素数は一致しても各点の値の並びにはならない。"""
        series = self._series()
        outcome = _fit(self._spec(lambda x, a: np.full((len(x), 1), a)), series)

        assert isinstance(outcome, EngineFailure), f"例外が漏れたか成功した: {outcome}"
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert "(5, 1)" in outcome.message
        assert dict(outcome.initial_values) == {"a": 1.0}

    def test_a_function_returning_per_point_values_succeeds(self) -> None:
        """失敗の報告が、形の食い違いだけに起因することを示す対照。"""
        series = self._series()
        outcome = _fit(self._spec(lambda x, a: np.full_like(x, a)), series)

        assert isinstance(outcome, EngineSuccess)
        assert _estimates(outcome)["a"].value == pytest.approx(2.0, abs=1e-6)


class TestInputImmutability:
    """設計: エンジンは純粋計算であり、入力を書き換えない。"""

    def test_does_not_mutate_the_prepared_model_initials(self) -> None:
        """同じ解決済みモデルを使い回しても初期値が汚染されない。"""
        series = _gaussian_series()
        prepared = _resolved(_gaussian_spec(initial={"sigma": 1.0}), series)
        before = {name: prepared._parameters[name].value for name in prepared.parameter_names}

        LeastSquaresEngine().fit(series, prepared)

        after = {name: prepared._parameters[name].value for name in prepared.parameter_names}
        assert after == before

    def test_does_not_mutate_the_input_series(self) -> None:
        """入力系列を書き換えない。"""
        x = np.linspace(0.0, 4.0, 5)
        y = 2.0 * x + 1.0
        weights = np.full(5, 2.0)
        series = DataSeries(source_id="s.csv", x=x.copy(), y=y.copy(), weights=weights.copy())

        _succeeded(_linear_spec(), series)

        assert np.array_equal(series.x, x)
        assert np.array_equal(series.y, y)
        assert series.weights is not None
        assert np.array_equal(series.weights, weights)

    def test_the_same_input_yields_the_same_result(self) -> None:
        """要件 8.2 の再現性は、エンジンが決定的であることを前提にする。"""
        series = _gaussian_series()
        first = _succeeded(_gaussian_spec(), series)
        second = _succeeded(_gaussian_spec(), series)

        assert [e.value for e in first.parameters] == [e.value for e in second.parameters]
        assert np.array_equal(first.y_fit, second.y_fit)


class TestCallsOutsideTheContract:
    """契約外の呼び出し。"""

    def test_passing_a_smoother_raises(self) -> None:
        """手法から実装への振り分けは本モジュールの責務ではない。"""
        smoother = PreparedSmoother(
            display_name="linear", kind=SmootherKind.LINEAR, options={}
        )
        with pytest.raises(TypeError):
            LeastSquaresEngine().fit(_line_series(), smoother)  # type: ignore[arg-type]


def _imported_modules(name: str) -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。"""
    tree = ast.parse((SRC / "engines" / name).read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class TestDependencyExposure:
    """依存の露出。"""

    def test_public_signatures_expose_no_underlying_library_types(self) -> None:
        """公開署名に基盤ライブラリの型が現れない。"""
        rendered = str(inspect.signature(LeastSquaresEngine.fit))
        for library in ("lmfit", "Model", "ModelResult", "DataFrame"):
            assert library not in rendered

    def test_depends_only_on_layers_to_its_left(self) -> None:
        """自パッケージでは左側の層だけに依存する。"""
        allowed = {
            "curvefit.types",
            "curvefit.errors",
            "curvefit.engines.base",
            "curvefit.models.expression",
            "curvefit.models.resolver",
        }
        own = {
            m for m in _imported_modules("least_squares.py") if m.split(".")[0] == "curvefit"
        }
        assert own <= allowed, f"想定外の依存: {own - allowed}"

    def test_performs_no_io(self) -> None:
        """入出力を行わない。"""
        forbidden = {"pathlib", "os", "sys", "logging", "io", "open", "subprocess"}
        for imported in _imported_modules("least_squares.py"):
            assert imported.split(".")[0] not in forbidden, (
                f"engines/least_squares.py が入出力に関わる {imported} を import している"
            )
