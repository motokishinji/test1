"""共有データ型と失敗分類の契約を検証する。

対応要件: 1.2（3 経路が同一構造の結果を返す土台）、5.3（パラメータなしの手法も同一形式）、
7.1（推定値と標準誤差）、7.2（適合度指標）
"""

from __future__ import annotations

import ast
import dataclasses
from pathlib import Path

import numpy as np
import pytest

from curvefit.errors import ConfigViolation, FailureReason, ViolationKind
from curvefit.types import (
    CurveData,
    DataSeries,
    FitFailure,
    FitSuccess,
    GoodnessOfFit,
    OutlierPoint,
    ParameterEstimate,
    PreprocessReport,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


def _series(n: int = 5, *, weights: bool = False) -> DataSeries:
    x = np.arange(n, dtype=np.float64)
    return DataSeries(
        source_id="sample.csv",
        x=x,
        y=x * 2.0,
        weights=np.ones(n, dtype=np.float64) if weights else None,
    )


class TestDataSeries:
    """入力データ系列。"""

    def test_constructs_from_arrays_of_equal_length(self) -> None:
        """同一長の配列で構成できる。"""
        s = _series()
        assert s.source_id == "sample.csv"
        assert s.weights is None
        assert len(s.x) == len(s.y) == 5

    def test_can_hold_a_weights_column(self) -> None:
        """重み列を保持できる。"""
        assert _series(weights=True).weights is not None

    def test_cannot_be_reassigned_after_construction(self) -> None:
        """生成後に再代入できない。"""
        with pytest.raises(dataclasses.FrozenInstanceError):
            _series().source_id = "other.csv"  # type: ignore[misc]

    def test_rejects_x_and_y_of_different_length(self) -> None:
        """x と y の長さが異なると拒否する。"""
        with pytest.raises(ValueError, match="長さ"):
            DataSeries(
                source_id="s",
                x=np.zeros(3, dtype=np.float64),
                y=np.zeros(4, dtype=np.float64),
            )

    def test_rejects_weights_of_different_length(self) -> None:
        """重みの長さが異なると拒否する。"""
        with pytest.raises(ValueError, match="長さ"):
            DataSeries(
                source_id="s",
                x=np.zeros(3, dtype=np.float64),
                y=np.zeros(3, dtype=np.float64),
                weights=np.zeros(2, dtype=np.float64),
            )

    def test_rejects_arrays_that_are_not_1d(self) -> None:
        """一次元でない配列を拒否する。"""
        with pytest.raises(ValueError, match="一次元"):
            DataSeries(
                source_id="s",
                x=np.zeros((2, 2), dtype=np.float64),
                y=np.zeros((2, 2), dtype=np.float64),
            )

    def test_rejects_arrays_that_are_not_float(self) -> None:
        """浮動小数点でない配列を拒否する。"""
        with pytest.raises(ValueError, match="float64"):
            DataSeries(source_id="s", x=np.arange(3), y=np.arange(3))

    def test_carries_the_resolved_column_header_name(self) -> None:
        """要件 7.3: 解決後の y 列の見出し名を保持できる。"""
        x = np.arange(3, dtype=np.float64)
        s = DataSeries(source_id="s.csv", x=x, y=x, column_name="signal")
        assert s.column_name == "signal"

    def test_column_header_name_is_empty_without_a_header(self) -> None:
        """要件 7.3: 見出しを持たない入力では見出し名は空（``None``）である。

        既定で空であることが、見出しの無い入力と系列直接指定の双方を 1 つの表現で
        扱えるようにしている。
        """
        assert _series().column_name is None


class TestParameterEstimate:
    """パラメータ推定値。"""

    def test_holds_the_value_and_the_standard_error(self) -> None:
        """推定値と標準誤差を保持する。"""
        p = ParameterEstimate(name="amplitude", value=1.5, stderr=0.02, fixed=False)
        assert (p.name, p.value, p.stderr, p.fixed) == ("amplitude", 1.5, 0.02, False)

    def test_allows_none_when_the_standard_error_is_uncomputable(self) -> None:
        """要件 7.1: ヤコビアン不足では標準誤差が得られない。失敗にはしない。"""
        assert ParameterEstimate(name="a", value=1.0, stderr=None, fixed=False).stderr is None

    def test_fixed_parameters_have_no_standard_error(self) -> None:
        """固定パラメータは標準誤差を持たない。"""
        assert ParameterEstimate(name="a", value=1.0, stderr=None, fixed=True).stderr is None

    def test_rejects_a_fixed_parameter_carrying_a_standard_error(self) -> None:
        """固定パラメータに標準誤差があると拒否する。"""
        with pytest.raises(ValueError, match="固定"):
            ParameterEstimate(name="a", value=1.0, stderr=0.1, fixed=True)


class TestGoodnessOfFit:
    """適合度指標。"""

    def test_holds_r_squared_and_rmse(self) -> None:
        """決定係数と rmse を保持する。"""
        g = GoodnessOfFit(r_squared=0.99, rmse=0.01, n_points=10, n_varied_params=3)
        assert (g.r_squared, g.rmse, g.n_points, g.n_varied_params) == (0.99, 0.01, 10, 3)

    def test_rejects_a_negative_point_count(self) -> None:
        """点数が負なら拒否する。"""
        with pytest.raises(ValueError, match="点数"):
            GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=-1, n_varied_params=0)


class TestCurveData:
    """曲線データ。"""

    def test_constructs_when_all_four_arrays_have_equal_length(self) -> None:
        """四配列が同一長なら構成できる。"""
        c = _curve(4)
        assert len(c.x) == len(c.y_observed) == len(c.y_fit) == len(c.residual) == 4

    def test_rejects_arrays_of_unequal_length(self) -> None:
        """配列長が揃わないと拒否する。"""
        with pytest.raises(ValueError, match="長さ"):
            CurveData(
                x=np.zeros(3, dtype=np.float64),
                y_observed=np.zeros(3, dtype=np.float64),
                y_fit=np.zeros(2, dtype=np.float64),
                residual=np.zeros(3, dtype=np.float64),
            )


def _curve(n: int) -> CurveData:
    z = np.zeros(n, dtype=np.float64)
    return CurveData(x=z, y_observed=z, y_fit=z, residual=z)


def _report(n: int = 5) -> PreprocessReport:
    return PreprocessReport(
        n_input=n,
        n_dropped_invalid=0,
        n_dropped_out_of_range=0,
        n_dropped_outlier=0,
        outlier_points=(),
    )


class TestPreprocessReport:
    """要件 2.2、2.3、2.5: 除去件数と、外れ値として除外した点の記録。"""

    def test_holds_x_observed_and_iteration_of_excluded_points(self) -> None:
        """要件 2.5: 件数だけでは、どの点がどの判定で外れたのかが利用者に届かない。"""
        report = PreprocessReport(
            n_input=5,
            n_dropped_invalid=0,
            n_dropped_out_of_range=0,
            n_dropped_outlier=2,
            outlier_points=(
                OutlierPoint(x=1.5, y=20.0, iteration=1),
                OutlierPoint(x=0.5, y=-3.0, iteration=2),
            ),
        )
        assert [(p.x, p.y, p.iteration) for p in report.outlier_points] == [
            (1.5, 20.0, 1),
            (0.5, -3.0, 2),
        ]
        assert report.n_used == 3

    def test_rejects_excluded_point_records_that_disagree_with_the_count(self) -> None:
        """要件 2.3 の件数と要件 2.5 の記録が食い違えば、どちらを信じるかが決まらない。"""
        with pytest.raises(ValueError, match="件数"):
            PreprocessReport(
                n_input=5,
                n_dropped_invalid=0,
                n_dropped_out_of_range=0,
                n_dropped_outlier=2,
                outlier_points=(OutlierPoint(x=1.5, y=20.0, iteration=1),),
            )

    def test_zero_exclusions_requires_an_empty_record(self) -> None:
        """除外が 0 件なら記録も空でなければならない。"""
        with pytest.raises(ValueError, match="件数"):
            PreprocessReport(
                n_input=5,
                n_dropped_invalid=0,
                n_dropped_out_of_range=0,
                n_dropped_outlier=0,
                outlier_points=(OutlierPoint(x=1.5, y=20.0, iteration=1),),
            )

    def test_rejects_a_negative_count(self) -> None:
        """件数が負なら拒否する。"""
        with pytest.raises(ValueError, match="負"):
            PreprocessReport(
                n_input=5,
                n_dropped_invalid=-1,
                n_dropped_out_of_range=0,
                n_dropped_outlier=0,
                outlier_points=(),
            )


class TestOutlierPoint:
    """要件 2.5: 除外した点 1 個の記録。"""

    def test_cannot_be_reassigned_after_construction(self) -> None:
        """生成後に再代入できない。"""
        point = OutlierPoint(x=1.0, y=2.0, iteration=1)
        with pytest.raises(dataclasses.FrozenInstanceError):
            point.x = 9.0  # type: ignore[misc]

    def test_iteration_is_one_based(self) -> None:
        """0 起点だと「1 回目の判定で除外した」を 0 と読ませることになる。"""
        with pytest.raises(ValueError, match="反復"):
            OutlierPoint(x=1.0, y=2.0, iteration=0)


class TestFitOutcome:
    """当てはめ結果。"""

    def test_constructs_a_success_outcome(self) -> None:
        """成功結果を構成できる。"""
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(ParameterEstimate(name="a", value=1.0, stderr=0.1, fixed=False),),
            goodness=GoodnessOfFit(r_squared=0.99, rmse=0.01, n_points=4, n_varied_params=1),
            curve=_curve(4),
            preprocess=_report(),
        )
        assert s.method_name == "gaussian"

    def test_methods_without_parameters_still_yield_a_success(self) -> None:
        """要件 5.3: 移動平均などパラメータのない手法でも適合度は必ず算出される。"""
        s = FitSuccess(
            source_id="a.csv",
            method_name="moving_average",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=0.8, rmse=0.2, n_points=4, n_varied_params=0),
            curve=_curve(4),
            preprocess=_report(),
        )
        assert s.parameters == ()
        assert s.goodness.rmse == 0.2

    def test_rejects_a_goodness_point_count_that_disagrees_with_the_curve(self) -> None:
        """適合度の点数が曲線長と食い違うと拒否する。"""
        with pytest.raises(ValueError, match="点数"):
            FitSuccess(
                source_id="a.csv",
                method_name="gaussian",
                parameters=(),
                goodness=GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=99, n_varied_params=0),
                curve=_curve(4),
                preprocess=_report(),
            )

    def test_constructs_a_success_with_the_curve_released(self) -> None:
        """要件 10.4: バッチが曲線を手放した後の状態を、型として表せること。

        点数は適合度に残る。曲線を落としたことが「点が 1 つも無かった」と混ざらない。
        """
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=4, n_varied_params=0),
            curve=None,
            preprocess=_report(),
        )
        assert s.curve is None
        assert s.goodness.n_points == 4

    def test_releasing_drops_only_the_curve(self) -> None:
        """要件 10.4: ``without_curve`` は推定値・適合度・前処理記録に触れない。"""
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(ParameterEstimate(name="a", value=1.0, stderr=0.1, fixed=False),),
            goodness=GoodnessOfFit(r_squared=0.99, rmse=0.01, n_points=4, n_varied_params=1),
            curve=_curve(4),
            preprocess=_report(),
        )

        released = s.without_curve()

        assert released.curve is None
        assert s.curve is not None, "元の結果が書き換えられている"
        assert (released.source_id, released.method_name) == (s.source_id, s.method_name)
        assert released.parameters == s.parameters
        assert released.goodness == s.goodness
        assert released.preprocess == s.preprocess

    def test_releasing_an_already_released_outcome_is_idempotent(self) -> None:
        """解放済みの結果を再度解放しても同じ結果になる。"""
        s = FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=4, n_varied_params=0),
            curve=_curve(4),
            preprocess=_report(),
        ).without_curve()

        assert s.without_curve() == s

    def test_failure_holds_the_reason_and_the_message(self) -> None:
        """失敗結果は理由と説明を持つ。"""
        f = FitFailure(
            source_id="a.csv",
            method_name="gaussian",
            reason=FailureReason.NOT_CONVERGED,
            message="収束しなかった",
            preprocess=_report(),
        )
        assert f.reason is FailureReason.NOT_CONVERGED

    def test_failure_before_preprocessing_carries_no_preprocess_report(self) -> None:
        """前処理到達前の失敗では前処理レポートを持たない。"""
        f = FitFailure(
            source_id="a.csv",
            method_name="gaussian",
            reason=FailureReason.COLUMN_NOT_FOUND,
            message="列 x が無い",
            preprocess=None,
        )
        assert f.preprocess is None


class TestOutcomeColumnIdentity:
    """要件 7.3、7.6: 結果が自分で持つ 2 つの列識別子。

    ``column_label`` は**指定の綴り**（列名または位置）で、ファイルを読む前に確定し
    出力名にも入る。``column_name`` は**解決後の見出し名**で、読み込み後にしか埋まらない。
    役割が違うため 1 つの場にまとめない。
    """

    def _success(self, **kwargs: object) -> FitSuccess:
        return FitSuccess(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(),
            goodness=GoodnessOfFit(r_squared=0.9, rmse=0.1, n_points=4, n_varied_params=0),
            curve=_curve(4),
            preprocess=_report(),
            **kwargs,  # type: ignore[arg-type]
        )

    def _failure(self, **kwargs: object) -> FitFailure:
        return FitFailure(
            source_id="a.csv",
            method_name="gaussian",
            reason=FailureReason.COLUMN_NOT_FOUND,
            message="列 2 が無い",
            preprocess=None,
            **kwargs,  # type: ignore[arg-type]
        )

    def test_success_holds_the_two_identifiers_separately(self) -> None:
        """要件 7.3、7.6: 成功結果は指定の綴りと解決後の見出し名を別々に持つ。"""
        s = self._success(column_label="2", column_name="signal")
        assert (s.column_label, s.column_name) == ("2", "signal")

    def test_failure_holds_the_two_identifiers_separately(self) -> None:
        """要件 7.3、7.6: 失敗結果も同じ 2 つの識別子を持つ。"""
        f = self._failure(column_label="2", column_name="signal")
        assert (f.column_label, f.column_name) == ("2", "signal")

    def test_the_two_identifiers_are_distinct_fields(self) -> None:
        """2 つの場が別物であること。片方の値がもう片方に漏れない。"""
        for outcome in (
            self._success(column_label="1", column_name="signal"),
            self._failure(column_label="1", column_name="signal"),
        ):
            names = {f.name for f in dataclasses.fields(outcome)}
            assert {"column_label", "column_name"} <= names
            assert outcome.column_label != outcome.column_name

    def test_direct_series_path_leaves_both_identifiers_empty(self) -> None:
        """要件 7.6: 系列を直接渡す経路では双方が空になる。

        この経路は列の概念を持たず出力物も書かないため、綴りも見出し名も存在しない。
        既定で双方が空であることが、その経路を追加の記述なしに表せる形にしている。
        """
        for outcome in (self._success(), self._failure()):
            assert outcome.column_label is None
            assert outcome.column_name is None

    def test_failure_before_reading_leaves_only_the_header_name_empty(self) -> None:
        """要件 7.3: 読み込みに至らない失敗では見出し名だけが空になる。

        綴りは読む前に確定しているため残る。見出し名は読んだ後にしか分からない。
        """
        f = self._failure(column_label="2")
        assert f.column_label == "2"
        assert f.column_name is None

    def test_rejects_a_header_name_without_the_specified_label(self) -> None:
        """見出し名だけを持ち綴りを持たない結果を拒否する。

        見出し名が分かるのは列指定を経て読み込んだ場合に限り、そのとき綴りは必ず
        確定している。綴りが空なのは系列直接指定の経路だけで、その経路は見出し名も持たない。
        """
        with pytest.raises(ValueError, match="column_label"):
            self._success(column_name="signal")
        with pytest.raises(ValueError, match="column_label"):
            self._failure(column_name="signal")

    def test_releasing_the_curve_keeps_the_two_identifiers(self) -> None:
        """要件 10.4: 曲線の解放は列識別子に触れない。"""
        released = self._success(column_label="2", column_name="signal").without_curve()
        assert (released.column_label, released.column_name) == ("2", "signal")


class TestFailureTaxonomy:
    """失敗分類。"""

    def test_runtime_failures_and_preflight_violations_are_separate_taxonomies(self) -> None:
        """統合すると「止めるべきか継続すべきか」の判断が呼び出し側に漏れる。"""
        assert FailureReason is not ViolationKind
        assert set(FailureReason) & set(ViolationKind) == set()

    def test_runtime_failure_reasons_map_to_requirements(self) -> None:
        """実行中失敗の理由が要件に対応している。"""
        assert {r.value for r in FailureReason} == {
            "column_not_found",
            "no_valid_data",
            "insufficient_points",
            "not_converged",
            "header_ambiguous",
            "input_unreadable",
            "resource_exhausted",
        }

    def test_preflight_violation_kinds_map_to_requirements(self) -> None:
        """実行前違反の種別が要件に対応している。"""
        assert {v.value for v in ViolationKind} == {
            "config_invalid",
            "model_unresolved",
            "initial_required",
            "initial_out_of_bounds",
            "output_not_writable",
            "smoother_option_invalid",
        }

    def test_config_violation_holds_a_location_and_a_message(self) -> None:
        """設定違反は箇所と説明を持つ。"""
        v = ConfigViolation(
            kind=ViolationKind.MODEL_UNRESOLVED,
            location="methods[0].builtin",
            message="未知のモデル名: gausian",
        )
        assert v.location == "methods[0].builtin"


def _imported_modules(filename: str) -> set[str]:
    """モジュールが実際に import している最上位モジュール名を AST から収集する。

    docstring や注釈中の文字列に反応しないよう、文字列検索ではなく構文木で判定する。
    """
    tree = ast.parse((SRC / filename).read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class TestDependencyExposure:
    """依存の露出。"""

    def test_does_not_import_underlying_libraries(self) -> None:
        """設計の Allowed Dependencies: lmfit / SciPy / matplotlib / pandas を外へ漏らさない。"""
        for name in ("types.py", "errors.py"):
            for imported in _imported_modules(name):
                root = imported.split(".")[0]
                assert root not in {"lmfit", "scipy", "matplotlib", "pandas"}, (
                    f"{name} が {imported} を import している"
                )

    def test_failure_taxonomy_depends_on_no_other_module_of_the_package(self) -> None:
        """失敗分類は自パッケージの他モジュールに依存しない。"""
        own = {m for m in _imported_modules("errors.py") if m.split(".")[0] == "curvefit"}
        assert own == set(), f"想定外の依存: {own}"

    def test_shared_types_depend_on_no_package_module_other_than_the_taxonomy(self) -> None:
        """共有型は失敗分類以外の自パッケージモジュールに依存しない。"""
        own = {m for m in _imported_modules("types.py") if m.split(".")[0] == "curvefit"}
        assert own <= {"curvefit.errors"}, f"想定外の依存: {own - {'curvefit.errors'}}"
