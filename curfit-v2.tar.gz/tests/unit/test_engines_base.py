"""当てはめ契約と適合度算出の契約を検証する。

対応要件: 5.2（回帰・スムージングをモデル関数フィットと同一手順で実行する）、
7.2（決定係数と RMSE を含む適合度指標を結果に含める）。

設計の engines.base ブロックが定める `FitEngine` / `EngineSuccess` / `EngineFailure` /
`EngineOutcome` / `compute_goodness` の契約、および「エンジン層は入出力を持たない」
「基盤ライブラリ固有の型を公開シグネチャに露出させない」を検証する。手法から実装への
振り分けは engines.base の責務ではないため、ここでは扱わない。

適合度の期待値はすべて手計算で与える。実装から逆算した値を書くと、算出式が変わっても
テストが追随して通り続けるため、指標の定義を固定する意味がなくなる。
"""

from __future__ import annotations

import ast
import dataclasses
import inspect
import math
from pathlib import Path

import numpy as np
import pytest

from curvefit.engines.base import (
    EngineFailure,
    EngineSuccess,
    FitEngine,
    compute_goodness,
)
from curvefit.errors import FailureReason
from curvefit.models.resolver import PreparedModel, PreparedSmoother, SmootherKind
from curvefit.types import DataSeries, GoodnessOfFit, ParameterEstimate

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


def _array(values: list[float]) -> np.ndarray:
    return np.array(values, dtype=np.float64)


def _series(n: int = 5) -> DataSeries:
    x = np.arange(n, dtype=np.float64)
    return DataSeries(source_id="sample.csv", x=x, y=x * 2.0)


def _prepared_model(name: str = "gaussian") -> PreparedModel:
    """当てはめ手段の選択だけを検証するための解決済みモデル。

    モデル実体とパラメータ束は選択の判定に用いられないため、基盤ライブラリの実体では
    なく素の :class:`object` を置く。エンジン選択が実体の中身を覗いていれば失敗する。
    """
    return PreparedModel(
        display_name=name,
        parameter_names=("a", "b"),
        applied_defaults={},
        _model=object(),
        _parameters=object(),
    )


def _prepared_smoother(kind: SmootherKind = SmootherKind.LINEAR) -> PreparedSmoother:
    return PreparedSmoother(display_name=kind.value, kind=kind, options={})


class _StubEngine:
    """`FitEngine` の形だけを満たす記録用のエンジン。"""

    def __init__(self, tag: str) -> None:
        self.tag = tag
        self.calls: list[tuple[DataSeries, PreparedModel | PreparedSmoother]] = []

    def fit(
        self, series: DataSeries, method: PreparedModel | PreparedSmoother
    ) -> EngineSuccess | EngineFailure:
        self.calls.append((series, method))
        return EngineSuccess(parameters=(), y_fit=series.y.copy(), applied_defaults={})


class _NotAnEngine:
    """`fit` を持たない、契約を満たさない実装。"""


class TestGoodnessComputation:
    """要件 7.2: 決定係数と RMSE。既知の残差に対する値を手計算で固定する。"""

    def test_r_squared_and_rmse_for_known_residuals(self) -> None:
        # y の平均は 3.0、全変動は 4+1+0+1+4 = 10.0
        # 残差は [-0.1, 0.1, -0.2, 0.2, -0.1]、残差平方和は 0.11
        """既知の残差に対する決定係数と RMSE。"""
        y_observed = _array([1.0, 2.0, 3.0, 4.0, 5.0])
        y_fit = _array([1.1, 1.9, 3.2, 3.8, 5.1])

        goodness = compute_goodness(y_observed, y_fit, n_varied_params=2)

        assert goodness.r_squared == pytest.approx(1.0 - 0.11 / 10.0)
        assert goodness.rmse == pytest.approx(math.sqrt(0.11 / 5.0))

    def test_keeps_the_point_count_and_varied_parameter_count(self) -> None:
        """点数と変動パラメータ数を保持する。"""
        goodness = compute_goodness(_array([1.0, 2.0, 4.0]), _array([1.0, 2.0, 4.0]), 3)
        assert goodness.n_points == 3
        assert goodness.n_varied_params == 3

    def test_returns_the_goodness_of_fit_type(self) -> None:
        """適合度指標型を返す。"""
        goodness = compute_goodness(_array([1.0, 2.0]), _array([1.0, 2.0]), 0)
        assert isinstance(goodness, GoodnessOfFit)

    def test_exact_match_gives_r_squared_1_and_rmse_0(self) -> None:
        """完全一致では決定係数が 1 で RMSE が 0。"""
        y_observed = _array([1.0, 4.0, 9.0, 16.0])
        goodness = compute_goodness(y_observed, y_observed.copy(), 2)
        assert goodness.r_squared == 1.0
        assert goodness.rmse == 0.0

    def test_r_squared_is_negative_when_worse_than_the_mean(self) -> None:
        # 全変動 2.0 に対し残差平方和 8.0。1 - 8/2 = -3.0
        """平均より当てはまりが悪い場合は決定係数が負になる。"""
        goodness = compute_goodness(_array([1.0, 2.0, 3.0]), _array([3.0, 2.0, 1.0]), 1)
        assert goodness.r_squared == pytest.approx(-3.0)
        assert goodness.rmse == pytest.approx(math.sqrt(8.0 / 3.0))

    def test_r_squared_is_not_clamped_from_below(self) -> None:
        """負の決定係数は 0 に切り上げない。

        切り上げると「平均より当てはまりが悪い」という利用者が知るべき状態が、
        「当てはまりが最悪でも 0」という無害な値に化ける。
        """
        goodness = compute_goodness(_array([0.0, 1.0]), _array([10.0, -10.0]), 1)
        assert goodness.r_squared < 0.0

    def test_constant_observations_with_exact_match_give_r_squared_1(self) -> None:
        """全変動が 0 の系列。残差も 0 であれば当てはめは完全である。"""
        goodness = compute_goodness(_array([5.0, 5.0, 5.0]), _array([5.0, 5.0, 5.0]), 1)
        assert goodness.r_squared == 1.0
        assert goodness.rmse == 0.0

    def test_constant_observations_with_residuals_give_r_squared_0(self) -> None:
        """全変動が 0 で残差が残る系列。無限大や NaN ではなく 0 を返す。"""
        goodness = compute_goodness(_array([5.0, 5.0, 5.0]), _array([6.0, 6.0, 6.0]), 1)
        assert goodness.r_squared == 0.0
        assert goodness.rmse == pytest.approx(1.0)

    def test_single_point_exact_match_gives_r_squared_1(self) -> None:
        """単一点で完全一致なら決定係数は 1。"""
        goodness = compute_goodness(_array([7.0]), _array([7.0]), 1)
        assert goodness.r_squared == 1.0
        assert goodness.rmse == 0.0
        assert goodness.n_points == 1

    def test_single_point_with_offset_gives_r_squared_0(self) -> None:
        """単一点でずれがあれば決定係数は 0。"""
        goodness = compute_goodness(_array([7.0]), _array([9.0]), 1)
        assert goodness.r_squared == 0.0
        assert goodness.rmse == pytest.approx(2.0)

    def test_identical_residuals_give_identical_metrics(self) -> None:
        """要件 5.2 / 5.3: 手法によらず残差だけから決まる。"""
        first = compute_goodness(_array([1.0, 2.0, 3.0]), _array([1.5, 2.0, 2.5]), 2)
        second = compute_goodness(_array([1.0, 2.0, 3.0]), _array([1.5, 2.0, 2.5]), 2)
        assert first == second

    def test_does_not_take_the_method_as_an_argument(self) -> None:
        """算出が手法に依存しないことを署名として固定する（要件 5.2）。"""
        names = tuple(inspect.signature(compute_goodness).parameters)
        assert names == ("y_observed", "y_fit", "n_varied_params")

    def test_does_not_mutate_its_inputs(self) -> None:
        """入力を書き換えない。"""
        y_observed = _array([1.0, 2.0, 3.0])
        y_fit = _array([1.0, 2.5, 2.0])
        compute_goodness(y_observed, y_fit, 1)
        assert np.array_equal(y_observed, _array([1.0, 2.0, 3.0]))
        assert np.array_equal(y_fit, _array([1.0, 2.5, 2.0]))

    def test_rejects_inputs_of_unequal_length(self) -> None:
        """長さが揃わない入力を拒否する。"""
        with pytest.raises(ValueError, match="長さ"):
            compute_goodness(_array([1.0, 2.0]), _array([1.0]), 1)

    def test_rejects_empty_inputs(self) -> None:
        """空の入力を拒否する。"""
        with pytest.raises(ValueError, match="1 点"):
            compute_goodness(_array([]), _array([]), 0)

    def test_rejects_a_negative_varied_parameter_count(self) -> None:
        """変動パラメータ数が負なら拒否する。"""
        with pytest.raises(ValueError):
            compute_goodness(_array([1.0, 2.0]), _array([1.0, 2.0]), -1)


class TestEngineSuccess:
    """成功結果。"""

    def test_holds_parameters_fitted_values_and_applied_defaults(self) -> None:
        """パラメータと当てはめ値と適用既定値を持つ。"""
        estimate = ParameterEstimate(name="a", value=1.0, stderr=0.1, fixed=False)
        success = EngineSuccess(
            parameters=(estimate,),
            y_fit=_array([1.0, 2.0]),
            applied_defaults={"window": 5},
        )
        assert success.parameters == (estimate,)
        assert np.array_equal(success.y_fit, _array([1.0, 2.0]))
        assert success.applied_defaults["window"] == 5

    def test_methods_without_parameters_give_an_empty_tuple(self) -> None:
        """要件 5.3: パラメータを持たない手法でも同一形式で表す。"""
        success = EngineSuccess(parameters=(), y_fit=_array([1.0]))
        assert success.parameters == ()
        assert dict(success.applied_defaults) == {}

    def test_cannot_be_reassigned_after_construction(self) -> None:
        """生成後に再代入できない。"""
        success = EngineSuccess(parameters=(), y_fit=_array([1.0]))
        with pytest.raises(dataclasses.FrozenInstanceError):
            success.y_fit = _array([2.0])  # type: ignore[misc]

    def test_applied_defaults_are_detached_from_the_caller_dict(self) -> None:
        """適用既定値は呼び出し側の辞書から切り離される。"""
        defaults: dict[str, float | int] = {"window": 5}
        success = EngineSuccess(parameters=(), y_fit=_array([1.0]), applied_defaults=defaults)
        defaults["window"] = 9
        assert success.applied_defaults["window"] == 5

    def test_applied_defaults_cannot_be_mutated(self) -> None:
        """適用既定値を書き換えられない。"""
        success = EngineSuccess(parameters=(), y_fit=_array([1.0]), applied_defaults={"w": 5})
        with pytest.raises(TypeError):
            success.applied_defaults["w"] = 9  # type: ignore[index]

    def test_rejects_fitted_values_that_are_not_a_1d_float_array(self) -> None:
        """当てはめ値が一次元の浮動小数点配列でなければ拒否する。"""
        with pytest.raises(ValueError):
            EngineSuccess(parameters=(), y_fit=np.zeros((2, 2), dtype=np.float64))
        with pytest.raises(ValueError):
            EngineSuccess(parameters=(), y_fit=np.array([1, 2], dtype=np.int64))


class TestEngineFailure:
    """失敗結果。"""

    def test_holds_the_reason_the_message_and_the_initial_values(self) -> None:
        """要件 4.7: 非収束の報告に、使用した初期値を含められる。"""
        failure = EngineFailure(
            reason=FailureReason.NOT_CONVERGED,
            message="最大反復回数に達した",
            initial_values={"amplitude": 1.0, "center": 0.0},
        )
        assert failure.reason is FailureReason.NOT_CONVERGED
        assert failure.initial_values["amplitude"] == 1.0
        assert failure.initial_values["center"] == 0.0

    def test_initial_values_may_be_omitted(self) -> None:
        """初期値は省略できる。"""
        failure = EngineFailure(reason=FailureReason.NOT_CONVERGED, message="非収束")
        assert dict(failure.initial_values) == {}

    def test_initial_values_are_detached_from_the_caller_dict(self) -> None:
        """初期値は呼び出し側の辞書から切り離される。"""
        initial = {"a": 1.0}
        failure = EngineFailure(
            reason=FailureReason.NOT_CONVERGED, message="非収束", initial_values=initial
        )
        initial["a"] = 2.0
        assert failure.initial_values["a"] == 1.0

    def test_initial_values_cannot_be_mutated(self) -> None:
        """初期値を書き換えられない。"""
        failure = EngineFailure(
            reason=FailureReason.NOT_CONVERGED, message="非収束", initial_values={"a": 1.0}
        )
        with pytest.raises(TypeError):
            failure.initial_values["a"] = 2.0  # type: ignore[index]

    def test_cannot_be_reassigned_after_construction(self) -> None:
        """生成後に再代入できない。"""
        failure = EngineFailure(reason=FailureReason.NOT_CONVERGED, message="非収束")
        with pytest.raises(dataclasses.FrozenInstanceError):
            failure.message = "別の理由"  # type: ignore[misc]

    def test_rejects_a_failure_without_a_message(self) -> None:
        """報告先を特定できない失敗は数百件のバッチでは無価値である。"""
        with pytest.raises(ValueError):
            EngineFailure(reason=FailureReason.NOT_CONVERGED, message="")

    def test_is_carried_as_a_value_not_an_exception(self) -> None:
        """例外ではなく値として運ばれる。"""
        assert not isinstance(
            EngineFailure(reason=FailureReason.NOT_CONVERGED, message="非収束"), BaseException
        )


class TestFitContract:
    """要件 5.2: モデル関数フィットと回帰・スムージングを同一の契約で扱う。"""

    def test_implementation_with_fit_satisfies_the_contract(self) -> None:
        """fit を持つ実装は契約を満たす。"""
        assert isinstance(_StubEngine("any"), FitEngine)

    def test_implementation_without_fit_does_not_satisfy_the_contract(self) -> None:
        """fit を持たない実装は契約を満たさない。"""
        assert not isinstance(_NotAnEngine(), FitEngine)

    def test_contract_signature_takes_a_series_and_a_prepared_method(self) -> None:
        """契約の署名が系列と解決済み手法を受け取る。"""
        names = tuple(inspect.signature(FitEngine.fit).parameters)
        assert names == ("self", "series", "method")

    def test_model_and_smoother_are_handled_by_the_same_call(self) -> None:
        """モデルと平滑化を同一の呼び出しで扱える。"""
        engine = _StubEngine("shared")
        series = _series()
        for method in (_prepared_model(), _prepared_smoother()):
            outcome = engine.fit(series, method)
            assert isinstance(outcome, EngineSuccess)
        assert len(engine.calls) == 2


class TestPackageExports:
    """パッケージの公開。"""

    def test_fit_contract_is_reachable_from_the_package(self) -> None:
        """当てはめ契約をパッケージから参照できる。"""
        import curvefit.engines as engines

        assert engines.compute_goodness is compute_goodness
        assert engines.EngineSuccess is EngineSuccess
        assert engines.EngineFailure is EngineFailure
        assert engines.FitEngine is FitEngine

    def test_public_names_are_declared(self) -> None:
        """公開名が宣言されている。"""
        import curvefit.engines as engines

        assert "EngineOutcome" in engines.__all__


def _module_source(name: str) -> str:
    return (SRC / "engines" / name).read_text(encoding="utf-8")


def _imported_modules(name: str) -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse(_module_source(name))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class TestDependencyExposure:
    """依存の露出。"""

    def test_does_not_import_underlying_libraries(self) -> None:
        """設計の Allowed Dependencies: 当てはめ契約は基盤ライブラリの型を持ち込まない。"""
        for imported in _imported_modules("base.py"):
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas"}, (
                f"engines/base.py が {imported} を import している"
            )

    def test_public_signatures_expose_no_underlying_library_types(self) -> None:
        """公開署名に基盤ライブラリの型が現れない。"""
        for function in (compute_goodness, FitEngine.fit):
            rendered = str(inspect.signature(function))
            for library in ("lmfit", "scipy", "ModelResult", "DataFrame"):
                assert library not in rendered, f"{function.__name__} に {library} が現れる"

    def test_depends_only_on_layers_to_its_left(self) -> None:
        """設計の依存方向: engines は types / errors / models までしか参照しない。"""
        allowed = {"curvefit.types", "curvefit.errors", "curvefit.models.resolver"}
        own = {m for m in _imported_modules("base.py") if m.split(".")[0] == "curvefit"}
        assert own <= allowed, f"想定外の依存: {own - allowed}"

    def test_performs_no_io(self) -> None:
        """設計: engines / preprocess はファイル・端末・ログに触れない。"""
        forbidden = {"pathlib", "os", "sys", "logging", "io", "open", "subprocess"}
        for name in ("base.py", "__init__.py"):
            for imported in _imported_modules(name):
                assert imported.split(".")[0] not in forbidden, (
                    f"engines/{name} が入出力に関わる {imported} を import している"
                )
