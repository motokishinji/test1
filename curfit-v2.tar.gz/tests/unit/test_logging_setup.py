"""実行ログのハンドラ構成を検証する。

対応要件: 8.4（処理した対象と各対象の成否・失敗理由を実行ログとして出力する）、
7.1（標準誤差が算出できない場合は失敗とせず警告として記録する）。

設計の execution / logging_setup ブロックと Error Handling → Monitoring
（「`run.log` に、実行開始時の解決済み設定、ジョブごとの成否と理由、終了時の成功/失敗
件数を記録する。`stderr` は算出不能時に警告として記録する。ログ順序はジョブ順序に従い
決定的である」）、writers / plotting の Batch / Job Contract（`{output_dir}/run.log`）を
対象とする。

**当てはめエンジンは入出力を持たない。** `engines.least_squares` は標準誤差を算出できない
場合に `stderr=None` を返すだけであり、要件 7.1 の「警告として記録する」を果たせるのは
ログを持つ本層だけである（tasks.md の Implementation Notes）。したがって警告の有無は
エンジン側では検証できず、ここで固定する。

**ログ構成は大域の副作用であってはならない。** `curvefit` を import しただけで根ロガーに
ハンドラが付くと、本ライブラリを取り込んだ利用者のアプリケーションのログ出力が乗っ取られる
（要件 9.1 のライブラリ利用）。import 時に何も起きないこと、明示的に構成した後は明示的に
解放できることを主張する。
"""

from __future__ import annotations

import ast
import logging
import subprocess
import sys
from collections.abc import Iterator
from pathlib import Path

import numpy as np
import pytest

from curvefit.errors import FailureReason
from curvefit.logging_setup import (
    FAILURE_STATUS,
    LOGGER_NAME,
    RUN_LOG_FILENAME,
    SUCCESS_STATUS,
    configure_run_log,
    log_outcome,
    log_run_start,
    log_summary,
)
from curvefit.types import (
    CurveData,
    FitFailure,
    FitOutcome,
    FitSuccess,
    FloatArray,
    GoodnessOfFit,
    ParameterEstimate,
    PreprocessReport,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


@pytest.fixture(autouse=True)
def preserve_logger_state() -> Iterator[None]:
    """`curvefit` ロガーの状態を試験ごとに元へ戻す。

    ログ構成は大域状態である。ある試験が残した水準・伝播・ハンドラが次の試験の前提に
    なると、単独実行と全体実行で結果が変わり、状態の復元を壊しても気づけない。順序に
    依らず同じことを主張するため、試験の前後で状態を固定する。
    """
    logger = logging.getLogger(LOGGER_NAME)
    level = logger.level
    propagate = logger.propagate
    handlers = list(logger.handlers)
    try:
        yield
    finally:
        for handler in list(logger.handlers):
            if handler not in handlers:
                logger.removeHandler(handler)
                handler.close()
        logger.setLevel(level)
        logger.propagate = propagate


def _array(values: list[float]) -> FloatArray:
    return np.array(values, dtype=np.float64)


def _curve(n: int = 3) -> CurveData:
    x = _array([float(i) for i in range(n)])
    y = _array([float(i) * 2.0 for i in range(n)])
    return CurveData(x=x, y_observed=y, y_fit=y, residual=_array([0.0] * n))


def _report() -> PreprocessReport:
    return PreprocessReport(
        n_input=3,
        n_dropped_invalid=0,
        n_dropped_out_of_range=0,
        n_dropped_outlier=0,
        outlier_points=(),
    )


def _success(
    source_id: str = "a.csv",
    method_name: str = "linear",
    parameters: tuple[ParameterEstimate, ...] = (),
    column_label: str | None = None,
) -> FitSuccess:
    curve = _curve()
    return FitSuccess(
        source_id=source_id,
        method_name=method_name,
        parameters=parameters,
        goodness=GoodnessOfFit(
            r_squared=0.99,
            rmse=0.01,
            n_points=len(curve),
            n_varied_params=len(parameters),
        ),
        curve=curve,
        preprocess=_report(),
        column_label=column_label,
    )


def _failure(
    source_id: str = "broken.csv",
    method_name: str = "gaussian",
    reason: FailureReason = FailureReason.NOT_CONVERGED,
    message: str = "当てはめが収束しなかった（初期値: amplitude=1.0）",
    column_label: str | None = None,
) -> FitFailure:
    return FitFailure(
        source_id=source_id,
        method_name=method_name,
        reason=reason,
        message=message,
        column_label=column_label,
    )


def _lines(path: Path) -> list[str]:
    return path.read_text(encoding="utf-8").splitlines()


def _written(directory: Path, outcomes: list[FitOutcome]) -> list[str]:
    """`outcomes` を与えられた順に記録し、書き出された行を返す。"""
    with configure_run_log(directory) as handle:
        for outcome in outcomes:
            log_outcome(handle.logger, outcome)
    return _lines(handle.path)


class TestRunLogDestination:
    """設計の Batch / Job Contract: `{output_dir}/run.log`。"""

    def test_destination_is_run_log_directly_under_the_output_directory(
        self, tmp_path: Path
    ) -> None:
        """出力先は出力ディレクトリ直下の run log。"""
        assert RUN_LOG_FILENAME == "run.log"

        with configure_run_log(tmp_path) as handle:
            assert handle.path == tmp_path / "run.log"
            assert handle.path.exists()

    def test_creates_the_output_directory_when_missing(self, tmp_path: Path) -> None:
        """出力ディレクトリが無ければ作る。"""
        directory = tmp_path / "out"

        with configure_run_log(directory) as handle:
            handle.logger.info("test")

        assert (directory / RUN_LOG_FILENAME).exists()

    def test_rerun_overwrites_the_same_path(self, tmp_path: Path) -> None:
        """設計の Idempotency & recovery。前回の実行分が残ると成否集計と食い違う。"""
        with configure_run_log(tmp_path) as handle:
            log_outcome(handle.logger, _success(source_id="first.csv"))
        with configure_run_log(tmp_path) as handle:
            log_outcome(handle.logger, _success(source_id="second.csv"))

        text = handle.path.read_text(encoding="utf-8")
        assert "first.csv" not in text
        assert "second.csv" in text


class TestPerSourceOutcomeRecording:
    """要件 8.4。処理した対象と各対象の成否・失敗理由を残す。"""

    def test_success_becomes_one_line_with_source_method_and_outcome(self, tmp_path: Path) -> None:
        """成功は対象と手法と成否を含む 1 行になる。"""
        lines = _written(tmp_path, [_success(source_id="a.csv", method_name="linear")])

        assert len(lines) == 1
        assert f"source_id={'a.csv'!r}" in lines[0]
        assert f"method={'linear'!r}" in lines[0]
        assert f"status={SUCCESS_STATUS}" in lines[0]

    def test_failure_includes_the_reason_and_the_explanation(self, tmp_path: Path) -> None:
        """失敗は理由と説明を含む。"""
        failure = _failure()
        lines = _written(tmp_path, [failure])

        assert len(lines) == 1
        assert f"source_id={'broken.csv'!r}" in lines[0]
        assert f"method={'gaussian'!r}" in lines[0]
        assert f"status={FAILURE_STATUS}" in lines[0]
        assert f"reason={FailureReason.NOT_CONVERGED.value}" in lines[0]
        assert failure.message in lines[0]

    def test_failure_is_recorded_at_error_level(self, tmp_path: Path) -> None:
        """失敗は誤りとして記録される。"""
        lines = _written(tmp_path, [_failure()])

        assert "ERROR" in lines[0]

    def test_one_line_is_emitted_per_source(self, tmp_path: Path) -> None:
        """対象ごとに 1 行が出る。"""
        outcomes: list[FitOutcome] = [
            _success(source_id="a.csv"),
            _failure(source_id="b.csv"),
            _success(source_id="c.csv"),
        ]

        lines = _written(tmp_path, outcomes)

        assert len(lines) == 3

    def test_failure_explanation_with_newlines_stays_on_one_line(self, tmp_path: Path) -> None:
        """失敗の説明は外から来る。

        `engines.least_squares` は利用者が与えた Python 関数の送出した例外（要件 3.3）や
        当てはめ器の返す文言をそのまま説明に載せる。複数行の説明が行を割ると、1 件の失敗が
        複数件に見え、要件 8.4 の対象ごとの成否を行として数えられなくなる。
        """
        failure = _failure(message="収束しなかった\n初期値: amplitude=1.0\n反復: 200")

        lines = _written(tmp_path, [failure])

        assert len(lines) == 1
        assert "初期値: amplitude=1.0" in lines[0]
        assert "反復: 200" in lines[0]

    def test_source_or_method_name_with_newlines_stays_on_one_line(self, tmp_path: Path) -> None:
        """対象名も外から来る。列名やファイル名に改行が混じっても行数は変えない。"""
        outcomes: list[FitOutcome] = [
            _success(source_id="a\nb.csv", method_name="li\nnear"),
            _failure(source_id="c\nd.csv", method_name="ga\nussian"),
        ]

        lines = _written(tmp_path, outcomes)

        assert len(lines) == 2

    def test_warning_for_a_source_name_with_newlines_stays_on_one_line(
        self, tmp_path: Path
    ) -> None:
        """要件 7.1 の警告も 1 パラメータ 1 行を保つ。"""
        success = _success(
            source_id="a\nb.csv",
            parameters=(ParameterEstimate(name="sigma", value=2.0, stderr=None, fixed=False),),
        )

        lines = _written(tmp_path, [success])

        assert len(lines) == 2
        assert "WARNING" in lines[1]

    def test_record_order_follows_the_given_order(self, tmp_path: Path) -> None:
        """要件 8.2。ジョブ順序は決定的であり、ログはその順序をそのまま写す。"""
        outcomes: list[FitOutcome] = [
            _success(source_id="c.csv"),
            _failure(source_id="a.csv"),
            _success(source_id="b.csv"),
        ]

        lines = _written(tmp_path, outcomes)

        assert [line.split("source_id=")[1].split(" ")[0] for line in lines] == [
            repr("c.csv"),
            repr("a.csv"),
            repr("b.csv"),
        ]

    def test_records_the_success_and_failure_counts(self, tmp_path: Path) -> None:
        """設計の Monitoring: 終了時の成功/失敗件数（要件 6.6）。"""
        with configure_run_log(tmp_path) as handle:
            log_summary(handle.logger, n_success=7, n_failure=2)

        assert "n_success=7" in _lines(handle.path)[0]
        assert "n_failure=2" in _lines(handle.path)[0]

    def test_records_the_resolved_run_config_at_startup(self, tmp_path: Path) -> None:
        """設計の Monitoring: 実行開始時の解決済み設定（要件 8.3）。"""
        with configure_run_log(tmp_path) as handle:
            log_run_start(
                handle.logger,
                config_path="/etc/curvefit/run.toml",
                resolved_config={"methods": ["linear"], "header": None},
            )

        line = _lines(handle.path)[0]
        assert "/etc/curvefit/run.toml" in line
        assert "methods=" in line
        assert "header=" in line


class TestColumnIdentityOnEachLine:
    """要件 8.4。1 ファイルの複数チャネルが、行として区別できること。

    設計の execution / logging_setup が、実行ログの 1 行は処理対象と手法を識別すると
    定める。対象がファイルだけなら、同一ファイルの 2 つの y 列は対象名も手法名も同じに
    なり、行を突き合わせても **どちらのチャネルの成否かが分からない**。指定の綴り
    （``column_label``）を対象名と併記することで、行の識別が列の粒度まで下りる。

    ここで併記するのは綴りであって見出し名ではない。綴りは読み込みに至らなかった失敗
    にも載る（``pipeline`` がジョブ展開の時点で刻む）。読めた場合にしか埋まらない
    見出し名を識別子にすると、失敗の行だけが列を失う。
    """

    def test_two_channels_of_one_file_become_distinguishable_lines(
        self, tmp_path: Path
    ) -> None:
        """対象名も手法名も同じ 2 行が、列の綴りだけで見分けられる。"""
        outcomes: list[FitOutcome] = [
            _success(source_id="run.csv", method_name="line", column_label="1"),
            _success(source_id="run.csv", method_name="line", column_label="2"),
        ]

        lines = _written(tmp_path, outcomes)

        assert len(lines) == 2
        assert f"column_label={'1'!r}" in lines[0]
        assert f"column_label={'2'!r}" in lines[1]
        assert lines[0].split(" ", 1)[1] != lines[1].split(" ", 1)[1]

    def test_the_column_identifier_sits_next_to_the_source_identifier(
        self, tmp_path: Path
    ) -> None:
        """対象の識別は「対象名 + 列の綴り」で 1 組である。併記の位置を固定する。"""
        lines = _written(
            tmp_path, [_success(source_id="run.csv", method_name="line", column_label="y")]
        )

        assert f"source_id={'run.csv'!r} column_label={'y'!r} method={'line'!r}" in lines[0]

    def test_failure_line_carries_the_column_identifier(self, tmp_path: Path) -> None:
        """失敗の行も列まで識別できる。どのチャネルが落ちたかが読めなければ追えない。"""
        lines = _written(
            tmp_path,
            [
                _failure(source_id="run.csv", method_name="line", column_label="1"),
                _failure(source_id="run.csv", method_name="line", column_label="2"),
            ],
        )

        assert len(lines) == 2
        assert f"column_label={'1'!r}" in lines[0]
        assert f"column_label={'2'!r}" in lines[1]

    def test_standard_error_warning_carries_the_column_identifier(
        self, tmp_path: Path
    ) -> None:
        """要件 7.1 の警告も、どの列のどのパラメータかまで特定できる。"""
        success = _success(
            source_id="run.csv",
            method_name="gaussian",
            parameters=(ParameterEstimate(name="sigma", value=2.0, stderr=None, fixed=False),),
            column_label="2",
        )

        lines = _written(tmp_path, [success])

        warnings = [line for line in lines if "WARNING" in line]
        assert len(warnings) == 1
        assert f"column_label={'2'!r}" in warnings[0]
        assert f"parameter={'sigma'!r}" in warnings[0]

    def test_a_job_without_a_column_still_keeps_the_line_shape(self, tmp_path: Path) -> None:
        """系列を直接渡す経路（要件 9.1）は列の概念を持たない。欄は空値として残す。

        行から欄ごと落とすと、列を持つ実行と持たない実行でログの形が変わり、外部から
        読む側が 2 通りの形を扱うことになる。
        """
        lines = _written(tmp_path, [_success(source_id="series", column_label=None)])

        assert f"column_label={None!r}" in lines[0]

    def test_a_column_identifier_with_newlines_stays_on_one_line(
        self, tmp_path: Path
    ) -> None:
        """綴りは利用者が設定ファイルに書いた列名であり、改行を持ちうる。

        対象名・手法名・失敗の説明と同じく :func:`repr` で書く。生のまま差し込むと
        1 件が複数行に割れ、要件 8.4 の対象ごとの成否を行として数えられなくなる。
        """
        outcomes: list[FitOutcome] = [
            _success(source_id="run.csv", column_label="a\nb"),
            _failure(source_id="run.csv", column_label="c\nd"),
        ]

        lines = _written(tmp_path, outcomes)

        assert len(lines) == 2
        assert f"column_label={'a' + chr(10) + 'b'!r}" in lines[0]
        assert f"column_label={'c' + chr(10) + 'd'!r}" in lines[1]


class TestStandardErrorWarning:
    """要件 7.1。算出できない標準誤差は失敗にせず警告として記録する。"""

    def test_uncomputable_standard_error_is_kept_as_a_warning(self, tmp_path: Path) -> None:
        """算出できない標準誤差は警告として残る。"""
        success = _success(
            source_id="a.csv",
            method_name="gaussian",
            parameters=(
                ParameterEstimate(name="amplitude", value=1.0, stderr=0.1, fixed=False),
                ParameterEstimate(name="sigma", value=2.0, stderr=None, fixed=False),
            ),
        )

        lines = _written(tmp_path, [success])

        warnings = [line for line in lines if "WARNING" in line]
        assert len(warnings) == 1
        assert f"source_id={'a.csv'!r}" in warnings[0]
        assert f"method={'gaussian'!r}" in warnings[0]
        assert f"parameter={'sigma'!r}" in warnings[0]

    def test_the_success_record_itself_is_kept(self, tmp_path: Path) -> None:
        """警告であって失敗ではない。成否の集計は成功のままである。"""
        success = _success(
            parameters=(ParameterEstimate(name="sigma", value=2.0, stderr=None, fixed=False),)
        )

        lines = _written(tmp_path, [success])

        assert len(lines) == 2
        assert f"status={SUCCESS_STATUS}" in lines[0]
        assert "WARNING" in lines[1]

    def test_no_warning_for_fixed_parameters(self, tmp_path: Path) -> None:
        """固定パラメータの標準誤差が空なのは仕様（要件 4.5）であり、異常ではない。"""
        success = _success(
            parameters=(ParameterEstimate(name="center", value=2.0, stderr=None, fixed=True),)
        )

        lines = _written(tmp_path, [success])

        assert [line for line in lines if "WARNING" in line] == []

    def test_no_warning_when_the_standard_error_was_computed(self, tmp_path: Path) -> None:
        """算出できた標準誤差には警告を出さない。"""
        success = _success(
            parameters=(ParameterEstimate(name="slope", value=2.0, stderr=0.1, fixed=False),)
        )

        lines = _written(tmp_path, [success])

        assert [line for line in lines if "WARNING" in line] == []

    def test_warnings_follow_the_parameter_order(self, tmp_path: Path) -> None:
        """警告はパラメータの並び順に出る。"""
        success = _success(
            parameters=(
                ParameterEstimate(name="b", value=1.0, stderr=None, fixed=False),
                ParameterEstimate(name="a", value=1.0, stderr=None, fixed=False),
            )
        )

        lines = _written(tmp_path, [success])

        warnings = [line for line in lines if "WARNING" in line]
        assert [line.split("parameter=")[1].split(" ")[0] for line in warnings] == [
            repr("b"),
            repr("a"),
        ]


class TestNoGlobalSideEffects:
    """要件 9.1。ライブラリとして取り込まれても利用者のログ構成を変えない。"""

    def test_importing_alone_attaches_no_handler(self) -> None:
        """別プロセスで確かめる。同一プロセスでは他の試験の構成が混ざる。"""
        script = (
            "import logging, sys\n"
            "import curvefit.logging_setup as m\n"
            "assert logging.getLogger().handlers == [], logging.getLogger().handlers\n"
            f"assert logging.getLogger({LOGGER_NAME!r}).handlers == []\n"
            "assert not logging.getLogger().disabled\n"
            "print('ok')\n"
        )
        completed = subprocess.run(
            [sys.executable, "-c", script], capture_output=True, text=True, check=False
        )

        assert completed.returncode == 0, completed.stderr
        assert completed.stdout.strip() == "ok"

    def test_configuring_does_not_reach_the_root_logger(self, tmp_path: Path) -> None:
        """構成しても根ロガーには波及しない。"""
        root = logging.getLogger()
        before = list(root.handlers)

        with configure_run_log(tmp_path) as handle:
            log_outcome(handle.logger, _success())
            assert list(root.handlers) == before

        assert list(root.handlers) == before

    def test_repeated_configuration_does_not_add_handlers(self, tmp_path: Path) -> None:
        """二重構成は 1 対象を 2 行記録し、成否集計と突き合わせられなくする。

        主張はハンドラ表そのものに対して行う。書き出された行数で見ると、2 つのハンドラが
        同じパスを `mode="w"` で開いて同じ内容を同じ位置に書くため、ハンドラが 2 つでも
        ファイルは 1 行のままになり、取り外しの欠落を見逃す。
        """
        first = configure_run_log(tmp_path)
        second = configure_run_log(tmp_path)
        logger = second.logger
        try:
            attached = [h for h in logger.handlers if isinstance(h, type(second.handler))]

            assert attached == [second.handler]
            assert first.handler not in logger.handlers

            log_outcome(second.logger, _success())
        finally:
            second.close()
            first.close()

        assert len(_lines(second.path)) == 1

    def test_closing_closes_the_file(self, tmp_path: Path) -> None:
        """開いたままの記述子は、数百件規模の連続実行で資源を食い潰す。"""
        handle = configure_run_log(tmp_path)
        stream = handle.handler.stream

        handle.close()

        assert stream.closed
        assert handle.handler not in handle.logger.handlers

    def test_closing_twice_is_not_an_error(self, tmp_path: Path) -> None:
        """二重解放は誤りにならない。"""
        handle = configure_run_log(tmp_path)

        handle.close()
        handle.close()

    def test_closing_restores_the_logger_settings(self, tmp_path: Path) -> None:
        """構成前の状態は目印を置いて作る。

        現在の状態をそのまま控えて突き合わせると、直前の試験が残した値を「元の状態」と
        して読み取ってしまい、復元を丸ごと削っても主張が通る。構成が必ず書き換える値
        （水準 `INFO`、伝播 `False`）とは異なる目印を先に置く。
        """
        logger = logging.getLogger(LOGGER_NAME)
        logger.setLevel(logging.CRITICAL)
        logger.propagate = True

        handle = configure_run_log(tmp_path)

        assert logger.level == logging.INFO

        handle.close()

        assert logger.level == logging.CRITICAL
        assert logger.propagate is True

    def test_no_propagation_while_configured(self, tmp_path: Path) -> None:
        """実行ログは出力ディレクトリに残す成果物であり、利用者の出力に混ぜない。"""
        logger = logging.getLogger(LOGGER_NAME)
        logger.propagate = True

        with configure_run_log(tmp_path) as handle:
            assert handle.logger.propagate is False

        assert logger.propagate is True

    def test_closing_restores_pre_configuration_settings_after_repeated_setup(
        self, tmp_path: Path
    ) -> None:
        """2 回目の構成が控えるのは、1 回目が書き換えた後の状態であってはならない。

        現在の状態を控えると、書き換え後の水準と伝播が「元の状態」として復元され、
        利用者のロガーが恒久的に汚染される。
        """
        logger = logging.getLogger(LOGGER_NAME)
        logger.setLevel(logging.CRITICAL)
        logger.propagate = True

        first = configure_run_log(tmp_path)
        second = configure_run_log(tmp_path)
        second.close()

        assert logger.level == logging.CRITICAL
        assert logger.propagate is True

        first.close()

        assert logger.level == logging.CRITICAL
        assert logger.propagate is True

    def test_closing_a_replaced_handle_does_not_break_the_current_setup(
        self, tmp_path: Path
    ) -> None:
        """古い取っ手のハンドラは構成時に外して閉じてある。後から閉じても設定は戻さない。"""
        logger = logging.getLogger(LOGGER_NAME)
        logger.setLevel(logging.CRITICAL)
        logger.propagate = True

        first = configure_run_log(tmp_path)
        second = configure_run_log(tmp_path)
        try:
            first.close()

            assert logger.level == logging.INFO
            assert logger.propagate is False
            assert second.handler in logger.handlers

            log_outcome(second.logger, _success())
        finally:
            second.close()

        assert len(_lines(second.path)) == 1


def _module_source() -> str:
    return (SRC / "logging_setup.py").read_text(encoding="utf-8")


def _imported_modules() -> set[str]:
    tree = ast.parse(_module_source())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class TestDependencyExposure:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_does_not_import_underlying_libraries(self) -> None:
        """基盤ライブラリを import しない。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval"}, (
                f"logging_setup.py が {imported} を import している"
            )

    def test_imports_only_types_and_errors_from_the_own_package(self) -> None:
        """自パッケージからは types と errors しか import しない。"""
        internal = {name for name in _imported_modules() if name.split(".")[0] == "curvefit"}

        assert internal <= {"curvefit.types", "curvefit.errors"}, (
            f"logging_setup.py が層をまたいで import している: {internal}"
        )

    def test_module_body_does_not_call_log_configuration(self) -> None:
        """import 時に構成が走ると、取り込んだ側のログ出力を乗っ取る。"""
        tree = ast.parse(_module_source())
        called = [
            ast.unparse(node.func)
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
        ]

        assert "logging.basicConfig" not in called

        for statement in tree.body:
            if isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Constant):
                continue  # モジュールの docstring
            assert not isinstance(statement, ast.Expr), (
                f"モジュール本体に副作用のある式がある: {ast.unparse(statement)[:60]}"
            )
