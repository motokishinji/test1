"""外れ値として除外した点の記録の E2E テスト（要件 2.5、9.1）。

要件 2.5 は「外れ値と判定した各点の x の値と実測値、および何回目の判定で除外したかを、
処理対象を識別できる形で出力ファイルに記録する」ことを求める。本テストは
**導入済みのコンソールスクリプトを別プロセスとして起動して** その記録が実際に手元の
ファイルとして届くことを確かめる。

既存の E2E との違い
-------------------

``tests/e2e/test_run_end_to_end.py`` と ``tests/e2e/test_reproducibility.py`` は
外れ値除去を有効にした実行を 1 つも持たない（前者にある唯一の ``[preprocess.outlier]``
は設定違反の検査用であり、実行前に停止する）。したがって前処理 CSV が出力ツリーに
現れる経路は、本ファイルが初めて利用者の側から検査する。

検査する 3 つの性質
-------------------

1. **当てはめが失敗しても書かれる**（要件 2.5）。図と曲線 CSV は当てはめの結果であり
   成功した処理単位にしか書かれないが、前処理 CSV は **前処理が何をしたかの説明** で
   あって当てはめの成否とは独立に成立する。外れ値を除いた結果として点数不足で落ちる
   場合は、まさにどの点が除かれたのかを知りたい場面である
2. **除外が 0 件の処理単位には作られない**。存在そのものが「この対象には除外があった」
   を意味する形にする。空のファイルが対象ごとに並ぶと、外れ値があった対象を探すのに
   ファイルを開く必要が生じる
3. **同一設定・同一入力の再実行でバイト単位に一致する**（要件 8.2）

``tests/e2e/test_run_end_to_end.py`` と同じく、**本テストは :mod:`curvefit` を一切
import しない**。ファイル名・列構成・終了コードはいずれも利用者と外部ツールが依存する
契約であり、実装の定数を取り込んで照合すると、定数の改名が利用者から見た破壊であっても
検出できない。
"""

from __future__ import annotations

import csv
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import pytest

# --- 利用者から見た契約（実装の定数は取り込まない）----------------------------------

PREPROCESS_DIRECTORY = "preprocess"
"""外れ値として除外した点を収める下位ディレクトリ（要件 2.5、設計の Batch / Job Contract）。"""

PREPROCESS_HEADER: tuple[str, ...] = ("x", "y_observed", "iteration")
"""前処理 CSV の列（設計の「前処理 CSV の列」表）。外部ツールが読む形であり順序も契約である。"""

SUMMARY_NAME = "summary.csv"
PLOTS_DIRECTORY = "plots"

EXIT_SUCCESS = 0
EXIT_PARTIAL_FAILURE = 1
"""要件 9.5: 1 件以上が失敗した実行の終了コード。"""

INSUFFICIENT_POINTS = "insufficient_points"
"""点数不足の失敗理由（要件 2.4）。サマリ表の ``failure_reason`` に現れる語。"""


def console_script() -> Path:
    """宣言されたコンソールスクリプトの実体（``tests/unit/test_package_scaffold.py``）。

    ``python -m curvefit.cli`` では ``[project.scripts]`` の宣言漏れを検出できない。
    """
    return Path(sys.executable).parent / "curvefit"


def run_command(config: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [str(console_script()), str(config)],
        capture_output=True,
        text=True,
        timeout=300,
    )


def toml_string(value: Path | str) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def write_rows(path: Path, rows: list[tuple[float, float]]) -> Path:
    """見出し行つきの測定データを書き出す。値は :func:`repr` で最終ビットまで書く。"""
    lines = ["x,y"] + [f"{x!r},{y!r}" for x, y in rows]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def preprocess_names(directory: Path) -> list[str]:
    """出力先に生成された前処理 CSV の名前を並べる。無ければ空。"""
    folder = directory / PREPROCESS_DIRECTORY
    if not folder.is_dir():
        return []
    return sorted(item.name for item in folder.iterdir() if item.is_file())


def preprocess_rows(path: Path) -> tuple[tuple[str, ...], list[list[str]]]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = tuple(next(reader))
        rows = list(reader)
    return header, rows


def summary_rows(directory: Path) -> list[dict[str, str]]:
    with (directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = tuple(next(reader))
        return [dict(zip(header, row, strict=True)) for row in reader]


@dataclass(frozen=True)
class Execution:
    process: subprocess.CompletedProcess[str]
    output_dir: Path

    @property
    def returncode(self) -> int:
        return self.process.returncode

    @property
    def stderr(self) -> str:
        return self.process.stderr


# --- シナリオ 1: 外れ値を除いた結果として当てはめが失敗する実行 ----------------------

SPIKE_X: tuple[float, ...] = (0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
"""8 点の等間隔な x。"""

SPIKE_AT: float = 2.0
DIP_AT: float = 5.0
"""意図的に直線から外した 2 点の x。前処理 CSV から読めることを確かめる対象である。"""

FAILING_CONFIG = """\
[input]
paths = [{source}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "poly"
builtin = "polynomial"
options = {{ degree = 4 }}

[preprocess.outlier]
sigma = 1.0

[output]
directory = {output_dir}
write_plot = false
"""
"""次数 4 の多項式は推定対象が 5 個であり、8 点から 4 点が除外されると点数不足になる。

``sigma`` を既定より小さくするのは、8 点の系列で外れ値判定を効かせるためである
（``OutlierSpec.sigma`` の盲点: ``n <= sigma**2`` の系列では単一の外れ値も除去されない）。
"""


def failing_rows() -> list[tuple[float, float]]:
    """直線 ``y = 2x + 1`` に 2 点の突出を混ぜた測定データ。"""
    rows: list[tuple[float, float]] = []
    for x in SPIKE_X:
        y = 2.0 * x + 1.0
        if x == SPIKE_AT:
            y += 50.0
        if x == DIP_AT:
            y -= 40.0
        rows.append((x, y))
    return rows


@pytest.fixture(scope="module")
def failing_run(tmp_path_factory: pytest.TempPathFactory) -> Execution:
    """外れ値の除去によって点数不足に落ちる 1 件を実行する。"""
    base = tmp_path_factory.mktemp("outlier_failing_run")
    data_dir = base / "data"
    data_dir.mkdir()
    source = write_rows(data_dir / "spike.csv", failing_rows())
    output_dir = base / "out"
    config = base / "run.toml"
    config.write_text(
        FAILING_CONFIG.format(
            source=toml_string(source), output_dir=toml_string(output_dir)
        ),
        encoding="utf-8",
    )
    return Execution(process=run_command(config), output_dir=output_dir)


class TestRecordOfFailedJob:
    """要件 2.5: 成否を条件にしない。失敗した対象でこそ必要になる。"""

    def test_exit_code_is_1(self, failing_run: Execution) -> None:
        """要件 9.5、2.4: 点数不足は失敗であり、成功時と区別できる終了コードで終わる。"""
        assert failing_run.returncode == EXIT_PARTIAL_FAILURE, failing_run.stderr

    def test_summary_records_insufficient_points_failure(self, failing_run: Execution) -> None:
        """前処理 CSV が「失敗した処理単位のもの」であることの裏付け。"""
        rows = summary_rows(failing_run.output_dir)
        assert len(rows) == 1
        assert rows[0]["status"] == "failure"
        assert rows[0]["failure_reason"] == INSUFFICIENT_POINTS
        assert int(rows[0]["n_dropped_outlier"]) > 0

    def test_fit_results_are_not_written(self, failing_run: Execution) -> None:
        """図と曲線 CSV は成功した処理単位にしか書かれない。前処理 CSV との対比である。"""
        assert not (failing_run.output_dir / PLOTS_DIRECTORY).exists()
        assert not (failing_run.output_dir / "curves").exists()

    def test_preprocess_csv_is_written(self, failing_run: Execution) -> None:
        """要件 2.5: 失敗した処理単位でも、除外の記録は出力ファイルとして残る。

        名前は ``{対象名}__{列}__{手法名}__{ジョブ番号}.csv`` である（要件 7.6）。
        """
        assert preprocess_names(failing_run.output_dir) == ["spike__y__poly__0000.csv"]

    def test_excluded_point_x_observed_and_iteration_are_readable(
        self, failing_run: Execution
    ) -> None:
        """要件 2.5: 元データを引き直さずに、どの点がなぜ消えたかを確かめられる。"""
        path = (
            failing_run.output_dir / PREPROCESS_DIRECTORY / "spike__y__poly__0000.csv"
        )
        header, rows = preprocess_rows(path)
        assert header == PREPROCESS_HEADER
        assert rows, path.read_text(encoding="utf-8")

        expected = dict(failing_rows())
        recorded = {float(row[0]): float(row[1]) for row in rows}
        # 意図的に外した 2 点が除外されていること。
        assert SPIKE_AT in recorded
        assert DIP_AT in recorded
        # 実測値は当てはめ値ではなく入力の y であること。
        for x_value, y_value in recorded.items():
            assert y_value == expected[x_value]
        # 反復回数は 1 起点の整数として書かれる（「3.0 回目」と読ませない）。
        for row in rows:
            assert row[2].isdigit()
            assert int(row[2]) >= 1

        # サマリ表の除去件数と行数が一致する。
        assert len(rows) == int(summary_rows(failing_run.output_dir)[0]["n_dropped_outlier"])


# --- シナリオ 2: 成功した実行と、除外が 0 件の対象 -----------------------------------

N_POINTS = 20
"""1 入力あたりの点数。既定の ``sigma`` で単一の外れ値が判定できる規模である。"""

NOISY_SPIKE_X = 3.5
NOISY_SPIKE_Y = 307.99
"""突出させた点の x と実測値。除外の記録として前処理 CSV に現れる値である。"""

SUCCEEDING_CONFIG = """\
[input]
paths = [{data_dir}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "line"
builtin = "linear"

[preprocess.outlier]
sigma = 3.0

[output]
directory = {output_dir}
write_plot = false
"""


def series_rows(*, spike: bool) -> list[tuple[float, float]]:
    """既知の直線に微小なばらつきを載せた測定データ。``spike`` で 1 点だけ突出させる。

    ばらつきを 0 にしない。残差が丸め誤差の水準になると、その中の相対的な突出が
    外れ値として除外されうる（``OutlierSpec.sigma`` の非ロバストな尺度）。
    """
    rows: list[tuple[float, float]] = []
    for index in range(N_POINTS):
        x = float(index) * 0.5
        y = 2.0 * x + 1.0 + (0.01 if index % 2 == 0 else -0.01)
        if spike and index == 7:
            y += 300.0
        rows.append((x, y))
    return rows


def build_succeeding(base: Path, output_name: str) -> tuple[Path, Path]:
    """入力 2 件（突出あり・なし）と設定ファイルを用意する。"""
    data_dir = base / "data"
    if not data_dir.is_dir():
        data_dir.mkdir()
        write_rows(data_dir / "noisy.csv", series_rows(spike=True))
        write_rows(data_dir / "steady.csv", series_rows(spike=False))
    output_dir = base / output_name
    config = base / f"{output_name}.toml"
    config.write_text(
        SUCCEEDING_CONFIG.format(
            data_dir=toml_string(data_dir), output_dir=toml_string(output_dir)
        ),
        encoding="utf-8",
    )
    return config, output_dir


@pytest.fixture(scope="module")
def succeeding_base(tmp_path_factory: pytest.TempPathFactory) -> Path:
    return tmp_path_factory.mktemp("outlier_succeeding_run")


@pytest.fixture(scope="module")
def succeeding_run(succeeding_base: Path) -> Execution:
    config, output_dir = build_succeeding(succeeding_base, "out")
    return Execution(process=run_command(config), output_dir=output_dir)


@pytest.fixture(scope="module")
def repeated_run(succeeding_base: Path, succeeding_run: Execution) -> Execution:
    """同一の入力・同一の設定を、出力先だけ変えてもう一度実行する（要件 8.2）。"""
    config, output_dir = build_succeeding(succeeding_base, "out2")
    return Execution(process=run_command(config), output_dir=output_dir)


class TestSucceedingJobAndJobWithNoExclusions:
    """要件 2.5: 除外があった対象にだけ、その記録が残ること。"""

    def test_exit_code_is_0(self, succeeding_run: Execution) -> None:
        """終了コードが 0 になる。"""
        assert succeeding_run.returncode == EXIT_SUCCESS, succeeding_run.stderr

    def test_preprocess_csv_only_for_jobs_with_exclusions(
        self, succeeding_run: Execution
    ) -> None:
        """除外 0 件の対象には空のファイルすら作らない。

        処理単位の番号は入力の絶対パスを並べ替えた順で振られるため、``noisy.csv`` が
        0000、``steady.csv`` が 0001 を占める。
        """
        assert preprocess_names(succeeding_run.output_dir) == ["noisy__y__line__0000.csv"]

    def test_excluded_points_are_readable(self, succeeding_run: Execution) -> None:
        """要件 2.5: 突出させた 1 点の x・実測値・反復回数がそのまま現れる。"""
        path = (
            succeeding_run.output_dir / PREPROCESS_DIRECTORY / "noisy__y__line__0000.csv"
        )
        header, rows = preprocess_rows(path)
        assert header == PREPROCESS_HEADER
        assert rows == [[repr(NOISY_SPIKE_X), repr(NOISY_SPIKE_Y), "1"]]

    def test_summary_row_of_succeeding_job_lists_removal_counts(
        self, succeeding_run: Execution
    ) -> None:
        """前処理 CSV の有無が、サマリ表の除去件数と食い違わないこと。"""
        counts = {
            Path(row["source_id"]).name: int(row["n_dropped_outlier"])
            for row in summary_rows(succeeding_run.output_dir)
        }
        assert counts == {"noisy.csv": 1, "steady.csv": 0}

    def test_rerun_matches_byte_for_byte(
        self, succeeding_run: Execution, repeated_run: Execution
    ) -> None:
        """要件 8.2: 同一設定・同一入力なら、前処理 CSV も逐字一致する。"""
        assert repeated_run.returncode == EXIT_SUCCESS, repeated_run.stderr
        # 比較する対象が実在することを先に確かめる。一覧同士の比較だけでは、双方が
        # 空でも通ってしまい、この検査が空振りする。
        expected = ["noisy__y__line__0000.csv"]
        assert preprocess_names(succeeding_run.output_dir) == expected
        assert preprocess_names(repeated_run.output_dir) == expected
        for name in expected:
            first = (succeeding_run.output_dir / PREPROCESS_DIRECTORY / name).read_bytes()
            second = (repeated_run.output_dir / PREPROCESS_DIRECTORY / name).read_bytes()
            assert first == second
            assert first
