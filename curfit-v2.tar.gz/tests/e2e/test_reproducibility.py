"""再現性の E2E テスト（要件 8.2、10.1、10.2）。

steering の ``product.md`` が本製品の中核価値に置くのは速度ではなく
「同じ設定ファイルと同じ入力なら誰がいつ実行しても同じ結果になる」ことである。
本テストはその主張を直接検査する。設計の Testing Strategy → E2E Tests の
「同一設定・同一入力で 2 回実行し、サマリ CSV がタイムスタンプ列を除いて完全一致
すること（8.2）」に対応する。

y 列を複数指定できるようになった改訂（要件 1.11）に伴い、本テストは 2 つの問いを
併せて担う。

- **複数列でも再現性が成立すること**（要件 8.2）: 列軸が加わったことで、ジョブの
  展開・出力名・サマリ表の行順に新しい並べ替えの余地が生まれた。列を 2 つ指定した
  設定でも、別プロセスとしての再実行がバイト単位で一致することを確かめる
- **単一列の既存の設定が従来と同じ結果を返すこと**（要件 8.2 の非退行）: 改訂前
  （コミット ``0c19bc4``）の実装に同一の入力と設定を与えて実測した値を
  :data:`LEGACY_SUMMARY_ROWS` と :data:`LEGACY_CURVE_NAMES` に literal として
  固定してある。変わってよいのは **出力名に列が入ること** と
  **サマリ表に列の 2 列が増えること** の 2 点だけであり（tasks.md 13.12 が周知した
  破壊的変更）、推定値・状態・件数はいずれも 1 文字も変わってはならない

検査する非決定性の源
--------------------

``research.md`` の「再現性を破る要因の洗い出し」と、実装中に実測された事実に対応する。

1. **ファイルシステムの走査順**: ``glob`` / ``Path.iterdir`` の順序は保証されない。
   ``pipeline.expand_sources`` が絶対パスを **集合に集めてから整列する** ことで
   吸収している。集合の反復順は文字列のハッシュに依存するため、整列を外すと
   同一プロセス内でも実行ごとにジョブ順が変わる
2. **SciPy の GCV による平滑化スプライン**: 完全な再現性を持たない。呼び出しごとに
   2 つの状態のいずれかに倒れ、**同一プロセス内でもプロセスを跨いでも**当てはめ値が
   変わる。当初これを有効数字 10 桁の丸めで吸収する方針だったが、丸めは必要条件で
   あって十分条件ではなく、値が境界付近にあれば表記が変わる（実測: 同一設定・同一
   入力の 12 回実行でサマリ表が 2 種類になった）。要件 5.5 で平滑化パラメータを必須に
   し、この経路そのものを断つことで解決している
3. **``PYTHONHASHSEED``**: 集合と辞書の反復順を決める。既定では起動ごとに無作為であり、
   固定した値でも別プロセスとして実行して確かめる

比較から除くもの（これ以外は一切除かない）
------------------------------------------

- ``execution.json`` の ``started_at``: 実行開始時刻であり、要件 8.3 が変わることを
  前提に記録している唯一の項目。除いてよいことを空振りさせないため、**除いた値が
  実行ごとに実際に異なること** も併せて表明する
- ``run.log`` の行頭の時刻: 1 行ごとに付く。書式が
  :data:`LOG_TIMESTAMP_PATTERN` に一致することを確かめてから、最初の空白までを
  取り除く。行の残り（水準・対象・列・手法・成否）は 1 文字も落とさない
- ``run.log`` の ``status=started`` 行（**入力の並び順の検査でのみ**）: この 1 行は
  解決済み設定をそのまま書き出しており、設定ファイルの綴り（``paths`` の並びと
  ``config_path``）を含む。並び順の検査は綴りを意図的に変えるため、この行だけは
  一致し得ない。処理単位の行と集計行は完全に一致することを表明する

サマリ CSV は **一切除かずにバイト単位で** 比較する。``source_id`` は絶対パスだが、
同一の入力ディレクトリを使う以上は実行を跨いで同一であり、除く理由がない
（要件 8.2 は同一環境を前提とする。design.md の execution / Risks）。

実行時間について
----------------

コンソールスクリプトを 7 回起動する（約 25 秒）。内訳は単一列の 5 回（それぞれ別の
非決定性を担当しており減らせない）と、複数列の 2 回である。複数列の側を 2 回に
留めるのは、列軸が加わって新しく生まれるのは **展開と並べ替え** の余地であって
ハッシュ種や走査順の非決定性そのものではなく、それらは単一列の 5 回が既に押さえて
いるためである。**同じ入力を単一列と複数列の双方で処理する** ことで、2 つの実行の
突き合わせ（:class:`TestAddingColumnsDoesNotDisturbTheExistingColumn`）も起動を
増やさずに行える。

グラフ出力は無効にしてある。画像の生成は本テストが見る契約（サマリ表・実行ログ・
実行条件の記録・出力名）に含まれず、1 回あたり約 1 秒を足すためである。
"""

from __future__ import annotations

import csv
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

import pytest

# --- 利用者から見た契約（実装の定数は取り込まない）----------------------------------

SUMMARY_NAME = "summary.csv"
"""サマリ表のファイル名（要件 7.3）。"""

RUN_LOG_NAME = "run.log"
"""実行ログのファイル名（要件 8.4）。"""

EXECUTION_RECORD_NAME = "execution.json"
"""実行条件の記録のファイル名（要件 8.3）。"""

CURVES_DIRECTORY = "curves"
"""曲線・残差 CSV を収める下位ディレクトリ（要件 7.5）。"""

CURVE_COLUMNS: tuple[str, ...] = ("x", "y_observed", "y_fit", "residual")
"""曲線・残差 CSV の列（要件 7.5）。"""

RESIDUAL_COLUMN = CURVE_COLUMNS.index("residual")
"""残差の列位置。RMSE を全精度から組み直すために使う。"""

SUMMARY_SIGNIFICANT_DIGITS = 10
"""サマリ表の数値の有効数字（設計の writers / Validation）。

利用者に対する公約であり、外部ツールが読む桁数でもある。実装の定数を取り込まずに
ここへ書き写すのは、桁数の変更が利用者から見た破壊であることを検出するためである。
"""

STARTED_AT_KEY = '"started_at"'
"""``execution.json`` のうち実行ごとに変わってよい唯一の項目（要件 8.3）。"""

LOG_TIMESTAMP_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ")
"""実行ログの行頭に付く UTC の時刻。除く範囲をこの形に限る。"""

STARTED_AT_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$")
"""``started_at`` の書式（UTC ISO 8601）。除いた項目が時刻であることを確かめる。"""

STARTED_LOG_MARKER = "status=started"
"""解決済み設定を書き出す実行ログの 1 行目を指す語。"""

EXIT_SUCCESS = 0
"""全処理単位が成功した（要件 9.5）。"""

# --- 入力の用意 ----------------------------------------------------------------------

SERIES_LENGTHS: Mapping[str, int] = {
    "alpha": 44,
    "beta": 36,
    "delta": 40,
    "gamma": 52,
}
"""入力ごとの点数。

**点数を入力ごとに変える。** 当初は「点数によって GCV スプラインの倒れ方が決まる」
という想定で散らしていたが、その想定は誤りだった（揺れは呼び出しごとの分岐であり、
点数では決まらない）。平滑化パラメータが必須になった今、散らす理由は別にある。
点数の違う系列が混ざっていれば、行数や整列に依存する不具合が出力に現れやすい。

名前の辞書順（alpha < beta < delta < gamma）と、後述の作成順は一致させない。
"""

CREATION_ORDER: tuple[str, ...] = ("alpha", "beta", "delta", "gamma")
"""基準となる実行で入力ファイルをディスクに作る順序。"""

NOISE_AMPLITUDE = 0.15
"""測定のばらつきの振幅。

0 にしない。残差が厳密に 0 の系列は当てはめが自明になり、実際の測定データが
通る経路を検査したことにならない。
"""

X_STEP = 0.25
"""独立変数の刻み。"""

PRIMARY_COLUMN = "y"
"""単一列の設定が指す測定チャネル。改訂前から存在する側であり、非退行の対象である。"""

SECOND_COLUMN = "y2"
"""複数列の設定でのみ処理される 2 本目の測定チャネル。

**形の違う曲線にする。** 1 本目の写しにすると、列の取り違えも列軸の脱落も同じ数値を
生んでしまい、複数列の検査が単一列の検査の焼き直しになる。
"""

SERIES_HEADER = f"x,{PRIMARY_COLUMN},{SECOND_COLUMN}"
"""入力ファイルの見出し行。**単一列の設定でも 2 本目を書き出す。**

入力を 1 種類に保つことで、単一列の実行と複数列の実行が同じバイト列を読み、
差が設定だけに由来することが言える。読まれない列が結果を動かさないこと自体も、
この構成でしか確かめられない。
"""


def write_series(path: Path, *, n_points: int, seed: int) -> Path:
    """曲がりのある測定データを 2 チャネル分書き出す。

    値は :func:`repr` で書き、最終ビットまで復元できる表記にする。NumPy のスカラは
    :func:`repr` が ``np.float64(...)`` を返すため、素の :class:`float` だけを扱う。

    ばらつきは :class:`random.Random` に種を与えて作る。**テストの入力自体が
    再現可能でなければ、再現性の検査に意味がない。** :data:`LEGACY_SUMMARY_ROWS` は
    この関数が書く値を改訂前の実装に与えて実測したものであり、生成の手順を変えると
    非退行の照合ごと意味を失う。
    """
    generator = random.Random(seed)
    lines = [SERIES_HEADER]
    for index in range(n_points):
        x = float(index) * X_STEP
        y = float(
            2.0 * math.sin(x)
            + 0.5 * x
            + generator.uniform(-NOISE_AMPLITUDE, NOISE_AMPLITUDE)
        )
        second = float(
            1.5 * math.cos(x)
            - 0.3 * x
            + generator.uniform(-NOISE_AMPLITUDE, NOISE_AMPLITUDE)
        )
        lines.append(f"{x!r},{y!r},{second!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def create_sources(data_dir: Path, order: Sequence[str]) -> None:
    """入力ファイル一式を、与えられた順序でディスク上に作り直す。

    いったん全件を消してから作る。作成順そのものがファイルシステムの走査順に影響し
    うるため、順序を変えた状況を実際に作らなければ要件 8.2 の「並び順の非決定性」を
    検査したことにならない。内容は名前ごとに一意に決まるため、順序を変えても
    出力は変わってはならない。
    """
    for name in SERIES_LENGTHS:
        path = data_dir / f"{name}.csv"
        if path.exists():
            path.unlink()
    for name in order:
        write_series(
            data_dir / f"{name}.csv",
            n_points=SERIES_LENGTHS[name],
            seed=sorted(SERIES_LENGTHS).index(name),
        )


CONFIG = """\
[input]
paths = {paths}
header = true

[input.columns]
x = "x"
y = {y_columns}

[[methods]]
name = "line"
builtin = "linear"

[[methods]]
name = "spl"
smoother = "spline"
options = {{ lam = 0.01 }}

[output]
directory = {output_dir}
write_plot = false
write_curve = true
"""
"""検査に使う実行条件。

手法を 2 つ置く。``spl``（平滑化スプライン）は、かつて自動選択によって揺れていた
経路である。要件 5.5 で平滑化パラメータを必須にしたため揺れは断たれており、
``options`` に ``lam`` を明示する。``line``（最小二乗）は当初から揺れない側の対照。

``write_curve`` を有効にするのは、丸める前の全精度の値を観測する手段がこれだけ
だからである（設計の writers / Validation: 丸めるのはサマリ表に限る）。

``y_columns`` には単一列（``"y"``）と複数列（``["y", "y2"]``）のいずれかが入る。
**同じひな型を使う。** 手法・平滑化パラメータ・出力設定まで揃えることで、2 つの
実行の差が y 列の指定だけであると言える。
"""

SINGLE_COLUMN = json.dumps(PRIMARY_COLUMN)
"""単一列の指定（改訂前から書ける記法。要件 1.11 の 1 件だけの形）。"""

MULTI_COLUMN = json.dumps([PRIMARY_COLUMN, SECOND_COLUMN])
"""複数列の指定（要件 1.11）。並びは記述順であり、出力の順序を決める。"""


def toml_string(value: Path | str) -> str:
    """TOML の文字列として安全に書ける形にする。"""
    return json.dumps(str(value), ensure_ascii=False)


def console_script() -> Path:
    """宣言されたコンソールスクリプトの実体。

    ``python -m curvefit.cli`` では ``[project.scripts]`` の宣言漏れを検出できない。
    また要件 8.2 が問うのは **別プロセスとして起動し直したときの一致** であり、
    同一プロセス内の呼び出しでは、記憶された状態が揺れを隠してしまう。
    """
    return Path(sys.executable).parent / "curvefit"


# --- 1 回の実行と、その成果物の写し ---------------------------------------------------


@dataclass(frozen=True)
class Snapshot:
    """1 回の実行が出力先に残したものの写し。

    出力先は全実行で共有し、実行のたびに写しを取る。出力先を実行ごとに分けると
    ``execution.json`` の ``resolved_config.output.directory`` と ``run.log`` の
    1 行目が必ず食い違い、比較から除く範囲が広がってしまう。
    """

    label: str
    directory: Path

    @property
    def summary_bytes(self) -> bytes:
        return (self.directory / SUMMARY_NAME).read_bytes()

    @property
    def file_names(self) -> list[str]:
        return sorted(
            path.relative_to(self.directory).as_posix()
            for path in self.directory.rglob("*")
            if path.is_file()
        )

    @property
    def summary_header(self) -> tuple[str, ...]:
        """サマリ表の見出し行。列の増減そのものを検査するために生のまま扱う。"""
        with (self.directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
            return tuple(next(csv.reader(handle)))

    @property
    def summary_cells(self) -> list[tuple[str, ...]]:
        """サマリ表の本体を、見出しに結び付けずセルの並びのまま読む。

        改訂前の実装との照合は「どの位置に何が入っているか」を問うため、辞書へ
        直すと列の並びの変化が比較から落ちる。
        """
        with (self.directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            next(reader)
            return [tuple(row) for row in reader]

    @property
    def summary_rows(self) -> list[dict[str, str]]:
        with (self.directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            header = tuple(next(reader))
            return [dict(zip(header, row, strict=True)) for row in reader]

    @property
    def curve_names(self) -> list[str]:
        curves = self.directory / CURVES_DIRECTORY
        return sorted(path.name for path in curves.iterdir() if path.is_file())

    def curve_bytes(self, name: str) -> bytes:
        return (self.directory / CURVES_DIRECTORY / name).read_bytes()

    def curve_rows(self, name: str) -> list[tuple[float, ...]]:
        """曲線・残差 CSV を全精度のまま読む。"""
        path = self.directory / CURVES_DIRECTORY / name
        with path.open(encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            header = tuple(next(reader))
            assert header == CURVE_COLUMNS, (name, header)
            return [tuple(float(cell) for cell in row) for row in reader]

    @property
    def log_lines(self) -> list[str]:
        """実行ログを、**行頭の時刻だけを除いて** 読む。

        除く範囲を狭く保つため、まず行頭が時刻の形であることを確かめ、最初の空白
        までを落とす。時刻の書式が変わればここで落ちる。
        """
        text = (self.directory / RUN_LOG_NAME).read_text(encoding="utf-8")
        stripped: list[str] = []
        for line in text.splitlines():
            if not line:
                continue
            assert LOG_TIMESTAMP_PATTERN.match(line), (self.label, line)
            stripped.append(line.split(" ", 1)[1])
        return stripped

    @property
    def job_log_lines(self) -> list[str]:
        """解決済み設定を書き出す 1 行目を除いた実行ログ。

        除くのは入力の並び順を変えた実行と比べるときだけである。その行は
        ``config_path`` と ``paths`` を字義どおり書き出しており、綴りを変えた以上
        一致し得ない。処理単位の行と集計行は綴りに依存しない。
        """
        return [line for line in self.log_lines if STARTED_LOG_MARKER not in line]

    @property
    def execution_record_parts(self) -> tuple[str, str]:
        """``execution.json`` を「``started_at`` の行」と「それ以外」に分ける。

        JSON として読み直さず本文のまま扱う。読み直すとキーの並びと数値の表記が
        比較から落ち、要件 8.2 が求めるバイト単位の一致より弱い検査になる。
        """
        text = (self.directory / EXECUTION_RECORD_NAME).read_text(encoding="utf-8")
        lines = text.splitlines(keepends=True)
        started = [line for line in lines if STARTED_AT_KEY in line]
        assert len(started) == 1, (self.label, started)
        rest = "".join(line for line in lines if STARTED_AT_KEY not in line)
        return rest, started[0]

    @property
    def started_at(self) -> str:
        _, line = self.execution_record_parts
        return json.loads(f"{{{line.strip().rstrip(',')}}}")["started_at"]


def run_command(config: Path, *, hash_seed: str | None) -> subprocess.CompletedProcess[str]:
    """コマンドを別プロセスとして起動する（要件 9.2）。

    :param hash_seed: ``PYTHONHASHSEED`` に与える値。``None`` は環境から取り除き、
        Python の既定である起動ごとの無作為なハッシュ種で動かすことを意味する。
    """
    environment = dict(os.environ)
    if hash_seed is None:
        environment.pop("PYTHONHASHSEED", None)
    else:
        environment["PYTHONHASHSEED"] = hash_seed
    return subprocess.run(
        [str(console_script()), str(config)],
        capture_output=True,
        text=True,
        timeout=300,
        env=environment,
    )


@dataclass(frozen=True)
class Repetitions:
    """同一の入力に対する 5 回の実行の写し。"""

    snapshots: Mapping[str, Snapshot]
    sources: tuple[Path, ...]
    hash_seeds: Mapping[str, str | None]
    """実行ごとに ``PYTHONHASHSEED`` へ実際に与えた値。``None`` は取り除いたことを表す。

    定数ではなく **起動時に使った値** を控える。検査が定数どうしを比べるだけになると、
    起動条件を変え忘れても表明が成立してしまう。
    """

    def __getitem__(self, label: str) -> Snapshot:
        return self.snapshots[label]

    @property
    def same_config(self) -> tuple[Snapshot, ...]:
        """同一の設定ファイルで起動した実行（並び順を変えた実行を除く）。"""
        return tuple(
            snapshot
            for label, snapshot in self.snapshots.items()
            if label != REORDERED
        )

    @property
    def all_snapshots(self) -> tuple[Snapshot, ...]:
        return tuple(self.snapshots.values())


BASELINE = "baseline"
"""基準となる実行。"""

REPEAT = "repeat"
"""基準と何も変えずに繰り返した実行。"""

REORDERED = "reordered"
"""入力の並び順だけを変えた実行（ディスク上の作成順と設定の記述順の双方）。"""

HASH_SEED_ZERO = "hash_seed_zero"
"""``PYTHONHASHSEED=0``（ハッシュのかく乱を止めた状態）で起動した実行。"""

HASH_SEED_MAX = "hash_seed_max"
"""``PYTHONHASHSEED`` に最大値を与えて起動した実行。"""

MAX_HASH_SEED = "4294967295"
"""``PYTHONHASHSEED`` が受け付ける最大値。"""


@pytest.fixture(scope="module")
def repetitions(tmp_path_factory: pytest.TempPathFactory) -> Repetitions:
    """同一の入力に対して 5 回起動し、それぞれの出力先の写しを返す。

    1. 基準
    2. 何も変えない繰り返し（要件 8.2 の本体）
    3. 入力の並び順を変えた実行（ディスク上の作成順を逆にし、設定にも逆順で書く）
    4. ``PYTHONHASHSEED=0``
    5. ``PYTHONHASHSEED`` 最大値

    3 が別の設定ファイルを使うのは、**走査順の非決定性を確実に作るため** である。
    ディスク上の作成順は、ファイルシステムが名前順に返す実装であれば出力順に影響を
    与えない。設定に逆順で書けば、整列が外れた瞬間に必ず順序が変わる。
    """
    base = tmp_path_factory.mktemp("reproducibility")
    data_dir = base / "data"
    data_dir.mkdir()
    output_dir = base / "out"

    create_sources(data_dir, CREATION_ORDER)
    sources = tuple(sorted(data_dir / f"{name}.csv" for name in SERIES_LENGTHS))

    directory_config = base / "run.toml"
    directory_config.write_text(
        CONFIG.format(
            paths=f"[{toml_string(data_dir)}]",
            y_columns=SINGLE_COLUMN,
            output_dir=toml_string(output_dir),
        ),
        encoding="utf-8",
    )
    reversed_config = base / "run_reversed.toml"
    reversed_config.write_text(
        CONFIG.format(
            paths="["
            + ", ".join(toml_string(source) for source in reversed(sources))
            + "]",
            y_columns=SINGLE_COLUMN,
            output_dir=toml_string(output_dir),
        ),
        encoding="utf-8",
    )

    plan: tuple[tuple[str, Path, str | None, tuple[str, ...]], ...] = (
        (BASELINE, directory_config, None, CREATION_ORDER),
        (REPEAT, directory_config, None, CREATION_ORDER),
        (REORDERED, reversed_config, None, tuple(reversed(CREATION_ORDER))),
        (HASH_SEED_ZERO, directory_config, "0", CREATION_ORDER),
        (HASH_SEED_MAX, directory_config, MAX_HASH_SEED, CREATION_ORDER),
    )

    snapshots: dict[str, Snapshot] = {}
    hash_seeds: dict[str, str | None] = {}
    for label, config, hash_seed, order in plan:
        create_sources(data_dir, order)
        process = run_command(config, hash_seed=hash_seed)
        assert process.returncode == EXIT_SUCCESS, (label, process.stderr)
        snapshot_dir = base / f"snapshot_{label}"
        shutil.copytree(output_dir, snapshot_dir)
        snapshots[label] = Snapshot(label=label, directory=snapshot_dir)
        hash_seeds[label] = hash_seed

    return Repetitions(snapshots=snapshots, sources=sources, hash_seeds=hash_seeds)


MULTI_BASELINE = "multi_baseline"
"""複数列の設定による基準の実行。"""

MULTI_REPEAT = "multi_repeat"
"""複数列の設定で、何も変えずに繰り返した実行。"""


@dataclass(frozen=True)
class MultiColumnPair:
    """複数列の設定による 2 回の実行の写し。"""

    baseline: Snapshot
    repeat: Snapshot
    sources: tuple[Path, ...]

    @property
    def both(self) -> tuple[Snapshot, Snapshot]:
        return (self.baseline, self.repeat)


@pytest.fixture(scope="module")
def multi_column_pair(repetitions: Repetitions) -> MultiColumnPair:
    """y 列を 2 つ指定した設定で 2 回起動し、それぞれの出力先の写しを返す。

    **入力は単一列の実行とまったく同じファイルを使う。** :func:`repetitions` が
    最後に :data:`CREATION_ORDER` で作り直したものをそのまま読むため、``source_id``
    まで一致し、2 つの実行の突き合わせから「別のデータを見ていた」可能性が消える。

    出力先は単一列の実行とは別に取る。生成されるファイルの集合が違う以上、同じ
    出力先を使うと片方の残骸が :attr:`Snapshot.file_names` に混ざる。
    """
    data_dir = repetitions.sources[0].parent
    base = data_dir.parent
    output_dir = base / "out_multi"

    config = base / "run_multi.toml"
    config.write_text(
        CONFIG.format(
            paths=f"[{toml_string(data_dir)}]",
            y_columns=MULTI_COLUMN,
            output_dir=toml_string(output_dir),
        ),
        encoding="utf-8",
    )

    snapshots: dict[str, Snapshot] = {}
    for label in (MULTI_BASELINE, MULTI_REPEAT):
        process = run_command(config, hash_seed=None)
        assert process.returncode == EXIT_SUCCESS, (label, process.stderr)
        snapshot_dir = base / f"snapshot_{label}"
        shutil.copytree(output_dir, snapshot_dir)
        snapshots[label] = Snapshot(label=label, directory=snapshot_dir)

    return MultiColumnPair(
        baseline=snapshots[MULTI_BASELINE],
        repeat=snapshots[MULTI_REPEAT],
        sources=repetitions.sources,
    )


# --- 比較の道具 ----------------------------------------------------------------------


def spline_curve_names(snapshot: Snapshot) -> list[str]:
    """平滑化スプラインの曲線 CSV の名前（出力名の規則 ``{対象}__{列}__{手法}__{番号}``）。"""
    return [name for name in snapshot.curve_names if "__spl__" in name]


def least_squares_curve_names(snapshot: Snapshot) -> list[str]:
    """最小二乗の曲線 CSV の名前。"""
    return [name for name in snapshot.curve_names if "__line__" in name]


def rmse_from_curve(rows: Sequence[tuple[float, ...]]) -> float:
    """全精度の残差から RMSE を組み直す（要件 7.2 の定義）。

    サマリ表の ``rmse`` 列が、丸める前の値をどこまで落としているかを見るために使う。
    実装を参照せず定義から組み直すことで、比較が「同じ実装を 2 回呼んだだけ」に
    ならないようにする。
    """
    residuals = [row[RESIDUAL_COLUMN] for row in rows]
    return math.sqrt(sum(value * value for value in residuals) / len(residuals))


# --- 同一設定・同一入力での再実行 -----------------------------------------------------


class TestRerunWithSameConfigAndInput:
    """要件 8.2: 同じ設定ファイルと同じ入力なら、いつ実行しても同じ結果になること。"""

    def test_summary_matches_byte_for_byte(self, repetitions: Repetitions) -> None:
        """要件 8.2、7.3: サマリ表は 1 バイトも違わない。除外は 1 つも設けない。

        サマリ表に実行日時に依存する内容は無く、``source_id`` は同一の入力を指す
        絶対パスであるため、除くべきものが存在しない。
        """
        baseline = repetitions[BASELINE]
        repeat = repetitions[REPEAT]
        assert baseline.summary_bytes == repeat.summary_bytes

    def test_compared_summary_is_neither_empty_nor_trivial(self, repetitions: Repetitions) -> None:
        """一致の表明が空振りしないことを、比較した中身の側から確かめる。

        行が 0 件でも「一致」は成立する。何がどれだけ一致したのかを固定する。
        """
        rows = repetitions[BASELINE].summary_rows
        # 4 入力 × (直線の 2 パラメータ + スプラインの 1 行) = 12 行。
        assert len(rows) == len(SERIES_LENGTHS) * 3
        assert {row["status"] for row in rows} == {"success"}
        assert {row["method_name"] for row in rows} == {"line", "spl"}
        # 揺れる側の手法が実際に表へ載っていること。ここが空だと丸めの検査ごと空振りする。
        spline_rows = [row for row in rows if row["method_name"] == "spl"]
        assert len(spline_rows) == len(SERIES_LENGTHS)
        assert all(row["rmse"] for row in spline_rows)

    def test_output_file_listing_and_names_match(self, repetitions: Repetitions) -> None:
        """要件 7.6: 出力名は対象と列と手法と処理単位番号から決まり、実行ごとに変わらない。"""
        baseline = repetitions[BASELINE]
        repeat = repetitions[REPEAT]
        assert baseline.file_names == repeat.file_names
        expected = [
            f"{CURVES_DIRECTORY}/{source.stem}__y__{method}__{index:04d}.csv"
            for index, (source, method) in enumerate(
                (source, method)
                for source in repetitions.sources
                for method in ("line", "spl")
            )
        ]
        assert baseline.file_names == sorted(
            [*expected, SUMMARY_NAME, RUN_LOG_NAME, EXECUTION_RECORD_NAME]
        )

    def test_execution_record_matches_except_started_at(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.3、8.2: 変わってよいのは ``started_at`` の 1 行だけである。"""
        baseline_rest, _ = repetitions[BASELINE].execution_record_parts
        repeat_rest, _ = repetitions[REPEAT].execution_record_parts
        assert baseline_rest == repeat_rest

    def test_excluded_started_at_actually_differs_per_run(
        self, repetitions: Repetitions
    ) -> None:
        """除外が過剰でないことの裏取り。

        変わらない項目を除外に含めていれば、その項目の不一致を見逃す。``started_at``
        が本当に実行ごとに変わることを示して初めて、除外が最小であると言える。
        """
        baseline = repetitions[BASELINE].started_at
        repeat = repetitions[REPEAT].started_at
        assert STARTED_AT_PATTERN.match(baseline), baseline
        assert STARTED_AT_PATTERN.match(repeat), repeat
        assert baseline != repeat

    def test_run_log_matches_except_leading_timestamps(self, repetitions: Repetitions) -> None:
        """要件 8.4、8.2: 記録の順序と内容が実行ごとに変わらない。

        除くのは各行の先頭に付く時刻だけである（:attr:`Snapshot.log_lines`）。
        """
        baseline = repetitions[BASELINE].log_lines
        repeat = repetitions[REPEAT].log_lines
        assert baseline == repeat
        # 除外後に残っているのが空でないこと。1 行目の設定と、処理単位ごとの行と集計行。
        assert len(baseline) == len(SERIES_LENGTHS) * 2 + 2
        assert any("n_success=8" in line and "n_failure=0" in line for line in baseline)


# --- 入力の並び順に対する不変性 -------------------------------------------------------


class TestIndependenceFromInputOrdering:
    """要件 8.2、6.1: 走査順や記述順が変わっても、結果は 1 バイトも変わらないこと。

    ``pipeline.expand_sources`` は入力の指定を **集合** に集めてから整列する。
    整列を外すと、集合の反復順（文字列のハッシュ依存）がそのままジョブ順になり、
    サマリ表の行順・処理単位番号・ログの記録順のすべてが実行ごとに変わる。
    """

    def test_summary_matches_byte_for_byte_across_orderings(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.2: 行順を含めて完全に一致する。"""
        baseline = repetitions[BASELINE]
        reordered = repetitions[REORDERED]
        assert baseline.summary_bytes == reordered.summary_bytes

    def test_output_file_names_match_across_orderings(
        self, repetitions: Repetitions
    ) -> None:
        """要件 7.6: 出力名に含まれる処理単位番号は、整列後の順序で振られる。

        番号が並び順に依存すると、同じ対象の出力が実行ごとに別のファイルへ移る。
        """
        baseline = repetitions[BASELINE]
        reordered = repetitions[REORDERED]
        assert baseline.file_names == reordered.file_names
        # 番号は入力の絶対パスを整列した順に振られる。設定の記述順（逆順）ではない。
        assert baseline.curve_names[0].startswith(f"{repetitions.sources[0].stem}__")

    def test_job_record_order_matches_across_orderings(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.4、8.2: ログの記録順も整列後の順序に従う。

        1 行目（``status=started``）だけは、設定ファイルの綴りをそのまま書き出す
        ため一致し得ない。除くのはその 1 行に限り、処理単位の行と集計行は完全に
        一致することを表明する。
        """
        baseline = repetitions[BASELINE]
        reordered = repetitions[REORDERED]
        assert baseline.job_log_lines == reordered.job_log_lines
        assert len(baseline.job_log_lines) == len(baseline.log_lines) - 1

    def test_reordered_run_actually_starts_with_different_spellings(
        self, repetitions: Repetitions
    ) -> None:
        """並び順を変えた状況が本当に作られていることの裏取り。

        設定の綴りが同じなら、上の 3 つは「同じものを 2 回実行しただけ」になる。
        """
        baseline_started = next(
            line for line in repetitions[BASELINE].log_lines if STARTED_LOG_MARKER in line
        )
        reordered_started = next(
            line for line in repetitions[REORDERED].log_lines if STARTED_LOG_MARKER in line
        )
        assert baseline_started != reordered_started
        # 逆順に書いた最初の入力が、整列後の最後の対象であること。
        assert str(repetitions.sources[-1]) in reordered_started


# --- ハッシュ種に対する不変性 ---------------------------------------------------------


class TestIndependenceFromHashSeed:
    """要件 8.2: ``PYTHONHASHSEED`` は集合と辞書の反復順を決める。

    実行順の決定を集合の反復順に委ねている箇所が残っていれば、種を変えた別プロセスの
    実行で結果が変わる。既定の無作為な種による 3 回の実行に、固定した 2 つの種を
    加えて確かめる。
    """

    def test_summary_matches_under_any_hash_seed(self, repetitions: Repetitions) -> None:
        """要件 8.2: 4 つの実行のサマリ表がすべて同一のバイト列になる。"""
        distinct = {snapshot.summary_bytes for snapshot in repetitions.same_config}
        assert len(distinct) == 1, [
            snapshot.label for snapshot in repetitions.same_config
        ]

    def test_execution_record_matches_except_started_at_under_any_hash_seed(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.3、8.2: 記録の内容もキーの並びも種に依存しない。"""
        distinct = {
            snapshot.execution_record_parts[0] for snapshot in repetitions.same_config
        }
        assert len(distinct) == 1

    def test_run_log_matches_except_leading_timestamps_under_any_hash_seed(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.4、8.2: 記録の順序も種に依存しない。"""
        distinct = {tuple(snapshot.log_lines) for snapshot in repetitions.same_config}
        assert len(distinct) == 1

    def test_compared_runs_are_really_separate_processes_with_different_seeds(
        self, repetitions: Repetitions
    ) -> None:
        """一致の表明が空振りしないことの裏取り。

        同じ条件で 4 回起動していたなら、上の 3 つは何も検査していない。起動時に
        与えた種が実際に食い違っていること、5 回が別プロセスであること（開始時刻が
        すべて異なる）を示す。
        """
        seeds = repetitions.hash_seeds
        assert seeds[HASH_SEED_ZERO] != seeds[HASH_SEED_MAX]
        assert {seeds[HASH_SEED_ZERO], seeds[HASH_SEED_MAX]} == {"0", MAX_HASH_SEED}
        # 既定の実行はハッシュ種を環境から取り除いてある（起動ごとに無作為）。
        assert seeds[BASELINE] is None and seeds[REPEAT] is None
        assert len({snapshot.started_at for snapshot in repetitions.all_snapshots}) == 5


# --- 有効数字 10 桁の丸めが担っている役割 ---------------------------------------------


class TestRoleOfTenSignificantDigitRounding:
    """設計の writers / Validation: サマリ表を有効数字 10 桁で書く決定の検証。

    丸めは **報告物の桁を揃えるため** であり、再現性の担保ではない。丸めは必要条件で
    あって十分条件ではなく、値が丸めの境界付近にあれば最終桁の刻みより小さい揺れでも
    表記は変わる。要件 8.2 の再現性は、揺れを生む経路（平滑化パラメータの自動選択）を
    要件 5.5 で断つことによって成立させている。

    かつてここには「全精度の出力が実行ごとに揺れる」という表明があった。平滑化
    パラメータが必須になり自動選択が到達不能になったため、その揺れはもはや存在しない。
    本クラスが残して検証するのは、サマリ表の数値が全精度の出力と同じ量の丸めであること
    と、その結果として実行を跨いで同一の文字列になることである。
    """

    def test_full_precision_least_squares_output_is_stable(self, repetitions: Repetitions) -> None:
        """最小二乗の全精度出力がプロセスを跨いで一致すること。"""
        snapshots = repetitions.all_snapshots
        for name in least_squares_curve_names(snapshots[0]):
            distinct = {snapshot.curve_bytes(name) for snapshot in snapshots}
            assert len(distinct) == 1, name

    def test_summary_rmse_is_full_precision_curve_rounded_to_ten_digits(
        self, repetitions: Repetitions
    ) -> None:
        """サマリ表の数値が、全精度の出力と同じ量の丸めであることを結び付ける。

        これが無いと「揺れる出力」と「一致するサマリ」が別々の量を指している可能性が
        残り、丸めが効いているという結論にならない。
        """
        for snapshot in repetitions.all_snapshots:
            rows = {
                (Path(row["source_id"]).stem, row["method_name"]): row["rmse"]
                for row in snapshot.summary_rows
            }
            for name in snapshot.curve_names:
                source, _column, method, _index = name.removesuffix(".csv").split("__")
                rebuilt = rmse_from_curve(snapshot.curve_rows(name))
                assert f"{rebuilt:.{SUMMARY_SIGNIFICANT_DIGITS}g}" == rows[(source, method)], (
                    snapshot.label,
                    name,
                )

    def test_full_precision_smoothing_spline_output_is_stable(
        self, repetitions: Repetitions
    ) -> None:
        """スプラインの全精度出力が実行を跨いで完全に一致すること。

        かつてここには「揺れが最終桁 1 つ分に収まる」という表明があった。それは誤った
        検査だった。丸めは必要条件であって十分条件ではなく、値が丸めの境界付近にあれば
        最終桁の刻みより小さい揺れでも表記は変わる（実測: 462 件中 5 件が境界をまたぎ、
        同一設定・同一入力の 12 回実行でサマリ表が 2 種類になった）。

        平滑化パラメータを必須にして自動選択を断ったため（要件 5.5）、揺れそのものが
        存在しない。丸めに頼らず全精度で一致することを直接確かめる。
        """
        snapshots = repetitions.all_snapshots
        for name in spline_curve_names(snapshots[0]):
            distinct = {snapshot.curve_bytes(name) for snapshot in snapshots}
            assert len(distinct) == 1, (name, len(distinct))

    def test_rounding_makes_summary_smoothing_spline_rows_match(
        self, repetitions: Repetitions
    ) -> None:
        """結論。揺れる量を含む行が、実行を跨いで同一の文字列になる。"""
        spline_cells = [
            tuple(
                (row["source_id"], row["r_squared"], row["rmse"])
                for row in snapshot.summary_rows
                if row["method_name"] == "spl"
            )
            for snapshot in repetitions.all_snapshots
        ]
        assert len(set(spline_cells)) == 1
        assert len(spline_cells[0]) == len(SERIES_LENGTHS)


# --- 複数列での再現性 -----------------------------------------------------------------


class TestRerunWithMultipleColumnsGivesTheSameBytes:
    """要件 8.2、1.11: y 列を 2 つ指定した実行でも、再実行が 1 バイトも変わらないこと。

    列軸が加わったことで新しく生まれた並べ替えの余地は 3 つある。ジョブの展開順
    （設計の pipeline: 入力 → 列 → 手法）、出力名に振られる処理単位番号、サマリ表の
    行順である。いずれも列の集合を反復する順序に依存しうるため、単一列の実行が緑でも
    ここが赤くなりうる。
    """

    def test_summary_matches_byte_for_byte(self, multi_column_pair: MultiColumnPair) -> None:
        """要件 8.2、7.3: 列が増えてもサマリ表に除外すべきものは無い。"""
        assert multi_column_pair.baseline.summary_bytes == multi_column_pair.repeat.summary_bytes

    def test_compared_summary_covers_both_columns(
        self, multi_column_pair: MultiColumnPair
    ) -> None:
        """一致の表明が空振りしないことを、比較した中身の側から確かめる。

        列軸が抜け落ちて片方の列しか処理されていなければ、行数は単一列の実行と同じに
        なる。行数と列の識別子の双方を固定する。
        """
        rows = multi_column_pair.baseline.summary_rows
        # 4 入力 × 2 列 × (直線の 2 パラメータ + スプラインの 1 行) = 24 行。
        assert len(rows) == len(SERIES_LENGTHS) * 2 * 3
        assert {row["status"] for row in rows} == {"success"}
        assert {row["column_label"] for row in rows} == {PRIMARY_COLUMN, SECOND_COLUMN}
        assert {row["column_name"] for row in rows} == {PRIMARY_COLUMN, SECOND_COLUMN}
        # 軸の順序（設計の pipeline: 入力 → 列 → 手法）。行順そのものが再現性の対象である。
        assert [(row["column_label"], row["method_name"]) for row in rows[:6]] == [
            (PRIMARY_COLUMN, "line"),
            (PRIMARY_COLUMN, "line"),
            (PRIMARY_COLUMN, "spl"),
            (SECOND_COLUMN, "line"),
            (SECOND_COLUMN, "line"),
            (SECOND_COLUMN, "spl"),
        ]

    def test_the_two_columns_are_not_the_same_numbers(
        self, multi_column_pair: MultiColumnPair
    ) -> None:
        """2 本目が 1 本目の写しでないこと。

        同じ曲線を 2 回当てはめていたなら、列を取り違える不具合も列軸が抜ける不具合も
        同じ数値を生み、上の検査が意味を失う。
        """
        rows = multi_column_pair.baseline.summary_rows
        by_column = {
            column: [
                row["value"] or row["rmse"]
                for row in rows
                if row["column_label"] == column
            ]
            for column in (PRIMARY_COLUMN, SECOND_COLUMN)
        }
        assert by_column[PRIMARY_COLUMN] != by_column[SECOND_COLUMN]

    def test_output_file_listing_and_names_match(
        self, multi_column_pair: MultiColumnPair
    ) -> None:
        """要件 7.6、8.2: 出力名と処理単位番号が実行ごとに変わらないこと。

        番号は 入力 → 列 → 手法 の順に振られる。列を跨いで番号が入れ替われば、同じ
        対象の結果が実行ごとに別のファイルへ移る。
        """
        baseline = multi_column_pair.baseline
        assert baseline.file_names == multi_column_pair.repeat.file_names
        expected = [
            f"{CURVES_DIRECTORY}/{source.stem}__{column}__{method}__{index:04d}.csv"
            for index, (source, column, method) in enumerate(
                (source, column, method)
                for source in multi_column_pair.sources
                for column in (PRIMARY_COLUMN, SECOND_COLUMN)
                for method in ("line", "spl")
            )
        ]
        assert baseline.file_names == sorted(
            [*expected, SUMMARY_NAME, RUN_LOG_NAME, EXECUTION_RECORD_NAME]
        )

    def test_full_precision_curves_match(self, multi_column_pair: MultiColumnPair) -> None:
        """丸める前の値も一致すること。サマリ表の丸めが揺れを隠していないことの裏取り。"""
        for name in multi_column_pair.baseline.curve_names:
            assert multi_column_pair.baseline.curve_bytes(
                name
            ) == multi_column_pair.repeat.curve_bytes(name), name

    def test_execution_record_matches_except_started_at(
        self, multi_column_pair: MultiColumnPair
    ) -> None:
        """要件 8.3、8.2: 記録のうち変わってよいのは ``started_at`` の 1 行だけである。"""
        baseline_rest, _ = multi_column_pair.baseline.execution_record_parts
        repeat_rest, _ = multi_column_pair.repeat.execution_record_parts
        assert baseline_rest == repeat_rest

    def test_run_log_matches_except_leading_timestamps(
        self, multi_column_pair: MultiColumnPair
    ) -> None:
        """要件 8.4、8.2: 記録の順序と内容が実行ごとに変わらないこと。"""
        baseline = multi_column_pair.baseline.log_lines
        assert baseline == multi_column_pair.repeat.log_lines
        # 1 行目の設定と、処理単位 16 件の行と、集計行。
        assert len(baseline) == len(SERIES_LENGTHS) * 2 * 2 + 2
        assert any("n_success=16" in line and "n_failure=0" in line for line in baseline)

    def test_compared_runs_are_really_two_separate_processes(
        self, multi_column_pair: MultiColumnPair
    ) -> None:
        """一致の表明が空振りしないことの裏取り。

        写しを 2 度取っただけなら、上の表明はどれも何も検査していない。開始時刻が
        食い違うことで、別プロセスとして 2 回起動したことを示す。
        """
        started = {snapshot.started_at for snapshot in multi_column_pair.both}
        assert len(started) == 2, started
        for value in started:
            assert STARTED_AT_PATTERN.match(value), value


# --- 列を増やしても既存の列が動かないこと ---------------------------------------------


class TestAddingColumnsDoesNotDisturbTheExistingColumn:
    """要件 8.2 の非退行: 2 本目の列を足しても 1 本目の結果が変わらないこと。

    単一列の実行と複数列の実行は、**同じ入力ファイル** を読み、y 列の指定だけが違う。
    したがって ``y`` に関する行と曲線は完全に一致しなければならない。前処理や重みが
    列を跨いで漏れる実装であれば、ここで数値が動く。
    """

    @staticmethod
    def _rows_of(snapshot: Snapshot, column: str) -> list[dict[str, str]]:
        return [row for row in snapshot.summary_rows if row["column_label"] == column]

    def test_summary_rows_for_the_first_column_are_identical(
        self, repetitions: Repetitions, multi_column_pair: MultiColumnPair
    ) -> None:
        """``source_id`` を含む全項目が一致すること。入力が同一であるため除外は無い。"""
        single = self._rows_of(repetitions[BASELINE], PRIMARY_COLUMN)
        multi = self._rows_of(multi_column_pair.baseline, PRIMARY_COLUMN)
        assert len(single) == len(SERIES_LENGTHS) * 3
        assert single == multi

    def test_full_precision_curves_for_the_first_column_are_identical(
        self, repetitions: Repetitions, multi_column_pair: MultiColumnPair
    ) -> None:
        """曲線の中身も一致すること。**番号だけは違う。**

        処理単位番号は列を含めて数え直されるため、``beta`` 以降は単一列の実行と
        複数列の実行で別の番号になる。番号を除いた ``(対象, 列, 手法)`` で対応付ける。
        """

        def keyed(snapshot: Snapshot) -> dict[tuple[str, str, str], bytes]:
            keys: dict[tuple[str, str, str], bytes] = {}
            for name in snapshot.curve_names:
                source, column, method, _index = name.removesuffix(".csv").split("__")
                if column != PRIMARY_COLUMN:
                    continue
                keys[(source, column, method)] = snapshot.curve_bytes(name)
            return keys

        single = keyed(repetitions[BASELINE])
        multi = keyed(multi_column_pair.baseline)
        assert len(single) == len(SERIES_LENGTHS) * 2
        assert single == multi

    def test_the_two_runs_really_differ_in_what_they_produced(
        self, repetitions: Repetitions, multi_column_pair: MultiColumnPair
    ) -> None:
        """一致の表明が空振りしないことの裏取り。

        複数列の実行が 2 本目を処理していなければ、上の 2 つは同じ実行を 2 度見て
        いるだけになる。生成物の集合が実際に増えていることを示す。
        """
        single_names = set(repetitions[BASELINE].curve_names)
        multi_names = set(multi_column_pair.baseline.curve_names)
        assert len(multi_names) == 2 * len(single_names)
        assert any(f"__{SECOND_COLUMN}__" in name for name in multi_names)
        assert not any(f"__{SECOND_COLUMN}__" in name for name in single_names)


# --- 改訂前の実装との照合（非退行）----------------------------------------------------

LEGACY_SUMMARY_COLUMNS: tuple[str, ...] = (
    "source_id",
    "method_name",
    "status",
    "parameter_name",
    "value",
    "stderr",
    "fixed",
    "r_squared",
    "rmse",
    "n_points",
    "n_dropped_invalid",
    "n_dropped_out_of_range",
    "n_dropped_outlier",
    "failure_reason",
    "message",
)
"""改訂前（コミット ``0c19bc4``）のサマリ表の列。

本改訂が加えたのは ``column_label`` と ``column_name`` の 2 列だけであり、それ以外の
列は名前も並びも変わらない。**この表を実装から取り込まない。** 取り込めば、列が消えても
名前が変わっても照合が成立してしまう。
"""

NEW_COLUMN_NAMES: tuple[str, ...] = ("column_label", "column_name")
"""本改訂が加えた 2 列（要件 7.3）。``source_id`` と ``method_name`` の間に入る。"""

NEW_COLUMN_POSITION = LEGACY_SUMMARY_COLUMNS.index("method_name")
"""加わった 2 列が入る位置。改訂前の列の並びに対して数える。"""

LEGACY_SUMMARY_ROWS: tuple[tuple[str, ...], ...] = (
    ("alpha", "line", "success", "slope", "0.3985717512", "0.06574855743", "False",
     "0.4666570554", "1.352697677", "44", "0", "0", "0", "", ""),
    ("alpha", "line", "success", "intercept", "0.7732558179", "0.4104350736", "False",
     "0.4666570554", "1.352697677", "44", "0", "0", "0", "", ""),
    ("alpha", "spl", "success", "", "", "", "",
     "0.9989692428", "0.05946694963", "44", "0", "0", "0", "", ""),
    ("beta", "line", "success", "slope", "0.502696718", "0.09097800448", "False",
     "0.473120445", "1.377717374", "36", "0", "0", "0", "", ""),
    ("beta", "line", "success", "intercept", "0.3998734387", "0.4628752789", "False",
     "0.473120445", "1.377717374", "36", "0", "0", "0", "", ""),
    ("beta", "spl", "success", "", "", "", "",
     "0.9985139333", "0.07316840922", "36", "0", "0", "0", "", ""),
    ("delta", "line", "success", "slope", "0.484259769", "0.07454695393", "False",
     "0.5261756551", "1.326158149", "40", "0", "0", "0", "", ""),
    ("delta", "line", "success", "intercept", "0.4827869667", "0.4223185278", "False",
     "0.5261756551", "1.326158149", "40", "0", "0", "0", "", ""),
    ("delta", "spl", "success", "", "", "", "",
     "0.9993228781", "0.05013257935", "40", "0", "0", "0", "", ""),
    ("gamma", "line", "success", "slope", "0.3656750129", "0.04942580173", "False",
     "0.5226150111", "1.311327393", "52", "0", "0", "0", "", ""),
    ("gamma", "line", "success", "intercept", "0.883935667", "0.3656131491", "False",
     "0.5226150111", "1.311327393", "52", "0", "0", "0", "", ""),
    ("gamma", "spl", "success", "", "", "", "",
     "0.999156733", "0.05511366564", "52", "0", "0", "0", "", ""),
)
"""改訂前の実装が :data:`CONFIG`（単一列）と同一の入力に対して書いたサマリ表。

コミット ``0c19bc4`` の ``src`` を作業ツリーとは別の場所に取り出し、**本ファイルの
:func:`write_series` が書いたものと同じ入力ファイル** を、同じ設定と同じ仮想環境で
処理させて得た実測値である（丸めは有効数字 10 桁、実装が書いた文字列そのまま）。

``source_id`` の欄だけは絶対パスを入力の名前に置き換えてある。一時ディレクトリの
綴りは実行ごとに変わり、固定できないためである。それ以外は 1 文字も加工していない。

**推定値をここに固定することが本表の目的である。** 「真値を回復すること」を検査すると
許容誤差の分だけ変化を見逃す。改訂前の出力そのものと突き合わせれば、最終桁 1 つの
違いも赤くなる。
"""

LEGACY_CURVE_NAMES: tuple[str, ...] = (
    "alpha__line__0000.csv",
    "alpha__spl__0001.csv",
    "beta__line__0002.csv",
    "beta__spl__0003.csv",
    "delta__line__0004.csv",
    "delta__spl__0005.csv",
    "gamma__line__0006.csv",
    "gamma__spl__0007.csv",
)
"""改訂前の実装が同じ実行で書いた曲線 CSV の名前（``{対象}__{手法}__{番号}``）。

本改訂は名前に列を挟む（要件 7.6）。**変わるのはそこだけである** ことを、処理単位
番号まで含めて固定する。
"""


class TestSingleColumnRunMatchesTheImplementationBeforeTheRevision:
    """要件 8.2 の非退行: 単一の y 列を指定した既存の設定が従来と同じ結果を返すこと。

    tasks.md 13.12 が周知した破壊的変更は 2 件（出力名に列が入る／サマリ表に列が
    2 つ増える）である。**それ以外は何も変わっていない** ことを、改訂前の実装の
    実測値（:data:`LEGACY_SUMMARY_ROWS`、:data:`LEGACY_CURVE_NAMES`）との照合で示す。

    比較の相手は :data:`BASELINE`、すなわち既に取ってある単一列の実行の写しである。
    新しい起動は要らない。
    """

    def test_summary_columns_are_the_old_ones_plus_exactly_two(
        self, repetitions: Repetitions
    ) -> None:
        """要件 7.3: 増えたのは 2 列だけで、位置も改訂前の並びを崩していないこと。"""
        header = repetitions[BASELINE].summary_header
        expected = (
            *LEGACY_SUMMARY_COLUMNS[:NEW_COLUMN_POSITION],
            *NEW_COLUMN_NAMES,
            *LEGACY_SUMMARY_COLUMNS[NEW_COLUMN_POSITION:],
        )
        assert header == expected

    def test_summary_content_is_unchanged_once_the_new_columns_are_removed(
        self, repetitions: Repetitions
    ) -> None:
        """要件 8.2: 推定値・状態・件数のいずれも改訂前と 1 文字も違わないこと。

        ``source_id`` は一時ディレクトリの綴りを含むため、入力の名前に直してから
        比べる。直す前の綴りが実在の入力を指していることは
        :meth:`test_source_ids_really_point_at_the_inputs` が別に示す。
        """
        rows = repetitions[BASELINE].summary_cells
        without_new_columns = tuple(
            (
                Path(row[0]).stem,
                *row[1:NEW_COLUMN_POSITION],
                *row[NEW_COLUMN_POSITION + len(NEW_COLUMN_NAMES) :],
            )
            for row in rows
        )
        assert without_new_columns == LEGACY_SUMMARY_ROWS

    def test_source_ids_really_point_at_the_inputs(self, repetitions: Repetitions) -> None:
        """上の照合で名前へ直した ``source_id`` が、実在の入力の絶対パスであること。

        これが無いと、``source_id`` の欄が壊れていても ``stem`` を取る過程で
        取り繕われてしまう。
        """
        sources = {str(source) for source in repetitions.sources}
        assert {row[0] for row in repetitions[BASELINE].summary_cells} == sources

    def test_the_new_columns_hold_the_single_column_identity(
        self, repetitions: Repetitions
    ) -> None:
        """加わった 2 列に入るのは、設定に書いた綴りと実際の見出しの双方であること。

        単一列の設定では両者が一致する（要件 7.3）。空欄で埋まっていれば、上の照合は
        通ってしまう。
        """
        position = NEW_COLUMN_POSITION
        added = {
            row[position : position + len(NEW_COLUMN_NAMES)]
            for row in repetitions[BASELINE].summary_cells
        }
        assert added == {(PRIMARY_COLUMN, PRIMARY_COLUMN)}

    def test_output_names_gain_the_column_and_nothing_else(
        self, repetitions: Repetitions
    ) -> None:
        """要件 7.6: 名前の変化は列が 1 つ挟まることに尽きること。

        処理単位番号まで改訂前と同じであることも併せて言う。番号が振り直されて
        いれば、既存の利用者が名前で拾っている出力が別のファイルへ移る。
        """
        expected = [
            "__".join((source, PRIMARY_COLUMN, method_and_index))
            for source, method_and_index in (
                name.split("__", 1) for name in LEGACY_CURVE_NAMES
            )
        ]
        assert repetitions[BASELINE].curve_names == expected
