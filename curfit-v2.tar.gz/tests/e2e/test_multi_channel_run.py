"""1 ファイル複数チャネルの通し実行の E2E テスト（要件 1.3、1.12、6.8、7.6）。

1 つの入力ファイルが複数の測定チャネル（y 列）を持つ場合を、**導入済みのコンソール
スクリプトを別プロセスとして起動して** 検証する。

- **全チャネル分の成果物**（要件 6.8、7.3、7.4、7.5）: コマンド 1 回で、指定した
  すべての y 列について結果・グラフ・曲線 CSV・サマリ行が揃うこと
- **上書きが起きないこと**（要件 7.6）: 同一ファイル・同一手法・**別の列** という、
  出力名が列を含まなければ 2 件目が 1 件目を潰す条件を再現し、双方の出力が残ること
- **誤差列の列ごとの対応**（要件 1.3、1.12）: 各チャネルの推定値が、記述順で
  対応付けられた **その列の** 誤差列の重みを反映すること

``tests/e2e/test_run_end_to_end.py`` との違い
--------------------------------------------

あちらの複数チャネルの場面は、サマリ表・実行ログ・実行条件の記録という **表と記録** の
上で列が区別できることを見る。本テストは **出力ファイルそのもの** が列ごとに分かれて
残ることと、**重みの対応付け** が推定値に現れることを見る。前者は名前の組み立て規則が、
後者は列指定の組み立て順序が壊れたときに落ちる。

本テストは :mod:`curvefit` を一切 import しない。ファイル名・列構成・終了コードは
利用者と外部ツールが依存する契約であり、実装の定数を取り込んで照合すると、定数の改名が
利用者から見た破壊であっても検出できない。

起動は 2 回だけである。1 回目が主となる実行、2 回目は誤差列の対応付けを **入れ替えた**
実行であり、同じ呼び出しを 2 度書いても対応付けの差は現れないため実際に別に起動する。
"""

from __future__ import annotations

import csv
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import pytest

# --- 利用者から見た契約（実装の定数は取り込まない）----------------------------------

SUMMARY_NAME = "summary.csv"
"""サマリ表のファイル名（要件 7.3）。"""

PLOTS_DIRECTORY = "plots"
"""グラフ画像を収める下位ディレクトリ（要件 7.4）。"""

CURVES_DIRECTORY = "curves"
"""曲線・残差 CSV を収める下位ディレクトリ（要件 7.5）。"""

CURVE_HEADER: tuple[str, ...] = ("x", "y_observed", "y_fit", "residual")
"""曲線・残差 CSV の列（要件 7.5）。"""

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
"""PNG の識別子。拡張子だけでは中身が画像であることを示せない。"""

EXIT_SUCCESS = 0
"""全処理単位が成功した（要件 9.5）。"""

# --- 入力の設計 ----------------------------------------------------------------------

N_POINTS = 24
"""1 チャネルあたりの点数。"""

INTERCEPT = 1.5
"""両チャネルに共通の真の切片。"""

CHANNEL_SLOPES: dict[str, float] = {"signal": 2.5, "ref": -1.25}
"""チャネルごとの真の傾き。符号を違えて、取り違えが数値として現れるようにする。"""

DISTORTED_INDEX: dict[str, int] = {"signal": 3, "ref": 20}
"""チャネルごとに 1 点だけ大きく外れる点の位置。

**位置を違える。** 同じ位置にすると、誤差列を入れ替えても同じ点が同じ重みを受け取り、
対応付けの正誤が推定値に現れない。
"""

DISTORTION = 200.0
"""外れた点の上乗せ量。重みが効かなかった場合の傾きのずれが、真値との
照合の許容（0.01）ではなく桁で分かる大きさになるよう選ぶ。"""

SMALL_SIGMA = 0.01
"""通常の点の測定誤差 σ。"""

LARGE_SIGMA = 1000.0
"""外れた点に添える測定誤差 σ。重み 1/σ は実質 0 になる（要件 1.3）。"""

SIGMA_COLUMNS: dict[str, str] = {"signal": "sigma_signal", "ref": "sigma_ref"}
"""チャネルに対応する誤差列の見出し名。"""


def write_two_channel_series(path: Path) -> Path:
    """2 チャネル分の測定値と、チャネルごとの測定誤差を書き出す。

    各チャネルは既知の直線に微小なばらつきを載せたものだが、**チャネルごとに別の位置** で
    1 点だけ大きく外れる。その点にだけ大きな σ を添える。誤差列が正しく対応付けられて
    いれば外れた点は無視され、入れ替わっていれば当てはめが傾く。

    値は :func:`repr` で書き、最終ビットまで復元できる表記にする（要件 1.9）。
    """
    names = tuple(CHANNEL_SLOPES)
    header = ("x", *names, *(SIGMA_COLUMNS[name] for name in names))
    lines = [",".join(header)]
    for index in range(N_POINTS):
        x = float(index) * 0.5
        wobble = SMALL_SIGMA if index % 2 == 0 else -SMALL_SIGMA
        observed: list[float] = []
        sigmas: list[float] = []
        for name in names:
            distorted = index == DISTORTED_INDEX[name]
            value = CHANNEL_SLOPES[name] * x + INTERCEPT + wobble
            observed.append(float(value + DISTORTION if distorted else value))
            sigmas.append(LARGE_SIGMA if distorted else SMALL_SIGMA)
        lines.append(",".join(repr(value) for value in (x, *observed, *sigmas)))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


CONFIG_TEMPLATE = """\
[input]
paths = [{source}]
header = true

[input.columns]
x = "x"
y = ["signal", "ref"]
weight = [{first_sigma}, {second_sigma}]

[[methods]]
name = "line"
builtin = "linear"

[output]
directory = {output_dir}
write_plot = true
write_curve = true
"""
"""y 列と誤差列を **記述順で** 対応付ける（要件 1.12）。列は名前で指定し、出力名に
チャネルの綴りがそのまま現れるようにする（要件 7.6）。"""


def toml_string(value: Path | str) -> str:
    """TOML の文字列として安全に書ける形にする。"""
    return json.dumps(str(value), ensure_ascii=False)


def console_script() -> Path:
    """宣言されたコンソールスクリプトの実体。

    ``python -m curvefit.cli`` では ``[project.scripts]`` の宣言漏れを検出できない。
    利用者が打つのはコマンド名であり、起動すべきはその実体である。
    """
    return Path(sys.executable).parent / "curvefit"


@dataclass(frozen=True)
class Execution:
    """1 回のコマンド実行と、その出力先。"""

    process: subprocess.CompletedProcess[str]
    output_dir: Path
    source: Path

    @property
    def returncode(self) -> int:
        return self.process.returncode

    @property
    def stderr(self) -> str:
        return self.process.stderr


def launch(base: Path, source: Path, *, swap_sigma: bool) -> Execution:
    """設定を書き出し、コマンドを別プロセスとして起動する（要件 9.2）。

    :param swap_sigma: 真のとき、誤差列の並びだけを入れ替える。y 列の並びは変えない
    """
    order = ("ref", "signal") if swap_sigma else ("signal", "ref")
    label = "swapped" if swap_sigma else "paired"
    output_dir = base / f"out_{label}"
    config = base / f"run_{label}.toml"
    config.write_text(
        CONFIG_TEMPLATE.format(
            source=toml_string(source),
            first_sigma=toml_string(SIGMA_COLUMNS[order[0]]),
            second_sigma=toml_string(SIGMA_COLUMNS[order[1]]),
            output_dir=toml_string(output_dir),
        ),
        encoding="utf-8",
    )
    process = subprocess.run(
        [str(console_script()), str(config)],
        capture_output=True,
        text=True,
        timeout=300,
    )
    return Execution(process=process, output_dir=output_dir, source=source)


@pytest.fixture(scope="module")
def channel_data(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """2 つの実行が共有する 1 つの入力ファイル。"""
    base = tmp_path_factory.mktemp("multi_channel")
    return write_two_channel_series(base / "run.csv")


@pytest.fixture(scope="module")
def paired_run(channel_data: Path) -> Execution:
    """誤差列を記述順どおりに対応付けた実行（コマンド 1 回、2 チャネル）。"""
    return launch(channel_data.parent, channel_data, swap_sigma=False)


@pytest.fixture(scope="module")
def swapped_run(channel_data: Path) -> Execution:
    """誤差列だけを入れ替えた実行。y 列の並びも入力も設定の他の部分も同じである。"""
    return launch(channel_data.parent, channel_data, swap_sigma=True)


# --- 成果物の読み取り ----------------------------------------------------------------


def summary_rows(directory: Path) -> list[dict[str, str]]:
    with (directory / SUMMARY_NAME).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def estimate(rows: list[dict[str, str]], column: str, parameter: str) -> float:
    """サマリ表から、ある列のあるパラメータの推定値を 1 つ取り出す。"""
    matched = [
        row
        for row in rows
        if row["column_label"] == column and row["parameter_name"] == parameter
    ]
    assert len(matched) == 1, (column, parameter, rows)
    return float(matched[0]["value"])


def names_in(directory: Path) -> list[str]:
    if not directory.is_dir():
        return []
    return sorted(item.name for item in directory.iterdir() if item.is_file())


def read_curve(path: Path) -> tuple[tuple[str, ...], list[tuple[float, ...]]]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = tuple(next(reader))
        rows = [tuple(float(cell) for cell in row) for row in reader]
    return header, rows


# --- 全チャネル分の成果物 ------------------------------------------------------------


class TestOneRunCoversEveryChannel:
    """要件 6.8、7.3、7.4、7.5: 1 回の実行が指定した全 y 列を処理し切ること。"""

    def test_exit_code_0(self, paired_run: Execution) -> None:
        assert paired_run.returncode == EXIT_SUCCESS, paired_run.stderr

    def test_summary_carries_a_row_set_per_channel(self, paired_run: Execution) -> None:
        """要件 6.8、7.3: 2 チャネル × 2 パラメータの行が、列の値で識別できる形で並ぶ。"""
        rows = summary_rows(paired_run.output_dir)
        assert [
            (row["column_label"], row["column_name"], row["method_name"], row["parameter_name"])
            for row in rows
        ] == [
            ("signal", "signal", "line", "slope"),
            ("signal", "signal", "line", "intercept"),
            ("ref", "ref", "line", "slope"),
            ("ref", "ref", "line", "intercept"),
        ]
        assert {row["source_id"] for row in rows} == {str(paired_run.source)}
        assert {row["status"] for row in rows} == {"success"}

    def test_progress_counts_every_channel(self, paired_run: Execution) -> None:
        """要件 6.3、6.6: 集計の件数がチャネル数分になる。入力は 1 件のままである。"""
        assert "成功 2 件" in paired_run.stderr


# --- 上書きが起きないこと ------------------------------------------------------------


class TestChannelOutputsDoNotOverwriteEachOther:
    """要件 7.6: 同一ファイル・同一手法・別の列の出力が互いを潰さないこと。

    出力名が ``{対象}__{手法}__{番号}`` のように **列を含まない** 形であれば、この条件で
    2 件目が 1 件目を上書きする。名前に列が入っていることを、実際に残ったファイルの
    集合と、その中身が別のチャネルのものであることの双方で確かめる。
    """

    def test_plot_files_are_named_per_channel(self, paired_run: Execution) -> None:
        """要件 7.4、7.6: グラフがチャネルごとに 1 枚ずつ残る。"""
        assert names_in(paired_run.output_dir / PLOTS_DIRECTORY) == [
            "run__ref__line__0001.png",
            "run__signal__line__0000.png",
        ]
        for name in names_in(paired_run.output_dir / PLOTS_DIRECTORY):
            content = (paired_run.output_dir / PLOTS_DIRECTORY / name).read_bytes()
            assert content.startswith(PNG_MAGIC), name
            assert len(content) > 1000, name

    def test_curve_files_are_named_per_channel(self, paired_run: Execution) -> None:
        """要件 7.5、7.6: 曲線 CSV がチャネルごとに 1 つずつ残る。"""
        assert names_in(paired_run.output_dir / CURVES_DIRECTORY) == [
            "run__ref__line__0001.csv",
            "run__signal__line__0000.csv",
        ]

    def test_each_curve_file_holds_its_own_channel(self, paired_run: Execution) -> None:
        """双方が残るだけでは足りない。中身が **別々のチャネル** であることまで見る。

        上書きが起きた場合、残った 1 つがどちらの内容であっても、片方の実測値は
        どこにも存在しなくなる。実測値の列を入力と突き合わせる。
        """
        curves = paired_run.output_dir / CURVES_DIRECTORY
        signal_header, signal_rows = read_curve(curves / "run__signal__line__0000.csv")
        ref_header, ref_rows = read_curve(curves / "run__ref__line__0001.csv")

        assert signal_header == CURVE_HEADER
        assert ref_header == CURVE_HEADER
        assert len(signal_rows) == N_POINTS
        assert len(ref_rows) == N_POINTS

        # 実測値の列だけで両者は区別できる。傾きの符号が逆であり、外れた点の位置も違う。
        observed = {
            "signal": [row[1] for row in signal_rows],
            "ref": [row[1] for row in ref_rows],
        }
        assert observed["signal"] != observed["ref"]
        for name, slope in CHANNEL_SLOPES.items():
            for index, value in enumerate(observed[name]):
                gap = value - (slope * float(index) * 0.5 + INTERCEPT)
                if index == DISTORTED_INDEX[name]:
                    assert gap == pytest.approx(DISTORTION, abs=0.02), (name, index)
                else:
                    assert abs(gap) == pytest.approx(SMALL_SIGMA, abs=1e-12), (name, index)

    def test_no_output_name_collapses_the_column(self, paired_run: Execution) -> None:
        """列を外した形の名前が生成物のどこにも現れないこと。

        列軸が抜けた実装では ``run__line__0000.png`` のような名前になり、上の 2 つの
        検査は「見つからない」形で落ちる。ここでは **その名前が実際に作られていない**
        ことを言い、落ち方を取り違えないようにする。
        """
        produced = sorted(
            str(item.relative_to(paired_run.output_dir))
            for item in paired_run.output_dir.rglob("*")
            if item.is_file()
        )
        for name in produced:
            stem = Path(name).stem
            if "__" not in stem:
                continue
            assert stem.count("__") == 3, name


# --- 誤差列の列ごとの対応 ------------------------------------------------------------


class TestWeightColumnsArePairedWithTheirOwnChannel:
    """要件 1.3、1.12: 各 y 列が **対応する** 誤差列の重みを反映すること。

    どちらのチャネルも、自分の外れた点にだけ大きな σ を持つ。対応付けが正しければ
    その点は実質無視され、真の直線が戻る。誤差列だけを入れ替えると、外れた点が満額の
    重みを受け取り、代わりに正常な点が捨てられるため、推定値が大きく動く。
    """

    def test_swapped_run_also_succeeds(self, swapped_run: Execution) -> None:
        """入れ替えた側も成功する。差が出るのは終了状態ではなく推定値である。"""
        assert swapped_run.returncode == EXIT_SUCCESS, swapped_run.stderr

    def test_paired_weights_recover_the_true_line_of_each_channel(
        self, paired_run: Execution
    ) -> None:
        """要件 1.3: 誤差の大きい点の寄与が小さくなり、チャネルごとの真値が戻る。"""
        rows = summary_rows(paired_run.output_dir)
        for name, slope in CHANNEL_SLOPES.items():
            assert estimate(rows, name, "slope") == pytest.approx(slope, abs=0.01)
            assert estimate(rows, name, "intercept") == pytest.approx(INTERCEPT, abs=0.05)

    def test_swapping_the_weight_columns_moves_every_channel(
        self, paired_run: Execution, swapped_run: Execution
    ) -> None:
        """要件 1.12: 対応付けが記述順に依存すること。

        入れ替えた側では、どちらのチャネルも真値から大きく外れる。「動く」ことだけを
        見ると微小な差でも通ってしまうため、真値からの隔たりの大きさで言う。
        """
        paired = summary_rows(paired_run.output_dir)
        swapped = summary_rows(swapped_run.output_dir)
        for name, slope in CHANNEL_SLOPES.items():
            paired_slope = estimate(paired, name, "slope")
            swapped_slope = estimate(swapped, name, "slope")
            assert abs(swapped_slope - slope) > 1.0, (name, swapped_slope)
            assert abs(swapped_slope - paired_slope) > 1.0, (name, paired_slope)

    def test_weights_are_not_shared_across_channels(
        self, paired_run: Execution, swapped_run: Execution
    ) -> None:
        """1 本の誤差列が全チャネルに使い回されていないこと。

        使い回す実装では、並びを入れ替えても両チャネルが同じ扱いを受けるか、片方だけが
        動く。両方が同時に動くのは、列ごとに別の誤差列が結び付いている場合だけである。
        """
        paired = summary_rows(paired_run.output_dir)
        swapped = summary_rows(swapped_run.output_dir)
        moved = {
            name
            for name in CHANNEL_SLOPES
            if estimate(paired, name, "slope") != estimate(swapped, name, "slope")
        }
        assert moved == set(CHANNEL_SLOPES)
