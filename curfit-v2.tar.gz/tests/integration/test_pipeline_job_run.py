"""単一処理単位の実行を結線する統合テスト（要件 4.1、7.4、7.5）。

本テストは `curvefit.pipeline.run_job` が次を満たすことを検証する。

- **段階の連結**: 読み込み → モデル解決 → 前処理 → 当てはめ → 出力の適用を順に通し、
  成功時は結果と出力ファイルが得られること
- **読み込み済みの系列の受け取り**（要件 9.1、9.3）: 処理単位が系列を伴う場合は
  読み込みの 1 段だけを省き、以降の段階は同一の手順を通ること。省略が読み込みに
  限られることは、ファイル経由の結果と最終ビットまで一致することで示す
- **短絡**: いずれかの段階が失敗結果を返したら、以降の段階に進まずその結果を
  そのまま処理単位の結果とすること。後続の段階が走っていないことは、出力物が
  1 件も生成されないことと、後続の段階が返すはずの失敗にならないことで示す
- **処理単位ごとのモデル解決**（要件 4.1）: 組込モデルの初期値を **その対象の** データ
  から推定すること。設定解決時に一度だけ推定して使い回すと、スケールの異なるデータで
  収束が悪化することを、同一の解決済みモデルを別スケールのデータに当てた結果で示す
- **最小点数の供給**: 前処理に渡す最小点数を解決済み手法の **推定対象** パラメータ数
  から導出すること（要件 2.4 の判定材料はこの層が供給する）。固定したパラメータは
  当てはめが動かさないため数に含めない（要件 4.5）
- **適用された既定値の中継**（要件 5.4）: 当てはめが補った既定値を `JobResult` に載せて
  返すこと。どの選択肢に既定値が効いたかは当てはめが走って初めて確定するため、
  `MethodSpec` からは再計算できない
- **重みが効かない手法の記録**: 誤差列が与えられているのにスプライン・移動平均が
  選ばれた場合、その旨を実行ログに残すこと。`FitOutcome` は重みの由来を持たないため、
  `DataSeries` と解決済み手法を同時に持つこの層でしか判定できない
- **出力の既定**: グラフ画像は既定で保存し（要件 7.4）、曲線・残差 CSV は有効化された
  場合にのみ生成すること（要件 7.5）
- **列識別子の刻印**（要件 1.4、1.5、7.3、7.6）: どの返り口を通った結果にも、利用者が
  書いた指定の綴り（`column_label`）が載ること。解決後の見出し名（`column_name`）は
  読み込めた場合にのみ載ること。刻む規則が 1 か所にあること

バッチの逐次実行・失敗集約・進捗通知・資源枯渇の扱い（タスク 7.3）は対象外である。

設計の Testing Strategy が `pipeline` の結線を統合テストに置いているため、単体では
なく `tests/integration/` に置く。
"""

from __future__ import annotations

import ast
import csv
import logging
import math
from collections.abc import Sequence
from pathlib import Path

import numpy as np
import pytest

from curvefit import pipeline as pipeline_module
from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.engines import EngineFailure, select_engine
from curvefit.engines.smoothing import (
    MOVING_AVERAGE_WINDOW_OPTION,
    NO_WEIGHT_SUPPORT_REASONS,
    SMOOTHER_OPTION_DEFAULTS,
)
from curvefit.errors import FailureReason
from curvefit.logging_setup import LOGGER_NAME
from curvefit.models.registry import DEFAULT_POLYNOMIAL_DEGREE, POLYNOMIAL_DEGREE_OPTION
from curvefit.models.resolver import MethodSpec, SmootherKind, resolve
from curvefit.pipeline import (
    CURVE_SUBDIRECTORY,
    PLOT_SUBDIRECTORY,
    PREPROCESS_SUBDIRECTORY,
    Job,
    JobResult,
    UnexpectedConfigViolation,
    expand_jobs,
    run_job,
)
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec, read_delimited
from curvefit.types import DataSeries, FitFailure, FitOutcome, FitSuccess
from curvefit.writers import CURVE_COLUMNS, PREPROCESS_COLUMNS, build_output_stem

GAUSSIAN = MethodSpec(name="gauss", kind="builtin", builtin="gaussian")
"""初期値を明示しない組込モデル。要件 4.1 の自動推定が働く経路である。"""

LINEAR = MethodSpec(name="lin", kind="builtin", builtin="linear")
BUILTIN_POLYNOMIAL = MethodSpec(name="bpoly", kind="builtin", builtin="polynomial")
"""次数を明示しない組込の多項式。次数の既定値（要件 5.4）が効く経路である。"""
SPLINE = MethodSpec(
    name="sp", kind="smoother", smoother=SmootherKind.SPLINE, options={"lam": 1e-2}
)
"""平滑化スプライン。平滑化パラメータの指定は必須である（要件 5.5）。"""
MOVING_AVERAGE = MethodSpec(name="ma", kind="smoother", smoother=SmootherKind.MOVING_AVERAGE)
SMOOTHER_LINEAR = MethodSpec(name="slin", kind="smoother", smoother=SmootherKind.LINEAR)
SMOOTHER_POLYNOMIAL = MethodSpec(name="spoly", kind="smoother", smoother=SmootherKind.POLYNOMIAL)


def gaussian_values(x: np.ndarray, height: float, center: float, sigma: float) -> np.ndarray:
    """合成データの生成元。基盤ライブラリを使わずに定義する。"""
    return height * np.exp(-((x - center) ** 2) / (2.0 * sigma**2))


def write_csv(
    path: Path,
    x: Sequence[object],
    y: Sequence[object],
    sigma: Sequence[object] | None = None,
) -> Path:
    """見出し行を持つ CSV を書き出す。値は文字列としてそのまま並べる。"""
    header = "x,y" if sigma is None else "x,y,sigma"
    lines = [header]
    for index, (x_value, y_value) in enumerate(zip(x, y, strict=True)):
        row = f"{x_value},{y_value}"
        if sigma is not None:
            row = f"{row},{sigma[index]}"
        lines.append(row)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_two_column_csv(path: Path, n_points: int = 21) -> Path:
    """x と 2 つの y 列（``signal`` / ``noise``）を持つ CSV。列ごとに別の直線である。"""
    lines = ["x,signal,noise"]
    for index in range(n_points):
        x = float(index)
        lines.append(f"{x},{2.0 * x + 1.0},{-3.0 * x + 5.0}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_gaussian_csv(
    path: Path, *, height: float, center: float, sigma: float, n_points: int = 41
) -> Path:
    """既知のガウシアンから合成データを書き出す。"""
    x = np.linspace(center - 4.0 * sigma, center + 4.0 * sigma, n_points)
    return write_csv(path, x.tolist(), gaussian_values(x, height, center, sigma).tolist())


DEFAULT_COLUMNS = (ColumnSpec(x="x", y="y"),)
"""既定の列指定。y 列ごとに 1 件の並びである（要件 1.11）。"""

UNREAD_COLUMNS = ColumnSpec(x="x", y="y")
"""系列を直接渡す処理単位が運ぶ列指定。読み込みを行わないため参照されない（要件 9.1）。"""


def series_job(
    method: MethodSpec,
    *,
    index: int = 0,
    source: str = "memory",
    series: DataSeries | None = None,
) -> Job:
    """読み込み済みの系列を載せた処理単位（要件 9.1）。

    列指定は読まれず、出力名に載る識別子（``column_label``）も持たない。
    """
    return Job(
        index=index,
        source=source,
        columns=UNREAD_COLUMNS,
        column_label=None,
        method=method,
        series=series,
    )


def make_config(
    directory: Path,
    paths: Sequence[str],
    methods: Sequence[MethodSpec],
    *,
    columns: Sequence[ColumnSpec] | None = None,
    preprocess: PreprocessSpec | None = None,
    write_plot: bool = True,
    write_curve: bool = False,
    header: bool | None = None,
) -> RunConfig:
    return RunConfig(
        inputs=InputSpec(
            paths=tuple(paths),
            columns=tuple(columns) if columns is not None else DEFAULT_COLUMNS,
            header=header,
        ),
        methods=tuple(methods),
        preprocess=preprocess if preprocess is not None else PreprocessSpec(),
        output=OutputSpec(
            directory=directory, write_plot=write_plot, write_curve=write_curve
        ),
    )


def single_job(config: RunConfig) -> Job:
    jobs = expand_jobs(config)
    assert len(jobs) == 1
    return jobs[0]


def run_outcome(job: Job, config: RunConfig) -> FitOutcome:
    """処理単位を実行し、当てはめ結果だけを取り出す。

    既定値の中継（要件 5.4）を検証しない試験のための補助である。
    """
    result = run_job(job, config)
    assert isinstance(result, JobResult)
    return result.outcome


def plot_path(config: RunConfig, job: Job) -> Path:
    stem = build_output_stem(job.source, job.column_label, job.method.name, job.index)
    return config.output.directory / PLOT_SUBDIRECTORY / f"{stem}.png"


def curve_path(config: RunConfig, job: Job) -> Path:
    stem = build_output_stem(job.source, job.column_label, job.method.name, job.index)
    return config.output.directory / CURVE_SUBDIRECTORY / f"{stem}.csv"


def assert_no_outputs(config: RunConfig) -> None:
    """出力物が 1 件も生成されていないこと。後続段階が走っていないことの証拠になる。"""
    directory = config.output.directory
    produced = sorted(str(p) for p in directory.rglob("*") if p.is_file())
    assert produced == []


def parameter(success: FitSuccess, name: str) -> float:
    return next(estimate.value for estimate in success.parameters if estimate.name == name)


class TestWiringOnSuccess:
    """1 件の入力と 1 つの手法で、結果と出力ファイルが得られること。"""

    def test_recovers_the_known_parameters(self, tmp_path: Path) -> None:
        """既知のパラメータを復元する。"""
        source = write_gaussian_csv(
            tmp_path / "peak.csv", height=10.0, center=5.0, sigma=1.0
        )
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.source_id == job.source
        assert outcome.method_name == "gauss"
        assert parameter(outcome, "center") == pytest.approx(5.0, abs=1e-6)
        assert parameter(outcome, "sigma") == pytest.approx(1.0, abs=1e-6)
        assert parameter(outcome, "amplitude") == pytest.approx(
            10.0 * 1.0 * math.sqrt(2.0 * math.pi), rel=1e-6
        )

    def test_goodness_and_curve_are_included_in_the_result(self, tmp_path: Path) -> None:
        """適合度と曲線が結果に含まれる。"""
        source = write_gaussian_csv(
            tmp_path / "peak.csv", height=10.0, center=5.0, sigma=1.0, n_points=41
        )
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.goodness.r_squared == pytest.approx(1.0, abs=1e-9)
        assert outcome.goodness.n_points == 41
        assert outcome.goodness.n_varied_params == 3
        assert len(outcome.curve) == 41
        assert outcome.curve.residual == pytest.approx(
            outcome.curve.y_observed - outcome.curve.y_fit
        )
        assert outcome.preprocess.n_input == 41
        assert outcome.preprocess.n_used == 41

    def test_saves_the_plot_image_by_default(self, tmp_path: Path) -> None:
        """要件 7.4: グラフ画像は既定で保存する。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        assert plot_path(config, job).is_file()
        assert plot_path(config, job).stat().st_size > 0

    def test_curve_csv_is_not_written_by_default(self, tmp_path: Path) -> None:
        """要件 7.5: 曲線・残差 CSV はオプトインである。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        assert not curve_path(config, job).exists()
        assert not (config.output.directory / CURVE_SUBDIRECTORY).exists()

    def test_curve_csv_is_written_when_enabled(self, tmp_path: Path) -> None:
        """要件 7.5。"""
        source = write_gaussian_csv(
            tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5, n_points=21
        )
        config = make_config(
            tmp_path / "out", [str(source)], [GAUSSIAN], write_curve=True
        )
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        written = curve_path(config, job)
        assert written.is_file()
        lines = written.read_text(encoding="utf-8").splitlines()
        assert lines[0] == ",".join(CURVE_COLUMNS)
        assert len(lines) == 1 + 21

    def test_disabling_the_plot_prevents_it_from_being_written(self, tmp_path: Path) -> None:
        """グラフを無効化すると生成しない。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out", [str(source)], [GAUSSIAN], write_plot=False
        )
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)

        assert not (config.output.directory / PLOT_SUBDIRECTORY).exists()

    def test_output_names_carry_the_job_index_and_never_overwrite_each_other(
        self, tmp_path: Path
    ) -> None:
        """要件 7.6 の命名がそのまま出力先に反映されること。"""
        first = tmp_path / "run1"
        second = tmp_path / "run2"
        first.mkdir()
        second.mkdir()
        write_gaussian_csv(first / "sample.csv", height=4.0, center=1.0, sigma=0.4)
        write_gaussian_csv(second / "sample.csv", height=6.0, center=3.0, sigma=0.7)
        config = make_config(
            tmp_path / "out",
            [str(first / "sample.csv"), str(second / "sample.csv")],
            [GAUSSIAN],
            write_curve=True,
        )

        jobs = expand_jobs(config)
        assert len(jobs) == 2
        for job in jobs:
            assert isinstance(run_outcome(job, config), FitSuccess)

        plots = sorted(p.name for p in (config.output.directory / PLOT_SUBDIRECTORY).iterdir())
        curves = sorted(p.name for p in (config.output.directory / CURVE_SUBDIRECTORY).iterdir())
        assert plots == ["sample__y__gauss__0000.png", "sample__y__gauss__0001.png"]
        assert curves == ["sample__y__gauss__0000.csv", "sample__y__gauss__0001.csv"]

    def test_two_columns_of_the_same_file_do_not_overwrite_each_other(
        self, tmp_path: Path
    ) -> None:
        """要件 7.6: 同一ファイルの別々の列の出力が互いを上書きしないこと。

        番号だけでは足りない理由を押さえる。ここで比較するのは、名前に列が入るか
        どうかである。
        """
        source = write_two_column_csv(tmp_path / "sample.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="signal"), ColumnSpec(x="x", y="noise")),
            write_curve=True,
        )

        jobs = expand_jobs(config)
        assert len(jobs) == 2
        for job in jobs:
            assert isinstance(run_outcome(job, config), FitSuccess)

        plots = sorted(p.name for p in (config.output.directory / PLOT_SUBDIRECTORY).iterdir())
        curves = sorted(p.name for p in (config.output.directory / CURVE_SUBDIRECTORY).iterdir())
        assert plots == ["sample__noise__lin__0001.png", "sample__signal__lin__0000.png"]
        assert curves == ["sample__noise__lin__0001.csv", "sample__signal__lin__0000.csv"]

    def test_a_single_column_is_named_by_the_same_rule(self, tmp_path: Path) -> None:
        """要件 7.6: y 列が 1 つだけでも名前に列が入る。命名規則は 1 通りである。"""
        source = write_two_column_csv(tmp_path / "sample.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="signal"),),
            write_curve=True,
        )

        job = single_job(config)
        assert isinstance(run_outcome(job, config), FitSuccess)

        curves = sorted(p.name for p in (config.output.directory / CURVE_SUBDIRECTORY).iterdir())
        assert curves == ["sample__signal__lin__0000.csv"]

    def test_a_positional_column_does_not_look_like_the_job_number(
        self, tmp_path: Path
    ) -> None:
        """要件 7.6: 位置指定に由来する数字は固定の位置に入り、番号と紛れない。"""
        source = write_two_column_csv(tmp_path / "sample.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x=0, y=1), ColumnSpec(x=0, y=2)),
            write_curve=True,
        )

        for job in expand_jobs(config):
            assert isinstance(run_outcome(job, config), FitSuccess)

        curves = sorted(p.name for p in (config.output.directory / CURVE_SUBDIRECTORY).iterdir())
        assert curves == ["sample__1__lin__0000.csv", "sample__2__lin__0001.csv"]

    def test_repeating_the_same_job_yields_the_same_result(self, tmp_path: Path) -> None:
        """要件 8.2: 同一入力・同一条件の再実行は同一結果になる。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=8.0, center=4.0, sigma=1.2)
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        first = run_outcome(job, config)
        second = run_outcome(job, config)

        assert isinstance(first, FitSuccess)
        assert isinstance(second, FitSuccess)
        assert first.parameters == second.parameters
        assert first.goodness == second.goodness


class TestShortCircuitPerStage:
    """各段階の失敗結果がそのまま処理単位の結果になり、以降の段階に進まないこと。"""

    def test_unresolvable_columns_stop_at_reading(self, tmp_path: Path) -> None:
        """列を解決できない場合は読み込みで止まる。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [GAUSSIAN],
            columns=(ColumnSpec(x="time", y="signal"),),
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.COLUMN_NOT_FOUND
        assert outcome.source_id == job.source
        assert outcome.method_name == "gauss"
        assert outcome.preprocess is None
        assert_no_outputs(config)

    def test_a_read_failure_returns_before_model_resolution(self, tmp_path: Path) -> None:
        """短絡の証拠。解決できない手法でも、読み込みが先に失敗すればそれが結果になる。

        解決まで進めば :class:`UnexpectedConfigViolation` が送出されるため、失敗結果が
        返ることは読み込みで止まったことを意味する。
        """
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [MethodSpec(name="unknown", kind="builtin", builtin="no_such_model")],
            columns=(ColumnSpec(x="time", y="signal"),),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.COLUMN_NOT_FOUND

    def test_insufficient_points_stop_at_preprocessing(self, tmp_path: Path) -> None:
        """点数不足は前処理で止まる。"""
        source = write_csv(tmp_path / "few.csv", [1.0, 2.0], [1.0, 2.0])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert outcome.preprocess is not None
        assert outcome.preprocess.n_used == 2
        assert_no_outputs(config)

    def test_a_fit_failure_becomes_the_result_as_is(self, tmp_path: Path) -> None:
        """スプラインは x の重複した系列に当てはめられない（非収束）。"""
        source = write_csv(
            tmp_path / "dup.csv",
            [1.0, 1.0, 2.0, 3.0, 4.0, 5.0],
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        )
        config = make_config(tmp_path / "out", [str(source)], [SPLINE])
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert outcome.source_id == job.source
        assert outcome.method_name == "sp"
        assert outcome.preprocess is not None
        assert_no_outputs(config)

    def test_the_non_convergence_report_keeps_the_initials_used(self, tmp_path: Path) -> None:
        """要件 4.7: 使用した初期値を報告する。

        :class:`~curvefit.types.FitFailure` は初期値の欄を持たないため、この層が説明に
        織り込まなければ報告が失われる。
        """

        def broken(x: np.ndarray, a: float) -> np.ndarray:
            return np.full(x.shape, np.nan)

        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [MethodSpec(name="broken", kind="callable", function=broken, initial={"a": 2.5})],
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert "a" in outcome.message
        assert "2.5" in outcome.message

    def test_no_valid_data_points_stops_at_reading(self, tmp_path: Path) -> None:
        """有効なデータ点がなければ読み込みで止まる。"""
        source = write_csv(tmp_path / "text.csv", ["a", "b"], ["c", "d"])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NO_VALID_DATA
        assert_no_outputs(config)


def random_arrays(n_points: int = 120, seed: int = 20260816) -> tuple[np.ndarray, np.ndarray]:
    """短い十進表記を持たない合成データ。

    **二進で厳密に表せる値では、経路の一致の主張が空になる。** そのような値は往復の
    丸めが正しくなくても元に戻るため、読み込みを省く経路と通す経路の差に対して
    構造的に盲目になる。x を 1000 付近の狭い幅に取り、当てはめを条件の悪い側に置く。
    """
    rng = np.random.default_rng(seed)
    x = np.sort(rng.uniform(1000.0, 1000.5, n_points))
    shifted = x - 1000.0
    y = 1.0 + 2.0 * shifted - 0.5 * shifted**2 + rng.normal(0.0, 1.0e-3, n_points)
    return x, y


def values(success: FitSuccess) -> dict[str, float]:
    return {estimate.name: estimate.value for estimate in success.parameters}


class TestAcceptingAPreloadedSeries:
    """要件 9.1、9.3: メモリ上の系列を、読み込み以降の同一手順にそのまま載せること。

    差込口は :class:`~curvefit.pipeline.Job` の ``series`` である。当てはめ専用の経路を
    作らず、省くのは読み込みの 1 段だけであることを、対照（系列を渡さない同一の処理単位）
    とファイル経由との厳密一致の双方で示す。
    """

    def _series(self, source_id: str = "memory", n_points: int = 41) -> DataSeries:
        x = np.linspace(1.0, 9.0, n_points)
        return DataSeries(source_id=source_id, x=x, y=gaussian_values(x, 10.0, 5.0, 1.0))

    def test_fits_without_reading(self, tmp_path: Path) -> None:
        """入力の位置に読めるものが無くても当てはめが成立すること。"""
        config = make_config(
            tmp_path / "out", [str(tmp_path / "無い.csv")], [GAUSSIAN], write_plot=False
        )
        series = self._series()
        job = series_job(GAUSSIAN, source=series.source_id, series=series)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.source_id == "memory"
        assert parameter(outcome, "center") == pytest.approx(5.0, abs=1e-6)
        assert parameter(outcome, "sigma") == pytest.approx(1.0, abs=1e-6)

    def test_the_same_job_without_a_series_fails_at_reading(self, tmp_path: Path) -> None:
        """対照。差込口が効いていなければ前の試験も同じ失敗になる（要件 1.8）。"""
        config = make_config(
            tmp_path / "out", [str(tmp_path / "無い.csv")], [GAUSSIAN], write_plot=False
        )
        job = series_job(GAUSSIAN)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INPUT_UNREADABLE

    def test_matches_the_file_path_bit_for_bit(self, tmp_path: Path) -> None:
        """要件 9.3: 読み込みを省いても値が動かないこと。全桁の乱数で確かめる。"""
        x, y = random_arrays()
        source = write_csv(tmp_path / "random.csv", x.tolist(), y.tolist())
        method = MethodSpec(
            name="poly", kind="builtin", builtin="polynomial", options={"degree": 3}
        )
        config = make_config(tmp_path / "out", [str(source)], [method], write_plot=False)

        from_file = run_outcome(single_job(config), config)
        from_memory = run_outcome(
            series_job(method, series=DataSeries(source_id="memory", x=x, y=y)),
            config,
        )

        assert isinstance(from_file, FitSuccess)
        assert isinstance(from_memory, FitSuccess)
        assert values(from_memory) == values(from_file)
        assert from_memory.goodness == from_file.goodness

    def test_matches_the_file_path_with_an_error_column_too(self, tmp_path: Path) -> None:
        """要件 1.3: 重みは σ の逆数として当てはめに効く。"""
        x, y = random_arrays(n_points=60)
        rng = np.random.default_rng(20260817)
        sigma = rng.lognormal(0.0, 1.0, x.size)
        source = write_csv(tmp_path / "weighted.csv", x.tolist(), y.tolist(), sigma.tolist())
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="y", weight="sigma"),),
            write_plot=False,
        )
        weights = 1.0 / sigma

        from_file = run_outcome(single_job(config), config)
        from_memory = run_outcome(
            series_job(LINEAR, series=DataSeries(source_id="memory", x=x, y=y, weights=weights)),
            config,
        )

        assert isinstance(from_file, FitSuccess)
        assert isinstance(from_memory, FitSuccess)
        assert values(from_memory) == values(from_file)

    def test_the_model_is_resolved_again_per_job(self, tmp_path: Path) -> None:
        """要件 4.1: 初期値の推定はその処理単位の系列から行われること。

        スケールの異なる 2 件がいずれも復元されることは、解決が使い回されていない
        ことを意味する（:class:`Test処理単位ごとのモデル解決` と同じ根拠）。
        """
        config = make_config(tmp_path / "out", [], [GAUSSIAN], write_plot=False)
        x_small = np.linspace(1.0, 9.0, 41)
        small = DataSeries(source_id="small", x=x_small, y=gaussian_values(x_small, 10.0, 5.0, 1.0))
        x_large = np.linspace(3800.0, 6200.0, 41)
        large = DataSeries(
            source_id="large", x=x_large, y=gaussian_values(x_large, 20000.0, 5000.0, 300.0)
        )

        outcomes = [
            run_outcome(
                series_job(GAUSSIAN, index=index, source=series.source_id, series=series),
                config,
            )
            for index, series in enumerate((small, large))
        ]

        assert all(isinstance(outcome, FitSuccess) for outcome in outcomes)
        assert parameter(outcomes[0], "center") == pytest.approx(5.0, rel=1e-6)  # type: ignore[arg-type]
        assert parameter(outcomes[1], "center") == pytest.approx(5000.0, rel=1e-6)  # type: ignore[arg-type]
        assert parameter(outcomes[1], "sigma") == pytest.approx(300.0, rel=1e-6)  # type: ignore[arg-type]

    def test_the_minimum_point_rule_applies_identically(self, tmp_path: Path) -> None:
        """要件 2.4、4.5: 前処理への供給も読み込みを省いた経路で同じであること。"""
        config = make_config(tmp_path / "out", [], [GAUSSIAN], write_plot=False)
        series = DataSeries(source_id="memory", x=np.array([1.0, 2.0]), y=np.array([1.0, 2.0]))

        outcome = run_outcome(
            series_job(GAUSSIAN, source=series.source_id, series=series), config
        )

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 3" in outcome.message

    def test_a_record_remains_for_methods_that_cannot_use_weights(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """誤差列の警告も読み込みを省いた経路で同じであること。

        対象は移動平均である。畳み込み係数は窓長と多項式次数だけで決まり、点ごとの
        重みを持ち込む場所が無い。
        """
        config = make_config(tmp_path / "out", [], [MOVING_AVERAGE], write_plot=False)
        x = np.linspace(1.0, 7.0, 7)
        series = DataSeries(
            source_id="memory", x=x, y=gaussian_values(x, 3.0, 4.0, 1.5), weights=np.ones(7)
        )

        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = run_outcome(
                series_job(MOVING_AVERAGE, source=series.source_id, series=series),
                config,
            )

        assert isinstance(outcome, FitSuccess)
        messages = [
            record.getMessage() for record in caplog.records if "重み" in record.getMessage()
        ]
        assert len(messages) == 1
        assert "memory" in messages[0]

    def test_no_output_is_written_even_when_the_outputs_are_enabled(
        self, tmp_path: Path
    ) -> None:
        """要件 9.1: この経路には名前を付ける出力物が無いこと。

        出力名の規則（要件 7.6）はファイル経路で固定する
        （:meth:`TestWiringOnSuccess.test_output_names_carry_the_job_index_and_never_overwrite_each_other`）。
        系列を直接渡された処理単位は出力先を持たず、フラグを有効にしても図も曲線 CSV も
        書かれないため、名前を確かめる対象そのものが存在しない。抑止の判断は
        :func:`~curvefit.pipeline._output_target` の 1 か所にある。
        """
        directory = tmp_path / "out"
        config = make_config(directory, [], [GAUSSIAN], write_plot=True, write_curve=True)
        series = self._series(source_id="実験A")
        job = series_job(GAUSSIAN, index=3, source=series.source_id, series=series)

        assert isinstance(run_outcome(job, config), FitSuccess)

        # 列を持たない経路でも名前の形は 1 通りである（列の位置に代替語が入る）。
        assert plot_path(config, job).name == "実験A__column__gauss__0003.png"
        assert not directory.exists()

    def test_the_series_is_excluded_from_job_identity(self) -> None:
        """処理単位を識別するのは対象・列・手法である。

        数値配列は要素ごとの比較を返すため、比較に含めると処理単位同士の比較が
        真偽値にならず :exc:`ValueError` になる。
        """
        with_series = series_job(GAUSSIAN, series=self._series())
        other = series_job(GAUSSIAN, series=self._series(n_points=61))
        without = series_job(GAUSSIAN)

        assert with_series == without
        assert with_series == other


class TestPerJobModelResolution:
    """要件 4.1: 組込モデルの初期値を、その対象のデータから推定する。"""

    def test_two_jobs_of_different_scale_both_converge(self, tmp_path: Path) -> None:
        """スケールの異なる2件がいずれも収束する。"""
        small = write_gaussian_csv(tmp_path / "small.csv", height=10.0, center=5.0, sigma=1.0)
        large = write_gaussian_csv(
            tmp_path / "large.csv", height=20000.0, center=5000.0, sigma=300.0
        )
        config = make_config(tmp_path / "out", [str(small), str(large)], [GAUSSIAN])

        outcomes = {}
        for job in expand_jobs(config):
            outcome = run_outcome(job, config)
            assert isinstance(outcome, FitSuccess)
            outcomes[Path(job.source).name] = outcome

        assert parameter(outcomes["small.csv"], "center") == pytest.approx(5.0, rel=1e-6)
        assert parameter(outcomes["small.csv"], "sigma") == pytest.approx(1.0, rel=1e-6)
        assert parameter(outcomes["large.csv"], "center") == pytest.approx(5000.0, rel=1e-6)
        assert parameter(outcomes["large.csv"], "sigma") == pytest.approx(300.0, rel=1e-6)

    def test_reusing_one_resolution_fails_to_recover_data_of_another_scale(
        self, tmp_path: Path
    ) -> None:
        """使い回しが成立しないことの実証。処理単位ごとに解決を呼び直す根拠である。

        小さいスケールのデータから推定した初期値のまま大きいスケールのデータに当てると、
        当てはめは初期値からほとんど動かず、中心も幅も復元されない。
        """
        x_small = np.linspace(1.0, 9.0, 41)
        small = DataSeries(
            source_id="small",
            x=x_small,
            y=gaussian_values(x_small, 10.0, 5.0, 1.0),
        )
        x_large = np.linspace(3800.0, 6200.0, 41)
        large = DataSeries(
            source_id="large",
            x=x_large,
            y=gaussian_values(x_large, 20000.0, 5000.0, 300.0),
        )

        shared = resolve(GAUSSIAN, sample=small)
        reused = select_engine(shared).fit(large, shared)

        recovered = {
            estimate.name: estimate.value for estimate in getattr(reused, "parameters", ())
        }
        assert recovered.get("center", 0.0) != pytest.approx(5000.0, rel=1e-3)


class TestMinimumPointDerivation:
    """前処理に渡す最小点数を、解決済み手法の推定パラメータ数から導出すること。"""

    def test_the_parameter_count_becomes_the_minimum_point_count(self, tmp_path: Path) -> None:
        """パラメータ数が最小点数になる。"""
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [1.0, 2.0])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 3" in outcome.message

    def test_a_method_with_fewer_parameters_passes_at_the_same_point_count(
        self, tmp_path: Path
    ) -> None:
        """同一データでも手法のパラメータ数によって判定が変わること。"""
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [2.0, 4.0])
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        assert parameter(outcome, "slope") == pytest.approx(2.0, abs=1e-9)

    def test_the_polynomial_degree_is_reflected_in_the_minimum(self, tmp_path: Path) -> None:
        """次数 4 の多項式回帰は係数 5 個を持つ。"""
        source = write_csv(tmp_path / "four.csv", [1.0, 2.0, 3.0, 4.0], [1.0, 2.0, 3.0, 4.0])
        method = MethodSpec(
            name="poly",
            kind="smoother",
            smoother=SmootherKind.POLYNOMIAL,
            options={"degree": 4},
        )
        config = make_config(tmp_path / "out", [str(source)], [method])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 5" in outcome.message

    def test_methods_without_parameters_still_require_at_least_one_point(
        self, tmp_path: Path
    ) -> None:
        """区間限定で 1 点も残らない場合、当てはめに進まず点数不足として報告する。"""
        source = write_csv(
            tmp_path / "range.csv",
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        )
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [SPLINE],
            preprocess=PreprocessSpec(x_min=100.0),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert outcome.preprocess is not None
        assert outcome.preprocess.n_used == 0


class TestFixedParametersAndTheMinimumPointCount:
    """要件 2.4、4.5: 最小点数は推定対象の数であり、固定したパラメータを含めない。"""

    FIXED_SIGMA = MethodSpec(name="gfix", kind="builtin", builtin="gaussian", fixed={"sigma": 1.0})
    """``sigma`` を固定したガウシアン。パラメータ名は 3 個だが推定対象は 2 個である。"""

    def test_fixed_parameters_are_not_counted_toward_the_minimum(self, tmp_path: Path) -> None:
        """固定した分まで数えると、当てはめられる処理単位が点数不足と誤報される。

        同じデータと同じ解決済みモデルで当てはめは成立する（推定対象は 2 個）。
        """
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [3.0, 5.0])
        config = make_config(tmp_path / "out", [str(source)], [self.FIXED_SIGMA])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.goodness.n_points == 2
        assert outcome.goodness.n_varied_params == 2
        assert parameter(outcome, "sigma") == pytest.approx(1.0, abs=1e-12)

    def test_the_varied_parameter_count_acts_as_the_lower_bound(self, tmp_path: Path) -> None:
        """固定しても推定対象が 2 個であることは変わらず、1 点では点数不足になる。"""
        source = write_csv(tmp_path / "one.csv", [1.0], [3.0])
        config = make_config(tmp_path / "out", [str(source)], [self.FIXED_SIGMA])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 2" in outcome.message
        assert_no_outputs(config)

    def test_without_fixing_the_same_data_is_short_of_points(self, tmp_path: Path) -> None:
        """対照。固定の有無だけで判定が変わることを、同一データで示す。"""
        source = write_csv(tmp_path / "two.csv", [1.0, 2.0], [3.0, 5.0])
        config = make_config(tmp_path / "out", [str(source)], [GAUSSIAN])

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert "必要な点数 3" in outcome.message


class TestProvisionalFitForOutlierRemoval:
    """暫定当てはめの手段をこの層がコールバックとして供給すること（要件 2.3）。"""

    def test_outliers_are_removed_and_their_count_and_position_recorded(
        self, tmp_path: Path
    ) -> None:
        """外れ値が除去され件数と位置が記録される。"""
        x = np.linspace(0.0, 19.0, 20)
        y = 2.0 * x + 1.0
        y[7] = y[7] + 300.0
        source = write_csv(tmp_path / "outlier.csv", x.tolist(), y.tolist())
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=3.0, max_iterations=3)),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitSuccess)
        # 混入させた点が最初の反復で除外されること。以降の反復では、外れ値を除いた
        # 残差が丸め誤差の水準まで小さくなり、その中の相対的な突出が除外されうる
        # （`OutlierSpec.sigma` の非ロバストな尺度）。除外の総数は固定しない。
        assert outcome.preprocess.outlier_points[0].x == 7.0
        assert outcome.preprocess.n_dropped_outlier == len(outcome.preprocess.outlier_points)
        assert outcome.goodness.n_points == 20 - outcome.preprocess.n_dropped_outlier
        assert parameter(outcome, "slope") == pytest.approx(2.0, abs=1e-9)

    def test_a_non_converging_provisional_fit_proceeds_with_zero_removals(
        self, tmp_path: Path
    ) -> None:
        """当てはめの失敗を ``None`` として前処理層に伝える経路（設計の Risks）。

        x の重複した系列にスプラインは当てはめられない。暫定当てはめは失敗を値
        （`EngineFailure`）で返し、この層はそれを ``None`` に写して渡す。前処理層は
        除去をスキップし、当てはめまで進む。例外として投げ直すと、前処理層は実装上の
        誤りと非収束を見分けられなくなる。
        """
        source = write_csv(
            tmp_path / "dup.csv",
            [1.0, 1.0, 2.0, 3.0, 4.0, 5.0],
            [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        )
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [SPLINE],
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=3.0, max_iterations=3)),
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert outcome.preprocess is not None
        assert outcome.preprocess.n_dropped_outlier == 0
        assert outcome.preprocess.n_used == 6


class TestRecordForMethodsThatCannotUseWeights:
    """誤差列があるのに重みを使えない手法が選ばれた場合、実行ログに残すこと。"""

    def _weighted_source(self, tmp_path: Path) -> Path:
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
        y = [1.0, 2.1, 2.9, 4.2, 5.1, 5.8, 7.2]
        return write_csv(tmp_path / "weighted.csv", x, y, [1.0] * len(x))

    def _run(
        self, tmp_path: Path, method: MethodSpec, caplog: pytest.LogCaptureFixture
    ) -> list[str]:
        source = self._weighted_source(tmp_path)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [method],
            columns=(ColumnSpec(x="x", y="y", weight="sigma"),),
        )
        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = run_outcome(single_job(config), config)
        assert isinstance(outcome, FitSuccess)
        return [
            record.getMessage()
            for record in caplog.records
            if record.name == LOGGER_NAME and "重み" in record.getMessage()
        ]

    def test_a_record_remains_for_the_moving_average(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """移動平均では記録が残る。"""
        messages = self._run(tmp_path, MOVING_AVERAGE, caplog)
        assert len(messages) == 1
        assert "ma" in messages[0]
        assert "weighted.csv" in messages[0]

    def test_the_warning_reason_comes_from_the_same_source_as_the_preflight_gate(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """理由の文言が 2 か所に書かれていないこと（要件 1.3、1.10）。

        実行前ゲートの違反文と実行ログの警告文が別々に書かれていた頃、Savitzky-Golay の
        誤った説明を訂正した際に片方だけが直り、利用者に出る警告には撤回した説明が
        残った。文言の所有は宣言と同じ場所（``engines.smoothing``）に 1 つだけ置く。
        """
        messages = self._run(tmp_path, MOVING_AVERAGE, caplog)

        assert len(messages) == 1
        assert NO_WEIGHT_SUPPORT_REASONS[SmootherKind.MOVING_AVERAGE] in messages[0], (
            "警告の理由が宣言側の文言と一致していない（二重所有に戻っている）"
        )

    def test_no_record_remains_for_the_spline(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """要件 1.3: スプラインは重みを反映するため、無視した旨を記録してはならない。

        記録が残ると、実際には推定に効いている重みを利用者が「効いていない」と読む。
        """
        assert self._run(tmp_path, SPLINE, caplog) == []

    def test_no_record_remains_for_linear_regression(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """線形回帰では記録が残らない。"""
        assert self._run(tmp_path, SMOOTHER_LINEAR, caplog) == []

    def test_no_record_remains_for_polynomial_regression(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """多項式回帰では記録が残らない。"""
        assert self._run(tmp_path, SMOOTHER_POLYNOMIAL, caplog) == []

    def test_no_record_remains_for_a_model_function_fit(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """モデル関数フィットでは記録が残らない。"""
        assert self._run(tmp_path, LINEAR, caplog) == []

    def test_no_record_remains_without_an_error_column(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """誤差列がなければ記録は残らない。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(tmp_path / "out", [str(source)], [SPLINE])
        with caplog.at_level(logging.WARNING, logger=LOGGER_NAME):
            outcome = run_outcome(single_job(config), config)
        assert isinstance(outcome, FitSuccess)
        assert [r for r in caplog.records if "重み" in r.getMessage()] == []


class TestRelayingOfAppliedDefaults:
    """要件 5.4: 当てはめが補った既定値を `JobResult` として呼び出し元へ渡すこと。

    どの選択肢に既定値が効いたかを決めるのは当てはめ層である（`_int_option`）。この層が
    運ばなければ、実行条件の記録（`execution.collect_applied_defaults`）に渡す材料が
    どこにも存在せず、要件 5.4 の「適用した値を実行条件として記録する」が満たせない。
    期待値は `SMOOTHER_OPTION_DEFAULTS` から読む。ここに値を書き写すと、既定値の所有が
    当てはめ層と試験の 2 か所に分かれる。
    """

    def _linear_source(self, tmp_path: Path, n_points: int = 10) -> Path:
        x = np.linspace(0.0, float(n_points - 1), n_points)
        return write_csv(tmp_path / "line.csv", x.tolist(), (2.0 * x + 1.0).tolist())

    def _run(
        self,
        tmp_path: Path,
        method: MethodSpec,
        *,
        n_points: int = 10,
        columns: Sequence[ColumnSpec] | None = None,
        preprocess: PreprocessSpec | None = None,
    ) -> JobResult:
        source = self._linear_source(tmp_path, n_points)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [method],
            columns=columns,
            preprocess=preprocess,
            write_plot=False,
        )
        return run_job(single_job(config), config)

    def test_moving_average_defaults_reach_the_caller(self, tmp_path: Path) -> None:
        """移動平均の既定値が呼び出し元に届く。"""
        result = self._run(tmp_path, MOVING_AVERAGE)

        assert isinstance(result.outcome, FitSuccess)
        expected = dict(SMOOTHER_OPTION_DEFAULTS[SmootherKind.MOVING_AVERAGE])
        assert expected  # 既定値を持つ手法であることの裏取り
        assert dict(result.applied_defaults) == expected

    def test_the_defaults_are_immutable(self, tmp_path: Path) -> None:
        """記録が実行と食い違わないよう、返した写像は凍結する。"""
        result = self._run(tmp_path, MOVING_AVERAGE)
        name = next(iter(SMOOTHER_OPTION_DEFAULTS[SmootherKind.MOVING_AVERAGE]))

        with pytest.raises(TypeError):
            result.applied_defaults[name] = 99  # type: ignore[index]

    def test_explicitly_given_options_are_not_recorded_as_defaults(self, tmp_path: Path) -> None:
        """記録に載せるのは「利用者が書いていないのに効いた値」だけである。"""
        defaults = SMOOTHER_OPTION_DEFAULTS[SmootherKind.MOVING_AVERAGE]
        explicit = MethodSpec(
            name="ma7",
            kind="smoother",
            smoother=SmootherKind.MOVING_AVERAGE,
            options={MOVING_AVERAGE_WINDOW_OPTION: 7},
        )

        result = self._run(tmp_path, explicit)

        assert isinstance(result.outcome, FitSuccess)
        assert MOVING_AVERAGE_WINDOW_OPTION not in result.applied_defaults
        assert dict(result.applied_defaults) == {
            name: value for name, value in defaults.items() if name != MOVING_AVERAGE_WINDOW_OPTION
        }

    def test_the_polynomial_regression_degree_default_arrives(self, tmp_path: Path) -> None:
        """多項式回帰の次数の既定値が届く。"""
        result = self._run(tmp_path, SMOOTHER_POLYNOMIAL)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == dict(
            SMOOTHER_OPTION_DEFAULTS[SmootherKind.POLYNOMIAL]
        )

    def test_the_spline_has_no_default(self, tmp_path: Path) -> None:
        """平滑化量に既定値は無い。未指定は実行前ゲートが拒否する（要件 5.5）。

        利用者が明示した値を ``applied_defaults`` に載せないことを併せて示している。
        載せると、実行条件の記録から「書いていないのに効いた値」を区別できなくなる。
        """
        result = self._run(tmp_path, SPLINE)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {}
        assert dict(SMOOTHER_OPTION_DEFAULTS[SmootherKind.SPLINE]) == {}

    def test_builtin_models_without_options_have_no_default(self, tmp_path: Path) -> None:
        """選択肢を持たない組込モデルは既定値を持たない。"""
        result = self._run(tmp_path, LINEAR)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {}

    def test_the_builtin_model_degree_default_arrives(self, tmp_path: Path) -> None:
        """要件 5.4 は手法の書き方を問わない。組込の多項式も次数の既定値を持つ。"""
        result = self._run(tmp_path, BUILTIN_POLYNOMIAL)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {
            POLYNOMIAL_DEGREE_OPTION: DEFAULT_POLYNOMIAL_DEGREE
        }

    def test_a_builtin_model_with_an_explicit_degree_records_no_default(
        self, tmp_path: Path
    ) -> None:
        """次数を明示した組込モデルは既定値を記録しない。"""
        explicit = MethodSpec(
            name="bpoly3",
            kind="builtin",
            builtin="polynomial",
            options={POLYNOMIAL_DEGREE_OPTION: 3},
        )
        result = self._run(tmp_path, explicit)

        assert isinstance(result.outcome, FitSuccess)
        assert dict(result.applied_defaults) == {}

    def test_the_same_user_input_records_identically_regardless_of_how_the_method_is_written(
        self, tmp_path: Path
    ) -> None:
        """要件 8.5: 記録が実行を説明するには、同じ入力に同じ記録が対応する必要がある。

        「多項式・次数の指定なし」という同一の利用者入力を、組込モデルと平滑化手法の
        両方の書き方で与える。片方だけが記録すると、記録の意味が書き方に依存する。
        """
        builtin = self._run(tmp_path, BUILTIN_POLYNOMIAL)
        smoother = self._run(tmp_path, SMOOTHER_POLYNOMIAL)

        assert isinstance(builtin.outcome, FitSuccess)
        assert isinstance(smoother.outcome, FitSuccess)
        assert dict(builtin.applied_defaults) == dict(smoother.applied_defaults)
        assert dict(builtin.applied_defaults)  # 双方が空では一致に意味がない

    def test_nothing_is_recorded_when_reading_fails(self, tmp_path: Path) -> None:
        """読み込みで失敗した場合は記録しない。"""
        result = self._run(
            tmp_path, MOVING_AVERAGE, columns=(ColumnSpec(x="time", y="signal"),)
        )

        assert isinstance(result.outcome, FitFailure)
        assert result.outcome.reason is FailureReason.COLUMN_NOT_FOUND
        assert dict(result.applied_defaults) == {}

    def test_nothing_is_recorded_when_preprocessing_fails(self, tmp_path: Path) -> None:
        """前処理で失敗した場合は記録しない。"""
        result = self._run(tmp_path, MOVING_AVERAGE, preprocess=PreprocessSpec(x_min=100.0))

        assert isinstance(result.outcome, FitFailure)
        assert result.outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert dict(result.applied_defaults) == {}

    def test_nothing_is_recorded_when_fitting_fails(self, tmp_path: Path) -> None:
        """窓長に満たない点数では当てはめが失敗する。

        当てはめ層は失敗を返す前に既定値を読み取っている。それでも記録が空になるのは、
        既定値が実際に効いた当てはめが存在しないためである。
        """
        result = self._run(tmp_path, MOVING_AVERAGE, n_points=3)

        assert isinstance(result.outcome, FitFailure)
        assert result.outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert dict(result.applied_defaults) == {}


class TestMethodThatSkippedPreflight:
    """`resolve` が違反を返すのは実行前ゲートを通っていない場合に限る。"""

    def test_an_unresolvable_method_is_raised_as_a_violation(self, tmp_path: Path) -> None:
        """解決できない手法は違反として送出される。"""
        source = write_gaussian_csv(tmp_path / "peak.csv", height=3.0, center=2.0, sigma=0.5)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [MethodSpec(name="unknown", kind="builtin", builtin="no_such_model")],
        )

        with pytest.raises(UnexpectedConfigViolation) as error:
            run_job(single_job(config), config)

        assert error.value.violations
        assert "no_such_model" in str(error.value)
        assert_no_outputs(config)


# --- 前処理 CSV の書き出し（要件 2.5、9.1）------------------------------------------


def preprocess_path(config: RunConfig, job: Job) -> Path:
    stem = build_output_stem(job.source, job.column_label, job.method.name, job.index)
    return config.output.directory / PREPROCESS_SUBDIRECTORY / f"{stem}.csv"


def preprocess_rows(path: Path) -> tuple[tuple[str, ...], list[list[str]]]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        return tuple(next(reader)), list(reader)


def write_outlier_csv(path: Path, *, spike: bool, n_points: int = 20) -> Path:
    """既知の直線に微小なばらつきを載せた系列。``spike`` で 1 点だけ突出させる。

    ばらつきを 0 にしない。残差が丸め誤差の水準になると、その中の相対的な突出が
    外れ値として除外されうる（``OutlierSpec.sigma`` の非ロバストな尺度）。
    """
    x = [float(index) * 0.5 for index in range(n_points)]
    y = [2.0 * value + 1.0 + (0.01 if index % 2 == 0 else -0.01) for index, value in enumerate(x)]
    if spike:
        y[7] += 300.0
    return write_csv(path, x, y)


def write_collapsing_csv(path: Path, n_points: int = 8) -> Path:
    """外れ値を除いた結果として点数不足に落ちる系列（要件 2.4、2.5）。"""
    x = [float(index) for index in range(n_points)]
    y = [2.0 * value + 1.0 for value in x]
    y[2] += 50.0
    y[5] -= 40.0
    return write_csv(path, x, y)


OUTLIER = PreprocessSpec(outlier=OutlierSpec(sigma=3.0, max_iterations=3))
"""既定の閾値。20 点の系列で単一の突出を除去できる規模である。"""

AGGRESSIVE_OUTLIER = PreprocessSpec(outlier=OutlierSpec(sigma=1.0, max_iterations=3))
"""8 点の系列で判定を効かせる閾値（``OutlierSpec.sigma`` の盲点: ``n <= sigma**2``）。"""

POLYNOMIAL_4 = MethodSpec(name="poly4", kind="builtin", builtin="polynomial", options={"degree": 4})
"""推定対象 5 個。8 点から 4 点が除外されると点数不足になる。"""


class TestPreprocessCsvWriting:
    """要件 2.5: 外れ値として除外した各点を、処理対象を識別できる形で記録すること。

    **この出力だけが「出力物を書き出すのは成功した場合に限る」から外れる。** 図と曲線
    CSV は当てはめの結果だが、前処理 CSV は前処理が何をしたかの説明であり、当てはめの
    成否とは独立に成立する。
    """

    def test_written_for_a_succeeding_job(self, tmp_path: Path) -> None:
        """成功した処理単位に書かれる。"""
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 1
        header, rows = preprocess_rows(preprocess_path(config, job))
        assert header == PREPROCESS_COLUMNS
        assert rows == [[repr(3.5), repr(307.99), "1"]]

    def test_written_exactly_once_per_job(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """書き出しの地点が 2 つあるため、どちらも通る形になっていないこと（要件 2.5）。

        成功する場合は当てはめ結果より先に :func:`_run_stages` の中で書き、それ以外は
        :func:`run_job` が書く。2 地点が排他でなくなると、同じ内容を 2 度書く（無駄な
        書き込み）か、どちらも通らない（記録の欠落）。前者は内容が同じであるため
        出力を見ても気付けない。

        逆向きの退行（どちらも通らない）は、この検査が 0 回を捉えることで塞ぐ。
        """
        calls: list[str] = []
        original = pipeline_module.write_preprocess

        def counting(outcome: FitOutcome, path: Path) -> None:
            calls.append(type(outcome).__name__)
            original(outcome, path)

        monkeypatch.setattr(pipeline_module, "write_preprocess", counting)

        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess), "成功する入力でなければ 2 地点を試せない"
        assert calls == ["FitSuccess"], f"書き出しが {len(calls)} 回になっている"

    def test_written_for_a_job_that_failed_in_preprocessing(self, tmp_path: Path) -> None:
        """外れ値を除いた結果として点数不足で落ちる場合こそ、除外点を知りたい場面である。"""
        source = write_collapsing_csv(tmp_path / "spike.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [POLYNOMIAL_4],
            preprocess=AGGRESSIVE_OUTLIER,
            write_plot=False,
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        header, rows = preprocess_rows(preprocess_path(config, job))
        assert header == PREPROCESS_COLUMNS
        assert len(rows) == outcome.preprocess.n_dropped_outlier
        # 意図的に外した 2 点が記録されていること。実測値は入力の y そのままである。
        recorded = {float(row[0]): float(row[1]) for row in rows}
        assert recorded[2.0] == 55.0
        assert recorded[5.0] == -29.0

    def test_written_for_a_job_that_failed_in_fitting(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """3 つ目の返り口（エンジンの失敗）も同じ書き出しを通ること。

        暫定当てはめと本当てはめは同じエンジンを通るため、収束する暫定当てはめの後で
        本当てはめだけが失敗する系列は作れない。前処理を終えた後の 1 回だけを失敗に
        差し替えて、返り口ごとの取りこぼしがないことを見る。
        """
        real_preprocess = pipeline_module.apply_preprocess
        state = {"armed": False}

        class _FailAfterPreprocess:
            def __init__(self, inner: object) -> None:
                self.inner = inner

            def fit(self, series: DataSeries, method: object) -> object:
                if state["armed"]:
                    return EngineFailure(reason=FailureReason.NOT_CONVERGED, message="試験用の失敗")
                return self.inner.fit(series, method)  # type: ignore[attr-defined]

        def wrapped_preprocess(*args: object, **kwargs: object) -> object:
            result = real_preprocess(*args, **kwargs)
            state["armed"] = True
            return result

        monkeypatch.setattr(
            pipeline_module,
            "select_engine",
            lambda method: _FailAfterPreprocess(select_engine(method)),
        )
        monkeypatch.setattr(pipeline_module, "apply_preprocess", wrapped_preprocess)

        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        _, rows = preprocess_rows(preprocess_path(config, job))
        assert rows == [[repr(3.5), repr(307.99), "1"]]

    def test_not_created_when_nothing_was_excluded(self, tmp_path: Path) -> None:
        """存在そのものが「この対象には除外があった」を意味する形にする。"""
        source = write_outlier_csv(tmp_path / "steady.csv", spike=False)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 0
        assert not preprocess_path(config, job).exists()
        # 下位ディレクトリも作らない。書かない対象のために階層を作ると、除外のあった
        # 対象を探す手掛かりが消える。
        assert not (config.output.directory / PREPROCESS_SUBDIRECTORY).exists()

    def test_not_created_when_outlier_removal_is_disabled(self, tmp_path: Path) -> None:
        """外れ値除去が無効なら作らない。"""
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(tmp_path / "out", [str(source)], [LINEAR], write_plot=False)
        job = single_job(config)

        assert isinstance(run_outcome(job, config), FitSuccess)
        assert not (config.output.directory / PREPROCESS_SUBDIRECTORY).exists()

    def test_not_created_for_failures_before_preprocessing(self, tmp_path: Path) -> None:
        """読み込みで止まった処理単位は ``preprocess`` を持たない（要件 1.4）。"""
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x="time", y="signal"),),
            preprocess=OUTLIER,
            write_plot=False,
        )

        outcome = run_outcome(single_job(config), config)

        assert isinstance(outcome, FitFailure)
        assert outcome.preprocess is None
        assert_no_outputs(config)

    def test_not_written_for_a_job_given_a_series_directly(self, tmp_path: Path) -> None:
        """要件 9.1、9.3: 出力先を持たない経路が利用者の領域に書き込まないこと。

        `api.fit_series` の出力先は共有の一時領域である。この出力はオプトインの
        フラグを持たないため、抑止の軸は `Job.series` の有無に置く。
        """
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        directory = tmp_path / "out"
        directory.mkdir()
        config = make_config(
            directory, [str(source)], [LINEAR], preprocess=OUTLIER, write_plot=False
        )
        loaded = read_delimited(
            source, config.inputs.columns[0], None, True, method_name=LINEAR.name
        )
        assert isinstance(loaded, DataSeries)
        job = series_job(LINEAR, series=loaded)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 1
        assert list(directory.rglob("*")) == []


class TestOutputSuppressionHasASingleAxis:
    """要件 7.4、7.5、9.1: 出力を書くか否かの判断を 1 か所に集めること。

    抑止は 2 つの軸に分かれていた。**系列を直接渡された処理単位**（出力先を持たない。
    :attr:`~curvefit.pipeline.Job.series`）と、**出力ごとの有効化フラグ**
    （:class:`~curvefit.config.OutputSpec`）である。前者だけを見る出力（前処理 CSV）と
    後者だけを見る出力（図・曲線 CSV）が並存すると、系列を直接渡す経路が何も書かない
    根拠が出力ごとに別々になる。実際、その経路で図と曲線 CSV が書かれないのは
    ``api.fit_series`` がフラグを 3 つとも切っているからにすぎず、フラグの既定値が
    変わるか、フラグを持たない出力が足されるだけで利用者の一時領域に書き込む。

    両軸を単一の判断に通し、**片方の軸だけを壊す変異でこの検査が落ちる**ようにする。
    系列の軸を壊せば :meth:`test_a_series_job_writes_nothing_even_with_every_output_enabled`
    と :meth:`test_a_series_job_does_not_touch_an_unwritable_output_directory` が、
    フラグの軸を壊せば :meth:`test_a_file_job_still_obeys_the_output_flags` と
    :meth:`test_a_file_job_writes_the_outputs_that_are_enabled` が落ちる。
    """

    def _series_job(self, source: Path, config: RunConfig) -> Job:
        """ファイルから読んだ系列を、処理単位に直接載せる（``api.fit_series`` と同じ形）。"""
        loaded = read_delimited(
            source, config.inputs.columns[0], None, True, method_name=LINEAR.name
        )
        assert isinstance(loaded, DataSeries)
        return series_job(LINEAR, series=loaded)

    def test_a_series_job_writes_nothing_even_with_every_output_enabled(
        self, tmp_path: Path
    ) -> None:
        """要件 9.1: 出力先を持たない経路は、フラグの状態によらず何も書かないこと。

        フラグをすべて有効にしても出力ディレクトリ自体が作られない。フラグが偽である
        ことに依存した抑止では、この条件で図と曲線 CSV が書き出される。
        """
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        directory = tmp_path / "out"
        config = make_config(
            directory,
            [str(source)],
            [LINEAR],
            preprocess=OUTLIER,
            write_plot=True,
            write_curve=True,
        )
        job = self._series_job(source, config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 1, "除外 0 件では検査が空振りする"
        assert not directory.exists()

    def test_a_series_job_does_not_touch_an_unwritable_output_directory(
        self, tmp_path: Path
    ) -> None:
        """要件 9.1、10.3: 書き込めない出力先でも当てはめが成立すること。

        出力先の親を通常ファイルにして、**実際に書き込み不能な状況**を作る。書き出しを
        試みれば本物の :exc:`OSError` が出て（要件 10.3 の中断源）当てはめが成立しない。
        出力を書く関数を新たに足したときに、この検査が落ちて気付ける形にしてある。
        """
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        blocker = tmp_path / "blocker"
        blocker.write_text("ディレクトリではない", encoding="utf-8")
        config = make_config(
            blocker / "out",
            [str(source)],
            [LINEAR],
            preprocess=OUTLIER,
            write_plot=True,
            write_curve=True,
        )
        job = self._series_job(source, config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert outcome.preprocess.n_dropped_outlier == 1
        assert blocker.read_text(encoding="utf-8") == "ディレクトリではない"

    def test_a_file_job_still_obeys_the_output_flags(self, tmp_path: Path) -> None:
        """要件 7.5: ファイル経路では従来どおりフラグが効くこと。

        フラグを切れば図も曲線 CSV も書かれない。一方で前処理 CSV はフラグを持たない
        出力であり（要件 2.5）、同じ条件で書かれる。系列の軸に寄せる際に、フラグを
        持たない出力までフラグへ結び付けると後半が落ちる。
        """
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            preprocess=OUTLIER,
            write_plot=False,
            write_curve=False,
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert not plot_path(config, job).exists()
        assert not curve_path(config, job).exists()
        assert preprocess_path(config, job).is_file()

    def test_a_file_job_writes_the_outputs_that_are_enabled(self, tmp_path: Path) -> None:
        """要件 7.4、7.5: 有効にした出力はファイル経路で書かれること（対照）。"""
        source = write_outlier_csv(tmp_path / "noisy.csv", spike=True)
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            preprocess=OUTLIER,
            write_plot=True,
            write_curve=True,
        )
        job = single_job(config)

        outcome = run_outcome(job, config)

        assert isinstance(outcome, FitSuccess)
        assert plot_path(config, job).is_file()
        assert curve_path(config, job).is_file()
        assert preprocess_path(config, job).is_file()


# --- 列識別子の刻印（要件 1.4、1.5、7.3、7.6）----------------------------------------


def write_named_channel_csv(path: Path, *, n_points: int = 11) -> Path:
    """見出し行 ``x,signal`` を持つ直線データ。

    **指定の綴りと見出し名を別の文字列にするために使う。** 位置で指定すれば綴りは
    ``"1"``、見出し名は ``"signal"`` になり、片方をもう片方で代用した実装がこの差で
    露見する。
    """
    x = [float(index) for index in range(n_points)]
    y = [2.0 * value + 1.0 for value in x]
    lines = ["x,signal"]
    lines.extend(f"{x_value!r},{y_value!r}" for x_value, y_value in zip(x, y, strict=True))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def identity_of(outcome: FitOutcome) -> tuple[str | None, str | None]:
    """結果に刻まれた列の 2 識別子（指定の綴り、解決後の見出し名）。"""
    return (outcome.column_label, outcome.column_name)


class TestColumnIdentityOnEveryOutcome:
    """要件 1.4、1.5、7.3、7.6: どの返り口を通った結果にも列の識別子を刻むこと。

    2 つの識別子は役割が違う（設計の types の Invariants）。**指定の綴り**
    （``column_label``）は利用者が書いた列名または位置であり、ファイルを読む前に確定
    するため、読み込みに至らない失敗にも載る。**解決後の見出し名**（``column_name``）は
    読み込めた系列からしか分からず、載らない場合がある。

    型はこの 2 欄に既定値 ``None`` を持つ（設計の types: 既定値を外すと構築地点 82 か所に
    波及する）。**したがって刻む処理を丸ごと削っても型は黙って通る。** 実際に埋まって
    いることは振る舞い側で押さえるほかなく、本クラスがその役目を負う。刻印を素通しに
    する変異では、本クラスの検査が返り口ごとに落ちる。
    """

    def _outcome(
        self,
        tmp_path: Path,
        source: Path,
        columns: ColumnSpec,
        method: MethodSpec = LINEAR,
        *,
        header: bool | None = None,
    ) -> FitOutcome:
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [method],
            columns=(columns,),
            write_plot=False,
            header=header,
        )
        return run_outcome(single_job(config), config)

    def test_a_success_carries_the_spelling_and_the_header_name(self, tmp_path: Path) -> None:
        """要件 7.3、7.6: 成功した結果は綴りと見出し名の双方を持つ。

        位置で指定しているため綴りは ``"1"`` である。見出し名 ``"signal"`` は読み込みが
        解決したものであり、綴りからは導けない。
        """
        source = write_named_channel_csv(tmp_path / "a.csv")

        outcome = self._outcome(tmp_path, source, ColumnSpec(x=0, y=1))

        assert isinstance(outcome, FitSuccess)
        assert identity_of(outcome) == ("1", "signal")

    def test_a_name_specification_carries_the_same_string_in_both(self, tmp_path: Path) -> None:
        """列名で指定した場合、綴りと見出し名は同じ文字列になる（対照）。"""
        source = write_named_channel_csv(tmp_path / "a.csv")

        outcome = self._outcome(tmp_path, source, ColumnSpec(x="x", y="signal"))

        assert isinstance(outcome, FitSuccess)
        assert identity_of(outcome) == ("signal", "signal")

    def test_an_unresolvable_column_failure_carries_the_spelling_only(
        self, tmp_path: Path
    ) -> None:
        """要件 1.4: 列を解決できない失敗にも、解決できなかった綴りが載る。

        見出し名は存在しないため ``None`` である。この失敗が**ファイル単位ではなく
        処理対象単位**で記録されることは、綴りが載ることで示される。
        """
        source = write_named_channel_csv(tmp_path / "a.csv")

        outcome = self._outcome(tmp_path, source, ColumnSpec(x="x", y="missing"))

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.COLUMN_NOT_FOUND
        assert identity_of(outcome) == ("missing", None)

    def test_a_no_valid_data_failure_carries_the_spelling(self, tmp_path: Path) -> None:
        """要件 1.5: 有効なデータ点が 1 件も無い失敗も、処理対象単位で識別できる。"""
        source = write_csv(tmp_path / "text.csv", ["a", "b"], ["c", "d"])

        outcome = self._outcome(tmp_path, source, ColumnSpec(x="x", y="y"))

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NO_VALID_DATA
        assert identity_of(outcome) == ("y", None)

    def test_an_unreadable_input_failure_carries_the_spelling(self, tmp_path: Path) -> None:
        """要件 1.8: 読み込みに至らない失敗にも綴りは載る。

        綴りはファイルを読む前に確定しているため、読み込みが 1 バイトも進まなくても
        報告できる。
        """
        outcome = self._outcome(tmp_path, tmp_path / "missing.csv", ColumnSpec(x="x", y="y"))

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INPUT_UNREADABLE
        assert identity_of(outcome) == ("y", None)

    def test_a_header_ambiguous_failure_carries_the_spelling(self, tmp_path: Path) -> None:
        """要件 1.7: 見出し行の有無が定まらない失敗にも綴りは載る。"""
        source = write_csv(tmp_path / "raw.csv", [0.0, 1.0, 2.0], [1.0, 3.0, 5.0])
        source.write_text("0.0,1.0\n1.0,3.0\n2.0,5.0\n", encoding="utf-8")

        outcome = self._outcome(tmp_path, source, ColumnSpec(x=0, y=1))

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.HEADER_AMBIGUOUS
        assert identity_of(outcome) == ("1", None)

    def test_a_preprocess_failure_carries_both_identifiers(self, tmp_path: Path) -> None:
        """要件 2.4: 前処理で止まった失敗は、読み込めているため見出し名も持つ。"""
        source = write_named_channel_csv(tmp_path / "few.csv", n_points=2)

        outcome = self._outcome(tmp_path, source, ColumnSpec(x=0, y=1), GAUSSIAN)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INSUFFICIENT_POINTS
        assert identity_of(outcome) == ("1", "signal")

    def test_a_fit_failure_carries_both_identifiers(self, tmp_path: Path) -> None:
        """要件 4.7: 当てはめで止まった失敗も同じ規則で埋まる。"""
        source = tmp_path / "dup.csv"
        source.write_text(
            "x,signal\n1.0,1.0\n1.0,2.0\n2.0,3.0\n3.0,4.0\n4.0,5.0\n5.0,6.0\n", encoding="utf-8"
        )

        outcome = self._outcome(tmp_path, source, ColumnSpec(x=0, y=1), SPLINE)

        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.NOT_CONVERGED
        assert identity_of(outcome) == ("1", "signal")

    def test_a_headerless_input_carries_no_header_name(self, tmp_path: Path) -> None:
        """要件 1.6、7.3: 見出しを持たない入力では見出し名が空になる。綴りは載る。"""
        source = tmp_path / "raw.csv"
        source.write_text("0.0,1.0\n1.0,3.0\n2.0,5.0\n3.0,7.0\n", encoding="utf-8")

        outcome = self._outcome(tmp_path, source, ColumnSpec(x=0, y=1), header=False)

        assert isinstance(outcome, FitSuccess)
        assert identity_of(outcome) == ("1", None)

    def test_a_series_job_carries_neither_identifier(self, tmp_path: Path) -> None:
        """要件 9.1: 系列を直接渡す経路では双方が空になる。

        渡された系列が見出し名を持っていても載せない。この経路は列の概念を持たず
        （:func:`~curvefit.pipeline._series_jobs` が綴りを付けない）、見出し名だけが
        載る状態は型の不変条件（見出し名を持つなら綴りも持つ）に反する。
        """
        source = write_named_channel_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(source)], [LINEAR], write_plot=False)
        loaded = read_delimited(source, ColumnSpec(x=0, y=1), None, True, method_name=LINEAR.name)
        assert isinstance(loaded, DataSeries)
        assert loaded.column_name == "signal", "見出し名を持たない系列では検査が空振りする"

        outcome = run_outcome(series_job(LINEAR, series=loaded), config)

        assert isinstance(outcome, FitSuccess)
        assert identity_of(outcome) == (None, None)


class TestColumnIdentityIsStampedInOnePlace:
    """要件 7.3、7.6: 列識別子を刻む規則を 1 か所に閉じること。

    返り口は 5 つある（読み込み不能・読み込みの失敗・前処理の失敗・当てはめの失敗・
    成功）。返り口ごとに刻むと、返り口を 1 つ足したときに刻み忘れが生まれ、型は既定値
    ``None`` を持つため黙って通る。刻印を行う関数を 1 つに限り、**結果の型に識別子を
    書き込む構文が他所に現れないこと**を構文木の水準で固定する。

    :class:`~curvefit.pipeline.Job` の組み立て（``_build_jobs``）は結果ではなく処理単位に
    綴りを載せる別の役目であり、対象から除く。
    """

    @staticmethod
    def _functions_writing(keyword: str) -> set[str]:
        """``pipeline`` の中で、その名前の引数を渡している関数の名前を集める。"""
        tree = ast.parse(Path(pipeline_module.__file__).read_text(encoding="utf-8"))
        found: set[str] = set()
        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef):
                continue
            for inner in ast.walk(node):
                if isinstance(inner, ast.Call) and any(
                    argument.arg == keyword for argument in inner.keywords
                ):
                    found.add(node.name)
        return found

    def test_the_header_name_is_written_in_a_single_function(self) -> None:
        """見出し名を書き込むのは 1 つの関数に限る。"""
        assert self._functions_writing("column_name") == {"_with_column_identity"}

    def test_the_spelling_is_written_only_when_stamping_or_building_a_job(self) -> None:
        """綴りを書き込むのは刻印と処理単位の組み立てに限る。"""
        assert self._functions_writing("column_label") == {
            "_build_jobs",
            "_with_column_identity",
        }
