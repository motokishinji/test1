"""ジョブ展開と決定的な実行順序の統合テスト（要件 6.1、6.2、8.2）。

本テストは `curvefit.pipeline.expand_jobs` が次を満たすことを検証する。

- **直積**: 入力集合 × y 列集合 × 手法集合を処理単位の一覧に展開すること。
  3 入力 × 2 列 × 2 手法が 12 件になり、複数ファイル処理（要件 6.1）・複数 y 列
  （要件 1.1、1.11、6.8）・複数手法の適用（要件 6.2）が、どの軸でも分岐しない
  単一の経路で扱われること
- **軸の順序**: 入力 → 列 → 手法。同一対象の各手法が隣り合い（要件 6.2 の横並び
  比較）、かつ同一ファイルの各列も隣接すること
- **決定的な順序**: 同じファイル集合であれば、**指定の与え方によらず** 常に同一の
  ジョブ列になること（要件 8.2）。`glob` と `Path.iterdir` の返す順序は
  ファイルシステム依存であり保証されない（`research.md` の「再現性を破る要因の
  洗い出し」）。ソートしなければ、推定値そのものは同一でもサマリ CSV の行順と
  実行ログの記録順が実行ごとに変わり、要件 8.2 が出力物の水準で破れる
- **手法の順序**: 設定の記述順を保つこと。ソートしない
- **重複の排除**: ディレクトリ指定とワイルドカードが同じファイルを指しても、
  1 ファイルにつき手法ごとに 1 件だけ処理すること
- **存在確認をしない**こと。存在しないファイルの直接指定もジョブになり、
  要件 1.4/1.5 の個別失敗として扱われる

本テストが対象とするのは `Job` 型と `expand_jobs` に限る（タスク 7.1、および列軸を
足すタスク 13.7）。1 件の実行（7.2）とバッチ制御（7.3）は対象外である。

設計の Testing Strategy が `pipeline` の結線を統合テストに置いているため、単体では
なく `tests/integration/` に置く。
"""

from __future__ import annotations

import ast
import os
import stat
import subprocess
import sys
from dataclasses import FrozenInstanceError, fields
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pytest

from curvefit import pipeline
from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.execution import ExecutionRecord, build_execution_record
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.pipeline import Job, JobResult, expand_jobs, expand_sources, run
from curvefit.preprocess import PreprocessSpec
from curvefit.readers import ColumnSpec
from curvefit.types import DataSeries
from curvefit.writers import build_output_stem

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src" / "curvefit"

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
"""root は権限ビットを無視して読めるため、読み取り不能の検証が成立しない。"""

requires_permission_bits = pytest.mark.skipif(
    IS_ROOT, reason="root では権限ビットによる読み取り不能を再現できない"
)

ZETA = MethodSpec(name="zeta", kind="builtin", builtin="gaussian")
ALPHA = MethodSpec(name="alpha", kind="smoother", smoother=SmootherKind.LINEAR)
"""手法の順序が記述順であることを示すための 2 件。

**名前の辞書順と記述順が食い違う** ように選んである。`("zeta", "alpha")` の順で
渡したとき結果が `("alpha", "zeta")` になれば、手法をソートしていることが分かる。
"""

SIGNAL = ColumnSpec(x="time", y="signal")
REF = ColumnSpec(x="time", y="ref")
"""y 列の異なる 2 件の列指定。x 列は共有する（要件 1.11）。

**綴りの辞書順と記述順が食い違う** ように選んである。`(SIGNAL, REF)` の順で渡したとき
結果が `ref` → `signal` の順になれば、列をソートしていることが分かる。
"""

ORDER_SCRIPT = '''
import sys
from pathlib import Path

from curvefit.config import InputSpec, OutputSpec, RunConfig
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.pipeline import expand_jobs
from curvefit.preprocess import PreprocessSpec
from curvefit.readers import ColumnSpec

base = Path(sys.argv[1])
config = RunConfig(
    inputs=InputSpec(
        paths=(str(base / "data"), str(base / "data" / "*.csv"), str(base / "other" / "z.tsv")),
        columns=(ColumnSpec(x="time", y="signal"), ColumnSpec(x="time", y="ref")),
    ),
    methods=(
        MethodSpec(name="zeta", kind="builtin", builtin="gaussian"),
        MethodSpec(name="alpha", kind="smoother", smoother=SmootherKind.LINEAR),
    ),
    preprocess=PreprocessSpec(),
    output=OutputSpec(directory=base / "out"),
)
for job in expand_jobs(config):
    print(job.index, Path(job.source).name, job.column_label, job.method.name, sep="\\t")
'''
"""別プロセスでジョブの並びを書き出す小さな台本。

`PYTHONHASHSEED` を変えて実行し、出力が一致することで、重複排除に用いる集合の
走査順に依存していないことを示す（要件 8.2）。
"""


def _config(
    paths: tuple[str, ...],
    *,
    methods: tuple[MethodSpec, ...] = (ZETA, ALPHA),
    columns: tuple[ColumnSpec, ...] = (SIGNAL,),
    directory: Path | None = None,
) -> RunConfig:
    """展開対象の実行条件を組み立てる。入力指定・列指定・手法一覧以外は既定で埋める。"""
    return RunConfig(
        inputs=InputSpec(paths=paths, columns=columns),
        methods=methods,
        preprocess=PreprocessSpec(),
        output=OutputSpec(directory=directory if directory is not None else Path("out")),
    )


def _make(directory: Path, *names: str) -> None:
    """入力ファイルを作る。中身は読まないため空でよい（本タスクは読み込みを行わない）。"""
    directory.mkdir(parents=True, exist_ok=True)
    for name in names:
        (directory / name).write_text("", encoding="utf-8")


def _names(jobs: tuple[Job, ...]) -> list[tuple[str, str]]:
    """対象のファイル名と手法名の組。異なる一時ディレクトリ間で比較するための射影。"""
    return [(Path(job.source).name, job.method.name) for job in jobs]


def _triples(jobs: tuple[Job, ...]) -> list[tuple[str, str | None, str]]:
    """対象のファイル名・列の識別子・手法名の組。3 軸の並びを見るための射影。"""
    return [(Path(job.source).name, job.column_label, job.method.name) for job in jobs]


class TestCartesianExpansion:
    """要件 6.1、6.2: 入力集合 × y 列集合 × 手法集合を単一の一覧として扱う。

    本クラスは列を 1 件に固定し、入力軸と手法軸の性質だけを見る。列軸そのものは
    :class:`TestColumnAxis` が扱う。
    """

    def test_three_inputs_times_two_methods_yields_six_jobs(self, tmp_path: Path) -> None:
        """3入力かける2手法が6件になる。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert len(jobs) == 6

    def test_job_index_is_zero_based_and_matches_the_final_order(self, tmp_path: Path) -> None:
        """`build_output_stem` が番号を出力名に使うため、番号は最終順序で確定する（要件 7.6）。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert [job.index for job in jobs] == list(range(len(jobs)))

    def test_methods_of_the_same_source_are_adjacent(self, tmp_path: Path) -> None:
        """要件 6.2: モデルごとの結果を横並びで比較できるよう、対象を外側の軸にする。"""
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert _names(jobs) == [
            ("a.csv", "zeta"),
            ("a.csv", "alpha"),
            ("b.csv", "zeta"),
            ("b.csv", "alpha"),
        ]

    def test_method_order_preserves_the_written_order(self, tmp_path: Path) -> None:
        """手法はソートしない（要件 8.2 の決定性は記述順の保存で満たす）。"""
        _make(tmp_path / "data", "a.csv")

        forward = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA, ALPHA)))
        backward = expand_jobs(_config((str(tmp_path / "data"),), methods=(ALPHA, ZETA)))

        assert [job.method.name for job in forward] == ["zeta", "alpha"]
        assert [job.method.name for job in backward] == ["alpha", "zeta"]

    def test_carries_the_method_spec_unchanged(self, tmp_path: Path) -> None:
        """解決前の指定をそのまま運ぶ。ジョブごとの解決は 7.2 の担当である。"""
        _make(tmp_path / "data", "a.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert jobs[0].method is ZETA

    def test_no_inputs_yields_no_jobs(self, tmp_path: Path) -> None:
        """ディレクトリにファイルが無い場合は正常な空の実行（設計の Risks）。"""
        (tmp_path / "data").mkdir()

        assert expand_jobs(_config((str(tmp_path / "data"),))) == ()

    def test_job_index_yields_a_unique_output_name(self, tmp_path: Path) -> None:
        """要件 7.6: 別ディレクトリの同名ファイルでも出力が互いを上書きしない。"""
        _make(tmp_path / "run1", "sample.csv")
        _make(tmp_path / "run2", "sample.csv")

        jobs = expand_jobs(_config((str(tmp_path / "run1"), str(tmp_path / "run2"))))
        stems = {
            build_output_stem(job.source, job.column_label, job.method.name, job.index)
            for job in jobs
        }

        assert len(stems) == len(jobs) == 4


class TestColumnAxis:
    """要件 1.1、1.11、6.8: y 列を第 2 の軸として展開する。"""

    def test_three_inputs_times_two_columns_times_two_methods_yields_twelve_jobs(
        self, tmp_path: Path
    ) -> None:
        """3入力かける2列かける2手法が12件になる。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), columns=(SIGNAL, REF)))

        assert len(jobs) == 12

    def test_axis_order_is_input_then_column_then_method(self, tmp_path: Path) -> None:
        """軸の順序は 入力 → 列 → 手法。各手法が隣り合い、同一ファイルの各列も隣接する。"""
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), columns=(SIGNAL, REF)))

        assert _triples(jobs) == [
            ("a.csv", "signal", "zeta"),
            ("a.csv", "signal", "alpha"),
            ("a.csv", "ref", "zeta"),
            ("a.csv", "ref", "alpha"),
            ("b.csv", "signal", "zeta"),
            ("b.csv", "signal", "alpha"),
            ("b.csv", "ref", "zeta"),
            ("b.csv", "ref", "alpha"),
        ]

    def test_column_order_preserves_the_written_order(self, tmp_path: Path) -> None:
        """列はソートしない。設定の記述順をそのまま保つ（要件 8.2）。"""
        _make(tmp_path / "data", "a.csv")

        forward = expand_jobs(_config((str(tmp_path / "data"),), columns=(SIGNAL, REF)))
        backward = expand_jobs(_config((str(tmp_path / "data"),), columns=(REF, SIGNAL)))

        assert [job.column_label for job in forward] == ["signal", "signal", "ref", "ref"]
        assert [job.column_label for job in backward] == ["ref", "ref", "signal", "signal"]

    def test_a_single_column_follows_the_same_rule(self, tmp_path: Path) -> None:
        """列を 1 つだけ指定した場合も規則は同じ。件数は 入力数 × 1 × 手法数である。"""
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), columns=(SIGNAL,)))

        assert _triples(jobs) == [
            ("a.csv", "signal", "zeta"),
            ("a.csv", "signal", "alpha"),
            ("b.csv", "signal", "zeta"),
            ("b.csv", "signal", "alpha"),
        ]

    def test_each_job_carries_its_own_column_spec(self, tmp_path: Path) -> None:
        """処理単位はその対象が読む x / y / weight の組を持つ（要件 1.11）。"""
        _make(tmp_path / "data", "a.csv")
        weighted = ColumnSpec(x="time", y="ref", weight="sigma")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), columns=(SIGNAL, weighted)))

        assert [job.columns for job in jobs] == [SIGNAL, SIGNAL, weighted, weighted]

    def test_column_label_comes_from_the_written_spelling(self, tmp_path: Path) -> None:
        """識別子は `ColumnSpec.y` の綴りである。位置指定ならその数字になる（要件 7.6）。"""
        _make(tmp_path / "data", "a.csv")

        jobs = expand_jobs(
            _config(
                (str(tmp_path / "data"),),
                columns=(ColumnSpec(x=0, y=3),),
                methods=(ZETA,),
            )
        )

        assert [job.column_label for job in jobs] == ["3"]

    def test_index_is_a_running_number_across_all_three_axes(self, tmp_path: Path) -> None:
        """通し番号は 3 軸を展開した後の並びで与えられる（要件 7.6、8.2）。"""
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), columns=(SIGNAL, REF)))

        assert [job.index for job in jobs] == list(range(8))

    def test_jobs_differing_only_by_column_are_not_the_same_unit(self, tmp_path: Path) -> None:
        """列は処理単位の同一性に含まれる。同一ファイルの別の列は別の処理単位である。"""
        _make(tmp_path / "data", "a.csv")

        jobs = expand_jobs(
            _config((str(tmp_path / "data"),), columns=(SIGNAL, REF), methods=(ZETA,))
        )

        assert jobs[0] != jobs[1]
        assert jobs[0].source == jobs[1].source

    def test_no_columns_yields_no_jobs(self, tmp_path: Path) -> None:
        """列が 0 件なら処理単位も 0 件。軸のひとつが空なら直積は空である。"""
        _make(tmp_path / "data", "a.csv")

        assert expand_jobs(_config((str(tmp_path / "data"),), columns=())) == ()


class TestDeterministicOrdering:
    """要件 8.2: 同じファイル集合なら、与え方によらず常に同一のジョブ列になる。"""

    def test_reordering_the_specs_yields_the_same_result(self, tmp_path: Path) -> None:
        """指定の並びを変えても同一になる。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")
        forward = tuple(str(tmp_path / "data" / name) for name in ("a.csv", "b.csv", "c.csv"))
        backward = tuple(reversed(forward))

        assert expand_jobs(_config(forward)) == expand_jobs(_config(backward))

    def test_directory_explicit_list_and_wildcard_agree(self, tmp_path: Path) -> None:
        """走査経路が違っても、同じファイル集合なら同じジョブ列になる。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")
        listed = tuple(str(tmp_path / "data" / name) for name in ("c.csv", "a.csv", "b.csv"))

        by_directory = expand_jobs(_config((str(tmp_path / "data"),)))
        by_list = expand_jobs(_config(listed))
        by_wildcard = expand_jobs(_config((str(tmp_path / "data" / "*.csv"),)))

        assert by_directory == by_list == by_wildcard
        assert len(by_directory) == 6

    def test_independent_of_file_creation_order(self, tmp_path: Path) -> None:
        """`Path.iterdir` の返す順序はファイルシステム依存である（research.md）。"""
        _make(tmp_path / "forward", "a.csv", "b.csv", "c.csv")
        _make(tmp_path / "backward", "c.csv", "b.csv", "a.csv")

        forward = expand_jobs(_config((str(tmp_path / "forward"),)))
        backward = expand_jobs(_config((str(tmp_path / "backward"),)))

        assert _names(forward) == _names(backward)
        assert [name for name, _ in _names(forward)] == [
            "a.csv",
            "a.csv",
            "b.csv",
            "b.csv",
            "c.csv",
            "c.csv",
        ]

    def test_redundant_spellings_normalize_to_the_same_path(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """`./data/a.csv` と `data/../data/a.csv` は同じ対象である。"""
        _make(tmp_path / "data", "a.csv")
        monkeypatch.chdir(tmp_path)

        plain = expand_jobs(_config(("data/a.csv",)))
        redundant = expand_jobs(_config(("./data/../data/a.csv",)))

        assert plain == redundant

    def test_relative_specs_expand_to_absolute_paths(self, tmp_path: Path, monkeypatch) -> None:
        """対象の識別子は絶対パスに揃える。実行位置の表記の差を出力に持ち込まない。"""
        _make(tmp_path / "data", "a.csv")
        monkeypatch.chdir(tmp_path)

        jobs = expand_jobs(_config(("data/a.csv",)))

        assert jobs[0].source == str(tmp_path / "data" / "a.csv")

    def test_ordering_is_unchanged_across_hash_seeds(self, tmp_path: Path) -> None:
        """重複排除に用いる集合の走査順に依存していないことを別プロセスで確かめる。"""
        _make(tmp_path / "data", "a.csv", "b.csv")
        _make(tmp_path / "other", "z.tsv")
        script = tmp_path / "order.py"
        script.write_text(ORDER_SCRIPT, encoding="utf-8")
        outputs = set()
        for seed in ("0", "1", "12345"):
            environment = {**os.environ, "PYTHONHASHSEED": seed, "PYTHONPATH": str(ROOT / "src")}
            completed = subprocess.run(
                [sys.executable, str(script), str(tmp_path)],
                capture_output=True,
                text=True,
                env=environment,
                check=True,
            )
            outputs.add(completed.stdout)

        assert len(outputs) == 1, outputs
        assert len(outputs.pop().strip().splitlines()) == 12


class TestDuplicateElimination:
    """同じファイルを 2 通りで指定しても、処理は 1 回だけである。"""

    def test_overlap_between_directory_and_wildcard_is_removed(self, tmp_path: Path) -> None:
        """ディレクトリとワイルドカードの重なりを排除する。"""
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"), str(tmp_path / "data" / "*.csv"))))

        assert len(jobs) == 4
        assert _names(jobs) == [
            ("a.csv", "zeta"),
            ("a.csv", "alpha"),
            ("b.csv", "zeta"),
            ("b.csv", "alpha"),
        ]

    def test_same_file_under_different_spellings_is_removed(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """表記の違う同一ファイルを排除する。"""
        _make(tmp_path / "data", "a.csv")
        monkeypatch.chdir(tmp_path)

        paths = ("data/a.csv", "./data/a.csv", str(tmp_path / "data" / "a.csv"))
        jobs = expand_jobs(_config(paths))

        assert len(jobs) == 2

    def test_symlink_and_target_are_not_merged(self, tmp_path: Path) -> None:
        """正規化で symlink を解決しない。どちらも利用者が明示した別々の対象である。

        融合すると、指定したはずのファイルが結果に 1 件も現れない。重複を残す代償
        （同じ処理が 2 回走る）と釣り合わない。
        """
        _make(tmp_path / "data", "a.csv")
        link = tmp_path / "data" / "link.csv"
        try:
            link.symlink_to(tmp_path / "data" / "a.csv")
        except (OSError, NotImplementedError):  # pragma: no cover - 環境依存
            pytest.skip("この環境では symlink を作成できない")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv", "link.csv"]

    def test_repeating_the_same_spec_adds_nothing(self, tmp_path: Path) -> None:
        """同じ指定を重ねても増えない。"""
        _make(tmp_path / "data", "a.csv")
        target = str(tmp_path / "data" / "a.csv")

        assert len(expand_jobs(_config((target, target)))) == 2


class TestInputClassification:
    """指定はファイル・ディレクトリ・ワイルドカードの 3 通りを取る（要件 6.1）。"""

    def test_a_missing_explicit_path_still_becomes_a_job(self, tmp_path: Path) -> None:
        """存在確認は行わない。不存在は要件 1.4/1.5 の個別失敗として扱う（設計の Risks）。"""
        jobs = expand_jobs(_config((str(tmp_path / "missing.csv"),)))

        assert len(jobs) == 2
        assert jobs[0].source == str(tmp_path / "missing.csv")

    def test_directory_takes_only_data_extensions(self, tmp_path: Path) -> None:
        """一括指定に紛れ込んだ付随ファイルを、直せない失敗として報告しない。"""
        _make(tmp_path / "data", "a.csv", "b.tsv", "c.txt", "README.md", ".DS_Store", "run.log")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv", "b.tsv", "c.txt"]

    def test_directory_spec_does_not_recurse(self, tmp_path: Path) -> None:
        """再帰は `**` を含むワイルドカードでの明示指定に限る。"""
        _make(tmp_path / "data", "a.csv")
        _make(tmp_path / "data" / "nested", "deep.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv"]

    def test_wildcard_accepts_a_recursive_pattern(self, tmp_path: Path) -> None:
        """ワイルドカードは再帰指定を受け付ける。"""
        _make(tmp_path / "data", "a.csv")
        _make(tmp_path / "data" / "nested", "deep.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data" / "**" / "*.csv"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv", "deep.csv"]

    def test_wildcard_does_not_filter_by_extension(self, tmp_path: Path) -> None:
        """並びを列挙したのは利用者自身であり、こちらで間引く理由がない。"""
        _make(tmp_path / "data", "a.dat")

        jobs = expand_jobs(_config((str(tmp_path / "data" / "*.dat"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.dat"]

    def test_directories_matched_by_a_wildcard_are_excluded(self, tmp_path: Path) -> None:
        """ディレクトリを読み込もうとすると、利用者に直しようのない失敗になる。"""
        _make(tmp_path / "data", "a.csv")
        (tmp_path / "data" / "nested").mkdir()

        jobs = expand_jobs(_config((str(tmp_path / "data" / "*"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a.csv"]

    def test_wildcard_with_no_match_yields_nothing(self, tmp_path: Path) -> None:
        """一致のないワイルドカードは0件になる。"""
        _make(tmp_path / "data", "a.csv")

        assert expand_jobs(_config((str(tmp_path / "data" / "*.tsv"),))) == ()

    def test_existing_file_with_brackets_is_taken_literally(self, tmp_path: Path) -> None:
        """存在する綴りはワイルドカードより優先し、文字どおりの 1 件として扱う。

        `[` は `glob` の文字クラスの開始でもあるため、実在するファイルをパターンとして
        解釈すると一致 0 件になり、利用者が明示したファイルが何の報告もなく消える。
        測定日をファイル名に括弧書きする慣習（`[2024]run.csv`）は珍しくない。
        """
        _make(tmp_path / "data", "[2024]run.csv")
        target = tmp_path / "data" / "[2024]run.csv"

        jobs = expand_jobs(_config((str(target),)))

        assert _names(jobs) == [("[2024]run.csv", "zeta"), ("[2024]run.csv", "alpha")]
        assert jobs[0].source == str(target)

    def test_existing_directory_with_brackets_is_expanded(self, tmp_path: Path) -> None:
        """分類はワイルドカードを先に見るため、存在確認を挟まないとディレクトリに到達しない。"""
        _make(tmp_path / "da[t]a", "x.csv")

        jobs = expand_jobs(_config((str(tmp_path / "da[t]a"),), methods=(ZETA,)))

        assert _names(jobs) == [("x.csv", "zeta")]
        assert jobs[0].source == str(tmp_path / "da[t]a" / "x.csv")

    def test_nonexistent_character_class_acts_as_a_wildcard(self, tmp_path: Path) -> None:
        """存在優先はパターン解釈を止めない。実在しない綴りは従来どおり `glob` に渡る。"""
        _make(tmp_path / "data", "a1.csv", "b1.csv", "c1.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data" / "[ab]1.csv"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["a1.csv", "b1.csv"]

    def test_uppercase_extensions_are_included(self, tmp_path: Path) -> None:
        """大文字の拡張子も対象にする。"""
        _make(tmp_path / "data", "A.CSV")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ZETA,)))

        assert [name for name, _ in _names(jobs)] == ["A.CSV"]

    @requires_permission_bits
    def test_unreadable_directory_raises(self, tmp_path: Path) -> None:
        """0 件として黙らせない。1 ディレクトリ分の入力が黙って消えるのは最悪の結末である。

        資源・環境の失敗であり利用者が設定で直せるものではないため、`expand_jobs` の
        返り値（ジョブ一覧）では表せない。捕捉と中断の判断はバッチ制御（7.3）が持つ。
        """
        locked = tmp_path / "locked"
        _make(locked, "a.csv")
        locked.chmod(stat.S_IWUSR | stat.S_IXUSR)
        try:
            with pytest.raises(OSError):
                expand_jobs(_config((str(locked),)))
        finally:
            locked.chmod(stat.S_IRWXU)


class TestPureExpansion:
    """設計の Responsibilities: 走査以外の入出力を持たず、実行条件を書き換えない。"""

    def test_does_not_mutate_the_run_config(self, tmp_path: Path) -> None:
        """実行条件を書き換えない。"""
        _make(tmp_path / "data", "a.csv")
        config = _config((str(tmp_path / "data"),))
        before = config.inputs.paths

        expand_jobs(config)

        assert config.inputs.paths == before
        assert config.methods == (ZETA, ALPHA)

    def test_same_run_config_yields_the_same_result_every_call(self, tmp_path: Path) -> None:
        """同じ実行条件なら何度呼んでも同じ結果。"""
        _make(tmp_path / "data", "a.csv", "b.csv")
        config = _config((str(tmp_path / "data"),))

        assert expand_jobs(config) == expand_jobs(config)

    def test_input_count_can_be_obtained_separately(self, tmp_path: Path) -> None:
        """進捗通知（要件 6.3）は総ジョブ数と総入力数の両方を必要とする。"""
        _make(tmp_path / "data", "a.csv", "b.csv", "c.csv")

        sources = expand_sources((str(tmp_path / "data"),))

        assert len(sources) == 3
        assert sources == tuple(sorted(sources))


class TestJobType:
    """設計の Contracts: `Job` は凍結され、index / source / columns / column_label /
    method / series を持つ。"""

    def test_fields_match_the_design(self) -> None:
        """フィールドが設計どおり。"""
        assert tuple(field.name for field in fields(Job)) == (
            "index",
            "source",
            "columns",
            "column_label",
            "method",
            "series",
        )

    def test_jobs_built_by_scanning_carry_no_series(self, tmp_path: Path) -> None:
        """`series` は要件 9.1 のライブラリ経路の差込口であり、走査は使わない。

        走査で系列を載せてしまうと、読み込みを省いた処理単位がファイル入力にも
        紛れ込み、`run_job` が入力の位置を読まなくなる。
        """
        _make(tmp_path / "data", "a.csv", "b.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),)))

        assert len(jobs) == 4
        assert all(job.series is None for job in jobs)

    def test_cannot_be_mutated_after_construction(self) -> None:
        """生成後に変更できない。"""
        job = Job(index=0, source="a.csv", columns=SIGNAL, column_label="signal", method=ZETA)

        with pytest.raises(FrozenInstanceError):
            job.index = 1  # type: ignore[misc]

    def test_caller_supplied_label_can_be_used_as_the_source(self) -> None:
        """設計の注記どおり `source` はファイルパスに限らない（要件 1.2 のライブラリ経路）。"""
        job = Job(
            index=0, source="in-memory", columns=SIGNAL, column_label="signal", method=ZETA
        )

        assert job.source == "in-memory"


class TestSeriesJobsHaveNoColumnIdentifier:
    """要件 9.1: 読み込み済みの系列を直接渡す経路は、y 列の綴りを持ち込まない。

    この経路は列指定を読まない。それでも `Job` の欄を埋めるために列指定を運ぶが、
    出力名とサマリ表に載る識別子（`column_label`）は `None` である。運んだ列指定の
    綴りを識別子にすると、`api.fit_series` が使う参照されない列指定（`UNUSED_COLUMNS`）
    の綴りが、利用者が書いてもいない名前として結果に載る。

    観測は `run` 越しに行う。処理単位の組み立ては `pipeline` の内部であり、外から
    見えるのは実行に渡された処理単位そのものである。
    """

    def _series(self) -> DataSeries:
        x = np.linspace(0.0, 10.0, 11)
        return DataSeries(source_id="memory", x=x, y=2.0 * x + 1.0)

    def _record(self) -> ExecutionRecord:
        return build_execution_record(
            resolved_config={"input": "test"},
            clock=lambda: datetime(2026, 1, 2, 3, 4, 5, tzinfo=UTC),
            tool_version="0.0.0-test",
            library_versions={},
        )

    def _executed_jobs(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, columns: tuple[ColumnSpec, ...]
    ) -> list[Job]:
        """系列を直接渡す実行が `run_job` に渡した処理単位を集める。"""
        config = _config((), methods=(ALPHA,), columns=columns, directory=tmp_path / "out")
        captured: list[Job] = []
        original = pipeline.run_job

        def spy(job: Job, run_config: RunConfig) -> JobResult:
            captured.append(job)
            return original(job, run_config)

        monkeypatch.setattr(pipeline, "run_job", spy)

        run(config, self._record(), series=self._series())

        return captured

    def test_a_series_job_carries_no_column_label(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """識別子は `None` である。運んだ列指定の綴りを流用しない。"""
        jobs = self._executed_jobs(tmp_path, monkeypatch, (REF, SIGNAL))

        assert [job.column_label for job in jobs] == [None]

    def test_a_series_job_carries_the_first_column_spec(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """列指定は運ぶ。列軸は展開せず、実行条件の先頭の 1 件だけが載る。"""
        jobs = self._executed_jobs(tmp_path, monkeypatch, (REF, SIGNAL))

        assert [job.columns for job in jobs] == [REF]

    def test_a_file_job_still_carries_its_label(self, tmp_path: Path) -> None:
        """対照。系列を伴わない処理単位では識別子が埋まる（要件 7.6）。"""
        _make(tmp_path / "data", "a.csv")

        jobs = expand_jobs(_config((str(tmp_path / "data"),), methods=(ALPHA,), columns=(REF,)))

        assert [job.column_label for job in jobs] == ["ref"]


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が上位層やライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse((SRC / "pipeline.py").read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class TestDependencyExposure:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_does_not_import_upper_layers(self) -> None:
        """上位層を import しない。"""
        assert not (_imported_modules() & {"curvefit.api", "curvefit.cli"})

    def test_does_not_directly_import_layer_confined_libraries(self) -> None:
        """pandas は readers/writers、matplotlib は plotting、lmfit と SciPy はエンジンに閉じる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval"}, (
                f"pipeline.py が {imported} を import している"
            )
