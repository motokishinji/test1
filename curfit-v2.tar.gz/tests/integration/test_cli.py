"""コマンドライン入口の統合テスト（要件 6.3、9.2、9.4、9.5）。

本テストは :mod:`curvefit.cli` が次を満たすことを検証する。

- **コマンドからの実行**（要件 9.2）: 入力指定・設定ファイル・出力先の指定のみで、
  出力一式（サマリ表・グラフ・実行ログ・実行条件の記録）が生成されること
- **終了コードの区別**（要件 9.5）: 全件成功・一部または全件失敗・実行前検証での停止の
  3 状態が、それぞれ異なる終了コードになること
- **上書きの委譲**（要件 9.4）: 実行時引数は ``config`` へ **そのまま** 渡り、優先順位の
  判断が CLI に無いこと。上書きした項目が実行条件の記録に残ること
- **進捗表示**（要件 6.3）: 処理済み件数と全体件数の双方が分かる進捗が標準エラー出力に
  現れ、標準出力を汚さないこと
- **依存方向**（設計の cli ブロックの Invariants）: ライブラリ側のどのモジュールからも
  ``cli`` が import されないこと
- **利用者への警告**（設計の Security Considerations）: 数式文字列の評価が任意コード実行と
  同等であることをヘルプに明記すること

設計の Testing Strategy は結線の検証を統合テストに置く。本テストは CLI から
``api`` → ``pipeline`` までを実際に通し、差し替えを行うのは「実行時引数がそのまま
``api`` へ渡ること」を観測する 1 か所に限る。

終了コードの検証は 3 状態を **同一の経路** で比べる。3 つを別々の仕組みで確かめると、
たとえば失敗と違反が同じコードに潰れていても、それぞれのテストは通ってしまう。
"""

from __future__ import annotations

import ast
import csv
import datetime
import inspect
import io
import json
import subprocess
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path

import numpy as np
import pytest

from curvefit import cli
from curvefit.cli import ExitCode, main
from curvefit.errors import FailureReason
from curvefit.execution import EXECUTION_RECORD_FILENAME, build_execution_record
from curvefit.logging_setup import RUN_LOG_FILENAME
from curvefit.pipeline import (
    PLOT_SUBDIRECTORY,
    SUMMARY_FILENAME,
    BatchReport,
    ProgressObserver,
)
from curvefit.preflight import PreflightResult
from curvefit.types import (
    CurveData,
    FitFailure,
    FitOutcome,
    FitSuccess,
    GoodnessOfFit,
    PreprocessReport,
)

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"


def _success_outcome(source_id: str, *, column_label: str | None = None) -> FitSuccess:
    """進捗の描き分けを見るためだけの最小の成功結果。"""
    zeros = np.zeros(3, dtype=np.float64)
    return FitSuccess(
        source_id=source_id,
        method_name="linear",
        parameters=(),
        goodness=GoodnessOfFit(r_squared=1.0, rmse=0.0, n_points=3, n_varied_params=0),
        curve=CurveData(x=zeros, y_observed=zeros, y_fit=zeros, residual=zeros),
        preprocess=PreprocessReport(
            n_input=3,
            n_dropped_invalid=0,
            n_dropped_out_of_range=0,
            n_dropped_outlier=0,
            outlier_points=(),
        ),
        column_label=column_label,
    )


def _failure_outcome(source_id: str, *, column_label: str | None = None) -> FitFailure:
    """失敗結果。列の綴りは進捗の描き分けを見る場合にだけ与える。"""
    return FitFailure(
        source_id=source_id,
        method_name="linear",
        reason=FailureReason.NOT_CONVERGED,
        message="収束しなかった",
        column_label=column_label,
    )

CONFIG_TEMPLATE = """\
[input]
paths = [{paths}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "{method_name}"
builtin = "{builtin}"

[output]
directory = {directory}
write_plot = {write_plot}
"""


def write_csv(path: Path, *, n_points: int = 12) -> Path:
    """当てはめに足りる直線データを書き出す。"""
    lines = ["x,y"]
    for index in range(n_points):
        x = float(index)
        lines.append(f"{x!r},{2.5 * x + 1.25!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_csv_with_error_column(path: Path, *, n_points: int = 12) -> Path:
    """当てはめに足りる直線データを、測定誤差の列つきで書き出す（要件 1.3）。"""
    lines = ["x,y,err"]
    for index in range(n_points):
        x = float(index)
        lines.append(f"{x!r},{2.5 * x + 1.25!r},{0.1 + 0.01 * index!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_two_channel_csv(path: Path, *, n_points: int = 12) -> Path:
    """1 つのファイルに測定チャネルが 2 つある入力（要件 1.11）。"""
    lines = ["x,signal,ref,sigma_signal,sigma_ref"]
    for index in range(n_points):
        x = float(index)
        lines.append(f"{x!r},{2.5 * x + 1.25!r},{-1.5 * x + 4.0!r},{0.1!r},{0.2!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_two_channel_config(
    path: Path,
    *,
    data: Path,
    directory: Path,
    weight: bool = False,
    method_names: Sequence[str] = ("lin",),
) -> Path:
    """2 つの測定チャネルを 1 回の実行で処理する設定ファイル（要件 1.11、6.8）。"""
    lines = [
        "[input]",
        f"paths = [{str(data)!r}]",
        "header = true",
        "",
        "[input.columns]",
        'x = "x"',
        'y = ["signal", "ref"]',
    ]
    if weight:
        lines.append('weight = ["sigma_signal", "sigma_ref"]')
    for name in method_names:
        lines += ["", "[[methods]]", f'name = "{name}"', 'builtin = "linear"']
    lines += ["", "[output]", f"directory = {str(directory)!r}", "write_plot = false"]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def summary_rows(directory: Path) -> list[dict[str, str]]:
    """サマリ表を名前引きで読む。列位置に依存させない。"""
    with (directory / SUMMARY_FILENAME).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_moving_average_config(
    path: Path, *, data: Path, directory: Path, weight_column: str | None
) -> Path:
    """移動平均 1 手法だけの設定ファイル。誤差列の指定は任意（要件 1.10）。"""
    lines = [
        "[input]",
        f"paths = [{str(data)!r}]",
        "",
        "[input.columns]",
        'x = "x"',
        'y = "y"',
    ]
    if weight_column is not None:
        lines.append(f"weight = {weight_column!r}")
    lines += [
        "",
        "[[methods]]",
        'name = "ma"',
        'smoother = "moving_average"',
        "",
        "[output]",
        f"directory = {str(directory)!r}",
        "write_plot = false",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_config(
    path: Path,
    *,
    paths: Sequence[Path | str],
    directory: Path,
    write_plot: bool = False,
    method_name: str = "lin",
    builtin: str = "linear",
    encoding: str = "utf-8",
) -> Path:
    path.write_text(
        CONFIG_TEMPLATE.format(
            paths=", ".join(repr(str(item)) for item in paths),
            directory=repr(str(directory)),
            write_plot="true" if write_plot else "false",
            method_name=method_name,
            builtin=builtin,
        ),
        encoding=encoding,
    )
    return path


def output_files(directory: Path) -> list[str]:
    """出力先に実際に生成されたファイルを、位置の分かる相対表記で並べる。"""
    if not directory.is_dir():
        return []
    return sorted(
        str(item.relative_to(directory))
        for item in directory.rglob("*")
        if item.is_file()
    )


# --- 終了コードの区別（要件 9.5）----------------------------------------------------


class TestExitCodes:
    """3 つの終了状態がそれぞれ異なる終了コードになること（要件 9.5）。"""

    def test_all_success_returns_0_and_writes_the_full_output_set(self, tmp_path: Path) -> None:
        """要件 9.2、9.5: 設定ファイルと出力先の指定だけで出力一式が揃う。"""
        data = write_csv(tmp_path / "sample.csv")
        out = tmp_path / "out"
        config = write_config(
            tmp_path / "run.toml", paths=[data], directory=out, write_plot=True
        )

        assert main([str(config)]) == ExitCode.SUCCESS

        generated = output_files(out)
        assert SUMMARY_FILENAME in generated
        assert RUN_LOG_FILENAME in generated
        assert EXECUTION_RECORD_FILENAME in generated
        assert any(name.startswith(f"{PLOT_SUBDIRECTORY}/") for name in generated), generated

    def test_partial_failure_returns_1_and_keeps_the_remaining_output(self, tmp_path: Path) -> None:
        """要件 6.4、9.5: 1 件の失敗は残りを止めない。終了コードは成功と区別される。"""
        data = write_csv(tmp_path / "good.csv")
        out = tmp_path / "out"
        config = write_config(
            tmp_path / "run.toml",
            paths=[data, tmp_path / "missing.csv"],
            directory=out,
        )

        assert main([str(config)]) == ExitCode.PARTIAL_FAILURE

        summary = (out / SUMMARY_FILENAME).read_text(encoding="utf-8")
        assert "good.csv" in summary
        assert "missing.csv" in summary

    def test_preflight_stop_returns_2_and_writes_nothing(
        self, tmp_path: Path
    ) -> None:
        """要件 8.5、9.5: 違反があれば処理単位を 1 件も実行せず、出力物を残さない。"""
        data = write_csv(tmp_path / "sample.csv")
        out = tmp_path / "out"
        config = write_config(
            tmp_path / "run.toml",
            paths=[data],
            directory=out,
            builtin="存在しないモデル",
        )

        assert main([str(config)]) == ExitCode.CONFIG_ERROR
        assert output_files(out) == []

    def test_returns_1_when_aborted_even_with_zero_failures(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """要件 6.5、10.3: 中断は残りを実行していない。成功として返してはならない。

        中断だけを起こす状況（ジョブ展開時の :class:`OSError`）は環境に依存するため、
        集計結果から終了コードへの写しだけを取り出して確かめる。
        """

        def fake_run(
            path: Path,
            overrides: Mapping[str, object] | None = None,
            observer: ProgressObserver | None = None,
        ) -> BatchReport:
            return BatchReport(
                outcomes=(),
                n_success=0,
                n_failure=0,
                aborted=True,
                execution=build_execution_record(
                    resolved_config={}, config_path=str(path), cli_overrides=()
                ),
            )

        monkeypatch.setattr(cli, "run_from_config", fake_run)
        config = tmp_path / "run.toml"
        config.write_text("", encoding="utf-8")

        assert main([str(config)]) == ExitCode.PARTIAL_FAILURE

    def test_the_three_exit_codes_are_mutually_distinct(self) -> None:
        """3 つの終了コードが互いに異なる。"""
        codes = {ExitCode.SUCCESS, ExitCode.PARTIAL_FAILURE, ExitCode.CONFIG_ERROR}
        assert len(codes) == 3
        assert (ExitCode.SUCCESS, ExitCode.PARTIAL_FAILURE, ExitCode.CONFIG_ERROR) == (0, 1, 2)


class TestViolationReporting:
    """違反は利用者が直せる形で、全件をそれぞれの位置つきで示す（設計の Error Handling）。"""

    def test_every_violation_is_reported_with_its_location(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """全違反がそれぞれの位置とともに示される。"""
        config = tmp_path / "run.toml"
        config.write_text(
            "\n".join(
                [
                    "unknown_top = 1",
                    "",
                    "[input]",
                    'paths = ["a.csv"]',
                    "",
                    "[input.columns]",
                    'x = "x"',
                    "",
                    "[[methods]]",
                    'name = "lin"',
                    'builtin = "linear"',
                    "",
                    "[output]",
                    f"directory = {str(tmp_path / 'out')!r}",
                ]
            )
            + "\n",
            encoding="utf-8",
        )

        assert main([str(config)]) == ExitCode.CONFIG_ERROR

        captured = capsys.readouterr()
        assert "unknown_top" in captured.err
        assert "input.columns.y" in captured.err
        assert captured.out == ""

    def test_an_unreadable_config_file_is_reported_as_a_violation(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """読み込めない設定ファイルも違反として示される。"""
        missing = tmp_path / "absent.toml"

        assert main([str(missing)]) == ExitCode.CONFIG_ERROR
        assert str(missing) in capsys.readouterr().err

    def test_parameters_given_to_a_smoother_are_rejected_with_2_and_leave_nothing(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """要件 4.4、4.5、8.5: 効かない指定を黙って捨てず、実行前に止める。

        捨てると exit=0 で上下限を無視した推定値が返り、しかもその上下限が
        実行条件の記録に「適用した条件」として残る。記録が実行を説明しなくなる。
        """
        data = write_csv(tmp_path / "sample.csv")
        out = tmp_path / "out"
        config = tmp_path / "run.toml"
        config.write_text(
            "\n".join(
                [
                    "[input]",
                    f"paths = [{str(data)!r}]",
                    "",
                    "[input.columns]",
                    'x = "x"',
                    'y = "y"',
                    "",
                    "[[methods]]",
                    'name = "sm"',
                    'smoother = "linear"',
                    "initial = { slope = 99.0 }",
                    "bounds = { slope = { min = 0.0, max = 0.001 } }",
                    "",
                    "[output]",
                    f"directory = {str(out)!r}",
                    "write_plot = false",
                ]
            )
            + "\n",
            encoding="utf-8",
        )

        assert main([str(config)]) == ExitCode.CONFIG_ERROR

        message = capsys.readouterr().err
        assert "method[sm].initial" in message
        assert "method[sm].bounds" in message
        assert "slope" in message
        assert output_files(out) == []

    def test_error_column_for_a_weightless_method_is_rejected_with_2_and_leaves_nothing(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """要件 1.10: 黙って無視すると exit=0 で「測定誤差を反映した結果」として読まれる。

        実行ログには従来から警告が出ていたが、`summary.csv` だけを読む利用者には
        届かない。実行前に止めて設定を直させる。
        """
        data = write_csv_with_error_column(tmp_path / "sample.csv")
        out = tmp_path / "out"
        config = write_moving_average_config(
            tmp_path / "run.toml", data=data, directory=out, weight_column="err"
        )

        assert main([str(config)]) == ExitCode.CONFIG_ERROR

        message = capsys.readouterr().err
        assert "method[ma].smoother" in message
        assert "moving_average" in message
        # どの y 列に書いた誤差列を消せばよいかが分かる形で載る（要件 1.11、1.12）
        assert "input.columns[0].weight" in message
        assert output_files(out) == []

    def test_moving_average_without_an_error_column_still_runs(
        self, tmp_path: Path
    ) -> None:
        """要件 1.10 の拒否が、正当な移動平均の実行まで止めていないこと。"""
        data = write_csv_with_error_column(tmp_path / "sample.csv")
        out = tmp_path / "out"
        config = write_moving_average_config(
            tmp_path / "run.toml", data=data, directory=out, weight_column=None
        )

        assert main([str(config)]) == ExitCode.SUCCESS
        assert SUMMARY_FILENAME in output_files(out)

    def test_config_file_with_a_bom_names_the_bom_in_the_guidance(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """既定の構文エラーは位置しか示さず、利用者は原因に到達できない。

        Windows のメモ帳が既定で付ける UTF-8 BOM が該当する。
        """
        data = write_csv(tmp_path / "sample.csv")
        config = write_config(
            tmp_path / "run.toml",
            paths=[data],
            directory=tmp_path / "out",
            encoding="utf-8-sig",
        )

        assert main([str(config)]) == ExitCode.CONFIG_ERROR

        message = capsys.readouterr().err
        # 一時ディレクトリの名前は pytest がテスト関数名から作るため "BOM" を含む。
        # メッセージには設定ファイルのパスも載るので、"BOM" の有無を見るだけの表明は
        # 検出を無効化しても成立してしまう。BOM 固有の語で固定する。
        assert "EF BB BF" in message
        assert "先頭に UTF-8 の BOM" in message
        assert "保存し直す" in message
        assert str(config) in message


# --- 実行時引数の委譲（要件 9.4）----------------------------------------------------


class TestRuntimeArguments:
    """優先順位を判断せず、指定をそのまま ``config`` へ渡すこと（要件 9.4）。"""

    def test_output_argument_overrides_the_config_file(self, tmp_path: Path) -> None:
        """出力先の指定が設定ファイルに優先する。"""
        data = write_csv(tmp_path / "sample.csv")
        from_config = tmp_path / "config-out"
        from_cli = tmp_path / "cli-out"
        config = write_config(
            tmp_path / "run.toml", paths=[data], directory=from_config
        )

        assert main([str(config), "--output", str(from_cli)]) == ExitCode.SUCCESS

        assert (from_cli / SUMMARY_FILENAME).is_file()
        assert not from_config.exists()

    def test_overridden_items_are_kept_in_the_execution_record(self, tmp_path: Path) -> None:
        """要件 9.4: 上書き前後の双方が ``execution.json`` に現れる。"""
        data = write_csv(tmp_path / "sample.csv")
        from_config = tmp_path / "config-out"
        from_cli = tmp_path / "cli-out"
        config = write_config(
            tmp_path / "run.toml", paths=[data], directory=from_config
        )

        assert main([str(config), "--output", str(from_cli)]) == ExitCode.SUCCESS

        record = json.loads(
            (from_cli / EXECUTION_RECORD_FILENAME).read_text(encoding="utf-8")
        )
        assert record["cli_overrides"] == [
            {
                "key": "output.directory",
                "config_value": str(from_config),
                "cli_value": str(from_cli),
            }
        ]

    def test_input_argument_overrides_the_config_file(self, tmp_path: Path) -> None:
        """入力指定が設定ファイルに優先する。"""
        write_csv(tmp_path / "listed.csv")
        actual = write_csv(tmp_path / "actual.csv")
        out = tmp_path / "out"
        config = write_config(
            tmp_path / "run.toml", paths=[tmp_path / "listed.csv"], directory=out
        )

        assert main([str(config), "--input", str(actual)]) == ExitCode.SUCCESS

        summary = (out / SUMMARY_FILENAME).read_text(encoding="utf-8")
        assert "actual.csv" in summary
        assert "listed.csv" not in summary

    def test_only_the_given_items_are_passed_as_overrides(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """CLI は値を解釈も比較もせず、設定ファイル側の値を見ない（要件 9.4）。

        優先順位の実装箇所を ``config`` の 1 か所に保つという設計の判断は、CLI が
        設定ファイルの値を **持たない** ことで構造的に成立する。
        """
        captured: dict[str, object] = {}

        def fake_run(
            path: Path,
            overrides: Mapping[str, object] | None = None,
            observer: ProgressObserver | None = None,
        ) -> BatchReport:
            captured["path"] = path
            captured["overrides"] = dict(overrides or {})
            return BatchReport(
                outcomes=(),
                n_success=0,
                n_failure=0,
                aborted=False,
                execution=build_execution_record(
                    resolved_config={}, config_path=str(path), cli_overrides=()
                ),
            )

        monkeypatch.setattr(cli, "run_from_config", fake_run)
        config = tmp_path / "run.toml"
        config.write_text("", encoding="utf-8")

        assert (
            main(
                [
                    str(config),
                    "--input",
                    "a.csv",
                    "--input",
                    "b.csv",
                    "--output",
                    "out",
                    "--delimiter",
                    "\t",
                    "--no-plot",
                    "--failure-policy",
                    "fail_fast",
                ]
            )
            == ExitCode.SUCCESS
        )

        assert captured["overrides"] == {
            "input.paths": ["a.csv", "b.csv"],
            "output.directory": "out",
            "input.delimiter": "\t",
            "output.write_plot": False,
            "failure_policy": "fail_fast",
        }

    def test_overridable_item_names_appear_in_the_config_side_list(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """CLI が独自の表記を作らないこと（``config.OVERRIDABLE_KEYS`` が権威）。"""
        from curvefit.config import OVERRIDABLE_KEYS

        captured: dict[str, object] = {}

        def fake_run(
            path: Path,
            overrides: Mapping[str, object] | None = None,
            observer: ProgressObserver | None = None,
        ) -> PreflightResult:
            captured["overrides"] = dict(overrides or {})
            return PreflightResult(violations=())

        monkeypatch.setattr(cli, "run_from_config", fake_run)
        config = tmp_path / "run.toml"
        config.write_text("", encoding="utf-8")

        main(
            [
                str(config),
                "--input",
                "a.csv",
                "--output",
                "out",
                "--delimiter",
                ",",
                "--header",
                "--x-column",
                "time",
                "--y-column",
                "signal",
                "--weight-column",
                "sigma",
                "--no-summary",
                "--plot",
                "--curve",
                "--failure-policy",
                "skip",
            ]
        )

        assert set(captured["overrides"]) <= set(OVERRIDABLE_KEYS)  # type: ignore[arg-type]
        assert set(captured["overrides"]) == set(OVERRIDABLE_KEYS)  # type: ignore[arg-type]


# --- 列の指定（要件 9.2、9.4）--------------------------------------------------------


class TestColumnArgument:
    """``--y-column`` は列の並びを 1 件に置き換えること（設計の cli ブロック）。

    要件 9.2 が求めるのは、設定ファイルに記述できるすべての実行条件をコマンドから
    実行できることであって、引数の側に並びの表現力を持たせることではない。並びを
    引数で書けるようにすると、上書きの単位が並び全体なのか 1 要素なのかが曖昧になる。
    複数列と位置指定は設定ファイルが担う。
    """

    def test_the_argument_replaces_the_whole_column_sequence(self, tmp_path: Path) -> None:
        """2 列の設定が、指定した 1 列だけの実行になる。"""
        data = write_two_channel_csv(tmp_path / "two.csv")
        out = tmp_path / "out"
        config = write_two_channel_config(tmp_path / "run.toml", data=data, directory=out)

        assert main([str(config), "--y-column", "ref"]) == ExitCode.SUCCESS

        labels = {row["column_label"] for row in summary_rows(out)}
        assert labels == {"ref"}, "並びの置き換えになっていない（1 要素の差し替えではない）"

    def test_the_replacement_is_kept_in_the_execution_record(self, tmp_path: Path) -> None:
        """要件 9.4: 置き換え前の並びと置き換え後の 1 件の双方が記録に残る。"""
        data = write_two_channel_csv(tmp_path / "two.csv")
        out = tmp_path / "out"
        config = write_two_channel_config(tmp_path / "run.toml", data=data, directory=out)

        assert main([str(config), "--y-column", "ref"]) == ExitCode.SUCCESS

        record = json.loads(
            (out / EXECUTION_RECORD_FILENAME).read_text(encoding="utf-8")
        )
        entries = {item["key"]: item for item in record["cli_overrides"]}
        assert entries["input.columns.y"]["config_value"] == ["signal", "ref"]
        assert entries["input.columns.y"]["cli_value"] == "ref"
        assert [item["y"] for item in record["resolved_config"]["columns"]] == ["ref"]

    def test_replacing_only_the_y_column_leaves_the_error_columns_unpaired(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """誤差列は y 列と 1 対 1 に対応する（要件 1.12、1.13）。

        置き換えは並び単位であるため、誤差列を 2 件のまま残した指定は個数が合わず、
        処理単位を 1 件も実行せずに停止する。黙って 1 件目を採ると、指定していない
        誤差列で重み付けされた結果が出る。
        """
        data = write_two_channel_csv(tmp_path / "two.csv")
        out = tmp_path / "out"
        config = write_two_channel_config(
            tmp_path / "run.toml", data=data, directory=out, weight=True
        )

        assert main([str(config), "--y-column", "ref"]) == ExitCode.CONFIG_ERROR

        assert "input.columns" in capsys.readouterr().err
        assert not out.exists(), "実行前に停止していない"

    def test_the_error_column_is_replaced_the_same_way(self, tmp_path: Path) -> None:
        """誤差列も並びを 1 件に置き換えれば対応が揃う。"""
        data = write_two_channel_csv(tmp_path / "two.csv")
        out = tmp_path / "out"
        config = write_two_channel_config(
            tmp_path / "run.toml", data=data, directory=out, weight=True
        )

        assert (
            main([str(config), "--y-column", "ref", "--weight-column", "sigma_ref"])
            == ExitCode.SUCCESS
        )

        record = json.loads(
            (out / EXECUTION_RECORD_FILENAME).read_text(encoding="utf-8")
        )
        assert record["resolved_config"]["columns"] == [
            {"x": "x", "y": "ref", "weight": "sigma_ref"}
        ]
        assert {row["column_label"] for row in summary_rows(out)} == {"ref"}


# --- 進捗表示（要件 6.3）-----------------------------------------------------------


class TestProgressDisplay:
    """処理済み件数と全体件数の双方が分かること（要件 6.3）。"""

    def test_both_the_input_count_and_the_job_count_are_shown(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """処理単位数は入力数 × 列数 × 手法数であり、利用者が数えるファイル数と一致しない。"""
        first = write_csv(tmp_path / "a.csv")
        second = write_csv(tmp_path / "b.csv")
        out = tmp_path / "out"
        config = tmp_path / "run.toml"
        config.write_text(
            "\n".join(
                [
                    "[input]",
                    f"paths = [{str(first)!r}, {str(second)!r}]",
                    "header = true",
                    "",
                    "[input.columns]",
                    'x = "x"',
                    'y = "y"',
                    "",
                    "[[methods]]",
                    'name = "lin"',
                    'builtin = "linear"',
                    "",
                    "[[methods]]",
                    'name = "quad"',
                    'smoother = "polynomial"',
                    "options = { degree = 2 }",
                    "",
                    "[output]",
                    f"directory = {str(out)!r}",
                    "write_plot = false",
                ]
            )
            + "\n",
            encoding="utf-8",
        )

        assert main([str(config)]) == ExitCode.SUCCESS

        captured = capsys.readouterr()
        assert "入力 2 件" in captured.err
        assert "処理単位 4 件" in captured.err
        assert "4/4" in captured.err

    def test_the_job_count_covers_the_column_axis(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """処理単位数は入力数 × 列数 × 手法数である（要件 1.11、6.8）。

        列軸を落とした説明では、1 ファイル 2 列 2 手法の実行で表示された 4 件が
        どこから来た数なのかを利用者が組み立て直せない。
        """
        data = write_two_channel_csv(tmp_path / "two.csv")
        config = write_two_channel_config(
            tmp_path / "run.toml",
            data=data,
            directory=tmp_path / "out",
            method_names=("lin", "lin2"),
        )

        assert main([str(config)]) == ExitCode.SUCCESS

        err = capsys.readouterr().err
        assert "入力 1 件" in err
        assert "処理単位 4 件" in err
        assert "入力 × 列 × 手法" in err

    def test_each_job_line_names_the_column(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """1 ファイル 2 列では対象と手法だけの行が完全に同一になる（要件 1.11）。

        実行ログが同じ理由で列を併記している（要件 8.4）。進捗の側だけ列を落とすと、
        どちらのチャネルまで進んだのかが端末から読み取れない。
        """
        data = write_two_channel_csv(tmp_path / "two.csv")
        config = write_two_channel_config(
            tmp_path / "run.toml", data=data, directory=tmp_path / "out"
        )

        assert main([str(config)]) == ExitCode.SUCCESS

        job_lines = [
            line for line in capsys.readouterr().err.splitlines() if line.startswith("[")
        ]
        assert len(job_lines) == 2
        assert len(set(job_lines)) == 2, f"2 つの列の行が区別できない: {job_lines}"
        assert any("signal" in line for line in job_lines)
        assert any("ref" in line for line in job_lines)

    def test_the_quiet_failure_line_names_the_column(self) -> None:
        """``--quiet`` の失敗報告にも列を併記する（要件 6.7）。

        こちらは失敗した対象を名指すことだけが目的の行であり、列が抜けると
        1 ファイル 2 列のうちどちらが落ちたのかが分からない。
        """
        stream = _ProgressStream(interactive=False)
        cli.FailureOnlyProgress(stream).on_job_done(
            1, 2, _failure_outcome("two.csv", column_label="ref")
        )

        assert "ref" in stream.getvalue()

    def test_writes_both_counts_at_startup(self) -> None:
        """双方を渡すという ``ProgressObserver`` の約束が描画にも及ぶこと（要件 6.3）。"""
        stream = io.StringIO()
        cli.TerminalProgress(stream).on_start(total_jobs=6, total_sources=3)

        rendered = stream.getvalue()
        assert "3" in rendered
        assert "6" in rendered

    def test_progress_does_not_pollute_stdout(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """進捗は標準出力を汚さない。"""
        data = write_csv(tmp_path / "sample.csv")
        config = write_config(
            tmp_path / "run.toml", paths=[data], directory=tmp_path / "out"
        )

        assert main([str(config)]) == ExitCode.SUCCESS

        captured = capsys.readouterr()
        assert captured.out == ""
        assert captured.err != ""

    def test_quiet_suppresses_progress(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """静音指定で進捗を出さない。"""
        data = write_csv(tmp_path / "sample.csv")
        config = write_config(
            tmp_path / "run.toml", paths=[data], directory=tmp_path / "out"
        )

        assert main([str(config), "--quiet"]) == ExitCode.SUCCESS
        assert capsys.readouterr().err == ""

    def test_quiet_still_reports_individual_failures(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """``--quiet`` の説明が約束する残り半分（要件 6.7）。

        引数の説明は「進捗と集計を表示しない。**違反と失敗の報告は表示する**」と
        述べている。失敗を含むバッチが終了コードだけを残して黙ると、数百件のうち何が
        落ちたのかを知るために実行ログを開かせることになる。
        """
        good = write_csv(tmp_path / "good.csv")
        bad = tmp_path / "bad.csv"
        bad.write_text("x,y\nERR,ERR\n", encoding="utf-8")
        config = write_config(
            tmp_path / "run.toml", paths=[good, bad], directory=tmp_path / "out"
        )

        assert main([str(config), "--quiet"]) == ExitCode.PARTIAL_FAILURE

        err = capsys.readouterr().err
        assert str(bad) in err, "失敗した対象が報告されていない"
        assert "開始:" not in err, "進捗を出している"
        assert "完了:" not in err, "集計を出している"

    def test_quiet_still_reports_preflight_violations(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """実行前検証で止まる場合、静音でも理由が分からなければ直しようがない（要件 6.7、8.5）。"""
        data = write_csv(tmp_path / "sample.csv")
        config = write_config(
            tmp_path / "run.toml",
            paths=[data],
            directory=tmp_path / "out",
            builtin="nosuchmodel",
        )

        assert main([str(config), "--quiet"]) == ExitCode.CONFIG_ERROR
        assert "nosuchmodel" in capsys.readouterr().err

    def test_progress_implementation_matches_the_observer_signature(self) -> None:
        """``pipeline`` は通知までを担い、描画は ``cli`` が持つ（設計の cli ブロック）。

        :class:`~curvefit.pipeline.ProgressObserver` は実行時検査可能な形では宣言されて
        いないため、メソッドの署名で確かめる。``pipeline`` は引数を名前ではなく位置で渡すが、
        名前まで一致させておかないと、通知の意味（``done`` と ``total``）が入れ替わって
        いても気付けない。
        """
        progress = cli.TerminalProgress(sys.stderr)
        for name in ("on_start", "on_job_done", "on_finish"):
            expected = inspect.signature(getattr(ProgressObserver, name))
            actual = inspect.signature(getattr(type(progress), name))
            assert [item.name for item in actual.parameters.values()] == [
                item.name for item in expected.parameters.values()
            ], name


# --- ヘルプ（設計の Security Considerations）----------------------------------------


class TestHelp:
    """ヘルプ。"""

    def test_help_states_the_risk_of_expression_evaluation(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """第三者から受け取った設定ファイルの実行は任意コード実行と同等である。"""
        with pytest.raises(SystemExit) as exit_info:
            main(["--help"])
        assert exit_info.value.code == 0

        text = capsys.readouterr().out
        assert "第三者" in text
        assert "任意の Python コード" in text

    def test_help_warns_about_passing_a_self_loaded_frame(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """既定の解釈器で読んだ値は渡される前に既に劣化している（実測 46.2%）。"""
        with pytest.raises(SystemExit):
            main(["--help"])
        assert "round_trip" in capsys.readouterr().out


# --- 依存方向（設計の Allowed Dependencies）-----------------------------------------


def _imported_modules(path: Path) -> set[str]:
    """対象ファイルが実際に import している最上位モジュール名を構文木から集める。

    docstring がモジュール名に言及するだけで誤検出しないよう、文字列ではなく構文木で
    判定する（``tests/integration/test_api.py`` と同じ規約）。
    """
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names - {"__future__"}


class _ProgressStream(io.StringIO):
    """端末直結かリダイレクト先かを差し替えられる出力先。

    ``TerminalProgress`` は ``isatty()`` の結果で描き方を変える。実際の端末を
    用意せずにその分岐を固定するため、返す値だけを差し替える。
    """

    def __init__(self, *, interactive: bool) -> None:
        super().__init__()
        self._interactive = interactive

    def isatty(self) -> bool:
        return self._interactive


def _emit_progress(stream: io.StringIO, outcomes: Sequence[FitOutcome]) -> str:
    """開始・各処理単位・完了の一連を流し、書かれた内容を返す。"""
    progress = cli.TerminalProgress(stream)
    progress.on_start(len(outcomes), 1)
    for index, outcome in enumerate(outcomes, start=1):
        progress.on_job_done(index, len(outcomes), outcome)
    progress.on_finish(
        BatchReport(
            outcomes=tuple(outcomes),
            n_success=sum(isinstance(o, FitSuccess) for o in outcomes),
            n_failure=sum(not isinstance(o, FitSuccess) for o in outcomes),
            aborted=False,
            execution=build_execution_record(
                config_path=None,
                resolved_config={},
                cli_overrides=(),
                clock=lambda: datetime.datetime(2026, 1, 1, tzinfo=datetime.UTC),
            ),
        )
    )
    return stream.getvalue()


class TestProgressRenderingPerStream:
    """端末直結では 1 行を上書きし、リダイレクト先では 1 件 1 行で残すこと。

    数百件のバッチ（要件 10.1）でログに流し込むと、上書き用の制御文字だけが増えて
    後から読む側の役に立たない。逆に端末では 1 件ごとに行が流れると、進捗というより
    ログの垂れ流しになる。この振る舞いは ``TerminalProgress`` の docstring が判断として
    明記しているものであり、回帰したときに気付けるよう固定する。
    """

    def test_leaves_no_control_characters_when_redirected(self) -> None:
        """リダイレクト先では制御文字を残さない。"""
        stream = _ProgressStream(interactive=False)
        written = _emit_progress(stream, [_success_outcome("a.csv"), _failure_outcome("b.csv")])

        assert "\r" not in written
        assert written.count("\n") == 4  # 開始 + 処理単位 2 件 + 完了
        assert "[1/2]" in written
        assert "[2/2]" in written

    def test_overwrites_the_job_line_on_a_terminal(self) -> None:
        """端末直結では処理単位の行を上書きする。"""
        stream = _ProgressStream(interactive=True)
        written = _emit_progress(stream, [_success_outcome("a.csv"), _failure_outcome("b.csv")])

        # 処理単位 1 件につき 1 つの復帰。開始と完了は上書きしないため改行で残る。
        assert written.count("\r") == 2
        assert written.count("\n") == 3

    def test_a_shorter_line_fully_covers_the_previous_one(self) -> None:
        """上書きは詰め物を伴う。伴わないと前の長い行の末尾が画面に残る。"""
        stream = _ProgressStream(interactive=True)
        written = _emit_progress(
            stream,
            [_success_outcome("非常に長い名前を持つ測定データ.csv"), _failure_outcome("a.csv")],
        )

        # 復帰で区切った各区間が 1 回の上書きに対応する。2 つ目の区間には後続の確定行が
        # 続くため、最初の改行までを 1 行として取り出す。
        long_line = written.split("\r")[1]
        short_line = written.split("\r")[2].split("\n")[0]
        assert len(short_line) >= len(long_line), (
            f"短い行が前の行を覆い切れていない: {len(short_line)} 文字 < {len(long_line)} 文字"
        )

    def test_the_final_line_does_not_absorb_the_overwritten_line(self) -> None:
        """上書き待ちの行がある状態で確定行を書くときは、先に改行して切り離す。"""
        stream = _ProgressStream(interactive=True)
        written = _emit_progress(stream, [_success_outcome("a.csv")])

        after_last_job = written.split("\r")[-1]
        assert "\n完了:" in after_last_job


class TestDependencyExposure:
    """依存の露出。"""

    def test_no_library_module_imports_it(self) -> None:
        """設計の cli ブロックの Invariants。"""
        for module in sorted(SRC.rglob("*.py")):
            if module.name == "cli.py":
                continue
            assert "curvefit.cli" not in _imported_modules(module), module

    def test_holds_no_config_file_values(self) -> None:
        """優先順位を判断しないことの構造的な裏づけ（要件 9.4 の実装箇所は ``config``）。

        判断するには設定ファイル側の値が要る。CLI は設定ファイルを解釈せず
        （:mod:`tomllib` を持たない）、``load_config`` も呼ばないため、比較のしようが
        ない。
        """
        imported = _imported_modules(SRC / "cli.py")
        assert "tomllib" not in imported
        source = (SRC / "cli.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        called = {
            node.func.id
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        } | {
            node.func.attr
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
        }
        assert "load_config" not in called

    def test_execution_goes_through_the_public_facade(self) -> None:
        """実行は公開ファサードを通る。"""
        assert "curvefit.api" in _imported_modules(SRC / "cli.py")


# --- コマンドとしての起動（要件 9.2）------------------------------------------------


def _console_script() -> Path:
    """宣言されたコンソールスクリプトの実体（``tests/unit/test_package_scaffold.py``）。"""
    return Path(sys.executable).parent / "curvefit"


class TestCommandInvocation:
    """コマンド起動。"""

    def test_running_the_command_writes_the_output_set_and_exits_0(self, tmp_path: Path) -> None:
        """要件 9.2、9.5: 実体を起動して経路全体を確かめる。"""
        data = write_csv(tmp_path / "sample.csv")
        out = tmp_path / "out"
        config = write_config(tmp_path / "run.toml", paths=[data], directory=out, write_plot=True)

        result = subprocess.run(
            [str(_console_script()), str(config)],
            capture_output=True,
            text=True,
            timeout=300,
        )

        assert result.returncode == ExitCode.SUCCESS, result.stderr
        assert result.stdout == ""
        generated = output_files(out)
        assert SUMMARY_FILENAME in generated
        assert EXECUTION_RECORD_FILENAME in generated
        assert RUN_LOG_FILENAME in generated
        assert any(name.startswith(f"{PLOT_SUBDIRECTORY}/") for name in generated), generated

    def test_no_arguments_prints_usage_and_exits_cleanly(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """``tests/unit/test_package_scaffold.py`` が要求する振る舞い。"""
        assert main([]) == ExitCode.SUCCESS
        assert "usage" in capsys.readouterr().out
