"""バッチ制御と失敗集約の統合テスト（要件 6.3、6.4、6.5、6.6、8.4、10.1、10.3）。

本テストは :func:`curvefit.pipeline.run` が次を満たすことを検証する。

- **逐次実行と集約**（要件 6.6、10.1）: 展開された処理単位を順に実行し、成功件数と
  失敗件数を含む集計結果を返すこと。サマリ表に全処理単位が現れること
- **既定はスキップ継続**（要件 6.4）: 個別の失敗が残りの処理を止めないこと
- **読めない入力ファイル**（要件 1.8、10.1）: 存在しない・読み取れない入力を
  :attr:`~curvefit.errors.FailureReason.INPUT_UNREADABLE` の個別失敗として記録し、
  後続の処理単位を実行すること。1 件の綴り誤りで数百件のバッチが終わってはならない
- **fail-fast**（要件 6.5）: 明示指定時は最初の失敗で中止し、それまでの結果を保持すること
- **進捗通知**（要件 6.3）: 総処理単位数と総入力数の双方を通知すること。処理単位数は
  入力数 × 列数 × 手法数であり、利用者が把握するファイル数と一致しない。端末への描画は
  行わないこと
- **列ごとの実行**（要件 1.11、6.8）: 同一ファイルの複数の y 列がそれぞれ独立した
  処理単位として走り、列ごとに読み込みが呼ばれること。読み込み結果をファイル単位で
  共有しないこと
- **0 件に解決された入力指定の警告**（要件 6.1、8.4）: その指定を明示して実行ログに
  残すこと。黙って正常終了すると 1 ディレクトリ分の入力が無報告で消える
- **資源枯渇**（要件 10.3）: ジョブ展開時の :exc:`OSError`、実行中の
  :exc:`MemoryError` / :exc:`OSError` を捕捉し、中断した対象を明示したうえで
  それまでの結果とサマリを保持して終了すること
- **適用既定値の記録**（要件 5.4）: 各処理単位が返した既定値を手法ごとに畳み込み、
  実行条件の記録に反映すること
- **決定性**（要件 8.2）: ログの順序が処理単位の順序に一致し、同一入力の再実行が
  同一のサマリ表を生むこと
- **メモリ上の系列の実行**（要件 9.1、9.3）: 読み込み済みの系列を受け取った実行が、
  入力の走査を行わず、出力先を持たないこと。それ以外の制御（処理単位の並び・進捗通知・
  適用既定値の畳み込み・資源枯渇の扱い）はファイル経由と同一であること

呼び出し側の誤りである :class:`~curvefit.pipeline.UnexpectedConfigViolation` は
捕捉しない。捕捉すべきは資源枯渇に限る（設計の Error Strategy）。

設計の Testing Strategy が `pipeline` の結線を統合テストに置いているため、単体では
なく `tests/integration/` に置く。
"""

from __future__ import annotations

import csv
import dataclasses
import json
import logging
import os
import stat
from collections.abc import Iterator, Sequence
from dataclasses import FrozenInstanceError
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pytest

from curvefit import pipeline
from curvefit.config import FailurePolicy, InputSpec, OutputSpec, RunConfig
from curvefit.errors import ConfigViolation, FailureReason, ViolationKind
from curvefit.execution import (
    EXECUTION_RECORD_FILENAME,
    ExecutionRecord,
    build_execution_record,
)
from curvefit.logging_setup import LOGGER_NAME, RUN_LOG_FILENAME
from curvefit.models.resolver import MethodSpec, SmootherKind
from curvefit.pipeline import (
    CURVE_SUBDIRECTORY,
    CURVE_SUFFIX,
    EMPTY_INPUT_STATUS,
    PLOT_SUBDIRECTORY,
    PREPROCESS_SUBDIRECTORY,
    SUMMARY_FILENAME,
    BatchReport,
    Job,
    JobResult,
    UnexpectedConfigViolation,
    expand_jobs,
    run,
)
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec
from curvefit.types import DataSeries, FitFailure, FitOutcome, FitSuccess

LINEAR = MethodSpec(name="lin", kind="builtin", builtin="linear")
POLYNOMIAL = MethodSpec(
    name="poly", kind="builtin", builtin="polynomial", options={"degree": 2}
)
MOVING_AVERAGE = MethodSpec(name="ma", kind="smoother", smoother=SmootherKind.MOVING_AVERAGE)

FIXED_MOMENT = datetime(2026, 1, 2, 3, 4, 5, tzinfo=UTC)
"""実行日時は実行ごとに正当に変わる唯一の値であるため、試験からは固定する（要件 8.2）。"""


def write_linear_csv(path: Path, *, n_points: int = 11, slope: float = 2.0) -> Path:
    """既知の直線から合成データを書き出す。見出し行を持つ。"""
    x = np.linspace(0.0, 10.0, n_points)
    y = slope * x + 1.0
    lines = ["x,y"]
    lines.extend(
        f"{x_value!r},{y_value!r}"
        for x_value, y_value in zip(x.tolist(), y.tolist(), strict=True)
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_broken_csv(path: Path) -> Path:
    """y 列を持たない CSV。要件 1.4 の ``COLUMN_NOT_FOUND`` になる。"""
    path.write_text("x,z\n0.0,1.0\n1.0,2.0\n2.0,3.0\n", encoding="utf-8")
    return path


def write_spiked_csv(path: Path, *, n_points: int = 11) -> Path:
    """外れ値を 1 点だけ含む直線データ。前処理が実際に除外を生む入力を作る。"""
    lines = ["x,y"]
    for index in range(n_points):
        x = float(index)
        y = 2.0 * x + (60.0 if index == n_points // 2 else 0.0)
        lines.append(f"{x!r},{y!r}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def make_config(
    directory: Path,
    paths: Sequence[str],
    methods: Sequence[MethodSpec],
    *,
    columns: Sequence[ColumnSpec] = (ColumnSpec(x="x", y="y"),),
    failure_policy: FailurePolicy = FailurePolicy.SKIP,
    write_summary: bool = True,
    write_plot: bool = False,
    write_curve: bool = False,
) -> RunConfig:
    """試験用の実行条件。グラフ出力は既定で切る（本試験の対象外であり実行が遅くなる）。

    ``write_curve`` を有効にすると、処理単位ごとの出力がファイルとして残る。集計の件数
    だけでは「実際にその処理単位が走ったか」を区別できない場面で用いる。
    """
    return RunConfig(
        inputs=InputSpec(paths=tuple(paths), columns=tuple(columns)),
        methods=tuple(methods),
        preprocess=PreprocessSpec(),
        output=OutputSpec(
            directory=directory,
            write_summary=write_summary,
            write_plot=write_plot,
            write_curve=write_curve,
        ),
        failure_policy=failure_policy,
    )


def make_record() -> ExecutionRecord:
    """実行前に組み立てた実行条件の記録。適用既定値はまだ空である。"""
    return build_execution_record(
        resolved_config={"input": "test"},
        clock=lambda: FIXED_MOMENT,
        tool_version="0.0.0-test",
        library_versions={},
    )


def read_log(config: RunConfig) -> str:
    return (config.output.directory / RUN_LOG_FILENAME).read_text(encoding="utf-8")


def summary_rows(config: RunConfig) -> list[dict[str, str]]:
    path = config.output.directory / SUMMARY_FILENAME
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def identities(outcomes: Sequence[FitOutcome]) -> list[tuple[str, str | None, str]]:
    """結果を識別する 3 つ組（設計の pipeline: 対象・列・手法）。

    対象と手法だけでは、同一ファイルの複数の y 列を扱う設定で 2 件が同じ組に潰れる。
    識別子として使う以上、設計が定める 3 つ目の軸を落とさない。
    """
    return [
        (outcome.source_id, outcome.column_label, outcome.method_name)
        for outcome in outcomes
    ]


def curve_outputs(config: RunConfig) -> list[str]:
    """出力先に実際に残った曲線 CSV の名前。

    集計の件数は「後続が走ったか」を保証しない。中断していても、その時点までの結果は
    同じ件数になりうる。実行の痕跡はファイルシステムで確かめる。
    """
    directory = config.output.directory / CURVE_SUBDIRECTORY
    if not directory.exists():
        return []
    return sorted(path.name for path in directory.glob(f"*{CURVE_SUFFIX}"))


def job_identities(config: RunConfig) -> list[tuple[str, str | None, str]]:
    return [
        (job.source, job.column_label, job.method.name) for job in expand_jobs(config)
    ]


def logged_identities(config: RunConfig) -> list[str]:
    """実行ログに現れた対象を、記録順のまま取り出す。"""
    collected: list[str] = []
    for line in read_log(config).splitlines():
        marker = "source_id="
        if marker not in line or "status=weights_ignored" in line:
            continue
        collected.append(line.split(marker, 1)[1].split(" ", 1)[0])
    return collected


class Recorder:
    """進捗通知の記録。:class:`~curvefit.pipeline.ProgressObserver` の試験実装。"""

    def __init__(self) -> None:
        self.started: list[tuple[int, int]] = []
        self.done: list[tuple[int, int, FitOutcome]] = []
        self.finished: list[BatchReport] = []

    def on_start(self, total_jobs: int, total_sources: int) -> None:
        self.started.append((total_jobs, total_sources))

    def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None:
        self.done.append((done, total, outcome))

    def on_finish(self, report: BatchReport) -> None:
        self.finished.append(report)


class TestSequentialRunAndAggregation:
    """展開された処理単位を順に実行し、集計結果を返すこと（要件 6.6、10.1）。"""

    def test_three_inputs_and_two_methods_give_six_results(self, tmp_path: Path) -> None:
        """3 入力かつ 2 手法で 6 件の結果になる。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        report = run(config, make_record())

        assert len(report.outcomes) == 6
        assert report.n_success == 6
        assert report.n_failure == 0
        assert report.aborted is False
        assert all(isinstance(outcome, FitSuccess) for outcome in report.outcomes)

    def test_result_order_matches_the_job_order(self, tmp_path: Path) -> None:
        """順序の所有者は :func:`expand_jobs` であり、集約は並べ替えない（要件 8.2）。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        report = run(config, make_record())

        assert identities(report.outcomes) == job_identities(config)

    def test_every_job_appears_in_the_summary(self, tmp_path: Path) -> None:
        """サマリ表に全処理単位が現れる。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        report = run(config, make_record())

        written = {
            (row["source_id"], row["column_label"], row["method_name"])
            for row in summary_rows(config)
        }
        # サマリ表は列の綴りを持たない結果を空文字で書く（``writers``）。
        assert written == {
            (source, label or "", method)
            for source, label, method in identities(report.outcomes)
        }

    def test_disabling_the_summary_prevents_it_from_being_written(self, tmp_path: Path) -> None:
        """サマリ出力を無効にすると書き出さない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR], write_summary=False
        )

        report = run(config, make_record())

        assert report.n_success == 1
        assert not (config.output.directory / SUMMARY_FILENAME).exists()

    def test_the_run_log_keeps_the_start_and_end_counts(self, tmp_path: Path) -> None:
        """要件 8.4: 処理した対象と成否を実行ログとして出力する。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        run(config, make_record())

        text = read_log(config)
        assert "status=started" in text
        assert "status=finished n_success=1 n_failure=0" in text

    def test_the_run_log_order_matches_the_job_order(self, tmp_path: Path) -> None:
        """実行ログの順序が処理単位の順序に一致する。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL]
        )

        run(config, make_record())

        assert logged_identities(config) == [
            repr(source) for source, _, _ in job_identities(config)
        ]

    def test_rerunning_the_same_input_yields_the_same_summary(self, tmp_path: Path) -> None:
        """要件 8.2: 同一設定・同一入力なら出力物が逐字一致する。"""
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        first = make_config(tmp_path / "out1", [str(tmp_path / "*.csv")], [LINEAR])
        second = make_config(tmp_path / "out2", [str(tmp_path / "*.csv")], [LINEAR])

        run(first, make_record())
        run(second, make_record())

        assert (first.output.directory / SUMMARY_FILENAME).read_bytes() == (
            second.output.directory / SUMMARY_FILENAME
        ).read_bytes()


def write_two_channel_csv(path: Path, *, n_points: int = 11) -> Path:
    """1 つの x 列に対して 2 つの y 列を持つ CSV。傾きが列ごとに異なる。"""
    x = np.linspace(0.0, 10.0, n_points)
    lines = ["x,y,z"]
    lines.extend(
        f"{value!r},{2.0 * value + 1.0!r},{5.0 * value + 1.0!r}" for value in x.tolist()
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def slope(outcome: FitOutcome) -> float:
    """直線当てはめの傾き。列ごとに別のデータが読まれたことを値で確かめる。"""
    assert isinstance(outcome, FitSuccess)
    values = {estimate.name: estimate.value for estimate in outcome.parameters}
    return float(values["slope"])


class TestColumnAxisInTheBatch:
    """要件 1.11、6.8: 同一ファイルの複数の y 列を、それぞれ独立した処理単位として走らせる。"""

    def test_two_columns_of_one_file_run_as_two_units(self, tmp_path: Path) -> None:
        """1 ファイル 2 列 1 手法が 2 件の結果になり、列ごとに別のデータが読まれる。"""
        write_two_channel_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "a.csv")],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="z")),
        )

        report = run(config, make_record())

        assert report.n_success == 2
        assert slope(report.outcomes[0]) == pytest.approx(2.0)
        assert slope(report.outcomes[1]) == pytest.approx(5.0)

    def test_three_files_times_two_columns_times_two_methods(self, tmp_path: Path) -> None:
        """3 ファイル × 2 列 × 2 手法が 12 処理単位になる（タスク 13.7 の完了状態）。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_two_channel_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "*.csv")],
            [LINEAR, POLYNOMIAL],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="z")),
        )

        report = run(config, make_record())

        assert len(report.outcomes) == 12
        assert report.n_success == 12

    def test_the_run_is_read_once_per_unit_not_once_per_file(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """読み込みは処理単位ごとに呼ばれる。結果をファイル単位で共有しない。

        共有すると処理単位が独立に実行できなくなり、要件 6.4 の個別失敗の非波及と
        要件 10.4 の常駐メモリの頭打ちの双方に影響する（設計の Responsibilities）。
        """
        write_two_channel_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "a.csv")],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="z")),
        )
        calls: list[ColumnSpec] = []
        original = pipeline.read_delimited

        def spy(path: Path, columns: ColumnSpec, *args: object, **kwargs: object) -> object:
            calls.append(columns)
            return original(path, columns, *args, **kwargs)  # type: ignore[arg-type]

        monkeypatch.setattr(pipeline, "read_delimited", spy)

        run(config, make_record())

        assert calls == [ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="z")]

    def test_a_missing_column_fails_only_its_own_unit(self, tmp_path: Path) -> None:
        """列を解決できない失敗は、同一ファイルの他の列に波及しない（要件 1.4、6.4）。"""
        write_two_channel_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "a.csv")],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="無い")),
        )

        report = run(config, make_record())

        assert report.n_success == 1
        assert report.n_failure == 1
        failure = report.outcomes[1]
        assert isinstance(failure, FitFailure)
        assert failure.reason is FailureReason.COLUMN_NOT_FOUND

    def test_progress_counts_units_not_files(self, tmp_path: Path) -> None:
        """進捗の総数は 入力数 × 列数 × 手法数である（要件 6.3）。"""
        write_two_channel_csv(tmp_path / "a.csv")
        write_two_channel_csv(tmp_path / "b.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "*.csv")],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="z")),
        )
        recorder = Recorder()

        run(config, make_record(), recorder)

        assert recorder.started == [(4, 2)]


class TestScaleAndResourceRelease:
    """要件 10.1: 1 回の実行で多数の入力を逐次処理する。"""

    def test_aggregates_many_jobs_without_dropping_any(self, tmp_path: Path) -> None:
        """多数の処理単位を取りこぼさずに集計する。"""
        sources = tmp_path / "data"
        sources.mkdir()
        for index in range(25):
            write_linear_csv(sources / f"m{index:03d}.csv")
        config = make_config(tmp_path / "out", [str(sources)], [LINEAR, POLYNOMIAL])

        recorder = Recorder()
        report = run(config, make_record(), recorder)

        assert recorder.started == [(50, 25)]
        assert report.n_success == 50
        assert report.n_failure == 0
        assert len({row["source_id"] for row in summary_rows(config)}) == 25

    def test_releases_the_run_log_handler_on_completion(self, tmp_path: Path) -> None:
        """開いたままにすると、連続実行でファイル記述子を食い潰す（要件 10.1）。"""
        write_linear_csv(tmp_path / "a.csv")
        logger = logging.getLogger(LOGGER_NAME)
        before = list(logger.handlers)

        for index in range(3):
            config = make_config(
                tmp_path / f"out{index}", [str(tmp_path / "a.csv")], [LINEAR]
            )
            run(config, make_record())

        assert list(logger.handlers) == before

    def test_releases_the_handler_even_for_an_aborted_run(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """例外で抜ける経路でも取っ手を閉じる（``with`` 文を使う理由）。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        logger = logging.getLogger(LOGGER_NAME)
        before = list(logger.handlers)
        stub_run_job(monkeypatch, UnexpectedConfigViolation(()), at_index=0)

        with pytest.raises(UnexpectedConfigViolation):
            run(config, make_record())

        assert list(logger.handlers) == before


class TestCurveDataRelease:
    """要件 10.4: 集計結果は曲線データを保持せず、常駐メモリが件数に比例して増えない。

    保持していた頃は 1 件あたり 4 配列 × 8 バイト × 点数（2 万行で 625 KiB）が実行終了まで
    解放されず、要件 10.1 の上限規模（500 件 × 5 万行）で約 800 MB に達していた。曲線は
    ``curves/*.csv`` として既にディスクにあり、メモリ上の保持は重複である。

    **常駐メモリそのものの推移は ``tests/performance/`` が見る。** ここで固定するのは、
    解放が起きること・出力より後に起きること・推定値に触れないことの 3 点である。
    """

    def test_curve_data_is_dropped_from_the_success_outcome(self, tmp_path: Path) -> None:
        """成功結果から曲線データが外れる。"""
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path)], [LINEAR, POLYNOMIAL])

        report = run(config, make_record())

        successes = [outcome for outcome in report.outcomes if isinstance(outcome, FitSuccess)]
        assert len(successes) == 4
        assert all(outcome.curve is None for outcome in successes)

    def test_the_release_happens_after_the_curve_csv_is_written(self, tmp_path: Path) -> None:
        """出力の適用より前に手放すと、要件 7.5 の出力が空になる。

        件数だけでは順序を固定できない。書かれた行数が点数と一致することまで見る。
        """
        source = write_linear_csv(tmp_path / "a.csv", n_points=11)
        config = make_config(
            tmp_path / "out", [str(source)], [LINEAR], write_curve=True, write_plot=True
        )

        report = run(config, make_record())

        assert [outcome.curve for outcome in report.outcomes] == [None]
        written = curve_outputs(config)
        assert len(written) == 1
        path = config.output.directory / CURVE_SUBDIRECTORY / written[0]
        with path.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        assert len(rows) == 11
        assert all(row["y_fit"] for row in rows)
        # グラフ画像も同じ順序に依存する（要件 7.4）。
        assert len(list((config.output.directory / "plots").glob("*.png"))) == 1

    def test_the_curve_remains_when_retention_is_requested(self, tmp_path: Path) -> None:
        """要件 9.1: 単一系列の経路（``api.fit_series``）が使う指定。

        曲線を返す経路が残っていることを ``pipeline`` の水準で固定する。ここが失われると
        ``fit_series`` の利用者は各点の当てはめ値と残差を受け取る手段を失う。
        """
        source = write_linear_csv(tmp_path / "a.csv", n_points=11)
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        report = run(config, make_record(), retain_curve=True)

        (outcome,) = report.outcomes
        assert isinstance(outcome, FitSuccess)
        assert outcome.curve is not None
        assert len(outcome.curve) == outcome.goodness.n_points == 11

    def test_releasing_leaves_estimates_and_goodness_unchanged(self, tmp_path: Path) -> None:
        """手放すのは曲線の欄だけである。集計に使う値に触れていないこと。"""
        source = write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        released = run(config, make_record())
        retained = run(make_config(tmp_path / "out2", [str(source)], [LINEAR]),
                       make_record(), retain_curve=True)

        (left,) = released.outcomes
        (right,) = retained.outcomes
        assert isinstance(left, FitSuccess) and isinstance(right, FitSuccess)
        assert left.parameters == right.parameters
        assert left.goodness == right.goodness
        assert left.preprocess == right.preprocess
        assert left == right.without_curve()

    def test_the_progress_observer_also_receives_the_released_outcome(self, tmp_path: Path) -> None:
        """通知と集計で別の値を渡すと、進捗で見た結果と後から読む結果が食い違う。"""
        source = write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        recorder = Recorder()
        report = run(config, make_record(), recorder)

        assert [outcome for _, _, outcome in recorder.done] == list(report.outcomes)
        assert all(
            outcome.curve is None
            for _, _, outcome in recorder.done
            if isinstance(outcome, FitSuccess)
        )


class TestBatchReportInvariants:
    """``len(outcomes) == n_success + n_failure``（設計の Postconditions）。"""

    def test_a_report_whose_counts_disagree_with_the_results_cannot_be_built(self) -> None:
        """件数が結果の総数と一致しない記録は作れない。"""
        with pytest.raises(ValueError):
            BatchReport(
                outcomes=(),
                n_success=1,
                n_failure=0,
                aborted=False,
                execution=make_record(),
            )

    def test_cannot_be_mutated_after_construction(self, tmp_path: Path) -> None:
        """生成後に変更できない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        report = run(config, make_record())

        with pytest.raises(FrozenInstanceError):
            report.aborted = True  # type: ignore[misc]


class TestDefaultIsSkipAndContinue:
    """要件 6.4: 個別の失敗は残りの処理を止めない。"""

    def test_one_failure_does_not_stop_the_rest(self, tmp_path: Path) -> None:
        """1 件失敗しても残りが処理される。"""
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        report = run(config, make_record())

        assert report.aborted is False
        assert len(report.outcomes) == 3
        assert report.n_success == 2
        assert report.n_failure == 1
        assert isinstance(report.outcomes[1], FitFailure)

    def test_the_failed_source_and_reason_stay_in_the_run_log(self, tmp_path: Path) -> None:
        """要件 6.4、8.4: 失敗した対象と失敗理由を記録する。"""
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        run(config, make_record())

        text = read_log(config)
        assert str(tmp_path / "b.csv") in text
        assert FailureReason.COLUMN_NOT_FOUND.value in text

    def test_failures_also_appear_in_the_summary(self, tmp_path: Path) -> None:
        """要件 6.6: 成否件数とサマリ表を突き合わせられること。"""
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        report = run(config, make_record())

        statuses = [row["status"] for row in summary_rows(config)]
        assert statuses.count("failure") == report.n_failure
        assert "success" in statuses


class TestFailFast:
    """要件 6.5: fail-fast では最初の失敗で残りを中止し、それまでの結果を保持する。"""

    def test_nothing_runs_after_the_first_failure(self, tmp_path: Path) -> None:
        """最初の失敗で以降を実行しない。"""
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "*.csv")],
            [LINEAR],
            failure_policy=FailurePolicy.FAIL_FAST,
        )

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 2
        assert report.n_success == 1
        assert report.n_failure == 1
        assert str(tmp_path / "c.csv") not in [o.source_id for o in report.outcomes]

    def test_results_so_far_remain_in_the_summary_on_abort(self, tmp_path: Path) -> None:
        """中止時もそれまでの結果がサマリ表に残る。"""
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        write_linear_csv(tmp_path / "c.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "*.csv")],
            [LINEAR],
            failure_policy=FailurePolicy.FAIL_FAST,
        )

        report = run(config, make_record())

        written = {row["source_id"] for row in summary_rows(config)}
        assert written == {str(tmp_path / "a.csv"), str(tmp_path / "b.csv")}
        assert report.n_success + report.n_failure == len(report.outcomes)


class TestProgressNotification:
    """要件 6.3: 処理済み件数と全体件数が分かる進捗を通知する。"""

    def test_receives_both_the_total_job_count_and_the_total_input_count(
        self, tmp_path: Path
    ) -> None:
        """処理単位数は入力数 × 列数 × 手法数であり、利用者が数えるファイル数と一致しない。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL])
        recorder = Recorder()

        run(config, make_record(), recorder)

        assert recorder.started == [(6, 3)]

    def test_notifies_once_per_job_in_job_order(self, tmp_path: Path) -> None:
        """処理単位ごとに 1 回ずつ処理単位の順序で通知する。"""
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR, POLYNOMIAL])
        recorder = Recorder()

        report = run(config, make_record(), recorder)

        assert [done for done, _, _ in recorder.done] == [1, 2, 3, 4]
        assert {total for _, total, _ in recorder.done} == {4}
        assert [outcome for _, _, outcome in recorder.done] == list(report.outcomes)

    def test_the_finish_notification_fires_once_with_the_report(self, tmp_path: Path) -> None:
        """終了通知は 1 回で集計結果を伴う。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        recorder = Recorder()

        report = run(config, make_record(), recorder)

        assert recorder.finished == [report]

    def test_runs_without_an_observer(self, tmp_path: Path) -> None:
        """通知先が無くても実行できる。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        report = run(config, make_record(), None)

        assert report.n_success == 1

    def test_does_not_draw_to_the_terminal(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """通知までが責任範囲であり、描画は CLI が持つ（設計の cli ブロック）。"""
        write_linear_csv(tmp_path / "a.csv")
        write_broken_csv(tmp_path / "b.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])

        run(config, make_record())

        captured = capsys.readouterr()
        assert captured.out == ""
        assert captured.err == ""


class TestInputSpecResolvingToNothing:
    """要件 6.1、8.4: 0 件になった指定を明示して実行ログに警告を残す。"""

    def test_warns_about_a_directory_with_no_matching_extension(self, tmp_path: Path) -> None:
        """拡張子が一致しないディレクトリを警告する。"""
        directory = tmp_path / "measurements"
        directory.mkdir()
        (directory / "notes.dat").write_text("x,y\n0,1\n", encoding="utf-8")
        config = make_config(tmp_path / "out", [str(directory)], [LINEAR])

        report = run(config, make_record())

        text = read_log(config)
        assert EMPTY_INPUT_STATUS in text
        assert repr(str(directory)) in text
        assert report.outcomes == ()
        assert report.aborted is False

    def test_warns_about_a_wildcard_with_no_match(self, tmp_path: Path) -> None:
        """一致しないワイルドカードを警告する。"""
        write_linear_csv(tmp_path / "a.csv")
        pattern = str(tmp_path / "*.tsv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv"), pattern], [LINEAR])

        report = run(config, make_record())

        text = read_log(config)
        assert repr(pattern) in text
        assert EMPTY_INPUT_STATUS in text
        assert report.n_success == 1

    def test_a_spec_that_resolved_produces_no_warning(self, tmp_path: Path) -> None:
        """解決できた指定は警告しない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        run(config, make_record())

        assert EMPTY_INPUT_STATUS not in read_log(config)

    def test_a_direct_spec_for_a_missing_file_produces_no_warning(self, tmp_path: Path) -> None:
        """存在確認は行わない。1 件の処理単位として個別失敗になる（要件 1.8）。

        件数だけを見ると、中断していても同じ 1 件になる。0 件の警告を出さない根拠は
        「個別の失敗として報告され、処理は継続する」ことであるため、中断していないことと
        失敗理由の双方を確かめる。
        """
        missing = str(tmp_path / "missing.csv")
        config = make_config(tmp_path / "out", [missing], [LINEAR])

        report = run(config, make_record())

        assert EMPTY_INPUT_STATUS not in read_log(config)
        assert report.n_failure == 1
        assert report.aborted is False
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.INPUT_UNREADABLE


class TestUnreadableInputFile:
    """要件 1.8、6.4、10.1: 読めない 1 件を個別の失敗として記録し、残りを継続する。

    綴り誤り 1 つ、あるいは共有先から実行中に消えた 1 ファイルで数百件のバッチが終わって
    はならない。中断してよいのは、対象を替えても解消しない失敗（出力先の不備・記憶領域の
    枯渇）に限る。
    """

    def test_a_missing_file_midway_does_not_stop_later_jobs(self, tmp_path: Path) -> None:
        """5 入力の 3 番目が存在しない場合でも、4 番目以降が実行されること。

        件数だけでは中断と区別できないため、後続の出力物が実際に残っているかを
        ファイルシステムで確かめる。
        """
        for name in ("a.csv", "b.csv", "d.csv", "e.csv"):
            write_linear_csv(tmp_path / name)
        paths = [str(tmp_path / name) for name in ("a.csv", "b.csv", "c.csv", "d.csv", "e.csv")]
        config = make_config(tmp_path / "out", paths, [LINEAR], write_curve=True)

        report = run(config, make_record())

        assert report.aborted is False
        assert report.n_success == 4
        assert report.n_failure == 1
        assert [outcome.source_id for outcome in report.outcomes] == paths
        failure = report.outcomes[2]
        assert isinstance(failure, FitFailure)
        assert failure.reason is FailureReason.INPUT_UNREADABLE
        assert curve_outputs(config) == [
            "a__y__lin__0000.csv",
            "b__y__lin__0001.csv",
            "d__y__lin__0003.csv",
            "e__y__lin__0004.csv",
        ]

    def test_reports_the_unreadable_source_and_the_reason(self, tmp_path: Path) -> None:
        """要件 1.8: 識別子と読み取れない理由の双方を載せる。"""
        missing = tmp_path / "missing.csv"
        config = make_config(tmp_path / "out", [str(missing)], [LINEAR])

        report = run(config, make_record())

        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.source_id == str(missing)
        assert outcome.method_name == "lin"
        assert "FileNotFoundError" in outcome.message
        assert str(missing) in outcome.message

    def test_stays_in_the_run_log_as_an_individual_failure(self, tmp_path: Path) -> None:
        """要件 8.4: 中断ではなく個別失敗として記録されること。"""
        missing = tmp_path / "missing.csv"
        write_linear_csv(tmp_path / "z.csv")
        config = make_config(tmp_path / "out", [str(missing), str(tmp_path / "z.csv")], [LINEAR])

        run(config, make_record())

        text = read_log(config)
        assert FailureReason.INPUT_UNREADABLE.value in text
        assert str(missing) in text
        assert "status=finished n_success=1 n_failure=1" in text

    def test_appears_in_the_summary_as_a_failure(self, tmp_path: Path) -> None:
        """要件 6.6: 読めなかった対象もサマリ表から辿れること。"""
        missing = tmp_path / "missing.csv"
        write_linear_csv(tmp_path / "z.csv")
        config = make_config(tmp_path / "out", [str(missing), str(tmp_path / "z.csv")], [LINEAR])

        run(config, make_record())

        written = {(row["source_id"], row["status"]) for row in summary_rows(config)}
        assert (str(missing), "failure") in written
        assert (str(tmp_path / "z.csv"), "success") in written

    def test_fail_fast_aborts_on_the_first_missing_file(self, tmp_path: Path) -> None:
        """要件 6.5: 明示指定時は個別失敗でも中止する。既定との違いを固定する。"""
        for name in ("b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        paths = [str(tmp_path / name) for name in ("a.csv", "b.csv", "c.csv")]
        config = make_config(
            tmp_path / "out",
            paths,
            [LINEAR],
            failure_policy=FailurePolicy.FAIL_FAST,
            write_curve=True,
        )

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        assert curve_outputs(config) == []

    @pytest.mark.skipif(
        hasattr(os, "geteuid") and os.geteuid() == 0,
        reason="root は読み取り権限の無いファイルも読めるため、この分岐を再現できない",
    )
    def test_an_unreadable_permission_also_continues_as_an_individual_failure(
        self, tmp_path: Path
    ) -> None:
        """存在しても読めない場合（要件 1.8 の後半）。後続は実行される。"""
        locked = write_linear_csv(tmp_path / "b.csv")
        for name in ("a.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        locked.chmod(0o000)
        paths = [str(tmp_path / name) for name in ("a.csv", "b.csv", "c.csv")]
        config = make_config(tmp_path / "out", paths, [LINEAR], write_curve=True)

        try:
            report = run(config, make_record())
        finally:
            locked.chmod(stat.S_IRUSR | stat.S_IWUSR)

        assert report.aborted is False
        assert report.n_success == 2
        failure = report.outcomes[1]
        assert isinstance(failure, FitFailure)
        assert failure.reason is FailureReason.INPUT_UNREADABLE
        assert "PermissionError" in failure.message
        assert curve_outputs(config) == ["a__y__lin__0000.csv", "c__y__lin__0002.csv"]


@pytest.mark.skipif(
    hasattr(os, "geteuid") and os.geteuid() == 0,
    reason="root は読み取り権限の無いディレクトリも読めるため、この分岐を再現できない",
)
class TestResourceExhaustionDuringExpansion:
    """要件 10.3: 読み取れないディレクトリを ``RESOURCE_EXHAUSTED`` として扱う。"""

    @pytest.fixture
    def unreadable(self, tmp_path: Path) -> Iterator[Path]:
        directory = tmp_path / "locked"
        directory.mkdir()
        (directory / "a.csv").write_text("x,y\n0,1\n", encoding="utf-8")
        directory.chmod(0o000)
        yield directory
        directory.chmod(stat.S_IRWXU)

    def test_reports_an_abort_and_yields_no_results(self, tmp_path: Path, unreadable: Path) -> None:
        """中断として報告し結果は空になる。"""
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])

        report = run(config, make_record())

        assert report.aborted is True
        assert report.outcomes == ()
        assert report.n_success == 0
        assert report.n_failure == 0

    def test_keeps_the_aborted_target_and_reason_in_the_run_log(
        self, tmp_path: Path, unreadable: Path
    ) -> None:
        """中断した対象と理由を実行ログに残す。"""
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])

        run(config, make_record())

        text = read_log(config)
        assert FailureReason.RESOURCE_EXHAUSTED.value in text
        assert str(unreadable) in text

    def test_the_summary_is_still_written(self, tmp_path: Path, unreadable: Path) -> None:
        """サマリ表は保持される。"""
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])

        run(config, make_record())

        assert (config.output.directory / SUMMARY_FILENAME).exists()
        assert summary_rows(config) == []

    def test_does_not_notify_start_but_does_notify_finish(
        self, tmp_path: Path, unreadable: Path
    ) -> None:
        """総数が確定していないため開始を通知できない。集計結果は必ず届ける。"""
        config = make_config(tmp_path / "out", [str(unreadable)], [LINEAR])
        recorder = Recorder()

        report = run(config, make_record(), recorder)

        assert recorder.started == []
        assert recorder.done == []
        assert recorder.finished == [report]


def stub_run_job(monkeypatch: pytest.MonkeyPatch, error: BaseException, *, at_index: int) -> None:
    """指定した処理単位で例外を送出する :func:`run_job` に差し替える。

    実運用でメモリ枯渇や書き込み不能を再現する手段が無いため、境界の外側から注入する。
    """
    original = pipeline.run_job

    def stubbed(job: Job, config: RunConfig) -> JobResult:
        if job.index == at_index:
            raise error
        return original(job, config)

    monkeypatch.setattr(pipeline, "run_job", stubbed)


class TestResourceExhaustionDuringTheRun:
    """要件 10.3: 中断した対象を明示し、それまでの結果とサマリを保持する。"""

    @pytest.mark.parametrize(
        "error", [MemoryError("記憶領域が尽きた"), OSError("書き込みに失敗した")]
    )
    def test_aborts_while_keeping_the_results_so_far(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, error: BaseException
    ) -> None:
        """それまでの結果を保持して中断する。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, error, at_index=1)

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 2
        assert isinstance(report.outcomes[0], FitSuccess)
        assert report.outcomes[0].source_id == str(tmp_path / "a.csv")
        assert report.n_success == 1
        assert report.n_failure == 1

    def test_names_the_aborted_target(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """中断した対象を明示する。"""
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, MemoryError("記憶領域が尽きた"), at_index=1)

        report = run(config, make_record())

        aborted_outcome = report.outcomes[-1]
        assert isinstance(aborted_outcome, FitFailure)
        assert aborted_outcome.source_id == str(tmp_path / "b.csv")
        assert aborted_outcome.method_name == "lin"
        assert aborted_outcome.reason is FailureReason.RESOURCE_EXHAUSTED
        assert str(tmp_path / "b.csv") in read_log(config)

    def test_writes_the_summary(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """サマリ表を書き出す。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, OSError("書き込みに失敗した"), at_index=1)

        run(config, make_record())

        written = {(row["source_id"], row["status"]) for row in summary_rows(config)}
        assert (str(tmp_path / "a.csv"), "success") in written
        assert (str(tmp_path / "b.csv"), "failure") in written
        assert str(tmp_path / "c.csv") not in {source for source, _ in written}

    def test_jobs_after_the_abort_do_not_run(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """中断後の処理単位は実行しない。"""
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR])
        stub_run_job(monkeypatch, MemoryError("記憶領域が尽きた"), at_index=1)
        recorder = Recorder()

        run(config, make_record(), recorder)

        assert [done for done, _, _ in recorder.done] == [1, 2]
        assert len(recorder.finished) == 1

    def test_aborts_when_the_output_cannot_be_written(self, tmp_path: Path) -> None:
        """注入ではなく実物の書き込み失敗で中断すること（要件 10.3）。

        入力を読めない場合（要件 1.8）と対になる分岐である。出力先の不備は対象を替えても
        解消しないため、個別の失敗として飲み込んではならない。``curves`` を通常ファイルに
        しておくと、最初の処理単位の出力書き込みが :exc:`OSError` になる。
        """
        for name in ("a.csv", "b.csv", "c.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR], write_curve=True
        )
        config.output.directory.mkdir(parents=True)
        (config.output.directory / CURVE_SUBDIRECTORY).write_text("not a dir", encoding="utf-8")

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.RESOURCE_EXHAUSTED
        assert outcome.source_id == str(tmp_path / "a.csv")

    def test_also_aborts_when_the_preprocess_csv_cannot_be_written(self, tmp_path: Path) -> None:
        """前処理 CSV の書き込み失敗も資源・環境の失敗として扱うこと（要件 10.3、2.5）。

        この出力は成否によらず書かれる唯一のものであり（要件 2.5）、しかもオプトインの
        フラグを持たない。書けない事態を個別の失敗として飲み込むと、出力先の不備が
        対象を替えても解消しないまま数百件を走り切ることになる。

        ``preprocess`` を通常ファイルにしておくと、除外の生じた最初の処理単位で
        :exc:`OSError` になる。
        """
        write_spiked_csv(tmp_path / "a.csv")
        write_spiked_csv(tmp_path / "b.csv")
        config = dataclasses.replace(
            make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [LINEAR]),
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=1.5, max_iterations=3)),
        )
        config.output.directory.mkdir(parents=True)
        (config.output.directory / PREPROCESS_SUBDIRECTORY).write_text(
            "not a dir", encoding="utf-8"
        )

        report = run(config, make_record())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.reason is FailureReason.RESOURCE_EXHAUSTED
        assert outcome.source_id == str(tmp_path / "a.csv")

    def test_the_preprocess_record_survives_an_unwritable_plot(self, tmp_path: Path) -> None:
        """当てはめ結果の書き込み失敗が、前処理の記録まで道連れにしないこと（要件 2.5、10.3）。

        前処理 CSV は「前処理が何をしたか」の記録であり、当てはめ結果とは独立に成立する。
        図や曲線 CSV の書き込みが :exc:`OSError` で落ちたとき、その処理単位で何点を
        どう除外したのかまで失われると、中断の原因を追う手がかりが減る。

        ``plots`` を通常ファイルにしておくと図の書き込みが失敗する。
        """
        write_spiked_csv(tmp_path / "a.csv")
        config = dataclasses.replace(
            make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR], write_plot=True),
            preprocess=PreprocessSpec(outlier=OutlierSpec(sigma=1.5, max_iterations=3)),
        )
        config.output.directory.mkdir(parents=True)
        (config.output.directory / PLOT_SUBDIRECTORY).write_text("not a dir", encoding="utf-8")

        report = run(config, make_record())

        assert report.aborted is True
        assert report.outcomes[0].reason is FailureReason.RESOURCE_EXHAUSTED
        written = config.output.directory / PREPROCESS_SUBDIRECTORY
        assert written.is_dir(), "図を書けなかったせいで前処理の記録まで失われている"
        (recorded,) = sorted(written.iterdir())
        assert len(recorded.read_text(encoding="utf-8").splitlines()) >= 2

    def test_aborts_keeping_results_when_the_summary_cannot_be_written(
        self, tmp_path: Path
    ) -> None:
        """書き込み不能は資源・環境の失敗であり、握り潰さない（要件 10.3）。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        (config.output.directory / SUMMARY_FILENAME).mkdir(parents=True)

        report = run(config, make_record())

        assert report.aborted is True
        assert report.n_success == 1
        assert FailureReason.RESOURCE_EXHAUSTED.value in read_log(config)

    def test_the_execution_record_survives_an_unwritable_summary(self, tmp_path: Path) -> None:
        """要件 8.3: 片方が書けないことは他方を捨てる理由にならない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [MOVING_AVERAGE])
        (config.output.directory / SUMMARY_FILENAME).mkdir(parents=True)

        report = run(config, make_record())

        assert report.aborted is True
        written = json.loads(
            (config.output.directory / EXECUTION_RECORD_FILENAME).read_text(encoding="utf-8")
        )
        assert written["applied_defaults"] == {"ma": {"window": 5, "polyorder": 0}}


class TestCallerErrorsAreNotSwallowed:
    """実行前ゲートを通っていない指定は、値ではなく例外で伝える（設計の Error Strategy）。"""

    def test_unexpected_config_violation_passes_through(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """UnexpectedConfigViolation を素通しする。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])
        violation = ConfigViolation(
            kind=ViolationKind.MODEL_UNRESOLVED, location="methods[0]", message="未知"
        )
        stub_run_job(monkeypatch, UnexpectedConfigViolation((violation,)), at_index=0)

        with pytest.raises(UnexpectedConfigViolation):
            run(config, make_record())


class TestAppliedDefaultsRecording:
    """要件 5.4: 当てはめが補った既定値を手法ごとに畳み込み、実行条件に反映する。"""

    def test_the_execution_record_carries_per_method_defaults(self, tmp_path: Path) -> None:
        """実行条件の記録に手法ごとの既定値が入る。"""
        for name in ("a.csv", "b.csv"):
            write_linear_csv(tmp_path / name)
        config = make_config(tmp_path / "out", [str(tmp_path / "*.csv")], [MOVING_AVERAGE])

        report = run(config, make_record())

        assert report.n_success == 2
        assert dict(report.execution.applied_defaults) == {"ma": {"window": 5, "polyorder": 0}}

    def test_the_passed_record_is_not_mutated(self, tmp_path: Path) -> None:
        """実行条件は読むだけであり、呼び出し側の値を変更しない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [MOVING_AVERAGE])
        record = make_record()

        report = run(config, record)

        assert dict(record.applied_defaults) == {}
        assert report.execution is not record
        assert report.execution.started_at == record.started_at

    def test_methods_applying_no_default_are_absent_from_the_record(self, tmp_path: Path) -> None:
        """既定値を適用しない手法は記録に現れない。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [LINEAR])

        report = run(config, make_record())

        assert dict(report.execution.applied_defaults) == {}

    def test_the_execution_record_lands_in_the_output_directory(self, tmp_path: Path) -> None:
        """要件 8.3、5.4: 適用した値を実行条件として記録する。"""
        write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(tmp_path / "a.csv")], [MOVING_AVERAGE])

        run(config, make_record())

        written = json.loads(
            (config.output.directory / EXECUTION_RECORD_FILENAME).read_text(encoding="utf-8")
        )
        assert written["applied_defaults"] == {"ma": {"window": 5, "polyorder": 0}}


# --- メモリ上の系列の実行（要件 9.1、9.3）------------------------------------------


def memory_series(source_id: str = "memory", *, n_points: int = 11) -> DataSeries:
    """バッチ制御の試験に用いる、読み込み済みの系列。"""
    x = np.linspace(0.0, 10.0, n_points)
    return DataSeries(source_id=source_id, x=x, y=2.0 * x + 1.0)


class TestRunningAnInMemorySeries:
    """要件 9.1: 読み込み済みの系列を、ファイル経由と同一のバッチ制御で実行すること。

    入力の走査を行わないこと以外は同じである。処理単位は 1 対象 × 手法数、結果の並びは
    手法の記述順（要件 8.2）、適用既定値の畳み込み（要件 5.4）も同じ経路を通る。

    **出力先を持たない実行である。** 結果は返り値でのみ渡るため、実行ログ（要件 8.4）と
    実行条件の記録（要件 8.3）を書く先が無い。書けば、対話環境からの当てはめが呼び出し
    ごとに痕跡を残す。
    """

    def test_runs_one_job_per_method(self, tmp_path: Path) -> None:
        """手法ごとに 1 件ずつ実行する。"""
        config = make_config(tmp_path / "out", [], [LINEAR, POLYNOMIAL])

        report = run(config, make_record(), series=memory_series())

        assert len(report.outcomes) == 2
        assert report.n_success == 2
        assert report.aborted is False
        assert identities(report.outcomes) == [
            ("memory", None, "lin"),
            ("memory", None, "poly"),
        ]

    def test_does_not_consult_the_input_location(self, tmp_path: Path) -> None:
        """走査も読み込みも行わないこと。存在しない指定が結果に影響しない。"""
        config = make_config(tmp_path / "out", [str(tmp_path / "無い.csv")], [LINEAR])

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert identities(report.outcomes) == [("memory", None, "lin")]

    def test_writes_neither_the_run_log_nor_the_execution_record(self, tmp_path: Path) -> None:
        """出力先を持たない実行であること。出力ディレクトリ自体が作られない。"""
        directory = tmp_path / "out"
        config = make_config(directory, [], [LINEAR])

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert not directory.exists()

    def test_folds_the_applied_defaults_into_the_record(self, tmp_path: Path) -> None:
        """要件 5.4: 記録の組み立てはファイル経由と同一である。"""
        config = make_config(tmp_path / "out", [], [MOVING_AVERAGE])

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert dict(report.execution.applied_defaults) == {"ma": {"window": 5, "polyorder": 0}}

    def test_estimates_match_the_file_path(self, tmp_path: Path) -> None:
        """要件 9.3: 経路の違いが値に現れないこと。"""
        source = write_linear_csv(tmp_path / "a.csv")
        file_config = make_config(tmp_path / "out", [str(source)], [LINEAR])
        memory_config = make_config(tmp_path / "out", [], [LINEAR])
        x = np.linspace(0.0, 10.0, 11)
        series = DataSeries(source_id="memory", x=x, y=2.0 * x + 1.0)

        from_file = run(file_config, make_record()).outcomes[0]
        from_memory = run(memory_config, make_record(), series=series).outcomes[0]

        assert isinstance(from_file, FitSuccess)
        assert isinstance(from_memory, FitSuccess)
        assert [estimate.value for estimate in from_memory.parameters] == [
            estimate.value for estimate in from_file.parameters
        ]

    def test_notifies_a_total_input_count_of_one(self, tmp_path: Path) -> None:
        """要件 6.3: 処理単位数は手法数であり、入力は 1 件である。"""
        config = make_config(tmp_path / "out", [], [LINEAR, POLYNOMIAL])
        recorder = Recorder()

        report = run(config, make_record(), recorder, series=memory_series())

        assert recorder.started == [(2, 1)]
        assert [done for done, _, _ in recorder.done] == [1, 2]
        assert recorder.finished == [report]

    @pytest.mark.parametrize(
        "error", [MemoryError("記憶領域が尽きた"), OSError("書き込みに失敗した")]
    )
    def test_reports_resource_exhaustion_as_an_abort(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, error: BaseException
    ) -> None:
        """要件 10.3: 中断した対象を明示すること。出力先が無くても値として返る。"""
        config = make_config(tmp_path / "out", [], [LINEAR])
        stub_run_job(monkeypatch, error, at_index=0)

        report = run(config, make_record(), series=memory_series())

        assert report.aborted is True
        assert len(report.outcomes) == 1
        outcome = report.outcomes[0]
        assert isinstance(outcome, FitFailure)
        assert outcome.source_id == "memory"
        assert outcome.reason is FailureReason.RESOURCE_EXHAUSTED

    def test_writes_nothing_even_when_every_output_is_enabled(self, tmp_path: Path) -> None:
        """要件 9.1、7.4、7.5: 出力先を持たない実行は、フラグの状態によらず何も書かないこと。

        出力を抑止する軸は 2 つあった。系列を直接渡されたか（本実行）と、出力ごとの
        有効化フラグである。フラグが偽であることに依存した抑止では、フラグをすべて
        有効にしたこの条件で処理単位ごとの図と曲線 CSV が書き出される。
        """
        directory = tmp_path / "out"
        config = make_config(
            directory,
            [],
            [LINEAR],
            write_summary=True,
            write_plot=True,
            write_curve=True,
        )

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert not directory.exists()

    def test_file_based_runs_keep_writing_their_output(self, tmp_path: Path) -> None:
        """対照。出力を書かないのはメモリ上の系列を受け取った実行に限る。"""
        source = write_linear_csv(tmp_path / "a.csv")
        config = make_config(tmp_path / "out", [str(source)], [LINEAR])

        run(config, make_record())

        assert (config.output.directory / RUN_LOG_FILENAME).is_file()
        assert (config.output.directory / EXECUTION_RECORD_FILENAME).is_file()
        assert (config.output.directory / SUMMARY_FILENAME).is_file()


# --- 列識別子による処理対象の区別（要件 1.4、1.5、7.3、7.6）--------------------------


def write_partly_broken_two_channel_csv(path: Path, *, n_points: int = 11) -> Path:
    """2 つの y 列のうち片方だけが有効な CSV。

    ``good`` は直線、``bad`` は数値として解釈できない文字列だけを持つ。同一ファイルの
    別々の列が、成功と失敗に分かれる実行を作る。
    """
    x = np.linspace(0.0, 10.0, n_points)
    lines = ["x,good,bad"]
    lines.extend(f"{value!r},{2.0 * value + 1.0!r},n/a" for value in x.tolist())
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def column_identities(outcomes: Sequence[FitOutcome]) -> list[tuple[str, str | None, str | None]]:
    """結果ごとの (成否, 指定の綴り, 解決後の見出し名)。"""
    return [
        (
            "success" if isinstance(outcome, FitSuccess) else "failure",
            outcome.column_label,
            outcome.column_name,
        )
        for outcome in outcomes
    ]


class TestColumnIdentityDistinguishesTargetsInABatch:
    """要件 1.4、1.5、7.3、7.6: 同一ファイルの別々の列を、結果の側で区別できること。

    処理対象は **1 ファイルの 1 y 列**であり（要件の Introduction）、失敗もその単位で
    記録される。``source_id`` だけでは同一ファイルの 2 列が同じ識別になり、成功と失敗が
    混在する実行でどちらの列が落ちたのかを呼び出し元が判別できない。
    """

    def test_a_mixed_run_over_one_file_distinguishes_the_two_columns(
        self, tmp_path: Path
    ) -> None:
        """タスク 13.8 の完了状態: 成功と失敗が混在しても列ごとに区別できる。"""
        source = write_partly_broken_two_channel_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="good"), ColumnSpec(x="x", y="bad")),
        )

        report = run(config, make_record())

        assert {outcome.source_id for outcome in report.outcomes} == {str(source)}
        assert column_identities(report.outcomes) == [
            ("success", "good", "good"),
            ("failure", "bad", None),
        ]

    def test_an_unresolvable_column_fails_per_target_not_per_file(self, tmp_path: Path) -> None:
        """要件 1.4、6.4: 解決できない列は、その列だけの失敗として記録される。

        同一ファイルの解決できる列は成功し続ける。失敗がファイル単位で記録されるなら、
        両方の結果が同じ識別を持つか、有効な列まで巻き添えになる。
        """
        source = write_two_channel_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="missing")),
        )

        report = run(config, make_record())

        assert (report.n_success, report.n_failure) == (1, 1)
        failure = report.outcomes[1]
        assert isinstance(failure, FitFailure)
        assert failure.reason is FailureReason.COLUMN_NOT_FOUND
        assert (failure.source_id, failure.column_label) == (str(source), "missing")

    def test_a_column_without_valid_points_fails_per_target(self, tmp_path: Path) -> None:
        """要件 1.5、6.4: 有効なデータ点が 1 件も無い列も、その列だけの失敗になる。"""
        source = write_partly_broken_two_channel_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out",
            [str(source)],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="bad"), ColumnSpec(x="x", y="good")),
        )

        report = run(config, make_record())

        failure = report.outcomes[0]
        assert isinstance(failure, FitFailure)
        assert failure.reason is FailureReason.NO_VALID_DATA
        assert (failure.source_id, failure.column_label) == (str(source), "bad")
        assert isinstance(report.outcomes[1], FitSuccess)

    def test_every_outcome_of_a_multi_column_run_carries_its_spelling(
        self, tmp_path: Path
    ) -> None:
        """要件 7.6: 2 ファイル × 2 列 × 2 手法のすべての結果に綴りが載る。"""
        for name in ("a.csv", "b.csv"):
            write_two_channel_csv(tmp_path / name)
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "*.csv")],
            [LINEAR, POLYNOMIAL],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="z")),
        )

        report = run(config, make_record())

        assert len(report.outcomes) == 8
        expected = ["y", "y", "z", "z"] * 2
        assert [outcome.column_label for outcome in report.outcomes] == expected

    def test_the_aborted_target_carries_its_spelling(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """要件 10.3、7.6: 資源枯渇で中断した対象も、どの列で止まったかを持つ。

        この失敗は :func:`~curvefit.pipeline.run_job` の外側で組み立てられる唯一の
        処理単位の結果である。刻む規則から外れると、中断した列だけが空欄になる。
        """
        write_two_channel_csv(tmp_path / "a.csv")
        config = make_config(
            tmp_path / "out",
            [str(tmp_path / "a.csv")],
            [LINEAR],
            columns=(ColumnSpec(x="x", y="y"), ColumnSpec(x="x", y="z")),
        )
        stub_run_job(monkeypatch, MemoryError("記憶領域が尽きた"), at_index=1)

        report = run(config, make_record())

        aborted = report.outcomes[-1]
        assert isinstance(aborted, FitFailure)
        assert aborted.reason is FailureReason.RESOURCE_EXHAUSTED
        assert (aborted.column_label, aborted.column_name) == ("z", None)

    def test_an_in_memory_series_run_carries_no_column_identity(self, tmp_path: Path) -> None:
        """要件 9.1: 系列を直接渡す実行の結果は 2 欄とも空である（対照）。"""
        config = make_config(tmp_path / "out", [], [LINEAR], write_summary=False)

        report = run(config, make_record(), series=memory_series())

        assert report.n_success == 1
        assert column_identities(report.outcomes) == [("success", None, None)]
