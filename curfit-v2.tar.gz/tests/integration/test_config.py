"""設定ファイルの読み込みと実行時上書きの統合テスト（要件 8.1、8.5、9.4、1.6）。

本テストは `curvefit.config` が次を満たすことを検証する。

- 設定ファイル 1 つから、入力指定・手法一覧・前処理設定・出力設定・失敗ポリシーの
  5 要素を備えた実行条件（`RunConfig`）が構築できる（要件 8.1）
- 実行時引数が設定ファイルより優先し、上書き記録が残る（要件 9.4）
- 未知のキー・必須項目の欠落・解釈できない値が、例外ではなく設定違反として
  **一度にまとめて** 返る（要件 8.5）
- 見出し行の指定が 3 状態（未指定 / あり / なし）のまま実行条件に載る（要件 1.6）

設計の Testing Strategy が `config` を統合テストに置いているため、単体ではなく
`tests/integration/` に置く。
"""

from __future__ import annotations

import ast
from dataclasses import FrozenInstanceError
from pathlib import Path
from typing import Any

import pytest

from curvefit.config import (
    OVERRIDABLE_KEYS,
    FailurePolicy,
    InputSpec,
    OutputSpec,
    RunConfig,
    load_config,
)
from curvefit.errors import ConfigViolation, ViolationKind
from curvefit.execution import OverrideRecord
from curvefit.models.resolver import SmootherKind
from curvefit.preprocess import OutlierSpec, PreprocessSpec
from curvefit.readers import ColumnSpec

SRC = Path(__file__).resolve().parents[2] / "src" / "curvefit"

FULL_CONFIG = """
failure_policy = "fail_fast"

[input]
paths = ["data/a.csv", "data/b.csv"]
delimiter = ","
header = true

[input.columns]
x = "time"
y = "signal"
weight = "sigma"

[[methods]]
name = "gauss"
builtin = "gaussian"
initial = { amplitude = 2.0, center = 1.0 }
fixed = { sigma = 0.5 }
bounds.amplitude = { min = 0.0, max = 10.0 }
bounds.center = { max = 5.0 }

[[methods]]
name = "poly"
smoother = "polynomial"
options = { degree = 3 }

[[methods]]
name = "expr"
expression = "a * x + b"
initial = { a = 1.0, b = 0.0 }

[preprocess]
x_min = 0.0
x_max = 10.0

[preprocess.outlier]
sigma = 2.5
max_iterations = 4

[output]
directory = "out"
write_summary = true
write_plot = false
write_curve = true
"""

MINIMAL_CONFIG = """
[input]
paths = ["a.csv"]

[input.columns]
x = 0
y = 1

[[methods]]
name = "line"
builtin = "linear"

[output]
directory = "out"
"""


def _top_level(line: str) -> str:
    """最上位のキーを足した設定を作る。TOML では最上位のキーは表より前に書く。"""
    return f"{line}\n{MINIMAL_CONFIG}"


def _write(tmp_path: Path, text: str) -> Path:
    path = tmp_path / "config.toml"
    path.write_text(text, encoding="utf-8")
    return path


def _load(
    tmp_path: Path, text: str, overrides: dict[str, object] | None = None
) -> tuple[Any, ...]:
    return load_config(_write(tmp_path, text), overrides or {})


def _load_bytes(tmp_path: Path, data: bytes) -> tuple[Any, ...]:
    """バイト列をそのまま設定ファイルとして読ませる。

    `_load` は必ず UTF-8 で書き出すため、UTF-8 以外の符号化で保存された設定ファイルを
    表現できない。文字コードの取り違えは日本語環境で最も起きやすい設定不備であり、
    バイト単位で書ける経路を別に用意しないと検証できない。
    """
    path = tmp_path / "config.toml"
    path.write_bytes(data)
    return load_config(path, {})


def _ok(result: tuple[Any, ...]) -> tuple[RunConfig, tuple[OverrideRecord, ...]]:
    """成功結果として取り出す。違反が返っていればその場で落とす。"""
    assert isinstance(result[0], RunConfig), f"違反が返った: {result}"
    config, records = result
    assert all(isinstance(record, OverrideRecord) for record in records)
    return config, records


def _violations(result: tuple[Any, ...]) -> tuple[ConfigViolation, ...]:
    """違反結果として取り出す。成功していればその場で落とす。"""
    assert result, "違反も実行条件も返っていない"
    assert all(isinstance(item, ConfigViolation) for item in result), f"成功が返った: {result}"
    return result


def _locations(result: tuple[Any, ...]) -> set[str]:
    return {violation.location for violation in _violations(result)}


class TestRunConfigConstruction:
    """要件 8.1: 設定ファイルに実行条件を記述できる。"""

    def test_all_five_parts_are_constructed(self, tmp_path: Path) -> None:
        """5 要素がすべて構築される。"""
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert isinstance(config.inputs, InputSpec)
        assert isinstance(config.methods, tuple)
        assert isinstance(config.preprocess, PreprocessSpec)
        assert isinstance(config.output, OutputSpec)
        assert config.failure_policy is FailurePolicy.FAIL_FAST

    def test_the_input_spec_is_read(self, tmp_path: Path) -> None:
        """入力指定が読み取られる。"""
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert config.inputs.paths == ("data/a.csv", "data/b.csv")
        assert config.inputs.delimiter == ","
        assert config.inputs.columns == (ColumnSpec(x="time", y="signal", weight="sigma"),)

    def test_columns_can_also_be_given_by_position(self, tmp_path: Path) -> None:
        """列は位置でも指定できる。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.inputs.columns == (ColumnSpec(x=0, y=1, weight=None),)

    def test_the_method_spec_maps_onto_method_spec(self, tmp_path: Path) -> None:
        """手法の指定が MethodSpec に写る。"""
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))
        gauss, poly, expr = config.methods

        assert (gauss.name, gauss.kind, gauss.builtin) == ("gauss", "builtin", "gaussian")
        assert dict(gauss.initial) == {"amplitude": 2.0, "center": 1.0}
        assert dict(gauss.fixed) == {"sigma": 0.5}
        assert dict(gauss.bounds) == {"amplitude": (0.0, 10.0), "center": (None, 5.0)}
        assert (poly.kind, poly.smoother) == ("smoother", SmootherKind.POLYNOMIAL)
        assert dict(poly.options) == {"degree": 3}
        assert (expr.kind, expr.expression) == ("expression", "a * x + b")

    def test_the_preprocess_settings_are_read(self, tmp_path: Path) -> None:
        """前処理設定が読み取られる。"""
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert config.preprocess.x_min == 0.0
        assert config.preprocess.x_max == 10.0
        assert config.preprocess.outlier == OutlierSpec(sigma=2.5, max_iterations=4)

    def test_no_outlier_table_means_no_outlier_removal(self, tmp_path: Path) -> None:
        """外れ値の表がなければ外れ値除去は行わない。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.preprocess == PreprocessSpec()
        assert config.preprocess.outlier is None

    def test_an_outlier_table_enables_removal_with_the_defaults(self, tmp_path: Path) -> None:
        """外れ値の表があれば既定値のまま有効になる。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG + "\n[preprocess.outlier]\n"))

        assert config.preprocess.outlier == OutlierSpec()

    def test_the_output_settings_are_read(self, tmp_path: Path) -> None:
        """出力設定が読み取られる。"""
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert config.output.directory == Path("out")
        assert (config.output.write_summary, config.output.write_plot) == (True, False)
        assert config.output.write_curve is True

    def test_the_output_default_is_summary_and_plot_only(self, tmp_path: Path) -> None:
        """出力の既定はサマリとプロットのみ。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert (config.output.write_summary, config.output.write_plot) == (True, True)
        assert config.output.write_curve is False

    def test_the_default_failure_policy_is_skip(self, tmp_path: Path) -> None:
        """要件 6.4 の既定。設定ファイルに書かなければ継続する。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.failure_policy is FailurePolicy.SKIP

    def test_the_run_config_cannot_be_mutated_after_construction(self, tmp_path: Path) -> None:
        """要件 8.2: 実行の途中で実行条件が書き換わると再現性が成立しない。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        with pytest.raises(FrozenInstanceError):
            config.failure_policy = FailurePolicy.FAIL_FAST  # type: ignore[misc]


class TestMethodListOrder:
    """要件 8.2 の決定性: 記述順を保持する。"""

    def test_preserves_the_written_order(self, tmp_path: Path) -> None:
        """記述順を保持する。"""
        config, _ = _ok(_load(tmp_path, FULL_CONFIG))

        assert [method.name for method in config.methods] == ["gauss", "poly", "expr"]

    def test_writing_them_reversed_yields_the_reversed_order(self, tmp_path: Path) -> None:
        """逆順に書けば逆順になる。"""
        text = """
[input]
paths = ["a.csv"]
[input.columns]
x = 0
y = 1
[[methods]]
name = "z"
builtin = "linear"
[[methods]]
name = "a"
builtin = "linear"
[output]
directory = "out"
"""
        config, _ = _ok(_load(tmp_path, text))

        assert [method.name for method in config.methods] == ["z", "a"]


class TestColumnSequences:
    """要件 1.11、1.12、1.13: y 列を 1 つ以上指定でき、誤差列と記述順で 1 対 1 に対応する。

    **個数の一致（要件 1.13）は本層が所有する。** 個数が合わない指定は
    `ColumnSpec` の並びに写せず（余剰は捨てられ、不足は `None` に潰れて「誤差列なし」と
    区別できなくなる）、写せない指定を拒むのは記述を型に写す本層の役目である。
    **値域の検証だけが実行前ゲート（`preflight`）の所有である。**

    ここで検証するのは、単一指定と複数指定が同じ記法で読めること、並びの順序が記述順
    どおりに保たれること、および対応付けられない個数の指定が拒まれることである。
    """

    @staticmethod
    def _with_columns(body: str) -> str:
        """``[input.columns]`` の中身だけを差し替えた最小の設定を作る。"""
        return f"""
[input]
paths = ["a.csv"]

[input.columns]
{body}

[[methods]]
name = "line"
builtin = "linear"

[output]
directory = "out"
"""

    def test_a_single_y_column_still_yields_one_entry(self, tmp_path: Path) -> None:
        """1 つだけ指定する従来の書き方が、1 件の並びとして読める。"""
        config, _ = _ok(_load(tmp_path, self._with_columns('x = "t"\ny = "s"')))

        assert config.inputs.columns == (ColumnSpec(x="t", y="s", weight=None),)

    def test_several_y_columns_yield_one_entry_each(self, tmp_path: Path) -> None:
        """y 列を並びで書くと、y 列ごとに 1 件の実行条件になる。"""
        config, _ = _ok(_load(tmp_path, self._with_columns('x = "t"\ny = ["a", "b", "c"]')))

        assert config.inputs.columns == (
            ColumnSpec(x="t", y="a", weight=None),
            ColumnSpec(x="t", y="b", weight=None),
            ColumnSpec(x="t", y="c", weight=None),
        )

    def test_the_written_order_of_the_y_columns_is_preserved(self, tmp_path: Path) -> None:
        """要件 8.2 の決定性: 並びは記述順のまま。名前順に並べ替えない。"""
        config, _ = _ok(_load(tmp_path, self._with_columns('x = "t"\ny = ["z", "a", "m"]')))

        assert [spec.y for spec in config.inputs.columns] == ["z", "a", "m"]

    def test_error_columns_pair_with_the_y_columns_in_the_written_order(
        self, tmp_path: Path
    ) -> None:
        """要件 1.12: 誤差列は記述順で y 列と 1 対 1 に対応する。"""
        config, _ = _ok(
            _load(tmp_path, self._with_columns('x = "t"\ny = ["a", "b"]\nweight = ["sa", "sb"]'))
        )

        assert config.inputs.columns == (
            ColumnSpec(x="t", y="a", weight="sa"),
            ColumnSpec(x="t", y="b", weight="sb"),
        )

    def test_the_pairing_follows_position_not_name(self, tmp_path: Path) -> None:
        """対応付けは名前の類似ではなく記述の位置で決まる。"""
        config, _ = _ok(
            _load(tmp_path, self._with_columns('x = "t"\ny = ["a", "b"]\nweight = ["sb", "sa"]'))
        )

        assert [(spec.y, spec.weight) for spec in config.inputs.columns] == [
            ("a", "sb"),
            ("b", "sa"),
        ]

    def test_a_single_error_column_uses_the_same_notation(self, tmp_path: Path) -> None:
        """誤差列も 1 つだけ指定する従来の書き方を受け付ける。"""
        config, _ = _ok(
            _load(tmp_path, self._with_columns('x = "t"\ny = "s"\nweight = "sigma"'))
        )

        assert config.inputs.columns == (ColumnSpec(x="t", y="s", weight="sigma"),)

    def test_the_x_column_is_shared_by_every_entry(self, tmp_path: Path) -> None:
        """x 列は 1 つで、すべての処理対象が共有する。"""
        config, _ = _ok(_load(tmp_path, self._with_columns('x = 0\ny = [1, 2]')))

        assert [spec.x for spec in config.inputs.columns] == [0, 0]

    def test_names_and_positions_can_be_mixed_inside_the_sequence(self, tmp_path: Path) -> None:
        """並びの中で列名と位置を混ぜて書ける。"""
        config, _ = _ok(_load(tmp_path, self._with_columns('x = 0\ny = ["sig", 2]')))

        assert [spec.y for spec in config.inputs.columns] == ["sig", 2]

    @pytest.mark.parametrize(
        "body",
        [
            'x = "t"\ny = ["a", "b"]\nweight = ["sa"]',
            'x = "t"\ny = ["a"]\nweight = ["sa", "sb"]',
            'x = "t"\ny = "a"\nweight = ["sa", "sb"]',
            'x = "t"\ny = ["a", "b"]\nweight = "sa"',
        ],
    )
    def test_a_count_mismatch_is_a_violation(self, tmp_path: Path, body: str) -> None:
        """要件 1.13: y 列と誤差列の個数が一致しない指定を、多い方向でも少ない方向でも拒む。

        個数の不一致は値域の検証ではなく **型に写せるか** の問題である。余剰の誤差列は
        捨てられ、不足は ``None`` に潰れて「誤差列なし」と区別できなくなるため、
        実行条件を見る実行前ゲートには検出できない。
        """
        result = _load(tmp_path, self._with_columns(body))

        assert "input.columns" in _locations(result)

    def test_the_count_mismatch_report_names_the_unpaired_specification(
        self, tmp_path: Path
    ) -> None:
        """要件 1.13: 対応付けられない指定内容が報告に載る。個数だけでは直せない。"""
        result = _load(
            tmp_path, self._with_columns('x = "t"\ny = ["a", "b"]\nweight = ["sa", "sb", "sc"]')
        )

        message = next(
            violation.message
            for violation in _violations(result)
            if violation.location == "input.columns"
        )
        assert "2" in message
        assert "3" in message
        assert "sc" in message

    def test_a_bad_item_does_not_also_count_as_a_pairing_mismatch(
        self, tmp_path: Path
    ) -> None:
        """個数は **記述されたとおり** に数える。写せた要素の数で比べない。

        写せた要素だけを数えると、``weight`` の 1 件が要素の型違反で落ちた瞬間に個数が
        減り、そろえて書かれた指定まで対応付け不能として重ねて責めることになる。
        書き手に見せる違反は要素の型違反 1 件でなければならない。
        """
        body = 'x = "t"\ny = ["a", "b"]\nweight = ["sa", 1.5]'
        result = _load(tmp_path, self._with_columns(body))

        assert "input.columns.weight[1]" in _locations(result)
        assert "input.columns" not in _locations(result)

    def test_omitting_the_error_columns_is_not_a_count_mismatch(self, tmp_path: Path) -> None:
        """誤差列を書かないのは正当である（要件 1.3 は指定されている場合の条件付き）。"""
        config, _ = _ok(_load(tmp_path, self._with_columns('x = "t"\ny = ["a", "b"]')))

        assert [spec.weight for spec in config.inputs.columns] == [None, None]

    def test_a_count_mismatch_is_reported_together_with_other_violations(
        self, tmp_path: Path
    ) -> None:
        """最初の違反で打ち切らない。個数不一致と他の違反が同時に返る（要件 8.5）。"""
        result = _load(
            tmp_path, self._with_columns('x = "t"\ny = ["a", "b"]\nweight = ["sa"]\nz = "q"')
        )

        assert {"input.columns", "input.columns.z"} <= _locations(result)

    def test_no_run_config_is_built_when_the_counts_disagree(self, tmp_path: Path) -> None:
        """個数の合わない設定では実行条件が組み上がらない。処理単位は 1 件も作られない。"""
        result = _load(tmp_path, self._with_columns('x = "t"\ny = ["a", "b"]\nweight = ["sa"]'))

        assert not any(isinstance(item, RunConfig) for item in result)

    def test_an_empty_y_sequence_is_a_violation(self, tmp_path: Path) -> None:
        """y 列は 1 つ以上。空の並びは指定の意味を持たない。"""
        result = _load(tmp_path, self._with_columns('x = "t"\ny = []'))

        assert "input.columns.y" in _locations(result)

    def test_an_empty_error_sequence_is_a_violation(self, tmp_path: Path) -> None:
        """誤差列を使わない場合は ``weight`` を書かない。空の並びは書き誤りである。"""
        result = _load(tmp_path, self._with_columns('x = "t"\ny = "s"\nweight = []'))

        assert "input.columns.weight" in _locations(result)

    def test_a_bad_item_in_the_sequence_is_reported_with_its_position(
        self, tmp_path: Path
    ) -> None:
        """並びの中の解釈できない要素は、その位置を示して報告する。"""
        result = _load(tmp_path, self._with_columns('x = "t"\ny = ["a", 1.5]'))

        assert "input.columns.y[1]" in _locations(result)

    def test_every_bad_item_in_the_sequence_is_reported_at_once(self, tmp_path: Path) -> None:
        """最初の違反で打ち切らない。"""
        result = _load(tmp_path, self._with_columns('x = "t"\ny = ["a", 1.5]\nweight = [true]'))

        assert {"input.columns.y[1]", "input.columns.weight[0]"} <= _locations(result)

    def test_two_bad_items_in_the_same_sequence_are_both_reported(
        self, tmp_path: Path
    ) -> None:
        """1 つの並びの中に不正要素が 2 つあれば、両方が報告される。

        不正要素を ``y`` と ``weight`` に分けて置く検査だけでは、**同じ並びを走査する
        途中で最初の違反により打ち切る**実装を落とせない。並びの走査そのものが
        全件を集めることをここで固定する。
        """
        result = _load(tmp_path, self._with_columns('x = "t"\ny = ["a", 1.5, {}, "b"]'))

        assert {"input.columns.y[1]", "input.columns.y[2]"} <= _locations(result)

    def test_the_x_column_is_not_a_sequence(self, tmp_path: Path) -> None:
        """x 列は 1 つだけ。並びで書くことはできない。"""
        result = _load(tmp_path, self._with_columns('x = ["t", "u"]\ny = "s"'))

        assert "input.columns.x" in _locations(result)

    def test_a_runtime_override_replaces_the_sequence_with_one_entry(
        self, tmp_path: Path
    ) -> None:
        """実行時引数による列の上書きは、並びを 1 件に置き換える形で成立する。"""
        text = self._with_columns('x = "t"\ny = ["a", "b"]')

        config, records = _ok(_load(tmp_path, text, {"input.columns.y": "only"}))

        assert config.inputs.columns == (ColumnSpec(x="t", y="only", weight=None),)
        assert records == (
            OverrideRecord(key="input.columns.y", config_value=["a", "b"], cli_value="only"),
        )

    def test_the_x_and_weight_columns_can_be_overridden_too(self, tmp_path: Path) -> None:
        """x 列と誤差列も上書きできる。上書き可能な項目の一覧は本モジュールが持つ。"""
        text = self._with_columns('x = "t"\ny = ["a", "b"]\nweight = ["sa", "sb"]')

        config, _ = _ok(
            _load(
                tmp_path,
                text,
                {"input.columns.x": "u", "input.columns.y": "only", "input.columns.weight": "s"},
            )
        )

        assert config.inputs.columns == (ColumnSpec(x="u", y="only", weight="s"),)

    def test_the_overridable_key_paths_for_columns_are_owned_here(self) -> None:
        """上書き可能な項目のキー路がこの層に定義されている。"""
        assert {
            "input.columns.x",
            "input.columns.y",
            "input.columns.weight",
        } <= set(OVERRIDABLE_KEYS)


class TestRuntimeArgumentPrecedence:
    """要件 9.4: 同一項目が双方で指定された場合は実行時引数を優先し、記録に残す。"""

    def test_runtime_arguments_win_over_the_config_file(self, tmp_path: Path) -> None:
        """実行時引数が設定ファイルに優先する。"""
        config, _ = _ok(
            _load(tmp_path, FULL_CONFIG, {"output.directory": "cli-out"}),
        )

        assert config.output.directory == Path("cli-out")

    def test_the_override_record_keeps_the_before_and_after_values(self, tmp_path: Path) -> None:
        """上書き記録に前後の値が残る。"""
        _, records = _ok(_load(tmp_path, FULL_CONFIG, {"output.directory": "cli-out"}))

        assert len(records) == 1
        assert records[0].key == "output.directory"
        assert records[0].config_value == "out"
        assert records[0].cli_value == "cli-out"

    def test_input_paths_can_be_overridden_too(self, tmp_path: Path) -> None:
        """入力パスも上書きできる。"""
        config, records = _ok(
            _load(tmp_path, FULL_CONFIG, {"input.paths": ["cli.csv"]}),
        )

        assert config.inputs.paths == ("cli.csv",)
        assert records[0].config_value == ["data/a.csv", "data/b.csv"]

    def test_the_failure_policy_can_be_overridden_too(self, tmp_path: Path) -> None:
        """失敗ポリシーも上書きできる。"""
        config, records = _ok(_load(tmp_path, MINIMAL_CONFIG, {"failure_policy": "fail_fast"}))

        assert config.failure_policy is FailurePolicy.FAIL_FAST
        assert records[0].config_value is None

    def test_overriding_an_item_absent_from_the_config_records_none_as_the_previous_value(
        self, tmp_path: Path
    ) -> None:
        """TOML は空値を書けないため、``config_value=None`` は「キーが無い」だけを意味する。"""
        _, records = _ok(_load(tmp_path, MINIMAL_CONFIG, {"input.delimiter": "\t"}))

        assert records[0] == OverrideRecord(
            key="input.delimiter", config_value=None, cli_value="\t"
        )

    def test_confirms_that_toml_has_no_null_syntax(self, tmp_path: Path) -> None:
        """``config_value=None`` の一意性の根拠。空値を書こうとすると構文誤りになる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace('x = 0', 'x = null'))

        assert _violations(result)

    def test_several_items_can_be_overridden_at_once(self, tmp_path: Path) -> None:
        """複数項目を同時に上書きできる。"""
        config, records = _ok(
            _load(
                tmp_path,
                FULL_CONFIG,
                {"output.directory": "cli-out", "input.paths": ["cli.csv"]},
            )
        )

        assert config.output.directory == Path("cli-out")
        assert config.inputs.paths == ("cli.csv",)
        assert {record.key for record in records} == {"output.directory", "input.paths"}

    def test_override_record_order_does_not_depend_on_how_the_arguments_were_given(
        self, tmp_path: Path
    ) -> None:
        """要件 8.2: 同一の実行条件なら記録も同一でなければならない。"""
        forward = {"output.directory": "cli-out", "input.paths": ["cli.csv"]}
        backward = {"input.paths": ["cli.csv"], "output.directory": "cli-out"}

        _, first = _ok(_load(tmp_path, FULL_CONFIG, forward))
        _, second = _ok(_load(tmp_path, FULL_CONFIG, backward))

        assert first == second

    def test_no_overrides_means_an_empty_record(self, tmp_path: Path) -> None:
        """上書きが無ければ記録も空。"""
        _, records = _ok(_load(tmp_path, FULL_CONFIG))

        assert records == ()

    def test_a_non_overridable_item_yields_a_violation(self, tmp_path: Path) -> None:
        """手法一覧は実行時引数で差し替えられない。黙って無視すると効かない指定が残る。"""
        result = _load(tmp_path, MINIMAL_CONFIG, {"methods": []})

        assert "methods" in _locations(result)

    def test_the_header_setting_can_be_overridden_too(self, tmp_path: Path) -> None:
        """見出し行の指定も上書きできる。"""
        config, _ = _ok(_load(tmp_path, FULL_CONFIG, {"input.header": False}))

        assert config.inputs.header is False


class TestTheThreeHeaderStates:
    """要件 1.6 とタスク 5.5 の carry-over: 未指定 / あり / なしを潰さない。"""

    def test_unspecified_is_none(self, tmp_path: Path) -> None:
        """未指定は None。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))

        assert config.inputs.header is None

    def test_true_is_true(self, tmp_path: Path) -> None:
        """真は True。"""
        text = MINIMAL_CONFIG.replace("[input]", "[input]\nheader = true")
        config, _ = _ok(_load(tmp_path, text))

        assert config.inputs.header is True

    def test_false_is_false(self, tmp_path: Path) -> None:
        """偽は False。"""
        config, _ = _ok(
            _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = false"))
        )

        assert config.inputs.header is False

    def test_the_three_states_are_mutually_distinguishable(self, tmp_path: Path) -> None:
        """3 状態は互いに区別できる。"""
        absent, _ = _ok(_load(tmp_path, MINIMAL_CONFIG))
        present, _ = _ok(
            _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = true"))
        )
        missing, _ = _ok(
            _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = false"))
        )

        assert len({absent.inputs.header, present.inputs.header, missing.inputs.header}) == 3

    def test_a_non_boolean_is_a_violation(self, tmp_path: Path) -> None:
        """真偽値以外は違反。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace("[input]", "[input]\nheader = 1"))

        assert "input.header" in _locations(result)


class TestUnknownKeys:
    """要件 8.5: 未知のキーを黙って無視しない。綴り誤りが黙って効かなくなるため。"""

    def test_an_unknown_top_level_key_is_a_violation(self, tmp_path: Path) -> None:
        """最上位の未知キーが違反になる。"""
        result = _load(tmp_path, _top_level('failure_polcy = "skip"'))

        assert "failure_polcy" in _locations(result)

    def test_an_unknown_key_in_the_input_table_is_a_violation(self, tmp_path: Path) -> None:
        """入力表の未知キーが違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace("[input]", '[input]\nseparator = ","'))

        assert "input.separator" in _locations(result)

    def test_an_unknown_key_in_a_method_is_a_violation(self, tmp_path: Path) -> None:
        """手法の未知キーが違反になる。"""
        result = _load(
            tmp_path, MINIMAL_CONFIG.replace('name = "line"', 'name = "line"\nkind = "builtin"')
        )

        assert "methods[0].kind" in _locations(result)

    def test_an_unknown_key_in_the_column_spec_is_a_violation(self, tmp_path: Path) -> None:
        """列指定の未知キーが違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace("x = 0", "x = 0\nsigma = 2"))

        assert "input.columns.sigma" in _locations(result)

    def test_an_unknown_key_in_preprocess_is_a_violation(self, tmp_path: Path) -> None:
        """前処理の未知キーが違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG + "\n[preprocess]\nxmin = 0.0\n")

        assert "preprocess.xmin" in _locations(result)

    def test_an_unknown_key_in_the_outlier_settings_is_a_violation(self, tmp_path: Path) -> None:
        """外れ値設定の未知キーが違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG + "\n[preprocess.outlier]\nthreshold = 3.0\n")

        assert "preprocess.outlier.threshold" in _locations(result)

    def test_an_unknown_key_in_output_is_a_violation(self, tmp_path: Path) -> None:
        """出力の未知キーが違反になる。"""
        result = _load(
            tmp_path,
            MINIMAL_CONFIG.replace('directory = "out"', 'directory = "out"\nwrite_log = true'),
        )

        assert "output.write_log" in _locations(result)

    def test_an_unknown_key_in_the_bounds_table_is_a_violation(self, tmp_path: Path) -> None:
        """上下限の未知キーが違反になる。"""
        text = MINIMAL_CONFIG.replace(
            'builtin = "linear"', 'builtin = "linear"\nbounds.slope = { lower = 0.0 }'
        )

        assert "methods[0].bounds.slope.lower" in _locations(_load(tmp_path, text))

    def test_the_violation_kind_is_config_invalid(self, tmp_path: Path) -> None:
        """違反の種別は設定不備。"""
        result = _load(tmp_path, _top_level('failure_polcy = "skip"'))

        assert {violation.kind for violation in _violations(result)} == {
            ViolationKind.CONFIG_INVALID
        }

    def test_the_violation_message_lists_the_allowed_keys(self, tmp_path: Path) -> None:
        """利用者の次の行動は綴りの修正であるため、選択肢を提示する。"""
        result = _load(tmp_path, _top_level('failure_polcy = "skip"'))
        violation = next(v for v in _violations(result) if v.location == "failure_polcy")

        assert "failure_policy" in violation.message


class TestMissingRequiredItems:
    """要件 8.5: 必須項目の欠落を報告し、処理を開始しない。"""

    @pytest.mark.parametrize(
        ("removed", "location"),
        [
            ('paths = ["a.csv"]', "input.paths"),
            ("[input.columns]", "input.columns"),
            ("x = 0", "input.columns.x"),
            ("y = 1", "input.columns.y"),
            ('directory = "out"', "output.directory"),
            ('name = "line"', "methods[0].name"),
        ],
    )
    def test_dropping_a_required_item_is_a_violation(
        self, tmp_path: Path, removed: str, location: str
    ) -> None:
        """必須項目を落とすと違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace(removed, ""))

        assert location in _locations(result)

    def test_a_missing_input_table_itself_is_a_violation(self, tmp_path: Path) -> None:
        """入力表そのものの欠落が違反になる。"""
        text = "\n".join(MINIMAL_CONFIG.splitlines()[7:])

        assert "input" in _locations(_load(tmp_path, text))

    def test_a_missing_method_list_is_a_violation(self, tmp_path: Path) -> None:
        """手法一覧の欠落が違反になる。"""
        result = _load(
            tmp_path, MINIMAL_CONFIG.replace('[[methods]]\nname = "line"\nbuiltin = "linear"', "")
        )

        assert "methods" in _locations(result)

    def test_an_empty_method_list_is_also_a_violation(self, tmp_path: Path) -> None:
        """手法一覧が空でも違反になる。"""
        text = """
methods = []

[input]
paths = ["a.csv"]

[input.columns]
x = 0
y = 1

[output]
directory = "out"
"""

        assert "methods" in _locations(_load(tmp_path, text))

    def test_an_empty_input_path_array_is_also_a_violation(self, tmp_path: Path) -> None:
        """入力パスが空配列でも違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace('paths = ["a.csv"]', "paths = []"))

        assert "input.paths" in _locations(result)

    def test_a_missing_output_table_itself_is_a_violation(self, tmp_path: Path) -> None:
        """出力表そのものの欠落が違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace('[output]\ndirectory = "out"', ""))

        assert "output" in _locations(result)


class TestMethodSpecificationRoute:
    """組込モデル・数式・平滑化のいずれか 1 つを選ぶ。関数は設定ファイルからは指定できない。"""

    def test_zero_specification_routes_is_a_violation(self, tmp_path: Path) -> None:
        """指定経路が 0 件なら違反。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace('builtin = "linear"', ""))

        assert "methods[0]" in _locations(result)

    def test_two_specification_routes_is_a_violation(self, tmp_path: Path) -> None:
        """指定経路が 2 件なら違反。"""
        result = _load(
            tmp_path,
            MINIMAL_CONFIG.replace('builtin = "linear"', 'builtin = "linear"\nsmoother = "spline"'),
        )

        assert "methods[0]" in _locations(result)

    def test_an_unknown_smoother_is_a_violation(self, tmp_path: Path) -> None:
        """未知の平滑化手法は違反。"""
        result = _load(
            tmp_path, MINIMAL_CONFIG.replace('builtin = "linear"', 'smoother = "median"')
        )

        assert "methods[0].smoother" in _locations(result)

    def test_builtin_model_name_validity_is_not_judged_here(self, tmp_path: Path) -> None:
        """要件 3.4 のモデル解決は実行前ゲート（タスク 6.2）が担う。ここは素通しする。"""
        config, _ = _ok(_load(tmp_path, MINIMAL_CONFIG.replace("linear", "no_such_model")))

        assert config.methods[0].builtin == "no_such_model"

    def test_duplicate_method_names_are_a_violation(self, tmp_path: Path) -> None:
        """要件 6.2 の比較は手法名で行うため、同名が 2 つあると結果を区別できない。"""
        text = MINIMAL_CONFIG.replace(
            '[[methods]]\nname = "line"\nbuiltin = "linear"',
            '[[methods]]\nname = "line"\nbuiltin = "linear"\n'
            '[[methods]]\nname = "line"\nbuiltin = "gaussian"',
        )

        assert "methods[1].name" in _locations(_load(tmp_path, text))


class TestValueTypes:
    """要件 8.5: 解釈できない項目を例外ではなく違反として返す。"""

    @pytest.mark.parametrize(
        ("original", "replacement", "location"),
        [
            ('paths = ["a.csv"]', 'paths = "a.csv"', "input.paths"),
            ('paths = ["a.csv"]', "paths = [1]", "input.paths[0]"),
            ("x = 0", "x = 1.5", "input.columns.x"),
            ("x = 0", "x = true", "input.columns.x"),
            ('directory = "out"', "directory = 1", "output.directory"),
            ('directory = "out"', 'directory = "out"\nwrite_plot = "yes"', "output.write_plot"),
            ('name = "line"', "name = 1", "methods[0].name"),
            ('name = "line"', 'name = ""', "methods[0].name"),
            ('builtin = "linear"', "builtin = 3", "methods[0].builtin"),
            (
                'builtin = "linear"',
                'builtin = "linear"\ninitial = { a = "x" }',
                "methods[0].initial.a",
            ),
            ('builtin = "linear"', 'builtin = "linear"\ninitial = 1', "methods[0].initial"),
            ('builtin = "linear"', 'builtin = "linear"\nbounds.a = [0, 1]', "methods[0].bounds.a"),
            (
                'builtin = "linear"',
                'builtin = "linear"\nbounds.a = { min = "x" }',
                "methods[0].bounds.a.min",
            ),
            ('builtin = "linear"', 'builtin = "linear"\nbounds.a = { }', "methods[0].bounds.a"),
            (
                'builtin = "linear"',
                'builtin = "linear"\noptions = { window = true }',
                "methods[0].options.window",
            ),
            ('builtin = "linear"', 'builtin = "linear"\nfixed = { a = "x" }', "methods[0].fixed.a"),
        ],
    )
    def test_a_value_of_the_wrong_type_is_a_violation(
        self, tmp_path: Path, original: str, replacement: str, location: str
    ) -> None:
        """型の合わない値が違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace(original, replacement))

        assert location in _locations(result)

    @pytest.mark.parametrize(
        ("added", "location"),
        [
            ('\n[preprocess]\nx_min = "zero"\n', "preprocess.x_min"),
            ("\n[preprocess]\nx_max = [1]\n", "preprocess.x_max"),
            ("\n[preprocess]\nx_min = nan\n", "preprocess.x_min"),
            ('\n[preprocess.outlier]\nsigma = "3"\n', "preprocess.outlier.sigma"),
            ("\n[preprocess.outlier]\nmax_iterations = 1.5\n", "preprocess.outlier.max_iterations"),
            (
                "\n[preprocess.outlier]\nmax_iterations = true\n",
                "preprocess.outlier.max_iterations",
            ),
        ],
    )
    def test_a_type_mismatch_in_preprocess_is_a_violation(
        self, tmp_path: Path, added: str, location: str
    ) -> None:
        """前処理の型違いが違反になる。"""
        result = _load(tmp_path, MINIMAL_CONFIG + added)

        assert location in _locations(result)

    def test_an_unknown_failure_policy_value_is_a_violation(self, tmp_path: Path) -> None:
        """失敗ポリシーの未知の値は違反。"""
        result = _load(tmp_path, _top_level('failure_policy = "abort"'))

        assert "failure_policy" in _locations(result)

    def test_an_empty_delimiter_is_a_violation(self, tmp_path: Path) -> None:
        """区切り文字が空文字なら違反。"""
        result = _load(tmp_path, MINIMAL_CONFIG.replace("[input]", '[input]\ndelimiter = ""'))

        assert "input.delimiter" in _locations(result)

    def test_an_integer_initial_value_is_accepted_as_a_float(self, tmp_path: Path) -> None:
        """整数の初期値は実数として受け取る。"""
        text = MINIMAL_CONFIG.replace(
            'builtin = "linear"', 'builtin = "linear"\ninitial = { a = 1 }'
        )
        config, _ = _ok(_load(tmp_path, text))

        assert config.methods[0].initial["a"] == pytest.approx(1.0)

    def test_method_option_ranges_are_not_judged_here(self, tmp_path: Path) -> None:
        """窓長の偶奇や次数の値域は実行前ゲート（タスク 6.2）が判定する。素通しして届ける。"""
        text = MINIMAL_CONFIG.replace(
            'builtin = "linear"',
            'smoother = "moving_average"\noptions = { window = 4, polyorder = 9 }',
        )
        config, _ = _ok(_load(tmp_path, text))

        assert dict(config.methods[0].options) == {"window": 4, "polyorder": 9}

    def test_outlier_setting_ranges_are_not_judged_here(self, tmp_path: Path) -> None:
        """``sigma <= 0`` と ``max_iterations < 0`` の拒否は実行前ゲートの担当。"""
        text = MINIMAL_CONFIG + "\n[preprocess.outlier]\nsigma = -1.0\nmax_iterations = -3\n"
        config, _ = _ok(_load(tmp_path, text))

        assert config.preprocess.outlier == OutlierSpec(sigma=-1.0, max_iterations=-3)


class TestCollectingAllViolationsAtOnce:
    """設計の Error Handling: 最初の 1 件で打ち切らず、全違反を一度に提示する。"""

    def test_several_violations_come_back_together(self, tmp_path: Path) -> None:
        """複数の違反が一度に返る。"""
        text = """
failure_polcy = "skip"

[input]
paths = []
separator = ","

[input.columns]
y = 1

[[methods]]
builtin = "linear"

[preprocess]
x_min = "zero"

[output]
write_log = true
"""
        locations = _locations(_load(tmp_path, text))

        assert {
            "failure_polcy",
            "input.paths",
            "input.separator",
            "input.columns.x",
            "methods[0].name",
            "preprocess.x_min",
            "output.write_log",
            "output.directory",
        } <= locations

    def test_several_type_mismatches_in_one_table_come_back_together(self, tmp_path: Path) -> None:
        """同一の表の中の複数の型違いが一度に返る。"""
        text = MINIMAL_CONFIG.replace(
            'directory = "out"', 'directory = "out"\nwrite_plot = "yes"\nwrite_curve = 1'
        )

        assert {"output.write_plot", "output.write_curve"} <= _locations(_load(tmp_path, text))

    def test_several_type_mismatches_in_the_outlier_settings_come_back_together(
        self, tmp_path: Path
    ) -> None:
        """外れ値設定の複数の型違いが一度に返る。"""
        text = MINIMAL_CONFIG + '\n[preprocess.outlier]\nsigma = "3"\nmax_iterations = 1.5\n'

        assert {
            "preprocess.outlier.sigma",
            "preprocess.outlier.max_iterations",
        } <= _locations(_load(tmp_path, text))

    def test_no_run_config_is_returned_when_there_are_violations(self, tmp_path: Path) -> None:
        """違反があれば実行条件は返らない。"""
        result = _load(tmp_path, _top_level("unknown = 1"))

        assert not any(isinstance(item, RunConfig) for item in result)

    def test_the_violation_order_is_stable_across_runs(self, tmp_path: Path) -> None:
        """要件 8.2: 同一設定なら報告も同一でなければ差分を追えない。"""
        text = _top_level("unknown_a = 1\nunknown_b = 2")

        assert _load(tmp_path, text) == _load(tmp_path, text)


class TestFailureOfTheLoadItself:
    """設計の Responsibilities: 利用者由来の設定内容で例外を送出しない。"""

    def test_a_syntax_error_comes_back_as_a_violation(self, tmp_path: Path) -> None:
        """構文誤りは違反として返る。"""
        result = _load(tmp_path, "[input\npaths = [")

        assert _violations(result)

    def test_the_syntax_error_report_carries_the_config_file_location(self, tmp_path: Path) -> None:
        """構文誤りの報告に設定ファイルの位置が載る。"""
        violations = _violations(_load(tmp_path, "[input\n"))

        assert any("config.toml" in violation.location for violation in violations)

    def test_a_missing_config_file_comes_back_as_a_violation(self, tmp_path: Path) -> None:
        """CLI は終了コード 2 で全違反を提示する。ここで例外にすると経路が 2 本になる。"""
        result = load_config(tmp_path / "no_such.toml", {})

        assert _violations(result)

    def test_pointing_at_a_directory_also_comes_back_as_a_violation(self, tmp_path: Path) -> None:
        """ディレクトリを指定しても違反として返る。"""
        result = load_config(tmp_path, {})

        assert _violations(result)

    @pytest.mark.parametrize(
        "text",
        [
            "",
            "input = 1",
            "[input]\npaths = 1",
            "methods = 1",
            "methods = [1]",
            "[[methods]]\n",
            "[output]\ndirectory = []",
            "[preprocess]\noutlier = 1",
            "[input]\ncolumns = 1",
            "[input.columns]\nx = 1970-01-01",
        ],
    )
    def test_no_config_content_ever_raises(self, tmp_path: Path, text: str) -> None:
        """どのような設定内容でも例外を送出しない。"""
        assert _violations(_load(tmp_path, text))


class TestConfigFileEncoding:
    """要件 8.5: TOML は UTF-8 を規定する。それ以外の符号化も違反として返す。

    本プロジェクトの設定ファイルには日本語の注釈が入る。Windows の日本語環境で
    編集器の既定（CP932）や「Unicode」（UTF-16）として保存すると復号自体が失敗するが、
    これは利用者が保存し直せる設定の不備であって資源の枯渇ではない。
    """

    # 日本語の注釈を含む、UTF-8 で保存されていれば成立する設定。
    JA_CONFIG = f"# 実行条件\n{MINIMAL_CONFIG}"

    @pytest.mark.parametrize("encoding", ["cp932", "utf-16", "shift_jis", "euc_jp"])
    def test_a_config_file_saved_in_a_non_utf_8_encoding_comes_back_as_a_violation(
        self, tmp_path: Path, encoding: str
    ) -> None:
        """UTF 8 以外で保存された設定ファイルは違反として返る。"""
        result = _load_bytes(tmp_path, self.JA_CONFIG.encode(encoding))

        assert _violations(result)

    def test_a_latin_1_comment_also_comes_back_as_a_violation(self, tmp_path: Path) -> None:
        """latin 1 の注釈も違反として返る。"""
        result = _load_bytes(tmp_path, f"# données\n{MINIMAL_CONFIG}".encode("latin-1"))

        assert _violations(result)

    def test_an_undecodable_config_file_still_does_not_raise(self, tmp_path: Path) -> None:
        """例外で返すと実行前の停止を導く経路が値と例外の 2 本に割れる。"""
        result = _load_bytes(tmp_path, b"\x82\xa0\x82\xa2\n")

        assert isinstance(result, tuple)
        assert _violations(result)

    def test_the_report_carries_the_location_and_the_advice_to_resave_as_utf_8(
        self, tmp_path: Path
    ) -> None:
        """どの対象が・何が原因かを利用者が直せる形で示す。"""
        violations = _violations(_load_bytes(tmp_path, self.JA_CONFIG.encode("cp932")))

        assert any("config.toml" in violation.location for violation in violations)
        assert any("UTF-8" in violation.message for violation in violations)

    def test_an_encoding_violation_also_comes_back_as_config_invalid(self, tmp_path: Path) -> None:
        """文字コードの違反も設定不備として返る。"""
        violations = _violations(_load_bytes(tmp_path, self.JA_CONFIG.encode("cp932")))

        assert all(violation.kind is ViolationKind.CONFIG_INVALID for violation in violations)

    def test_utf_8_with_a_bom_also_comes_back_as_a_violation(self, tmp_path: Path) -> None:
        """Windows の編集器が付ける BOM も、例外ではなく違反として返る。"""
        result = _load_bytes(tmp_path, self.JA_CONFIG.encode("utf-8-sig"))

        assert _violations(result)

    def test_utf_8_without_a_bom_still_reads(self, tmp_path: Path) -> None:
        """文字コードの検査が、正しく保存された設定ファイルを巻き込まないことを確かめる。"""
        config, _ = _ok(_load_bytes(tmp_path, self.JA_CONFIG.encode("utf-8")))

        assert config.inputs.paths == ("a.csv",)


class TestWherePrecedenceIsImplemented:
    """要件 9.4: 優先順位が実装される箇所を本モジュールのみに限定する。"""

    def test_only_one_function_reads_the_runtime_arguments(self) -> None:
        """設定の組み立て側が実行時引数を知らないことを、構文木で確かめる。"""
        tree = ast.parse((SRC / "config.py").read_text(encoding="utf-8"))
        readers = {
            node.name
            for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef)
            and any(
                isinstance(inner, ast.Name) and inner.id == "overrides" for inner in ast.walk(node)
            )
        }

        assert readers == {"load_config", "_apply_overrides"}, readers


def _imported_modules() -> set[str]:
    """実際に import している最上位モジュール名を AST から収集する。

    docstring が基盤ライブラリ名に言及するだけで誤検出しないよう、構文木で判定する。
    """
    tree = ast.parse((SRC / "config.py").read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
    return names


class TestDependencyExposure:
    """設計の Allowed Dependencies: 依存方向は左からのみ。"""

    def test_does_not_import_upper_layers(self) -> None:
        """上位層を import しない。"""
        forbidden = {
            "curvefit.preflight",
            "curvefit.pipeline",
            "curvefit.api",
            "curvefit.cli",
        }

        assert not (_imported_modules() & forbidden)

    def test_does_not_import_underlying_libraries(self) -> None:
        """設定の読み込みは標準ライブラリの tomllib で足りる。"""
        for imported in _imported_modules():
            root = imported.split(".")[0]
            assert root not in {"lmfit", "scipy", "matplotlib", "pandas", "asteval", "numpy"}, (
                f"config.py が {imported} を import している"
            )

    def test_uses_the_standard_library_to_read_the_config_file(self) -> None:
        """設定ファイルの読み込みに標準ライブラリを使う。"""
        assert "tomllib" in _imported_modules()

    def test_imports_types_from_existing_modules_instead_of_redefining_them(self) -> None:
        """型を再定義せず既存モジュールから取り込む。"""
        expected = {
            "curvefit.errors",
            "curvefit.execution",
            "curvefit.models.resolver",
            "curvefit.preprocess",
            "curvefit.readers",
        }

        assert expected <= _imported_modules()
