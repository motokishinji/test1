"""規模と応答性の性能テスト（要件 10.1、10.2、10.3）。

設計の Testing Strategy → Performance Tests が置く 3 項目に対応する。

- **500 ファイル × 10,000 行、グラフ出力あり、逐次実行で 5 分以内**（要件 10.1、10.2）
- **同バッチ実行中の常駐メモリが頭打ちになり、ジョブ数に比例して増加しないこと**
  （要件 10.4、加えて 10.2、10.3）。matplotlib の ``Figure`` 再利用と、``BatchReport`` が
  曲線データを手放すことの双方が機能していることの回帰検出を兼ねる
- **1 ファイル 100,000 行での単一フィットが実用時間内に完了すること**（要件 10.1 の上限側）

既定の実行から外してある理由
----------------------------

本モジュールは ``performance`` マーカを持ち、``pyproject.toml`` の
``addopts = "-m 'not performance'"`` によって既定の ``pytest`` から除外される。
マーカと除外の設定は本タスク以前から存在しており、本モジュールがその最初の利用者である。

除外を維持する判断の根拠は費用である。既定の一式は約 128 秒で 1,279 件を実行する。
本モジュールは 500 件のバッチを実測どおりに動かすため、入力の生成に約 13 秒、実行に
約 95 秒、単一フィットに約 1 秒を要し、一式を **倍近くに引き伸ばす**。加えて一時領域に
約 120 MB の入力と 500 枚の PNG を書く。要件 10 が問うのは「数百件を数分以内」という
運用上の性質であり、これは 1 コミットごとに確かめる種類の性質ではない。規模を縮めて
既定に入れる案は採らない。**件数を減らした規模テストは規模を検証しない** ためである
（後述の「空振りしない閾値」）。

閾値の出どころ
--------------

**実測値を丸めた値は使わない。** 時間の閾値 :data:`BATCH_TIME_LIMIT_SECONDS` は要件 10.2
の「数分以内」を設計の Performance & Scalability が測定可能な形にした 5 分そのものである。
余裕を閾値側に取り込んで締め上げることはしない。締め上げれば、要件が許容している速度の
実装で赤くなる。

**余裕は負荷条件に依存する。どの条件で測ったかを書かない余裕の主張は意味を持たない。**
同一機（Intel i7-8850H、6 物理 / 12 論理コア）での実測は次のとおり。

===================  ==========  ======
負荷条件             所要時間    余裕
===================  ==========  ======
環境負荷のみ（2.5）  92.1 秒     3.3 倍
6 本占有（負荷 9）   110.4 秒    2.7 倍
12 本占有（負荷 16） 166.7 秒    1.8 倍
===================  ==========  ======

**この所要時間には本モジュール自身の計測費用が含まれる。** :class:`MemorySampler` が
処理単位ごとに ``ps`` を起動するためで、実測 6.7 ミリ秒 × 500 件 = 約 3.4 秒にあたる。
計測を差し込まない同一規模の実行は 84.7 秒（3.5 倍）である。閾値に対しては安全側に働く
ため、この費用を計時から外す扱いはしない。

費用の内訳（100 件、環境負荷のみ）は **描画が 1 件あたり 173.1 ミリ秒中 150.2 ミリ秒
（87%）** を占める。行数を増やすと描画以外が線形に伸び、10,000／20,000／50,000 行で
22.9／40.8／87.1 ミリ秒。手法による差は小さい（直線 173.1、ガウシアン 187.6、
数式 169.9 ミリ秒）。

飽和時の 1 件あたり費用は **約 6.1 ミリ秒 / 1,000 行 + 249 ミリ秒** で近似でき、予算
600 ミリ秒（500 件で 5 分）に達するのは **約 58,000 行**。要件 10.1 が想定する
「数千〜数万行」の上端では、全コアが埋まっていると余裕がほぼ無い。

一方 :data:`GROWTH_LIMIT_KIB_PER_JOB` は要件が数値を与えていないため実測から定めた。
根拠と倍率は定数の説明に書く。

常駐メモリについて
------------------

**観測された増加そのものを閾値にする**（要件 10.4）。「常駐メモリの使用量が処理件数に
比例して増加しない」ことが要件の文言であり、1 件あたりの増加量を上限で押さえる形が
その直接の表現である。差し引く量を持たない立て方であるがゆえに、増加の由来が何であれ
（描画・結果の保持・その他）件数に比例する増加は等しく捕まる。

**以前は差し引きの形で立てていた。** ``BatchReport.outcomes`` が全処理単位の
``FitSuccess.curve``（:class:`~curvefit.types.CurveData`、``x`` / ``y_observed`` /
``y_fit`` / ``residual`` の 4 配列を全点数分）を抱えており、1 件あたり ``4 × 8 × 点数``
バイトが実行終了まで解放されなかったためである。10,000 行なら 312.5 KiB/件、500 件で
約 153 MiB。実測でもグラフ出力を切った 120 件 × 20,000 行で常駐メモリが 86 MB 増え、うち
75 MB が保持中の ``CurveData`` で説明できた（625 KiB/件 = ``4 × 8 × 20000``）。この保持は
タスク 8.6 で解消した（要件 10.4、``pipeline.run`` が出力の適用後に手放す）。差し引く量が
0 になった以上、差し引きの形を残す理由は無い。

この立て方は空振りしない。両方向の退行が閾値 :data:`GROWTH_LIMIT_KIB_PER_JOB` を超える。

- ``plotting`` が対象ごとに ``pyplot`` で図を作る形に戻すと **実測 3,046 KiB/件**
- 曲線データの解放をやめると（``retain_curve=True`` 相当）
  :data:`RELEASED_CURVE_KIB_PER_JOB` = 312.5 KiB/件 が上乗せされる。実測でも 20,000 行の
  バッチで 60 件 826.1 KiB/件・240 件 691.1 KiB/件（保持分 625.0 KiB/件）だったものが、
  解放後は 2.8／2.5 KiB/件 に落ちた。**件数を変えても増加率が変わらないことが頭打ちの
  中身である**

現在の実装（グラフ出力あり・10,000 行、500 件）の実測は **4.2／4.8／−63.1 KiB/件**（3 回、
最小二乗の傾き）である。負値は実行の途中で割り付け器が領域を返したことによる。同じ実行から
解放をやめた場合の実測は **334.8 KiB/件** であり、閾値 100 を 3.3 倍超えて赤くなる（この
値は実際に解放を外して確かめた）。閾値が退行の大きさより下にあることは
:meth:`Test常駐メモリの推移.test_閾値は曲線データの保持が起きれば必ず超える大きさである`
が固定する。

**捕まえられるのは「保持」であって「churn」ではない。** ``pyplot`` を使わずに対象ごとに
``Figure`` を作るだけの形（図は参照が残らず回収される）は実測 29.3 KiB/件 にとどまり、
本検査では捕まらない。これは閾値の緩さではなく、その形が実際にはメモリを保持しないため
である。閾値を下げても捕まえられるようにはならず、偽陽性が増えるだけなので下げない。
危険なのは大域の登録簿に参照が残る形であり、そちらは 2 桁の差で捕まる。

空振りしない閾値であること
--------------------------

性能テストの失敗様式は「100 倍遅くしても通る閾値」と「数百件を謳いながら数件しか流さない
規模」の 2 つである。本モジュールは前者を要件の数値をそのまま使うことで、後者を件数を
設計の数値どおり 500 に取ることで避ける。実装を意図的に劣化させて赤くなることを確認して
ある（実測）。

- ``plotting`` を ``pyplot`` 経由の毎回生成に戻す → 増加が 3,046 KiB/件、常駐メモリの
  検査が落ちる（所要時間は 118 秒で **通ってしまう**）
- ``pipeline.run`` の曲線データの解放をやめる → 増加に 312.5 KiB/件 が上乗せされ、
  常駐メモリの検査が落ちる（所要時間には現れない）
- ``FIGURE_DPI`` を 100 → 500 に上げる → 633 ミリ秒/件、316.7 秒で時間の検査が落ちる
- ``plotting`` の並べ替えを二乗の素朴な実装にする → 100,000 行 1 件が 9.7 秒、上限側の
  検査が落ちる（500 件バッチ側には現れない。1 件あたり 0.03 秒でしかないため）
- ``render_fit_plot`` を丸ごと省く → 実行は 18.6 秒に **縮み**、時間の検査は余裕 16 倍で
  通る。これを捕らえるのが :meth:`Test数百件規模の逐次実行.test_全件分のグラフが生成される`
  であり、所要時間だけを見るテストが最も陥りやすい穴である

時間の閾値に対する感度について
------------------------------

実測 93 秒に対して上限は 300 秒であり、**3.2 倍未満の劣化はこの検査では捕まらない**。
これは閾値の設定ミスではなく、要件 10.2 が現在の実装に対して緩いということである。速度の
追跡が要るなら、それは要件 10.2 とは別の目標として立てるべきものであり、要件の数値を実測
に寄せて締め上げる形にはしない。要件が許容している速度の実装で赤くなるテストは、要件では
なく実測を守ることになる。

なお ``execution._version_cache`` の記憶は本モジュールの検査対象ではない。
``collect_library_versions`` は ``build_record`` から **実行あたり 1 回** 呼ばれるため、
記憶を外しても 500 件バッチに現れるのは約 21 ミリ秒（全体の 0.02%）にすぎない。この記憶が
効くのは系列ごとに呼ぶ対話的な利用（要件 9.1、``fit_series`` が 34 → 5.83 ミリ秒）であり、
守るべき試験は ``tests/unit/test_execution.py`` の側にある。

要件 10.3 について
------------------

資源枯渇そのものの取り回し（中断した対象を明示し、それまでの結果とサマリを保持する）は
``tests/integration/test_pipeline_batch.py`` が :exc:`MemoryError` と :exc:`OSError` の
両方で既に検証している。本モジュールが 10.3 に対して担うのは、設計の Performance Tests が
10.3 を割り当てているとおり **その経路に到達しないこと** の側である。``research.md`` は
matplotlib のループ描画によるメモリ増加を「理論上の懸念ではなく、この経路で現実に起こり
うる」と記録しており、常駐メモリの検査はその回帰検出にあたる。
"""

from __future__ import annotations

import dataclasses
import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pytest

from curvefit.api import run_from_config
from curvefit.pipeline import BatchReport
from curvefit.types import CurveData, FitOutcome, FitSuccess

pytestmark = pytest.mark.performance
"""本モジュールは既定の実行から除外される（``pyproject.toml`` の ``addopts``）。"""


# --- 規模と閾値 ----------------------------------------------------------------------

N_FILES = 500
"""入力ファイル数。要件 10.1 の「数百件」を設計が 500 と定めたもの。

**減らさない。** 数件で流すテストは所要時間が件数に比例することを確かめられず、
1 件あたりの固定費に埋もれる。規模テストが規模を検証しなくなる。
"""

N_ROWS = 10_000
"""1 ファイルあたりの行数。要件 10.1 の「数千〜数万行」を設計が 10,000 と定めたもの。"""

BATCH_TIME_LIMIT_SECONDS = 300.0
"""バッチの所要時間の上限（要件 10.2）。

設計の Performance & Scalability が要件 10.2 の「数分以内」を測定可能にした 5 分そのもの
であり、**実測を丸めた値ではない**。実測約 95 秒に対して約 3.2 倍の余裕がある。
"""

SINGLE_FIT_TIME_LIMIT_SECONDS = 5.0
"""100,000 行 1 件の当てはめの上限（要件 10.1 の上限側）。

要件は「実用時間内」としか言わないため実測から定めた。実測は読み込み・当てはめ・描画・
出力を含めて約 0.41〜0.57 秒であり、閾値まで約 9 倍の余裕がある。

**当初 30 秒に置いたが、それでは空振りすることを実測で確かめて 5 秒に下げた。** この検査
の目的は速さの追跡ではなく、点数に対して破綻的な計算量を持ち込まないことの検出である。
``plotting`` の並べ替えを素朴な順位計算（点ごとに全点と比較する二乗の実装）に置き換えると
当てはめは約 12.9 秒になるが、これは 30 秒を下回るため通ってしまっていた。この種の劣化は
**10,000 行では 1 件あたり 0.03 秒にしかならず本モジュールの 500 件バッチにも現れない**
ため、ここで捕まえなければどこでも捕まらない。9 倍は、計算機の速度差を吸収しつつ二乗の
劣化を捕らえられる位置である。
"""

SINGLE_FIT_ROWS = 100_000
"""単一当てはめの行数（要件 10.1 の上限側の確認）。"""

GROWTH_LIMIT_KIB_PER_JOB = 100.0
"""1 件あたりの常駐メモリ増加の上限（KiB/件、要件 10.4）。

要件が数値を与えないため実測から定めた。**現在の実装は 4.2／4.8／−63.1 KiB/件**（同一機、
他条件同一の 3 回、最小二乗の傾き）。差し引きの形で 2 点差から測っていた頃の
13.4／20.8／21.6／24.7 KiB/件 を最悪値と見ても、閾値まで 4 倍の余裕がある。

上側は 2 種類の退行のいずれもこの値を超える。``pyplot`` 経由の毎回生成に戻すと
3,046 KiB/件 で 30 倍、曲線データの解放をやめると **実測 334.8 KiB/件** で 3.3 倍
（:data:`RELEASED_CURVE_KIB_PER_JOB` の 312.5 KiB/件 が上乗せされる）。
**両側に 3 倍以上の距離がある** ことがこの値を選んだ理由である。

余裕を 4 倍に留めるのは、上側の退行のうち小さいほう（曲線データの保持）が
``4 × 8 × 点数`` という点数依存の量であり、閾値を上げるほど捕らえられなくなるためである。
下側の振れ幅（割り付け器の断片化・フォントキャッシュ・NumPy の内部確保）は実測で
11 KiB/件 程度であり、4 倍はそれを吸収する。
"""

WARMUP_FRACTION = 0.25
"""増加率を測る際に読み飛ばす前半の割合。

最初の数十件では matplotlib のフォント一覧の構築と各ライブラリの遅延 import が乗る。
これらは件数に比例しない一度きりの費用であり、含めると増加率を過大に見積もる。
"""

CURVE_ARRAYS_PER_JOB = 4
"""``CurveData`` が持つ配列の数（``x`` / ``y_observed`` / ``y_fit`` / ``residual``）。"""

RELEASED_CURVE_KIB_PER_JOB = CURVE_ARRAYS_PER_JOB * 8 * N_ROWS / 1024
"""解放をやめた場合に 1 件あたり積み上がる量（KiB/件）。

要件 10.4 が避けようとしている増加の大きさそのものである。``float64`` が 8 バイトである
ことと :data:`N_ROWS` から導く。閾値がこの値を下回っていることを
:meth:`Test常駐メモリの推移.test_閾値は曲線データの保持が起きれば必ず超える大きさである`
で固定し、**解放をやめた実装で検査が必ず赤くなる** ことを保証する。
"""

CONFIG_TEMPLATE = """\
[input]
paths = [{data_dir}]
header = true

[input.columns]
x = "x"
y = "y"

[[methods]]
name = "line"
builtin = "linear"

[output]
directory = {output_dir}
write_plot = true
"""
"""要件 10.1 の実行条件。

**グラフ出力を有効にする**（``write_plot = true``、要件 7.4 の既定でもある）。支配的な
費用は描画であり、切って測ると要件 10.2 に対する答えにならない（設計の
Performance & Scalability）。手法は組込の直線 1 つに絞る。手法を増やすと処理単位が
ファイル数の倍数になり、「500 ファイル」と「所要時間」の対応が読めなくなる。
"""


# --- 常駐メモリの観測 ----------------------------------------------------------------


def resident_kib() -> int:
    """呼び出し元プロセスの常駐メモリを KiB で返す。

    ``resource.getrusage`` は最大値しか返さず、頭打ちかどうかを見るには使えない。
    ``ps`` は macOS と Linux のいずれでも RSS を KiB で報告する。
    """
    completed = subprocess.run(
        ["ps", "-o", "rss=", "-p", str(os.getpid())],
        capture_output=True,
        text=True,
        check=True,
    )
    return int(completed.stdout.strip())


def resident_kib_available() -> bool:
    """常駐メモリを観測できるかどうか。観測手段が無い環境では検査を飛ばす。

    **判定は観測を始める前に行う**（:func:`make_sampler`）。検査の内側で呼んでも遅い。
    ``ps`` の無い環境では :meth:`MemorySampler.on_job_done` が
    :exc:`FileNotFoundError` を送出し、``pipeline.run`` は進捗通知を
    :exc:`MemoryError` / :exc:`OSError` の捕捉範囲の **外** で呼ぶため、例外は
    ``run_from_config`` を貫いて fixture を error にする。skip 判定はそこまで到達しない。
    """
    try:
        resident_kib()
    except (OSError, ValueError, subprocess.SubprocessError):
        return False
    return True


@dataclass
class MemorySampler:
    """処理単位の完了ごとに常駐メモリを記録する進捗通知先（要件 6.3 の ``observer``）。

    実行の外側で前後 2 点だけ測る方法は採らない。頭打ちかどうかは推移の形の問題であり、
    2 点では増加が線形なのか初期の一度きりなのかを区別できない。

    **観測できない環境では何もしない**（``enabled`` が偽）。観測の可否は実行を始める前に
    確定させる（:func:`make_sampler`）。通知の途中で例外を送出すると、それはバッチ実行の
    失敗として呼び出し元まで届き、検査を飛ばす判断に到達できない。
    """

    samples: list[int]
    enabled: bool

    def on_start(self, total_jobs: int, total_sources: int) -> None:
        del total_jobs, total_sources

    def on_job_done(self, done: int, total: int, outcome: FitOutcome) -> None:
        del done, total, outcome
        if self.enabled:
            self.samples.append(resident_kib())

    def on_finish(self, report: BatchReport) -> None:
        del report


def make_sampler() -> MemorySampler:
    """観測の可否を先に確かめてから、進捗通知先を作る。

    観測できない環境では記録しない通知先を返す。標本が 0 件であることが、後段の検査に
    「この環境では測れなかった」を伝える唯一の経路である。
    """
    return MemorySampler(samples=[], enabled=resident_kib_available())


def growth_kib_per_job(samples: list[int]) -> float:
    """立ち上がりを除いた区間の、1 件あたりの常駐メモリ増加量を返す。

    **収集した全標本に対する最小二乗の傾きで求める。** 区間の両端 2 点の差で求めると、
    2 点では増加が線形なのか初期の一度きりなのかを区別できないという
    :class:`MemorySampler` 自身の論拠と食い違う。常駐メモリは割り付け器の都合で階段状に
    動くため、端点がたまたま段の上か下かで値が振れる。約 500 点を使えばその振れは平均され、
    傾きは推移全体の形を表す。
    """
    start = int(len(samples) * WARMUP_FRACTION)
    used = np.asarray(samples[start:], dtype=float)
    assert len(used) > 1, f"増加率を測るには標本が足りない: {len(samples)} 件"
    jobs = np.arange(len(used), dtype=float)
    centered = jobs - jobs.mean()
    return float((centered * (used - used.mean())).sum() / (centered * centered).sum())


def retained_curve_kib(outcomes: tuple[FitOutcome, ...]) -> float:
    """結果が保持している曲線データの総量を KiB で返す。

    要件 10.4 により、バッチの結果ではこれが 0 になる（``pipeline.run`` が出力の適用後に
    ``FitSuccess.curve`` を手放す）。0 でない量が現れたら、それは件数に比例して積み上がる
    増加が戻ったということである。
    """
    total = 0
    for outcome in outcomes:
        if isinstance(outcome, FitSuccess) and outcome.curve is not None:
            curve = outcome.curve
            total += (
                curve.x.nbytes
                + curve.y_observed.nbytes
                + curve.y_fit.nbytes
                + curve.residual.nbytes
            )
    return total / 1024


# --- 入力の用意 ----------------------------------------------------------------------


def write_series(path: Path, *, slope: float, rows: int, rng: np.random.Generator) -> Path:
    """既知の直線に雑音を載せた測定データを書き出す。

    ファイルごとに傾きと雑音を変える。全ファイルを同一内容にすると、読み込み側や
    当てはめ側に内容依存の記憶が入り込んだときに費用が消えて見える。
    """
    x = np.linspace(0.0, 100.0, rows)
    y = slope * x + 1.5 + rng.normal(0.0, 0.5, rows)
    np.savetxt(
        path,
        np.column_stack([x, y]),
        delimiter=",",
        header="x,y",
        comments="",
        fmt="%.10g",
    )
    return path


def write_config(base: Path, data_dir: Path, output_dir: Path) -> Path:
    config = base / "run.toml"
    config.write_text(
        CONFIG_TEMPLATE.format(
            data_dir=f'"{data_dir}"', output_dir=f'"{output_dir}"'
        ),
        encoding="utf-8",
    )
    return config


# --- 500 件のバッチ ------------------------------------------------------------------


@dataclass(frozen=True)
class BatchMeasurement:
    """1 回のバッチ実行と、その間に観測した値。"""

    report: BatchReport
    elapsed_seconds: float
    generate_seconds: float
    samples: tuple[int, ...]
    output_dir: Path


TREND_SAMPLE_COUNT = 10
"""推移として書き出す標本の数。"""


def report_measurements(measurement: BatchMeasurement) -> None:
    """実測値と常駐メモリの推移を書き出す（タスク 8.4 の「推移が記録される」）。

    合否だけでは要件 10 に対する余裕が分からない。閾値を下回ったことではなく **どれだけ
    下回ったか** が、グラフ出力の既定値を要件側に差し戻すかどうかの判断材料になる
    （設計の pipeline Risks）。``pytest -s`` で読め、失敗時は捕捉された出力として出る。
    """
    samples = list(measurement.samples)
    retained_per_job = retained_curve_kib(measurement.report.outcomes) / N_FILES

    lines = [
        "",
        f"=== 規模と応答性の実測（{N_FILES} ファイル × {N_ROWS} 行、グラフ出力あり）===",
        f"入力生成      : {measurement.generate_seconds:8.1f} 秒",
        f"逐次実行      : {measurement.elapsed_seconds:8.1f} 秒 "
        f"(上限 {BATCH_TIME_LIMIT_SECONDS:.0f} 秒、"
        f"余裕 {BATCH_TIME_LIMIT_SECONDS / measurement.elapsed_seconds:.1f} 倍)",
        f"1 件あたり    : {measurement.elapsed_seconds / N_FILES * 1000:8.1f} ミリ秒",
    ]
    if not samples:
        lines += ["常駐メモリ    : 観測手段が無いため測っていない", ""]
        print("\n".join(lines))
        return

    observed = growth_kib_per_job(samples)
    lines.append("--- 常駐メモリの推移 (件数, KiB) ---")
    step = max(1, len(samples) // TREND_SAMPLE_COUNT)
    for index in range(0, len(samples), step):
        lines.append(f"  {index + 1:5d} {samples[index]:10d}")
    lines.append(f"  {len(samples):5d} {samples[-1]:10d}")
    lines += [
        f"増加 (立ち上がり後の最小二乗): {observed:8.1f} KiB/件"
        f" (上限 {GROWTH_LIMIT_KIB_PER_JOB:.0f})",
        f"  結果が保持する曲線データ  : {retained_per_job:8.1f} KiB/件"
        f"  ← 解放しなければ {RELEASED_CURVE_KIB_PER_JOB:.1f} KiB/件",
        "",
    ]
    print("\n".join(lines))


@pytest.fixture(scope="module")
def batch(tmp_path_factory: pytest.TempPathFactory) -> BatchMeasurement:
    """500 ファイル × 10,000 行を、グラフ出力ありで 1 回だけ実行する。

    **1 回の実行を複数の観点で見る。** 所要時間と常駐メモリの推移は同じ実行から取る必要が
    ある。別々に走らせると、時間を満たす実行とメモリを満たす実行が別物になり、
    「グラフ出力を有効にしたまま数分以内かつ頭打ち」という主張が成立しない。
    """
    base = tmp_path_factory.mktemp("scale")
    data_dir = base / "data"
    data_dir.mkdir()

    rng = np.random.default_rng(0)
    started = time.perf_counter()
    for index in range(N_FILES):
        write_series(
            data_dir / f"series{index:04d}.csv",
            slope=1.0 + index * 0.01,
            rows=N_ROWS,
            rng=rng,
        )
    generate_seconds = time.perf_counter() - started

    output_dir = base / "out"
    config = write_config(base, data_dir, output_dir)

    # 観測の可否は実行を始める前に確定させる（:func:`resident_kib_available`）。
    sampler = make_sampler()
    started = time.perf_counter()
    report = run_from_config(config, observer=sampler)
    elapsed = time.perf_counter() - started

    assert isinstance(report, BatchReport), f"実行前検証で停止した: {report}"
    measurement = BatchMeasurement(
        report=report,
        elapsed_seconds=elapsed,
        generate_seconds=generate_seconds,
        samples=tuple(sampler.samples),
        output_dir=output_dir,
    )
    report_measurements(measurement)
    return measurement


class TestSequentialRunAtHundredsOfFiles:
    """要件 10.1、10.2: 500 ファイル × 10,000 行をグラフ出力ありで処理し切ること。"""

    def test_all_jobs_processed_without_abort(self, batch: BatchMeasurement) -> None:
        """要件 10.1: 1 回の実行で数百件を処理し切る。

        時間だけを見ると、失敗して早く終わった実行が速い実行として通る。件数と成否を
        先に固定する。
        """
        report = batch.report
        assert report.n_success == N_FILES, [
            outcome for outcome in report.outcomes if not isinstance(outcome, FitSuccess)
        ][:3]
        assert report.n_failure == 0
        assert report.aborted is False
        assert len(report.outcomes) == N_FILES

    def test_plot_written_for_every_job(self, batch: BatchMeasurement) -> None:
        """要件 7.4、10.2: 支配的な費用である描画が実際に 500 回行われたこと。

        描画が黙って飛ばされていれば所要時間は当然縮む。要件 10.2 は「グラフ出力を
        有効にした状態」の話であり、枚数を確かめなければ測ったものが変わる。
        """
        plots = sorted((batch.output_dir / "plots").glob("*.png"))
        assert len(plots) == N_FILES
        assert all(plot.stat().st_size > 0 for plot in plots)

    def test_every_series_processes_all_points(self, batch: BatchMeasurement) -> None:
        """要件 10.1: 「1 ファイルあたり数千〜数万行」が実際に流れていること。

        行が落ちていれば費用も落ちる。点数を確かめずに時間だけを見ると、読み込みが
        先頭だけを読む実装に退行しても通る。
        """
        successes = [o for o in batch.report.outcomes if isinstance(o, FitSuccess)]
        assert {o.goodness.n_points for o in successes} == {N_ROWS}

    def test_completes_within_time_limit(self, batch: BatchMeasurement) -> None:
        """要件 10.2: 一般的な作業用 PC 上で数分以内に完了する。

        閾値は要件 10.2 を設計が測定可能にした 5 分であり、実測を丸めた値ではない。
        """
        assert batch.elapsed_seconds < BATCH_TIME_LIMIT_SECONDS, (
            f"500 ファイル × 10,000 行の逐次実行が {batch.elapsed_seconds:.1f} 秒かかった"
            f"（上限 {BATCH_TIME_LIMIT_SECONDS:.0f} 秒）。"
            "設計の Risks に従い、並列化ではなくグラフ出力の既定値を含めて要件側に差し戻す"
        )


class TestResidentMemoryTrend:
    """要件 10.4: 常駐メモリが処理件数に比例して増加しないこと。

    要件 10.2、10.3 に対しては、描画資源の再利用が効いていることの回帰検出を兼ねる。
    """

    def test_results_do_not_retain_curve_data(self, batch: BatchMeasurement) -> None:
        """要件 10.4: ``BatchReport.outcomes`` が曲線データを抱えていないこと。

        常駐メモリの検査は環境（``ps`` の有無・割り付け器の癖）に左右されるが、こちらは
        返り値だけで決まる。要件 10.4 が求める性質のうち **実装が直接約束している部分** を、
        観測の粗さを介さずに固定する。

        点数は :class:`~curvefit.types.GoodnessOfFit` に残る。曲線を落としたことが
        「何も処理していない」と区別できることまで見る。
        """
        successes = [o for o in batch.report.outcomes if isinstance(o, FitSuccess)]
        assert len(successes) == N_FILES
        assert all(outcome.curve is None for outcome in successes)
        assert retained_curve_kib(batch.report.outcomes) == 0.0
        assert {o.goodness.n_points for o in successes} == {N_ROWS}

    def test_threshold_exceeded_if_curve_data_retained(self) -> None:
        """閾値が退行の大きさより下にあることを、実行せずに固定する。

        この関係が崩れると、上の検査は通ったまま
        :meth:`test_常駐メモリの増加が件数に比例しない` だけが緩み、**解放をやめた実装が
        性能テスト全体を素通りする**。閾値を引き上げたくなったときに、その代償がここで
        見える形になっていることが要点である。
        """
        # CurveData の配列本数を実物に結び付ける。ここを定義式で書き直すと恒真になり、
        # 列が増えたとき退行の見積もりだけが小さいまま取り残される。
        assert len(dataclasses.fields(CurveData)) == CURVE_ARRAYS_PER_JOB
        assert GROWTH_LIMIT_KIB_PER_JOB * 3 < RELEASED_CURVE_KIB_PER_JOB, (
            f"閾値 {GROWTH_LIMIT_KIB_PER_JOB:.0f} KiB/件 が、曲線データの保持による増加"
            f" {RELEASED_CURVE_KIB_PER_JOB:.1f} KiB/件 に対して十分低くない。"
            "この位置関係が、要件 10.4 の退行で検査が赤くなることの根拠である"
        )

    def test_resident_memory_growth_not_proportional_to_job_count(
        self, batch: BatchMeasurement
    ) -> None:
        """要件 10.4: 1 件あたりの常駐メモリ増加が上限を下回ること。

        観測された増加をそのまま閾値と比べる。差し引く量を持たないため、増加の由来が
        結果の保持でも描画資源でも等しく捕まる。

        - 曲線データの解放をやめれば :data:`RELEASED_CURVE_KIB_PER_JOB` が上乗せされる
        - ``plotting`` を ``pyplot`` 経由の毎回生成に戻せば 3,046 KiB/件 になる

        いずれも閾値を超える（モジュール docstring の実測）。
        """
        if not batch.samples:
            pytest.skip("常駐メモリを観測できない環境")

        observed = growth_kib_per_job(list(batch.samples))
        retained_per_job = retained_curve_kib(batch.report.outcomes) / N_FILES

        assert observed < GROWTH_LIMIT_KIB_PER_JOB, (
            f"常駐メモリが 1 件あたり {observed:.1f} KiB 増えている"
            f"（上限 {GROWTH_LIMIT_KIB_PER_JOB:.0f}、"
            f"結果が保持する曲線データ {retained_per_job:.1f} KiB/件）。"
            "結果の保持（pipeline.run の retain_curve）と"
            "描画資源の再利用（plotting._shared_canvas）の 2 点を見る"
        )


# --- 上限側の単一当てはめ ------------------------------------------------------------


class TestSingleFitOfHundredThousandRows:
    """要件 10.1 の上限側: 1 ファイルが十万行規模でも実用時間内に完了すること。"""

    def test_completes_within_practical_time(self, tmp_path: Path) -> None:
        """点数に対して破綻的な計算量を持ち込んでいないことを見る。

        グラフ出力を有効にしたまま測る。描画は点数に比例して重くなる側であり、切ると
        上限側の確認にならない。
        """
        data_dir = tmp_path / "data"
        data_dir.mkdir()
        write_series(
            data_dir / "large.csv",
            slope=2.5,
            rows=SINGLE_FIT_ROWS,
            rng=np.random.default_rng(1),
        )
        output_dir = tmp_path / "out"
        config = write_config(tmp_path, data_dir, output_dir)

        started = time.perf_counter()
        report = run_from_config(config)
        elapsed = time.perf_counter() - started

        assert isinstance(report, BatchReport), f"実行前検証で停止した: {report}"
        assert report.n_success == 1, report.outcomes
        successes = [o for o in report.outcomes if isinstance(o, FitSuccess)]
        assert successes[0].goodness.n_points == SINGLE_FIT_ROWS
        assert elapsed < SINGLE_FIT_TIME_LIMIT_SECONDS, (
            f"100,000 行 1 件の当てはめが {elapsed:.1f} 秒かかった"
            f"（上限 {SINGLE_FIT_TIME_LIMIT_SECONDS:.0f} 秒）"
        )
